/// <mls fileReference="_102047_/l1/reembolsoDespesas/layer_2_application/requests/despesas_da_equipe.ts" enhancement="_blank"/>

import type { Despesas_da_equipeContracts, DespesaAnalise, DespesaPendenteResumo } from '/_102047_/l2/reembolsoDespesas/web/contracts/despesas_da_equipe.defs.js';
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { getDespesa } from '/_102047_/l1/reembolsoDespesas/layer_2_application/usecases/getDespesa.js';
import { listDespesa } from '/_102047_/l1/reembolsoDespesas/layer_2_application/usecases/listDespesa.js';
import { aprovarDespesa } from '/_102047_/l1/reembolsoDespesas/layer_2_application/usecases/aprovarDespesa.js';
import { rejeitarDespesa } from '/_102047_/l1/reembolsoDespesas/layer_2_application/usecases/rejeitarDespesa.js';
import { getColaborador } from '/_102047_/l1/reembolsoDespesas/layer_2_application/usecases/getColaborador.js';

type DespesaStatus = 'draft' | 'awaitingApproval' | 'rejected' | 'approved' | 'paid';

interface DespesaRecord {
  id: string;
  version: number;
  colaboradorId: string;
  status: string;
  details: {
    dataDespesa: string;
    categoria: string;
    valor: string;
    descricao: string;
    motivoRejeicao?: string;
    reenvioRealizado: boolean;
  };
}

const STATUS_VALUES: DespesaStatus[] = ['draft', 'awaitingApproval', 'rejected', 'approved', 'paid'];

function toStatus(value: string): DespesaStatus {
  const found = STATUS_VALUES.find((s) => s === value);
  if (found === undefined) {
    throw new AppError('INVALID_STATUS', `unknown expense status: ${value}`, 500);
  }
  return found;
}

function containsId(value: unknown, id: string): boolean {
  if (typeof value === 'string') return value === id;
  if (Array.isArray(value)) return value.some((v) => containsId(v, id));
  if (value !== null && typeof value === 'object') {
    return Object.values(value as Record<string, unknown>).some((v) => containsId(v, id));
  }
  return false;
}

function currentManagerId(ctx: RequestContext): string {
  const managerId = ctx.sessionContext.person?.mdmId;
  if (managerId == null || managerId === '') {
    throw new AppError('FORBIDDEN', 'manager identity not resolved for this session', 403, { ruleId: 'managerTeamExpenseAccess' });
  }
  return managerId;
}

/** Returns the collaborator name when the collaborator reports to the manager (ReportsTo); null otherwise.
 * The MDM keeps a ReportsTo link as compact refs: `reportManagers` on the collaborator (`reports` on the manager). */
async function teamMemberName(colaboradorId: string, managerId: string, ctx: RequestContext): Promise<string | null> {
  const colaborador = await getColaborador({ id: colaboradorId }, ctx);
  const refs = colaborador.details.base.relationshipRefs;
  if (!containsId(refs['reportManagers'], managerId)) return null;
  return colaborador.details.identification.name;
}

async function requireTeamMemberName(colaboradorId: string, managerId: string, ctx: RequestContext): Promise<string> {
  const name = await teamMemberName(colaboradorId, managerId, ctx);
  if (name === null) {
    throw new AppError('FORBIDDEN', 'the expense does not belong to a collaborator of your team', 403, { ruleId: 'managerTeamExpenseAccess' });
  }
  return name;
}

function nomeColaborador(name: string): DespesaAnalise['colaborador'] {
  return { details: { identification: { details: { identification: { name } } } } };
}

function buildAnalise(despesa: DespesaRecord, name: string): DespesaAnalise {
  const details: DespesaAnalise['details']['details'] = {
    dataDespesa: despesa.details.dataDespesa,
    categoria: despesa.details.categoria,
    valor: despesa.details.valor,
    descricao: despesa.details.descricao,
    reenvioRealizado: despesa.details.reenvioRealizado,
  };
  if (despesa.details.motivoRejeicao != null) {
    details.motivoRejeicao = despesa.details.motivoRejeicao;
  }
  return {
    id: despesa.id,
    version: despesa.version,
    colaboradorId: despesa.colaboradorId,
    status: toStatus(despesa.status),
    details: { details },
    colaborador: nomeColaborador(name),
  };
}

function requireAwaitingApproval(despesa: DespesaRecord): void {
  if (despesa.status !== 'awaitingApproval') {
    throw new AppError('INVALID_STATE', 'the expense is not awaiting approval', 409);
  }
}

export const requests: { [K in keyof Despesas_da_equipeContracts]: (input: Despesas_da_equipeContracts[K]['input'], ctx: RequestContext) => Promise<Despesas_da_equipeContracts[K]['output']> } = {
  "reembolsoDespesas.despesas_da_equipe.listarDespesasPendentesEquipe": async function (input, ctx) {
    const managerId = currentManagerId(ctx);
    const page = input.page >= 1 ? Math.floor(input.page) : 1;
    const pageSize = input.pageSize >= 1 ? Math.min(Math.floor(input.pageSize), 200) : 20;

    // Read every expense awaiting approval, then keep the ones of the manager's team.
    const pending: DespesaRecord[] = [];
    let cursor = 1;
    let more = true;
    while (more) {
      const res = await listDespesa({ status: 'awaitingApproval', page: cursor, pageSize: 200 }, ctx);
      for (const d of res.items) pending.push(d);
      more = res.hasMore;
      cursor += 1;
    }

    const names = new Map<string, string | null>();
    const team: { despesa: DespesaRecord; name: string }[] = [];
    for (const despesa of pending) {
      if (!names.has(despesa.colaboradorId)) {
        names.set(despesa.colaboradorId, await teamMemberName(despesa.colaboradorId, managerId, ctx));
      }
      const name = names.get(despesa.colaboradorId);
      // managerTeamExpenseAccess: only expenses of collaborators that report to the manager
      if (name != null) team.push({ despesa, name });
    }

    team.sort((a, b) => a.despesa.details.dataDespesa.localeCompare(b.despesa.details.dataDespesa));

    const start = (page - 1) * pageSize;
    const slice = team.slice(start, start + pageSize);
    const items: DespesaPendenteResumo[] = slice.map(({ despesa, name }) => ({
      id: despesa.id,
      colaboradorId: despesa.colaboradorId,
      status: toStatus(despesa.status),
      details: {
        details: {
          dataDespesa: despesa.details.dataDespesa,
          categoria: despesa.details.categoria,
          valor: despesa.details.valor,
        },
      },
      colaborador: nomeColaborador(name),
    }));

    return { despesas: { items, page, pageSize, hasMore: start + pageSize < team.length } };
  },

  "reembolsoDespesas.despesas_da_equipe.obterDespesaParaAnalise": async function (input, ctx) {
    const managerId = currentManagerId(ctx);
    const despesa = await getDespesa({ id: input.despesaId }, ctx);
    // managerTeamExpenseAccess
    const name = await requireTeamMemberName(despesa.colaboradorId, managerId, ctx);
    return { despesa: buildAnalise(despesa, name) };
  },

  "reembolsoDespesas.despesas_da_equipe.aprovarDespesa": async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const managerId = currentManagerId(bound);
      const atual = await getDespesa({ id: input.id }, bound);
      // managerTeamExpenseAccess
      const name = await requireTeamMemberName(atual.colaboradorId, managerId, bound);
      requireAwaitingApproval(atual);
      const updated = await aprovarDespesa({ id: input.id, version: Number(input.version) }, bound);
      return { despesa: buildAnalise(updated, name) };
    });
  },

  "reembolsoDespesas.despesas_da_equipe.rejeitarDespesa": async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const managerId = currentManagerId(bound);
      const atual = await getDespesa({ id: input.id }, bound);
      // managerTeamExpenseAccess
      const name = await requireTeamMemberName(atual.colaboradorId, managerId, bound);
      requireAwaitingApproval(atual);
      const motivo = typeof input.details.motivoRejeicao === 'string' ? input.details.motivoRejeicao.trim() : '';
      if (motivo === '') {
        throw new AppError('VALIDATION_ERROR', 'a rejection reason is required to reject an expense', 400, { ruleId: 'rejectionReasonRequired' });
      }
      const updated = await rejeitarDespesa({ id: input.id, version: Number(input.version), details: { motivoRejeicao: motivo } }, bound);
      return { despesa: buildAnalise(updated, name) };
    });
  },
};

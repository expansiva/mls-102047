/// <mls fileReference="_102047_/l1/inicio/layer_3_domain/entities/empresa.defs.ts" enhancement="_blank"/>

export const definition = {
  "schemaVersion": "2026-09-24-d1-definition-v2",
  "artifactType": "domainEntity",
  "artifactId": "Empresa",
  "moduleName": "inicio",
  "status": "pending",
  "dependencies": [],
  "data": {
    "entityId": "Empresa",
    "storageTarget": "mdm",
    "fields": [
      {
        "name": "id",
        "type": "uuid",
        "derived": true
      },
      {
        "name": "version",
        "type": "integer",
        "derived": true
      },
      {
        "name": "details",
        "type": "object"
      },
      {
        "name": "details.identification",
        "type": "object"
      },
      {
        "name": "details.identification.subtype",
        "type": "enum",
        "derived": true
      },
      {
        "name": "details.identification.name",
        "type": "string"
      },
      {
        "name": "details.identification.status",
        "type": "enum",
        "derived": true
      },
      {
        "name": "details.identification.docType",
        "type": "enum"
      },
      {
        "name": "details.identification.docId",
        "type": "string"
      },
      {
        "name": "details.identification.countryCode",
        "type": "string"
      },
      {
        "name": "details.identification.tags",
        "type": "string",
        "derived": true
      },
      {
        "name": "details.base",
        "type": "object"
      },
      {
        "name": "details.base.aliases",
        "type": "string"
      },
      {
        "name": "details.base.addresses",
        "type": "object"
      },
      {
        "name": "details.base.contacts",
        "type": "object",
        "derived": true
      },
      {
        "name": "details.company",
        "type": "object"
      },
      {
        "name": "details.company.companyKind",
        "type": "enum"
      },
      {
        "name": "details.company.legalName",
        "type": "string"
      },
      {
        "name": "details.company.tradeName",
        "type": "string"
      },
      {
        "name": "details.general",
        "type": "object"
      },
      {
        "name": "details.inicio",
        "type": "object"
      },
      {
        "name": "details.inicio.preparada",
        "type": "boolean",
        "derived": true
      },
      {
        "name": "details.inicio.dadosFaltantes",
        "type": "string",
        "derived": true
      }
    ],
    "lifecycle": {
      "states": [],
      "transitions": []
    },
    "invariants": [
      "empresaPreparadaDadosObrigatorios",
      "naoPedirDadoJaExistente",
      "somenteResponsavelEditaEmpresa"
    ],
    "imports": []
  }
} as const;

export default definition;

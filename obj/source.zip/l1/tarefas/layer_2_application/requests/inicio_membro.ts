/// <mls fileReference="_102047_/l1/tarefas/layer_2_application/requests/inicio_membro.ts" enhancement="_blank"/>

import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type {
  Inicio_membroContracts,
  TarefaResumo,
  ResumoMinhasTarefas,
  EsperaPorMim,
  TarefaPendencia,
  AvisoDoDia,
  AvisoTarefa,
  MembroRef,
} from '/_102047_/l2/tarefas/web/contracts/inicio_membro.defs.js';
import { listTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import type { ListTarefaInput } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import { getTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/getTarefa.js';
import { getLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/getLista.js';
import { getMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/getMembroEquipe.js';
import { listItemChecklist } from '/_102047_/l1/tarefas/layer_2_application/usecases/listItemChecklist.js';
import { listAvisoVencimento } from '/_102047_/l1/tarefas/layer_2_application/usecases/listAvisoVencimento.js';
import { getAvisoVencimento } from '/_102047_/l1/tarefas/layer_2_application/usecases/getAvisoVencimento.js';
import { avancarEtapaTarefa } from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';
import type { TransicaoTarefa } from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';

type Contratos = Inicio_membroContracts;
type StatusTarefa = TarefaResumo['status'];
type PrioridadeTarefa = TarefaResumo['prioridade'];

interface TarefaRec {
  id: string;
  version: number;
  titulo: string;
  status: string;
  prioridade: string;
  prazo: string;
  listaId: string;
  responsavelId: string;
  criadorId: string;
  details: {
    motivoDevolucao?: string | null;
    devolvidaEm?: string | null;
  };
}

interface Loader {
  listas: Map<string, string>;
  membros: Map<string, string>;
  progressos: Map<string, string>;
}

const STATUS_VALUES: StatusTarefa[] = ['aFazer', 'emAndamento', 'emRevisao', 'concluida', 'cancelada'];
const PRIORIDADE_VALUES: PrioridadeTarefa[] = ['low', 'medium', 'high'];
const AVISO_STATUS_VALUES: AvisoDoDia['status'][] = ['pending', 'completed', 'failed'];
const SITUACAO_VALUES: AvisoTarefa['situacaoPrazo'][] = ['dueToday', 'overdue'];

function asStatus(value: string): StatusTarefa {
  const found = STATUS_VALUES.find((s) => s === value);
  if (found === undefined) throw new AppError('INVALID_DATA', 'Situação de tarefa desconhecida: ' + value, 500);
  return found;
}

function asPrioridade(value: string): PrioridadeTarefa {
  const found = PRIORIDADE_VALUES.find((s) => s === value);
  if (found === undefined) throw new AppError('INVALID_DATA', 'Prioridade de tarefa desconhecida: ' + value, 500);
  return found;
}

function asAvisoStatus(value: string): AvisoDoDia['status'] {
  const found = AVISO_STATUS_VALUES.find((s) => s === value);
  if (found === undefined) throw new AppError('INVALID_DATA', 'Situação de aviso desconhecida: ' + value, 500);
  return found;
}

function asSituacao(value: string): AvisoTarefa['situacaoPrazo'] {
  const found = SITUACAO_VALUES.find((s) => s === value);
  if (found === undefined) throw new AppError('INVALID_DATA', 'Situação de prazo desconhecida: ' + value, 500);
  return found;
}

function hoje(ctx: RequestContext): string {
  const tz = ctx.organization.timezone;
  const nowIso = ctx.clock.nowIso();
  if (tz) {
    return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(nowIso));
  }
  return nowIso.slice(0, 10);
}

function pessoaDaSessao(ctx: RequestContext): string {
  const id = ctx.sessionContext.actorId;
  if (id == null || id === '') throw new AppError('UNAUTHENTICATED', 'Pessoa da sessão não identificada', 401);
  return id;
}

function novoLoader(): Loader {
  return { listas: new Map(), membros: new Map(), progressos: new Map() };
}

function indicadores(t: TarefaRec, dia: string): { aberta: boolean; venceHoje: boolean; atrasada: boolean } {
  const aberta = t.status !== 'concluida' && t.status !== 'cancelada';
  const prazo = t.prazo.slice(0, 10);
  return {
    aberta,
    venceHoje: aberta && prazo === dia,
    atrasada: aberta && prazo < dia,
  };
}

function temDevolucao(t: TarefaRec): boolean {
  const motivo = t.details.motivoDevolucao;
  const em = t.details.devolvidaEm;
  return (motivo != null && motivo !== '') || (em != null && em !== '');
}

async function listarTarefas(
  filtro: { responsavelId?: string; criadorId?: string; status?: string },
  ctx: RequestContext,
): Promise<TarefaRec[]> {
  const todas: TarefaRec[] = [];
  let page = 1;
  for (;;) {
    const entrada: ListTarefaInput = { page, pageSize: 200 };
    if (filtro.responsavelId !== undefined) entrada.responsavelId = filtro.responsavelId;
    if (filtro.criadorId !== undefined) entrada.criadorId = filtro.criadorId;
    if (filtro.status !== undefined) entrada.status = filtro.status;
    const saida = await listTarefa(entrada, ctx);
    for (const item of saida.items) todas.push(item);
    if (!saida.hasMore) break;
    page += 1;
  }
  return todas;
}

async function nomeLista(loader: Loader, ctx: RequestContext, id: string): Promise<string> {
  const cached = loader.listas.get(id);
  if (cached !== undefined) return cached;
  const lista = await getLista({ id }, ctx);
  loader.listas.set(id, lista.nome);
  return lista.nome;
}

async function nomeMembro(loader: Loader, ctx: RequestContext, id: string): Promise<string> {
  const cached = loader.membros.get(id);
  if (cached !== undefined) return cached;
  const membro = await getMembroEquipe({ id }, ctx);
  const nome = membro.details.identification.name;
  loader.membros.set(id, nome);
  return nome;
}

async function progressoChecklist(loader: Loader, ctx: RequestContext, tarefaId: string): Promise<string> {
  const cached = loader.progressos.get(tarefaId);
  if (cached !== undefined) return cached;
  let total = 0;
  let feitos = 0;
  let page = 1;
  for (;;) {
    const saida = await listItemChecklist({ tarefaId, page, pageSize: 200 }, ctx);
    for (const item of saida.items) {
      total += 1;
      if (item.feito) feitos += 1;
    }
    if (!saida.hasMore) break;
    page += 1;
  }
  const texto = String(feitos) + '/' + String(total);
  loader.progressos.set(tarefaId, texto);
  return texto;
}

async function membroRef(loader: Loader, ctx: RequestContext, id: string): Promise<MembroRef> {
  const name = await nomeMembro(loader, ctx, id);
  return { details: { identification: { name } } };
}

function prioridadeRank(p: string): number {
  if (p === 'high') return 0;
  if (p === 'medium') return 1;
  return 2;
}

async function montarResumo(minhas: TarefaRec[], ctx: RequestContext, dia: string, loader: Loader): Promise<ResumoMinhasTarefas> {
  let quantidadeAbertas = 0;
  let quantidadeVencemHoje = 0;
  let quantidadeAtrasadas = 0;
  const abertas: TarefaRec[] = [];
  for (const t of minhas) {
    const ind = indicadores(t, dia);
    if (ind.aberta) {
      quantidadeAbertas += 1;
      abertas.push(t);
    }
    if (ind.venceHoje) quantidadeVencemHoje += 1;
    if (ind.atrasada) quantidadeAtrasadas += 1;
  }
  const rank = (t: TarefaRec): number => {
    const ind = indicadores(t, dia);
    if (ind.atrasada) return 0;
    if (ind.venceHoje) return 1;
    return 2;
  };
  abertas.sort((a, b) => {
    const r = rank(a) - rank(b);
    if (r !== 0) return r;
    const pa = a.prazo.slice(0, 10);
    const pb = b.prazo.slice(0, 10);
    if (pa !== pb) return pa < pb ? -1 : 1;
    return prioridadeRank(a.prioridade) - prioridadeRank(b.prioridade);
  });
  const tarefas: TarefaResumo[] = [];
  for (const t of abertas.slice(0, 10)) {
    const ind = indicadores(t, dia);
    tarefas.push({
      id: t.id,
      titulo: t.titulo,
      status: asStatus(t.status),
      prazo: t.prazo,
      prioridade: asPrioridade(t.prioridade),
      listaId: t.listaId,
      details: {
        aberta: ind.aberta,
        venceHoje: ind.venceHoje,
        atrasada: ind.atrasada,
        progressoChecklist: await progressoChecklist(loader, ctx, t.id),
      },
      lista: { nome: await nomeLista(loader, ctx, t.listaId) },
    });
  }
  return { quantidadeAbertas, quantidadeVencemHoje, quantidadeAtrasadas, tarefas };
}

async function montarPendencia(t: TarefaRec, ctx: RequestContext, loader: Loader): Promise<TarefaPendencia> {
  const details: TarefaPendencia['details'] = {
    progressoChecklist: await progressoChecklist(loader, ctx, t.id),
  };
  const motivo = t.details.motivoDevolucao;
  const em = t.details.devolvidaEm;
  const base: TarefaPendencia = {
    id: t.id,
    version: t.version,
    titulo: t.titulo,
    status: asStatus(t.status),
    prazo: t.prazo,
    prioridade: asPrioridade(t.prioridade),
    responsavelId: t.responsavelId,
    criadorId: t.criadorId,
    details,
    responsavel: await membroRef(loader, ctx, t.responsavelId),
    criador: await membroRef(loader, ctx, t.criadorId),
  };
  if (motivo != null && motivo !== '') base.details.motivoDevolucao = motivo;
  if (em != null && em !== '') base.details.devolvidaEm = em;
  return base;
}

async function montarEspera(minhas: TarefaRec[], paraRevisarRecs: TarefaRec[], ctx: RequestContext, loader: Loader): Promise<EsperaPorMim> {
  const paraIniciar: TarefaPendencia[] = [];
  const paraEnviarRevisao: TarefaPendencia[] = [];
  const devolvidas: TarefaPendencia[] = [];
  const paraRevisar: TarefaPendencia[] = [];
  for (const t of minhas) {
    if (t.status === 'aFazer') {
      paraIniciar.push(await montarPendencia(t, ctx, loader));
    } else if (t.status === 'emAndamento') {
      if (temDevolucao(t)) devolvidas.push(await montarPendencia(t, ctx, loader));
      else paraEnviarRevisao.push(await montarPendencia(t, ctx, loader));
    }
  }
  for (const t of paraRevisarRecs) {
    if (t.status === 'emRevisao') paraRevisar.push(await montarPendencia(t, ctx, loader));
  }
  return { paraIniciar, paraEnviarRevisao, paraRevisar, devolvidas };
}

async function resumoEEspera(me: string, ctx: RequestContext): Promise<{ resumo: ResumoMinhasTarefas; esperaPorMim: EsperaPorMim }> {
  const dia = hoje(ctx);
  const loader = novoLoader();
  const minhas = await listarTarefas({ responsavelId: me }, ctx);
  const aRevisar = await listarTarefas({ criadorId: me, status: 'emRevisao' }, ctx);
  const resumo = await montarResumo(minhas, ctx, dia, loader);
  const esperaPorMim = await montarEspera(minhas, aRevisar, ctx, loader);
  return { resumo, esperaPorMim };
}

interface RegrasTransicao {
  quem: 'responsavel' | 'criador';
  statusEsperado: StatusTarefa;
  transicao: TransicaoTarefa;
  motivoDevolucao?: string;
}

async function executarTransicao(
  input: { id: string; version: number },
  ctx: RequestContext,
  regras: RegrasTransicao,
): Promise<{ resumo: ResumoMinhasTarefas; esperaPorMim: EsperaPorMim }> {
  const me = pessoaDaSessao(ctx);
  return ctx.data.moduleData.runInTransaction(async (tx) => {
    const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
    const tarefa = await getTarefa({ id: String(input.id) }, bound);

    if (regras.quem === 'responsavel') {
      if (tarefa.responsavelId !== me) {
        throw new AppError('FORBIDDEN', 'Somente o responsável da tarefa pode executar este passo', 403, { ruleId: 'somenteResponsavelExecuta' });
      }
    } else if (tarefa.criadorId !== me) {
      throw new AppError('FORBIDDEN', 'Somente o criador da tarefa pode revisá-la', 403, { ruleId: 'somenteCriadorRevisa' });
    }
    if (regras.transicao === 'devolver') {
      const motivo = regras.motivoDevolucao;
      if (motivo == null || motivo.trim() === '') {
        throw new AppError('VALIDATION_ERROR', 'Informe o motivo da devolução', 400, { ruleId: 'devolucaoExigeMotivo' });
      }
    }
    if (tarefa.status === 'concluida' || tarefa.status === 'cancelada') {
      throw new AppError('INVALID_STATE', 'Tarefa concluída ou cancelada não muda mais de situação', 409, { ruleId: 'tarefaEncerradaNaoTransiciona' });
    }
    if (tarefa.status !== regras.statusEsperado) {
      throw new AppError('INVALID_STATE', 'A tarefa não está em ' + regras.statusEsperado + ' (situação atual: ' + tarefa.status + ')', 409);
    }
    if (tarefa.version !== Number(input.version)) {
      throw new AppError('VERSION_CONFLICT', 'A tarefa foi alterada por outra pessoa; recarregue e tente de novo', 409);
    }

    if (regras.motivoDevolucao !== undefined) {
      await avancarEtapaTarefa({ id: tarefa.id, transicao: regras.transicao, motivoDevolucao: regras.motivoDevolucao }, bound);
    } else {
      await avancarEtapaTarefa({ id: tarefa.id, transicao: regras.transicao }, bound);
    }

    return resumoEEspera(me, bound);
  });
}

export const requests: { [K in keyof Inicio_membroContracts]: (input: Inicio_membroContracts[K]['input'], ctx: RequestContext) => Promise<Inicio_membroContracts[K]['output']> } = {
  'tarefas.inicio_membro.carregarInicio': async function (input, ctx) {
    const me = pessoaDaSessao(ctx);
    const dia = hoje(ctx);
    const loader = novoLoader();
    const minhas = await listarTarefas({ responsavelId: me }, ctx);
    const aRevisar = await listarTarefas({ criadorId: me, status: 'emRevisao' }, ctx);
    const resumo = await montarResumo(minhas, ctx, dia, loader);
    const esperaPorMim = await montarEspera(minhas, aRevisar, ctx, loader);

    // avisoUnicoPorResponsavelEDia: no máximo um aviso da pessoa para a data de hoje
    const avisos = await listAvisoVencimento({ responsavelId: me, dataReferencia: dia, page: 1, pageSize: 1 }, ctx);
    if (avisos.items.length === 0) {
      return { resumo, esperaPorMim };
    }
    const aviso = await getAvisoVencimento({ id: avisos.items[0].id }, ctx);
    const tarefasAviso: AvisoTarefa[] = aviso.details.tarefas.map((t) => ({
      tarefaId: t.tarefaId,
      prazo: t.prazo,
      situacaoPrazo: asSituacao(t.situacaoPrazo),
    }));
    const avisoDoDia: AvisoDoDia = {
      id: aviso.id,
      dataReferencia: aviso.dataReferencia,
      status: asAvisoStatus(aviso.status),
      details: {
        quantidadeTarefas: tarefasAviso.length,
        quantidadeAtrasadas: tarefasAviso.filter((t) => t.situacaoPrazo === 'overdue').length,
        tarefas: tarefasAviso,
      },
    };
    return { resumo, avisoDoDia, esperaPorMim };
  },

  'tarefas.inicio_membro.iniciarTarefa': async function (input, ctx) {
    return executarTransicao({ id: input.id, version: input.version }, ctx, {
      quem: 'responsavel',
      statusEsperado: 'aFazer',
      transicao: 'iniciar',
    });
  },

  'tarefas.inicio_membro.enviarParaRevisao': async function (input, ctx) {
    return executarTransicao({ id: input.id, version: input.version }, ctx, {
      quem: 'responsavel',
      statusEsperado: 'emAndamento',
      transicao: 'enviarParaRevisao',
    });
  },

  'tarefas.inicio_membro.aceitarEntrega': async function (input, ctx) {
    return executarTransicao({ id: input.id, version: input.version }, ctx, {
      quem: 'criador',
      statusEsperado: 'emRevisao',
      transicao: 'aceitar',
    });
  },

  'tarefas.inicio_membro.devolverComMotivo': async function (input, ctx) {
    return executarTransicao({ id: input.id, version: input.version }, ctx, {
      quem: 'criador',
      statusEsperado: 'emRevisao',
      transicao: 'devolver',
      motivoDevolucao: input.details.motivoDevolucao,
    });
  },
};

/// <mls fileReference="_102047_/l1/tarefas/layer_2_application/requests/minhas_tarefas.ts" enhancement="_blank"/>

import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { resolveRepository } from '/_102034_/l1/server/layer_2_application/repositoryRegistry.js';
import type {
  Minhas_tarefasContracts,
  TarefaDetalhe,
  TarefaResumo,
  ItemChecklistLinha,
  ListaOpcao,
  MembroOpcao,
} from '/_102047_/l2/tarefas/web/contracts/minhas_tarefas.defs.js';
import { getTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/getTarefa.js';
import { listTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import type { ListTarefaInput } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import { updateTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateTarefa.js';
import type { UpdateTarefaInput } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateTarefa.js';
import { getLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/getLista.js';
import { listLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/listLista.js';
import { getMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/getMembroEquipe.js';
import { listMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/listMembroEquipe.js';
import { listItemChecklist } from '/_102047_/l1/tarefas/layer_2_application/usecases/listItemChecklist.js';
import { updateItemChecklist } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateItemChecklist.js';
import type { ItemChecklistRepository } from '/_102047_/l1/tarefas/layer_2_application/ports/itemChecklistRepository.js';
import {
  abrirOcorrenciaTarefa,
  avancarEtapaTarefa,
  reatribuirQuemAge,
} from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';
import type {
  AbrirOcorrenciaTarefaInput,
  AvancarEtapaTarefaInput,
  TransicaoTarefa,
} from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';

type Contracts = Minhas_tarefasContracts;
type ItemChecklistRegistro = Awaited<ReturnType<ItemChecklistRepository['list']>>[number];

interface TarefaFonte {
  id: string;
  version: number;
  titulo: string;
  status: string;
  prioridade: string;
  prazo: string;
  listaId: string;
  responsavelId: string;
  criadorId: string;
  criadaEm: string;
  details: {
    descricao?: string;
    motivoDevolucao?: string;
    devolvidaEm?: string;
    concluidaEm?: string;
    canceladaEm?: string;
  };
}

const TAMANHO_LOTE = 200;
const LIMITE_BUSCA_MEMBROS = 20;

// ---------------------------------------------------------------- helpers

function pessoaDaSessao(ctx: RequestContext): string {
  const id = ctx.sessionContext.actorId ?? ctx.sessionContext.person?.mdmId;
  if (id == null || id === '') {
    throw new AppError('UNAUTHENTICATED', 'A sessão não identifica o membro da equipe', 401);
  }
  return id;
}

function hoje(ctx: RequestContext): string {
  const agora = ctx.clock.nowIso();
  const tz = ctx.organization.timezone;
  if (tz != null && tz !== '') {
    return new Date(agora).toLocaleDateString('en-CA', { timeZone: tz });
  }
  return agora.slice(0, 10);
}

function normalizar(texto: string): string {
  return texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

function toStatus(v: string): TarefaResumo['status'] {
  if (v === 'aFazer' || v === 'emAndamento' || v === 'emRevisao' || v === 'concluida' || v === 'cancelada') return v;
  throw new AppError('DADO_INVALIDO', `Situação de tarefa desconhecida: ${v}`, 500, { valor: v });
}

function toPrioridade(v: string): TarefaResumo['prioridade'] {
  if (v === 'low' || v === 'medium' || v === 'high') return v;
  throw new AppError('DADO_INVALIDO', `Prioridade de tarefa desconhecida: ${v}`, 500, { valor: v });
}

function toTipoLista(v: string): ListaOpcao['details']['tipo'] {
  if (v === 'project' || v === 'area') return v;
  throw new AppError('DADO_INVALIDO', `Tipo de lista desconhecido: ${v}`, 500, { valor: v });
}

function toStatusMembro(v: string): MembroOpcao['details']['identification']['status'] {
  if (v === 'Active' || v === 'Inactive' || v === 'Merged' || v === 'Blocked') return v;
  throw new AppError('DADO_INVALIDO', `Situação de membro desconhecida: ${v}`, 500, { valor: v });
}

async function listarTudo<T>(
  buscar: (page: number, pageSize: number) => Promise<{ items: T[]; hasMore: boolean }>,
): Promise<T[]> {
  const todos: T[] = [];
  let page = 1;
  for (;;) {
    const r = await buscar(page, TAMANHO_LOTE);
    todos.push(...r.items);
    if (!r.hasMore) return todos;
    page += 1;
  }
}

async function listarChecklist(tarefaId: string, ctx: RequestContext): Promise<ItemChecklistRegistro[]> {
  const itens = await listarTudo((page, pageSize) => listItemChecklist({ tarefaId, page, pageSize }, ctx));
  return [...itens].sort((a, b) => a.ordem - b.ordem);
}

function linhaChecklist(i: ItemChecklistRegistro): ItemChecklistLinha {
  const details: ItemChecklistLinha['details'] = { descricao: i.details.descricao };
  if (i.details.marcadoEm != null) details.marcadoEm = i.details.marcadoEm;
  return { id: i.id, version: i.version, ordem: i.ordem, feito: i.feito, details };
}

async function nomesDeMembros(ids: string[], ctx: RequestContext): Promise<Map<string, string>> {
  const unicos = Array.from(new Set(ids));
  const pares = await Promise.all(
    unicos.map(async (id) => {
      const m = await getMembroEquipe({ id }, ctx);
      return [id, m.details.identification.name] as [string, string];
    }),
  );
  return new Map(pares);
}

async function nomesDeListas(ids: string[], ctx: RequestContext): Promise<Map<string, string>> {
  const unicos = Array.from(new Set(ids));
  const pares = await Promise.all(
    unicos.map(async (id) => {
      const l = await getLista({ id }, ctx);
      return [id, l.nome] as [string, string];
    }),
  );
  return new Map(pares);
}

function nomeOuErro(mapa: Map<string, string>, id: string, o: string): string {
  const nome = mapa.get(id);
  if (nome == null) throw new AppError('NOT_FOUND', `${o} não encontrado(a)`, 404, { id });
  return nome;
}

function exigirVisivel(t: TarefaFonte, me: string): void {
  // editarSomenteTarefaVisivel
  if (t.criadorId !== me && t.responsavelId !== me) {
    throw new AppError('FORBIDDEN', `Você não pode ver nem editar a tarefa "${t.titulo}"`, 403, {
      ruleId: 'editarSomenteTarefaVisivel',
      tarefaId: t.id,
    });
  }
}

async function exigirListaAtiva(listaId: string, ctx: RequestContext): Promise<void> {
  const lista = await getLista({ id: listaId }, ctx);
  // listaInativaNaoRecebeTarefa
  if (!lista.ativa) {
    throw new AppError('LISTA_INATIVA', `A lista "${lista.nome}" está inativa e não recebe novas tarefas`, 422, {
      ruleId: 'listaInativaNaoRecebeTarefa',
      listaId,
    });
  }
}

async function exigirMembroAtivo(membroId: string, ctx: RequestContext): Promise<void> {
  const m = await getMembroEquipe({ id: membroId }, ctx);
  // responsavelDeveSerMembroAtivo
  if (m.details.identification.status !== 'Active') {
    throw new AppError(
      'RESPONSAVEL_INATIVO',
      `O membro "${m.details.identification.name}" não está ativo e não pode ser responsável`,
      422,
      { ruleId: 'responsavelDeveSerMembroAtivo', responsavelId: membroId },
    );
  }
}

function exigirVersao(t: TarefaFonte, version: number): void {
  if (t.version !== version) {
    throw new AppError(
      'VERSION_CONFLICT',
      `A tarefa "${t.titulo}" foi alterada por outra pessoa; recarregue e tente de novo`,
      409,
      { tarefaId: t.id, versaoLida: version, versaoAtual: t.version },
    );
  }
}

async function montarDetalhe(t: TarefaFonte, ctx: RequestContext): Promise<TarefaDetalhe> {
  const me = pessoaDaSessao(ctx);
  const [lista, criador, responsavel, checklist] = await Promise.all([
    getLista({ id: t.listaId }, ctx),
    getMembroEquipe({ id: t.criadorId }, ctx),
    getMembroEquipe({ id: t.responsavelId }, ctx),
    listarChecklist(t.id, ctx),
  ]);
  const details: TarefaDetalhe['details'] = {};
  if (t.details.descricao != null) details.descricao = t.details.descricao;
  if (t.details.motivoDevolucao != null) details.motivoDevolucao = t.details.motivoDevolucao;
  if (t.details.devolvidaEm != null) details.devolvidaEm = t.details.devolvidaEm;
  if (t.details.concluidaEm != null) details.concluidaEm = t.details.concluidaEm;
  if (t.details.canceladaEm != null) details.canceladaEm = t.details.canceladaEm;
  return {
    id: t.id,
    version: t.version,
    titulo: t.titulo,
    details,
    listaId: t.listaId,
    lista: { nome: lista.nome },
    criadorId: t.criadorId,
    criador: { details: { identification: { name: criador.details.identification.name } } },
    responsavelId: t.responsavelId,
    responsavel: { details: { identification: { name: responsavel.details.identification.name } } },
    prazo: t.prazo,
    prioridade: toPrioridade(t.prioridade),
    status: toStatus(t.status),
    criadaEm: t.criadaEm,
    souCriador: t.criadorId === me,
    souResponsavel: t.responsavelId === me,
    checklist: checklist.map(linhaChecklist),
  };
}

async function tarefasDe(
  campo: 'criadorId' | 'responsavelId',
  me: string,
  status: string | undefined,
  ctx: RequestContext,
): Promise<TarefaFonte[]> {
  return listarTudo((page, pageSize) => {
    const filtro: ListTarefaInput = { page, pageSize };
    filtro[campo] = me;
    if (status != null) filtro.status = status;
    return listTarefa(filtro, ctx);
  });
}

async function transicionar(
  ctx: RequestContext,
  id: string,
  version: number,
  cfg: {
    transicao: TransicaoTarefa;
    papel: 'responsavel' | 'criador';
    ruleId: string;
    statusPermitidos: string[];
    verbo: string;
    exigeMotivo?: boolean;
    motivoDevolucao?: string;
  },
): Promise<{ tarefa: TarefaDetalhe }> {
  return ctx.data.moduleData.runInTransaction(async (tx) => {
    const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
    const me = pessoaDaSessao(bound);
    const tarefa = await getTarefa({ id }, bound);
    const esperado = cfg.papel === 'responsavel' ? tarefa.responsavelId : tarefa.criadorId;
    // regra do papel (somenteResponsavelExecuta / somenteCriadorRevisa / cancelamentoPorCriadorOuGestor)
    if (me !== esperado) {
      const quem = cfg.papel === 'responsavel' ? 'o responsável' : 'quem criou a tarefa';
      throw new AppError('FORBIDDEN', `Somente ${quem} "${tarefa.titulo}" pode ${cfg.verbo}`, 403, {
        ruleId: cfg.ruleId,
        tarefaId: id,
      });
    }
    // tarefaEncerradaNaoTransiciona
    if (tarefa.status === 'concluida' || tarefa.status === 'cancelada') {
      throw new AppError('TAREFA_ENCERRADA', `A tarefa "${tarefa.titulo}" está encerrada e não muda mais de situação`, 409, {
        ruleId: 'tarefaEncerradaNaoTransiciona',
        tarefaId: id,
        status: tarefa.status,
      });
    }
    if (!cfg.statusPermitidos.includes(tarefa.status)) {
      throw new AppError(
        'STATUS_INVALIDO',
        `A tarefa "${tarefa.titulo}" está em ${tarefa.status} e não pode ${cfg.verbo}`,
        409,
        { tarefaId: id, status: tarefa.status, permitidos: cfg.statusPermitidos },
      );
    }
    if (cfg.exigeMotivo === true) {
      const motivo = cfg.motivoDevolucao;
      // devolucaoExigeMotivo
      if (motivo == null || motivo.trim() === '') {
        throw new AppError('MOTIVO_OBRIGATORIO', `Informe o motivo para devolver a tarefa "${tarefa.titulo}"`, 422, {
          ruleId: 'devolucaoExigeMotivo',
          tarefaId: id,
        });
      }
    }
    exigirVersao(tarefa, version);
    const entrada: AvancarEtapaTarefaInput = { id, transicao: cfg.transicao };
    if (cfg.exigeMotivo === true && cfg.motivoDevolucao != null) {
      entrada.motivoDevolucao = cfg.motivoDevolucao.trim();
    }
    const r = await avancarEtapaTarefa(entrada, bound);
    return { tarefa: await montarDetalhe(r.tarefa, bound) };
  });
}

// ---------------------------------------------------------------- requests

export const requests: { [K in keyof Minhas_tarefasContracts]: (input: Minhas_tarefasContracts[K]['input'], ctx: RequestContext) => Promise<Minhas_tarefasContracts[K]['output']> } = {
  'tarefas.minhas_tarefas.qryMinhasTarefas': async function (input, ctx) {
    const me = pessoaDaSessao(ctx);
    const page = Math.max(1, Math.floor(input.page || 1));
    const pageSize = Math.min(200, Math.max(1, Math.floor(input.pageSize || 20)));
    const statusFiltro =
      input.filtro === 'emRevisao' ? 'emRevisao' : input.filtro === 'devolvidas' ? 'emAndamento' : undefined;

    // editarSomenteTarefaVisivel: só as tarefas que o membro criou ou pelas quais é responsável
    const visiveis = new Map<string, TarefaFonte>();
    if (input.filtro !== 'atribuidasAMim') {
      for (const t of await tarefasDe('criadorId', me, statusFiltro, ctx)) visiveis.set(t.id, t);
    }
    if (input.filtro !== 'criadasPorMim') {
      for (const t of await tarefasDe('responsavelId', me, statusFiltro, ctx)) visiveis.set(t.id, t);
    }
    let selecionadas = Array.from(visiveis.values());
    if (input.filtro === 'devolvidas') {
      selecionadas = selecionadas.filter((t) => t.details.devolvidaEm != null);
    }
    selecionadas.sort((a, b) => {
      if (a.prazo !== b.prazo) return a.prazo < b.prazo ? -1 : 1;
      return a.titulo.localeCompare(b.titulo);
    });

    const inicio = (page - 1) * pageSize;
    const pagina = selecionadas.slice(inicio, inicio + pageSize);
    const hasMore = inicio + pageSize < selecionadas.length;

    const [nomesListas, nomesMembros] = await Promise.all([
      nomesDeListas(pagina.map((t) => t.listaId), ctx),
      nomesDeMembros(pagina.flatMap((t) => [t.responsavelId, t.criadorId]), ctx),
    ]);
    const dataHoje = hoje(ctx);

    const items: TarefaResumo[] = await Promise.all(
      pagina.map(async (t) => {
        const [filhas, checklist] = await Promise.all([
          listarTudo((p, s) => listTarefa({ tarefaPaiId: t.id, page: p, pageSize: s }, ctx)),
          listarChecklist(t.id, ctx),
        ]);
        const aberta = t.status !== 'concluida' && t.status !== 'cancelada';
        const prazo = t.prazo.slice(0, 10);
        const details: TarefaResumo['details'] = {
          // derivados: calculados aqui, nunca lidos do armazenamento
          quantidadeSubtarefas: filhas.length,
          progressoChecklist: `${checklist.filter((i) => i.feito).length}/${checklist.length}`,
          venceHoje: aberta && prazo === dataHoje,
          atrasada: aberta && prazo < dataHoje,
        };
        if (t.details.devolvidaEm != null) details.devolvidaEm = t.details.devolvidaEm;
        return {
          id: t.id,
          version: t.version,
          titulo: t.titulo,
          listaId: t.listaId,
          lista: { nome: nomeOuErro(nomesListas, t.listaId, 'Lista') },
          responsavelId: t.responsavelId,
          responsavel: {
            details: { identification: { name: nomeOuErro(nomesMembros, t.responsavelId, 'Responsável') } },
          },
          criadorId: t.criadorId,
          criador: { details: { identification: { name: nomeOuErro(nomesMembros, t.criadorId, 'Criador') } } },
          prioridade: toPrioridade(t.prioridade),
          prazo: t.prazo,
          status: toStatus(t.status),
          details,
        };
      }),
    );

    return { tarefas: { items, page, pageSize, hasMore } };
  },

  'tarefas.minhas_tarefas.qryTarefa': async function (input, ctx) {
    const me = pessoaDaSessao(ctx);
    const tarefa = await getTarefa({ id: input.tarefaId }, ctx);
    exigirVisivel(tarefa, me);
    return { tarefa: await montarDetalhe(tarefa, ctx) };
  },

  'tarefas.minhas_tarefas.qryListasAtivas': async function (_input, ctx) {
    // listaInativaNaoRecebeTarefa: só listas com ativa = true
    const listas = await listarTudo((page, pageSize) => listLista({ ativa: true, page, pageSize }, ctx));
    const ordenadas = listas.filter((l) => l.ativa).sort((a, b) => a.nome.localeCompare(b.nome));
    const out: ListaOpcao[] = ordenadas.map((l) => ({
      id: l.id,
      nome: l.nome,
      ativa: l.ativa,
      details: { tipo: toTipoLista(l.details.tipo) },
    }));
    return { listas: out };
  },

  'tarefas.minhas_tarefas.qryBuscarMembros': async function (input, ctx) {
    const termo = normalizar(input.termo.trim());
    const membros = await listarTudo((page, pageSize) => listMembroEquipe({ page, pageSize }, ctx));
    const encontrados = membros
      // responsavelDeveSerMembroAtivo: somente situação Active
      .filter((m) => m.details.identification.status === 'Active')
      .filter((m) => normalizar(m.details.identification.name).includes(termo))
      .sort((a, b) => a.details.identification.name.localeCompare(b.details.identification.name))
      .slice(0, LIMITE_BUSCA_MEMBROS);
    const out: MembroOpcao[] = encontrados.map((m) => ({
      id: m.id,
      details: {
        identification: {
          name: m.details.identification.name,
          status: toStatusMembro(m.details.identification.status),
        },
      },
    }));
    return { membros: out };
  },

  'tarefas.minhas_tarefas.cmdCriarTarefa': async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const me = pessoaDaSessao(bound);
      if (input.criadorId != null && input.criadorId !== me) {
        throw new AppError(
          'CRIADOR_DIFERENTE_DA_SESSAO',
          'O criador da tarefa deve ser a pessoa da sessão',
          403,
          { criadorId: input.criadorId },
        );
      }

      // criacaoIdempotente: a mesma chaveCriacao devolve a tarefa já criada, sem criar outra
      const existentes = await listTarefa({ chaveCriacao: input.chaveCriacao, page: 1, pageSize: 1 }, bound);
      const jaCriada = existentes.items[0];
      if (jaCriada != null) {
        return { tarefa: await montarDetalhe(jaCriada, bound) };
      }

      await exigirListaAtiva(input.listaId, bound);
      await exigirMembroAtivo(input.responsavelId, bound);

      const abrir: AbrirOcorrenciaTarefaInput = {
        chaveCriacao: input.chaveCriacao,
        titulo: input.titulo,
        prioridade: input.prioridade,
        prazo: input.prazo,
        listaId: input.listaId,
        responsavelId: input.responsavelId,
      };
      if (input.details.descricao != null) abrir.descricao = input.details.descricao;
      const aberta = await abrirOcorrenciaTarefa(abrir, bound);

      const repo = resolveRepository<ItemChecklistRepository>(bound, 'ItemChecklistRepository');
      for (const item of input.checklist ?? []) {
        const details: ItemChecklistRegistro['details'] = { descricao: item.details.descricao };
        if (item.feito) details.marcadoEm = bound.clock.nowIso();
        const novo: ItemChecklistRegistro = {
          id: bound.idGenerator.newId(),
          version: 1,
          tarefaId: aberta.tarefa.id,
          ordem: item.ordem,
          feito: item.feito,
          details,
        };
        await repo.create(novo);
      }

      return { tarefa: await montarDetalhe(aberta.tarefa, bound) };
    });
  },

  'tarefas.minhas_tarefas.cmdSalvarEdicao': async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const me = pessoaDaSessao(bound);
      const tarefa = await getTarefa({ id: input.id }, bound);
      exigirVisivel(tarefa, me);
      exigirVersao(tarefa, input.version);

      if (input.listaId !== tarefa.listaId) {
        await exigirListaAtiva(input.listaId, bound);
      }
      const trocouResponsavel = input.responsavelId !== tarefa.responsavelId;
      if (trocouResponsavel) {
        // reatribuicaoPorCriadorOuGestor
        if (tarefa.criadorId !== me) {
          throw new AppError(
            'FORBIDDEN',
            `Somente quem criou a tarefa "${tarefa.titulo}" pode trocar o responsável`,
            403,
            { ruleId: 'reatribuicaoPorCriadorOuGestor', tarefaId: tarefa.id },
          );
        }
        await exigirMembroAtivo(input.responsavelId, bound);
      }

      const details: UpdateTarefaInput['details'] = {};
      if (input.details.descricao != null) details.descricao = input.details.descricao;
      if (tarefa.details.motivoDevolucao != null) details.motivoDevolucao = tarefa.details.motivoDevolucao;
      if (tarefa.details.devolvidaEm != null) details.devolvidaEm = tarefa.details.devolvidaEm;
      if (tarefa.details.concluidaEm != null) details.concluidaEm = tarefa.details.concluidaEm;
      if (tarefa.details.canceladaEm != null) details.canceladaEm = tarefa.details.canceladaEm;

      const dados: UpdateTarefaInput = {
        id: tarefa.id,
        version: input.version,
        titulo: input.titulo,
        // edicaoNaoMudaSituacao: a situação segue a gravada
        status: tarefa.status,
        prioridade: input.prioridade,
        prazo: input.prazo,
        listaId: input.listaId,
        // a troca de responsável passa por reatribuirQuemAge, abaixo
        responsavelId: tarefa.responsavelId,
        criadorId: tarefa.criadorId,
        chaveCriacao: tarefa.chaveCriacao,
        details,
      };
      if (tarefa.tarefaPaiId != null) dados.tarefaPaiId = tarefa.tarefaPaiId;
      await updateTarefa(dados, bound);

      if (trocouResponsavel) {
        await reatribuirQuemAge({ id: tarefa.id, novoResponsavelId: input.responsavelId }, bound);
      }

      const atual = await getTarefa({ id: tarefa.id }, bound);
      return { tarefa: await montarDetalhe(atual, bound) };
    });
  },

  'tarefas.minhas_tarefas.cmdSalvarChecklist': async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const me = pessoaDaSessao(bound);
      const tarefa = await getTarefa({ id: input.tarefaId }, bound);
      exigirVisivel(tarefa, me);

      const existentes = await listarChecklist(tarefa.id, bound);
      const porId = new Map<string, ItemChecklistRegistro>();
      for (const e of existentes) porId.set(e.id, e);

      // valida tudo antes de gravar: item existente e versão lida
      for (const item of input.itens) {
        if (item.id == null) continue;
        const atual = porId.get(item.id);
        if (atual == null) {
          throw new AppError('NOT_FOUND', `Item da checklist "${item.details.descricao}" não encontrado`, 404, {
            itemId: item.id,
            tarefaId: tarefa.id,
          });
        }
        if (item.version == null) {
          throw new AppError(
            'VALIDATION_ERROR',
            `Informe a versão do item da checklist "${atual.details.descricao}"`,
            400,
            { itemId: item.id },
          );
        }
        if (item.version !== atual.version) {
          throw new AppError(
            'VERSION_CONFLICT',
            `O item da checklist "${atual.details.descricao}" foi alterado por outra pessoa; recarregue e tente de novo`,
            409,
            { itemId: item.id, versaoLida: item.version, versaoAtual: atual.version },
          );
        }
      }

      // checklistNaoMudaSituacao: a situação da tarefa não é tocada aqui
      const repo = resolveRepository<ItemChecklistRepository>(bound, 'ItemChecklistRepository');
      for (const item of input.itens) {
        const details: ItemChecklistRegistro['details'] = { descricao: item.details.descricao };
        if (item.id != null && item.version != null) {
          const atual = porId.get(item.id);
          if (atual == null) continue;
          if (item.feito) {
            details.marcadoEm = atual.feito && atual.details.marcadoEm != null ? atual.details.marcadoEm : bound.clock.nowIso();
          }
          await updateItemChecklist(
            {
              id: item.id,
              version: item.version,
              tarefaId: tarefa.id,
              ordem: item.ordem,
              feito: item.feito,
              details,
            },
            bound,
          );
        } else {
          if (item.feito) details.marcadoEm = bound.clock.nowIso();
          const novo: ItemChecklistRegistro = {
            id: bound.idGenerator.newId(),
            version: 1,
            tarefaId: tarefa.id,
            ordem: item.ordem,
            feito: item.feito,
            details,
          };
          await repo.create(novo);
        }
      }

      const atualTarefa = await getTarefa({ id: tarefa.id }, bound);
      return { tarefa: await montarDetalhe(atualTarefa, bound) };
    });
  },

  'tarefas.minhas_tarefas.cmdIniciar': async function (input, ctx) {
    return transicionar(ctx, input.id, input.version, {
      transicao: 'iniciar',
      papel: 'responsavel',
      ruleId: 'somenteResponsavelExecuta',
      statusPermitidos: ['aFazer'],
      verbo: 'iniciá-la',
    });
  },

  'tarefas.minhas_tarefas.cmdEnviarRevisao': async function (input, ctx) {
    return transicionar(ctx, input.id, input.version, {
      transicao: 'enviarParaRevisao',
      papel: 'responsavel',
      ruleId: 'somenteResponsavelExecuta',
      statusPermitidos: ['emAndamento'],
      verbo: 'enviá-la para revisão',
    });
  },

  'tarefas.minhas_tarefas.cmdAceitar': async function (input, ctx) {
    return transicionar(ctx, input.id, input.version, {
      transicao: 'aceitar',
      papel: 'criador',
      ruleId: 'somenteCriadorRevisa',
      statusPermitidos: ['emRevisao'],
      verbo: 'aceitá-la',
    });
  },

  'tarefas.minhas_tarefas.cmdDevolver': async function (input, ctx) {
    return transicionar(ctx, input.id, input.version, {
      transicao: 'devolver',
      papel: 'criador',
      ruleId: 'somenteCriadorRevisa',
      statusPermitidos: ['emRevisao'],
      verbo: 'devolvê-la para ajuste',
      exigeMotivo: true,
      motivoDevolucao: input.details.motivoDevolucao,
    });
  },

  'tarefas.minhas_tarefas.cmdCancelar': async function (input, ctx) {
    return transicionar(ctx, input.id, input.version, {
      transicao: 'cancelar',
      papel: 'criador',
      ruleId: 'cancelamentoPorCriadorOuGestor',
      statusPermitidos: ['aFazer', 'emAndamento', 'emRevisao'],
      verbo: 'cancelá-la',
    });
  },
};

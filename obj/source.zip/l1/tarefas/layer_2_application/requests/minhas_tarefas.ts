/// <mls fileReference="_102047_/l1/tarefas/layer_2_application/requests/minhas_tarefas.ts" enhancement="_blank"/>

import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { resolveRepository } from '/_102034_/l1/server/layer_2_application/repositoryRegistry.js';
import type {
  Minhas_tarefasContracts,
  TarefaResumo,
  TarefaAberta,
  MembroNome,
  MembroOpcao,
  ListaOpcao,
  ItemChecklistLinha,
} from '/_102047_/l2/tarefas/web/contracts/minhas_tarefas.defs.js';
import { getTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/getTarefa.js';
import type { GetTarefaOutput } from '/_102047_/l1/tarefas/layer_2_application/usecases/getTarefa.js';
import { listTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import type { ListTarefaInput } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import { updateTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateTarefa.js';
import type { UpdateTarefaInput } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateTarefa.js';
import { getLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/getLista.js';
import { listLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/listLista.js';
import { listItemChecklist } from '/_102047_/l1/tarefas/layer_2_application/usecases/listItemChecklist.js';
import { updateItemChecklist } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateItemChecklist.js';
import type { UpdateItemChecklistInput } from '/_102047_/l1/tarefas/layer_2_application/usecases/updateItemChecklist.js';
import { getMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/getMembroEquipe.js';
import { listMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/listMembroEquipe.js';
import {
  abrirOcorrenciaTarefa,
  avancarEtapaTarefa,
  reatribuirQuemAge,
} from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';
import type { AvancarEtapaTarefaInput } from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';

// ---------------------------------------------------------------------------
// Local shapes (only the fields this service reads)
// ---------------------------------------------------------------------------

interface TarefaBase {
  id: string;
  version: number;
  titulo: string;
  status: string;
  prioridade: string;
  prazo: string;
  listaId: string;
  responsavelId: string;
  criadorId: string;
  criadaEm: string;
  details: {
    descricao?: string | null;
    motivoDevolucao?: string | null;
    devolvidaEm?: string | null;
    concluidaEm?: string | null;
    canceladaEm?: string | null;
  };
}

interface ItemRegistro {
  id: string;
  version: number;
  tarefaId: string;
  ordem: number;
  feito: boolean;
  details: { descricao: string; marcadoEm?: string | null };
}

interface MembroRegistro {
  id: string;
  details: { identification: { name: string; status: string } };
}

/**
 * No usecase of the module creates or deletes checklist items (only list and update exist),
 * so the item repository of the module is used here for those two writes.
 */
interface ItemChecklistRepository {
  create(input: {
    tarefaId: string;
    ordem: number;
    feito: boolean;
    details: { descricao: string };
  }): Promise<unknown>;
  delete(id: string): Promise<unknown>;
}

type Leitor = ReturnType<typeof criarLeitor>;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const STATUS_VALIDOS = ['aFazer', 'emAndamento', 'emRevisao', 'concluida', 'cancelada'] as const;
const PRIORIDADES_VALIDAS = ['low', 'medium', 'high'] as const;
const TIPOS_LISTA_VALIDOS = ['project', 'area'] as const;
const LIMITE_RESPONSAVEIS = 10;

function lerStatus(valor: string): TarefaResumo['status'] {
  for (const s of STATUS_VALIDOS) {
    if (s === valor) return s;
  }
  throw new AppError('INVALID_DATA', `situação de tarefa desconhecida: ${valor}`, 500);
}

function lerPrioridade(valor: string): TarefaResumo['prioridade'] {
  for (const p of PRIORIDADES_VALIDAS) {
    if (p === valor) return p;
  }
  throw new AppError('INVALID_DATA', `prioridade de tarefa desconhecida: ${valor}`, 500);
}

function lerTipoLista(valor: string): ListaOpcao['details']['details']['tipo'] {
  for (const t of TIPOS_LISTA_VALIDOS) {
    if (t === valor) return t;
  }
  throw new AppError('INVALID_DATA', `tipo de lista desconhecido: ${valor}`, 500);
}

function membroDaSessao(ctx: RequestContext): string {
  const id = ctx.sessionContext.person?.mdmId ?? ctx.sessionContext.actorId;
  if (id == null || id === '') {
    throw new AppError('UNAUTHORIZED', 'membro da sessão não identificado pelo login', 401);
  }
  return id;
}

function hoje(ctx: RequestContext): string {
  const agora = ctx.clock.nowIso();
  const tz = ctx.organization.timezone;
  if (tz == null || tz === '') return agora.slice(0, 10);
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: tz,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(agora));
}

function tarefaAberta(status: string): boolean {
  return status !== 'concluida' && status !== 'cancelada';
}

function normalizar(texto: string): string {
  return texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

function nomeMembroObjeto(nome: string): MembroNome {
  return { details: { identification: { details: { identification: { name: nome } } } } };
}

function criarLeitor(ctx: RequestContext) {
  const listas = new Map<string, Promise<string>>();
  const membros = new Map<string, Promise<string>>();
  return {
    nomeLista(id: string): Promise<string> {
      let p = listas.get(id);
      if (p === undefined) {
        p = getLista({ id }, ctx).then((l) => l.nome);
        listas.set(id, p);
      }
      return p;
    },
    nomeMembro(id: string): Promise<string> {
      let p = membros.get(id);
      if (p === undefined) {
        p = getMembroEquipe({ id }, ctx).then((m) => m.details.identification.name);
        membros.set(id, p);
      }
      return p;
    },
  };
}

function exigirVisivel(t: { criadorId: string; responsavelId: string }, membro: string): void {
  // editarSomenteTarefaVisivel: o membro vê as tarefas que criou ou pelas quais é responsável
  if (t.criadorId !== membro && t.responsavelId !== membro) {
    throw new AppError('FORBIDDEN', 'a tarefa não é visível para o membro da sessão', 403, {
      ruleId: 'editarSomenteTarefaVisivel',
    });
  }
}

async function exigirListaAtiva(listaId: string, ctx: RequestContext): Promise<void> {
  const lista = await getLista({ id: listaId }, ctx);
  // listaInativaNaoRecebeTarefa
  if (!lista.ativa) {
    throw new AppError('LISTA_INATIVA', 'uma lista inativa não pode receber tarefas', 422, {
      ruleId: 'listaInativaNaoRecebeTarefa',
    });
  }
}

async function exigirMembroAtivo(membroId: string, ctx: RequestContext): Promise<void> {
  const membro = await getMembroEquipe({ id: membroId }, ctx);
  // responsavelDeveSerMembroAtivo
  if (membro.details.identification.status !== 'Active') {
    throw new AppError('RESPONSAVEL_INATIVO', 'o responsável deve ser um membro ativo da equipe', 422, {
      ruleId: 'responsavelDeveSerMembroAtivo',
    });
  }
}

async function listarChecklist(tarefaId: string, ctx: RequestContext): Promise<ItemRegistro[]> {
  const todos: ItemRegistro[] = [];
  let page = 1;
  let mais = true;
  while (mais) {
    const r = await listItemChecklist({ tarefaId, page, pageSize: 200 }, ctx);
    for (const it of r.items) todos.push(it);
    mais = r.hasMore;
    page += 1;
  }
  todos.sort((a, b) => a.ordem - b.ordem);
  return todos;
}

async function listarTarefas(filtros: Omit<ListTarefaInput, 'page' | 'pageSize'>, ctx: RequestContext): Promise<TarefaBase[]> {
  const todas: TarefaBase[] = [];
  let page = 1;
  let mais = true;
  while (mais) {
    const entrada: ListTarefaInput = { ...filtros, page, pageSize: 200 };
    const r = await listTarefa(entrada, ctx);
    for (const t of r.items) todas.push(t);
    mais = r.hasMore;
    page += 1;
  }
  return todas;
}

async function contarSubtarefas(tarefaId: string, ctx: RequestContext): Promise<number> {
  let total = 0;
  let page = 1;
  let mais = true;
  while (mais) {
    const r = await listTarefa({ tarefaPaiId: tarefaId, page, pageSize: 200 }, ctx);
    total += r.items.length;
    mais = r.hasMore;
    page += 1;
  }
  return total;
}

function progresso(itens: ItemRegistro[]): string {
  // progressoChecklist (derivado): itens feitos do total
  const feitos = itens.filter((i) => i.feito).length;
  return `${feitos}/${itens.length}`;
}

async function montarResumo(
  t: TarefaBase,
  ctx: RequestContext,
  leitor: Leitor,
  checklist: ItemRegistro[],
): Promise<TarefaResumo> {
  const dia = hoje(ctx);
  const aberta = tarefaAberta(t.status);
  const prazoDia = t.prazo.slice(0, 10);
  const quantidadeSubtarefas = await contarSubtarefas(t.id, ctx);
  const inner: TarefaResumo['details']['details'] = {
    quantidadeSubtarefas,
    progressoChecklist: progresso(checklist),
    // venceHoje / atrasada (derivados): prazo contra a data atual, só em tarefas abertas
    venceHoje: aberta && prazoDia === dia,
    atrasada: aberta && prazoDia < dia,
  };
  if (t.details.devolvidaEm != null) inner.devolvidaEm = t.details.devolvidaEm;
  const nomeLista = await leitor.nomeLista(t.listaId);
  const nomeResponsavel = await leitor.nomeMembro(t.responsavelId);
  const nomeCriador = await leitor.nomeMembro(t.criadorId);
  return {
    id: t.id,
    version: t.version,
    titulo: t.titulo,
    listaId: t.listaId,
    lista: { nome: nomeLista },
    responsavelId: t.responsavelId,
    responsavel: nomeMembroObjeto(nomeResponsavel),
    criadorId: t.criadorId,
    criador: nomeMembroObjeto(nomeCriador),
    prioridade: lerPrioridade(t.prioridade),
    prazo: t.prazo,
    status: lerStatus(t.status),
    details: { details: inner },
  };
}

async function montarAberta(
  t: TarefaBase,
  ctx: RequestContext,
  leitor: Leitor,
  checklist: ItemRegistro[],
): Promise<TarefaAberta> {
  const nomeLista = await leitor.nomeLista(t.listaId);
  const nomeResponsavel = await leitor.nomeMembro(t.responsavelId);
  const nomeCriador = await leitor.nomeMembro(t.criadorId);
  const inner: TarefaAberta['details']['details'] = {
    progressoChecklist: progresso(checklist),
  };
  if (t.details.descricao != null) inner.descricao = t.details.descricao;
  if (t.details.motivoDevolucao != null) inner.motivoDevolucao = t.details.motivoDevolucao;
  if (t.details.devolvidaEm != null) inner.devolvidaEm = t.details.devolvidaEm;
  if (t.details.concluidaEm != null) inner.concluidaEm = t.details.concluidaEm;
  if (t.details.canceladaEm != null) inner.canceladaEm = t.details.canceladaEm;
  const linhas: ItemChecklistLinha[] = checklist.map((it) => {
    const det: ItemChecklistLinha['details']['details'] = { descricao: it.details.descricao };
    if (it.details.marcadoEm != null) det.marcadoEm = it.details.marcadoEm;
    return { id: it.id, version: it.version, ordem: it.ordem, feito: it.feito, details: { details: det } };
  });
  return {
    id: t.id,
    version: t.version,
    titulo: t.titulo,
    status: lerStatus(t.status),
    prioridade: lerPrioridade(t.prioridade),
    prazo: t.prazo,
    listaId: t.listaId,
    lista: { nome: nomeLista },
    criadorId: t.criadorId,
    criador: nomeMembroObjeto(nomeCriador),
    responsavelId: t.responsavelId,
    responsavel: nomeMembroObjeto(nomeResponsavel),
    criadaEm: t.criadaEm,
    details: { details: inner },
    checklist: linhas,
  };
}

async function carregarSaida(
  id: string,
  ctx: RequestContext,
): Promise<{ tarefa: TarefaAberta; resumo: TarefaResumo }> {
  const t = await getTarefa({ id }, ctx);
  const leitor = criarLeitor(ctx);
  const checklist = await listarChecklist(id, ctx);
  const tarefa = await montarAberta(t, ctx, leitor, checklist);
  const resumo = await montarResumo(t, ctx, leitor, checklist);
  return { tarefa, resumo };
}

async function emTransacao<T>(ctx: RequestContext, corpo: (bound: RequestContext) => Promise<T>): Promise<T> {
  return ctx.data.moduleData.runInTransaction(async (tx) => {
    const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
    return corpo(bound);
  });
}

async function transicionar(
  bound: RequestContext,
  args: {
    id: string;
    version: number;
    transicao: AvancarEtapaTarefaInput['transicao'];
    ator: 'responsavel' | 'criador';
    ruleId: string;
    motivoDevolucao?: string;
  },
): Promise<{ tarefa: TarefaAberta; resumo: TarefaResumo }> {
  const membro = membroDaSessao(bound);
  const atual = await getTarefa({ id: args.id }, bound);
  if (args.ator === 'responsavel') {
    // somenteResponsavelExecuta
    if (atual.responsavelId !== membro) {
      throw new AppError('FORBIDDEN', 'somente o responsável da tarefa pode executar esta ação', 403, {
        ruleId: 'somenteResponsavelExecuta',
      });
    }
  } else if (atual.criadorId !== membro) {
    // somenteCriadorRevisa / cancelamentoPorCriadorOuGestor, conforme a transição
    throw new AppError('FORBIDDEN', 'somente o criador da tarefa pode executar esta ação', 403, {
      ruleId: args.ruleId,
    });
  }
  if (args.transicao === 'devolver' && (args.motivoDevolucao ?? '').trim() === '') {
    // devolucaoExigeMotivo
    throw new AppError('VALIDATION_ERROR', 'informe o motivo da devolução', 422, {
      ruleId: 'devolucaoExigeMotivo',
    });
  }
  // tarefaEncerradaNaoTransiciona
  if (!tarefaAberta(atual.status)) {
    throw new AppError('TAREFA_ENCERRADA', 'uma tarefa concluída ou cancelada não muda mais de situação', 409, {
      ruleId: 'tarefaEncerradaNaoTransiciona',
    });
  }
  if (atual.version !== args.version) {
    throw new AppError('CONFLICT', 'a tarefa foi alterada por outra pessoa; recarregue e tente de novo', 409);
  }
  const entrada: AvancarEtapaTarefaInput = { id: args.id, transicao: args.transicao };
  if (args.motivoDevolucao !== undefined) entrada.motivoDevolucao = args.motivoDevolucao.trim();
  await avancarEtapaTarefa(entrada, bound);
  return carregarSaida(args.id, bound);
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

export const requests: { [K in keyof Minhas_tarefasContracts]: (input: Minhas_tarefasContracts[K]['input'], ctx: RequestContext) => Promise<Minhas_tarefasContracts[K]['output']> } = {
  'tarefas.minhas_tarefas.minhasTarefas': async function (input, ctx) {
    const membro = membroDaSessao(ctx);
    const page = Math.max(1, Math.floor(input.page || 1));
    const pageSize = Math.min(200, Math.max(1, Math.floor(input.pageSize || 20)));

    const base: Omit<ListTarefaInput, 'page' | 'pageSize'> = {};
    if (input.status !== undefined) base.status = input.status;

    // editarSomenteTarefaVisivel: a visão se limita às tarefas em que o membro é criador ou responsável
    let candidatas: TarefaBase[];
    if (input.criadasPorMim === true || input.atribuidasAMim === true) {
      const filtros = { ...base };
      if (input.criadasPorMim === true) filtros.criadorId = membro;
      if (input.atribuidasAMim === true) filtros.responsavelId = membro;
      candidatas = await listarTarefas(filtros, ctx);
    } else {
      const criadas = await listarTarefas({ ...base, criadorId: membro }, ctx);
      const atribuidas = await listarTarefas({ ...base, responsavelId: membro }, ctx);
      const vistos = new Set<string>();
      candidatas = [];
      for (const t of [...criadas, ...atribuidas]) {
        if (vistos.has(t.id)) continue;
        vistos.add(t.id);
        candidatas.push(t);
      }
    }

    let filtradas = candidatas;
    if (input.somenteDevolvidas === true) {
      filtradas = candidatas.filter((t) => t.details.devolvidaEm != null && t.status === 'emAndamento');
    }

    filtradas.sort((a, b) => {
      const pa = a.prazo.slice(0, 10);
      const pb = b.prazo.slice(0, 10);
      if (pa !== pb) return pa < pb ? -1 : 1;
      return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
    });

    const inicio = (page - 1) * pageSize;
    const pagina = filtradas.slice(inicio, inicio + pageSize);
    const hasMore = inicio + pageSize < filtradas.length;

    const leitor = criarLeitor(ctx);
    const items: TarefaResumo[] = [];
    for (const t of pagina) {
      const checklist = await listarChecklist(t.id, ctx);
      items.push(await montarResumo(t, ctx, leitor, checklist));
    }
    return { tarefas: { items, page, pageSize, hasMore } };
  },

  'tarefas.minhas_tarefas.tarefaAberta': async function (input, ctx) {
    const membro = membroDaSessao(ctx);
    const t = await getTarefa({ id: input.tarefaId }, ctx);
    exigirVisivel(t, membro);
    const leitor = criarLeitor(ctx);
    const checklist = await listarChecklist(t.id, ctx);
    const tarefa = await montarAberta(t, ctx, leitor, checklist);
    return { tarefa };
  },

  'tarefas.minhas_tarefas.opcoesFormulario': async function (_input, ctx) {
    // listaInativaNaoRecebeTarefa: só listas ativas aparecem
    const ativas: { id: string; nome: string; ativa: boolean; tipo: string }[] = [];
    let page = 1;
    let mais = true;
    while (mais) {
      const r = await listLista({ ativa: true, page, pageSize: 200 }, ctx);
      for (const l of r.items) {
        if (l.ativa) ativas.push({ id: l.id, nome: l.nome, ativa: l.ativa, tipo: l.details.tipo });
      }
      mais = r.hasMore;
      page += 1;
    }
    ativas.sort((a, b) => a.nome.localeCompare(b.nome));
    const listas: ListaOpcao[] = ativas.map((l) => ({
      tarefa: { listaId: l.id },
      nome: l.nome,
      ativa: l.ativa,
      details: { details: { tipo: lerTipoLista(l.tipo) } },
    }));
    return { listas };
  },

  'tarefas.minhas_tarefas.buscarResponsaveis': async function (input, ctx) {
    const termo = normalizar(input.termo.trim());
    const encontrados: MembroRegistro[] = [];
    let page = 1;
    let mais = true;
    while (mais) {
      const r = await listMembroEquipe({ page, pageSize: 200 }, ctx);
      for (const m of r.items) {
        // responsavelDeveSerMembroAtivo: só situação Active
        if (m.details.identification.status !== 'Active') continue;
        if (!normalizar(m.details.identification.name).includes(termo)) continue;
        encontrados.push(m);
      }
      mais = r.hasMore;
      page += 1;
    }
    encontrados.sort((a, b) => a.details.identification.name.localeCompare(b.details.identification.name));
    const membros: MembroOpcao[] = encontrados.slice(0, LIMITE_RESPONSAVEIS).map((m) => ({
      responsavelId: m.id,
      details: {
        identification: {
          details: { identification: { name: m.details.identification.name, status: 'Active' } },
        },
      },
    }));
    return { membros };
  },

  'tarefas.minhas_tarefas.salvarNovaTarefa': async function (input, ctx) {
    return emTransacao(ctx, async (bound) => {
      const membro = membroDaSessao(bound);
      if (input.criadorId !== membro) {
        throw new AppError('FORBIDDEN', 'o criador deve ser o membro da sessão', 403);
      }

      // criacaoIdempotente: chave já usada devolve a tarefa existente, sem duplicar
      const existente = await listTarefa({ chaveCriacao: input.chaveCriacao, page: 1, pageSize: 1 }, bound);
      if (existente.items.length > 0) {
        return carregarSaida(existente.items[0].id, bound);
      }

      await exigirListaAtiva(input.listaId, bound);
      await exigirMembroAtivo(input.responsavelId, bound);

      const aberta = await abrirOcorrenciaTarefa(
        {
          titulo: input.titulo,
          prioridade: input.prioridade,
          prazo: input.prazo,
          listaId: input.listaId,
          responsavelId: input.responsavelId,
          chaveCriacao: input.chaveCriacao,
          ...(input.details.descricao !== undefined ? { details: { descricao: input.details.descricao } } : {}),
        },
        bound,
      );
      const tarefaId = aberta.tarefa.id;

      if (input.checklist !== undefined && input.checklist.length > 0) {
        const repo = resolveRepository<ItemChecklistRepository>(bound, 'ItemChecklistRepository');
        const itens = [...input.checklist].sort((a, b) => a.ordem - b.ordem);
        for (const item of itens) {
          await repo.create({
            tarefaId,
            ordem: item.ordem,
            feito: false,
            details: { descricao: item.details.details.descricao },
          });
        }
      }
      return carregarSaida(tarefaId, bound);
    });
  },

  'tarefas.minhas_tarefas.salvarEdicaoTarefa': async function (input, ctx) {
    return emTransacao(ctx, async (bound) => {
      const membro = membroDaSessao(bound);
      const atual: GetTarefaOutput = await getTarefa({ id: input.id }, bound);
      exigirVisivel(atual, membro);
      if (atual.version !== input.version) {
        throw new AppError('CONFLICT', 'a tarefa foi alterada por outra pessoa; recarregue e tente de novo', 409);
      }

      const trocouResponsavel = input.responsavelId !== atual.responsavelId;
      if (trocouResponsavel) {
        // reatribuicaoPorCriadorOuGestor
        if (atual.criadorId !== membro) {
          throw new AppError('FORBIDDEN', 'somente o criador da tarefa pode trocar o responsável', 403, {
            ruleId: 'reatribuicaoPorCriadorOuGestor',
          });
        }
        await exigirMembroAtivo(input.responsavelId, bound);
      }
      if (input.listaId !== atual.listaId) {
        await exigirListaAtiva(input.listaId, bound);
      }

      // edicaoNaoMudaSituacao: o status gravado é repassado como está
      const detalhes: UpdateTarefaInput['details'] = {};
      if (input.details.descricao !== undefined) detalhes.descricao = input.details.descricao;
      if (atual.details.motivoDevolucao != null) detalhes.motivoDevolucao = atual.details.motivoDevolucao;
      if (atual.details.devolvidaEm != null) detalhes.devolvidaEm = atual.details.devolvidaEm;
      if (atual.details.concluidaEm != null) detalhes.concluidaEm = atual.details.concluidaEm;
      if (atual.details.canceladaEm != null) detalhes.canceladaEm = atual.details.canceladaEm;
      const entrada: UpdateTarefaInput = {
        id: input.id,
        version: Number(input.version),
        titulo: input.titulo,
        status: atual.status,
        prioridade: input.prioridade,
        prazo: input.prazo,
        listaId: input.listaId,
        responsavelId: atual.responsavelId,
        criadorId: atual.criadorId,
        chaveCriacao: atual.chaveCriacao,
        details: detalhes,
      };
      if (atual.tarefaPaiId !== undefined) entrada.tarefaPaiId = atual.tarefaPaiId;
      await updateTarefa(entrada, bound);

      if (input.checklist !== undefined) {
        // checklistNaoMudaSituacao: os itens são gravados sem tocar na situação da tarefa
        const existentes = await listarChecklist(input.id, bound);
        const porId = new Map<string, ItemRegistro>();
        for (const ex of existentes) porId.set(ex.id, ex);
        const mantidos = new Set<string>();
        const repo = resolveRepository<ItemChecklistRepository>(bound, 'ItemChecklistRepository');
        for (const item of input.checklist) {
          const descricao = item.details.details.descricao;
          if (item.id !== undefined && item.id !== '') {
            const ex = porId.get(item.id);
            if (ex === undefined) {
              throw new AppError('NOT_FOUND', `item de checklist não encontrado nesta tarefa: ${item.id}`, 404);
            }
            mantidos.add(ex.id);
            if (ex.ordem !== item.ordem || ex.details.descricao !== descricao) {
              const det: UpdateItemChecklistInput['details'] = { descricao };
              if (ex.details.marcadoEm != null) det.marcadoEm = ex.details.marcadoEm;
              await updateItemChecklist(
                {
                  id: ex.id,
                  version: Number(item.version ?? ex.version),
                  tarefaId: input.id,
                  ordem: item.ordem,
                  feito: ex.feito,
                  details: det,
                },
                bound,
              );
            }
          } else {
            await repo.create({ tarefaId: input.id, ordem: item.ordem, feito: false, details: { descricao } });
          }
        }
        for (const ex of existentes) {
          if (!mantidos.has(ex.id)) await repo.delete(ex.id);
        }
      }

      if (trocouResponsavel) {
        await reatribuirQuemAge({ id: input.id, responsavelId: input.responsavelId }, bound);
      }
      return carregarSaida(input.id, bound);
    });
  },

  'tarefas.minhas_tarefas.iniciarTarefa': async function (input, ctx) {
    return emTransacao(ctx, (bound) =>
      transicionar(bound, {
        id: input.id,
        version: input.version,
        transicao: 'iniciar',
        ator: 'responsavel',
        ruleId: 'somenteResponsavelExecuta',
      }),
    );
  },

  'tarefas.minhas_tarefas.marcarItemChecklist': async function (input, ctx) {
    return emTransacao(ctx, async (bound) => {
      const membro = membroDaSessao(bound);
      const encontrados = await listItemChecklist({ id: input.id, page: 1, pageSize: 1 }, bound);
      if (encontrados.items.length === 0) {
        throw new AppError('NOT_FOUND', `item de checklist não encontrado: ${input.id}`, 404);
      }
      const item: ItemRegistro = encontrados.items[0];
      const tarefa = await getTarefa({ id: item.tarefaId }, bound);
      exigirVisivel(tarefa, membro);
      if (item.version !== input.version) {
        throw new AppError('CONFLICT', 'o item foi alterado por outra pessoa; recarregue e tente de novo', 409);
      }
      // checklistNaoMudaSituacao: só o item é gravado; a situação da tarefa não é tocada
      const det: UpdateItemChecklistInput['details'] = { descricao: item.details.descricao };
      if (input.feito) det.marcadoEm = bound.clock.nowIso();
      await updateItemChecklist(
        {
          id: item.id,
          version: Number(input.version),
          tarefaId: item.tarefaId,
          ordem: item.ordem,
          feito: input.feito,
          details: det,
        },
        bound,
      );
      return carregarSaida(item.tarefaId, bound);
    });
  },

  'tarefas.minhas_tarefas.enviarParaRevisao': async function (input, ctx) {
    return emTransacao(ctx, (bound) =>
      transicionar(bound, {
        id: input.id,
        version: input.version,
        transicao: 'enviarParaRevisao',
        ator: 'responsavel',
        ruleId: 'somenteResponsavelExecuta',
      }),
    );
  },

  'tarefas.minhas_tarefas.aceitarEntrega': async function (input, ctx) {
    return emTransacao(ctx, (bound) =>
      transicionar(bound, {
        id: input.id,
        version: input.version,
        transicao: 'aceitar',
        ator: 'criador',
        ruleId: 'somenteCriadorRevisa',
      }),
    );
  },

  'tarefas.minhas_tarefas.devolverComMotivo': async function (input, ctx) {
    return emTransacao(ctx, (bound) =>
      transicionar(bound, {
        id: input.id,
        version: input.version,
        transicao: 'devolver',
        ator: 'criador',
        ruleId: 'somenteCriadorRevisa',
        motivoDevolucao: input.details.motivoDevolucao,
      }),
    );
  },

  'tarefas.minhas_tarefas.cancelarTarefa': async function (input, ctx) {
    return emTransacao(ctx, (bound) =>
      transicionar(bound, {
        id: input.id,
        version: input.version,
        transicao: 'cancelar',
        ator: 'criador',
        ruleId: 'cancelamentoPorCriadorOuGestor',
      }),
    );
  },
};

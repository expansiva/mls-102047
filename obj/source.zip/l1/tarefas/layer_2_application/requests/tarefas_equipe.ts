/// <mls fileReference="_102047_/l1/tarefas/layer_2_application/requests/tarefas_equipe.ts" enhancement="_blank"/>
import type { Tarefas_equipeContracts, TarefaEquipeItem, TarefaDetalhe, MembroResumo, ListaResumo, ItemChecklistLinha } from '/_102047_/l2/tarefas/web/contracts/tarefas_equipe.defs.js';
import { AppError } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import type { RequestContext } from '/_102034_/l1/server/layer_2_controllers/contracts.js';
import { getTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/getTarefa.js';
import { listTarefa } from '/_102047_/l1/tarefas/layer_2_application/usecases/listTarefa.js';
import { getLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/getLista.js';
import { listLista } from '/_102047_/l1/tarefas/layer_2_application/usecases/listLista.js';
import { getMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/getMembroEquipe.js';
import { listMembroEquipe } from '/_102047_/l1/tarefas/layer_2_application/usecases/listMembroEquipe.js';
import { listItemChecklist } from '/_102047_/l1/tarefas/layer_2_application/usecases/listItemChecklist.js';
import { reatribuirQuemAge, avancarEtapaTarefa } from '/_102047_/l1/tarefas/layer_2_application/workflows/cicloTarefa.js';

type Contracts = Tarefas_equipeContracts;

interface TarefaRecord {
  id: string;
  version: number;
  titulo: string;
  status: string;
  prioridade: string;
  prazo: string;
  responsavelId: string;
  criadorId: string;
  criadaEm: string;
  details: {
    descricao?: string | null;
    motivoDevolucao?: string | null;
    devolvidaEm?: string | null;
    concluidaEm?: string | null;
    canceladaEm?: string | null;
  };
}

const PAGE_SIZE_MAX = 200;

function isAberta(status: string): boolean {
  return status === 'aFazer' || status === 'emAndamento' || status === 'emRevisao';
}

function dayOf(value: string): string {
  return value.slice(0, 10);
}

function todayOf(ctx: RequestContext): string {
  return dayOf(ctx.clock.nowIso());
}

function isGestor(ctx: RequestContext): boolean {
  const scope = ctx.sessionContext.actorScope ?? [];
  return scope.some((s) => s === 'gestor' || s.endsWith(':gestor'));
}

async function collectAll<T>(fetchPage: (page: number) => Promise<{ items: T[]; hasMore: boolean }>): Promise<T[]> {
  const all: T[] = [];
  let page = 1;
  for (;;) {
    const result = await fetchPage(page);
    for (const item of result.items) all.push(item);
    if (!result.hasMore) break;
    page += 1;
  }
  return all;
}

async function membroResumo(ctx: RequestContext, id: string): Promise<MembroResumo> {
  const membro = await getMembroEquipe({ id }, ctx);
  return {
    id: membro.id,
    details: {
      identification: {
        name: membro.details.identification.name,
        status: membro.details.identification.status as MembroResumo['details']['identification']['status'],
      },
    },
  };
}

async function listarChecklist(ctx: RequestContext, tarefaId: string) {
  const itens = await collectAll((page) => listItemChecklist({ tarefaId, page, pageSize: PAGE_SIZE_MAX }, ctx));
  return itens.slice().sort((a, b) => a.ordem - b.ordem);
}

function progresso(itens: { feito: boolean }[]): string {
  const feitos = itens.filter((i) => i.feito).length;
  return `${feitos}/${itens.length}`;
}

async function montarDetalhe(ctx: RequestContext, tarefa: TarefaRecord): Promise<TarefaDetalhe> {
  const criador = await membroResumo(ctx, tarefa.criadorId);
  const responsavel = await membroResumo(ctx, tarefa.responsavelId);
  const itens = await listarChecklist(ctx, tarefa.id);
  const subtarefas = await collectAll((page) => listTarefa({ tarefaPaiId: tarefa.id, page, pageSize: PAGE_SIZE_MAX }, ctx));
  const itensChecklist: ItemChecklistLinha[] = itens.map((i) => ({
    id: i.id,
    ordem: i.ordem,
    feito: i.feito,
    details: { descricao: i.details.descricao },
  }));
  const d = tarefa.details;
  return {
    id: tarefa.id,
    version: tarefa.version,
    titulo: tarefa.titulo,
    status: tarefa.status as TarefaDetalhe['status'],
    prioridade: tarefa.prioridade as TarefaDetalhe['prioridade'],
    prazo: tarefa.prazo,
    criadaEm: tarefa.criadaEm,
    criadorId: tarefa.criadorId,
    criador,
    responsavelId: tarefa.responsavelId,
    responsavel,
    details: {
      ...(d.descricao != null ? { descricao: d.descricao } : {}),
      ...(d.motivoDevolucao != null ? { motivoDevolucao: d.motivoDevolucao } : {}),
      ...(d.devolvidaEm != null ? { devolvidaEm: d.devolvidaEm } : {}),
      ...(d.concluidaEm != null ? { concluidaEm: d.concluidaEm } : {}),
      ...(d.canceladaEm != null ? { canceladaEm: d.canceladaEm } : {}),
      aberta: isAberta(tarefa.status),
      quantidadeSubtarefas: subtarefas.length,
      progressoChecklist: progresso(itens),
    },
    itensChecklist,
  };
}

function checkVersion(atual: number, informada: number): void {
  if (Number(informada) !== atual) {
    throw new AppError('VERSION_CONFLICT', 'A tarefa foi alterada por outra pessoa; recarregue e tente de novo.', 409);
  }
}

export const requests: { [K in keyof Tarefas_equipeContracts]: (input: Tarefas_equipeContracts[K]['input'], ctx: RequestContext) => Promise<Tarefas_equipeContracts[K]['output']> } = {
  "tarefas.tarefas_equipe.carregarOpcoesEquipe": async function (input, ctx) {
    const listasRaw = await collectAll((page) => listLista({ page, pageSize: PAGE_SIZE_MAX }, ctx));
    const membrosRaw = await collectAll((page) => listMembroEquipe({ page, pageSize: PAGE_SIZE_MAX }, ctx));
    const listas: ListaResumo[] = listasRaw
      .map((l) => ({ id: l.id, nome: l.nome }))
      .sort((a, b) => a.nome.localeCompare(b.nome));
    // responsavelDeveSerMembroAtivo: the status is returned so the page can tell active members (the only accepted as responsável).
    const membros: MembroResumo[] = membrosRaw
      .map((m) => ({
        id: m.id,
        details: {
          identification: {
            name: m.details.identification.name,
            status: m.details.identification.status as MembroResumo['details']['identification']['status'],
          },
        },
      }))
      .sort((a, b) => a.details.identification.name.localeCompare(b.details.identification.name));
    return { listas, membros };
  },

  "tarefas.tarefas_equipe.listarTarefasEquipe": async function (input, ctx) {
    const page = input.page >= 1 ? Math.floor(input.page) : 1;
    const pageSize = input.pageSize >= 1 ? Math.min(PAGE_SIZE_MAX, Math.floor(input.pageSize)) : 20;
    const today = todayOf(ctx);

    // editarSomenteTarefaVisivel: the gestor sees all the tasks of the team (organization scope), so no visibility narrowing here.
    const todas = await collectAll((p) =>
      listTarefa(
        {
          ...(input.listaId ? { listaId: input.listaId } : {}),
          ...(input.responsavelId ? { responsavelId: input.responsavelId } : {}),
          ...(input.prioridade ? { prioridade: input.prioridade } : {}),
          ...(input.status ? { status: input.status } : {}),
          page: p,
          pageSize: PAGE_SIZE_MAX,
        },
        ctx,
      ),
    );

    const querVenceHoje = input.details?.venceHoje === true;
    const queAtrasada = input.details?.atrasada === true;

    const sinais = (t: { status: string; prazo: string }) => {
      const aberta = isAberta(t.status);
      const prazo = dayOf(t.prazo);
      return { venceHoje: aberta && prazo === today, atrasada: aberta && prazo < today };
    };

    const filtradas = todas.filter((t) => {
      const prazo = dayOf(t.prazo);
      if (input.prazoDe && prazo < dayOf(input.prazoDe)) return false;
      if (input.prazoAte && prazo > dayOf(input.prazoAte)) return false;
      if (querVenceHoje || queAtrasada) {
        const s = sinais(t);
        if (!((querVenceHoje && s.venceHoje) || (queAtrasada && s.atrasada))) return false;
      }
      return true;
    });

    const ordenadas = filtradas.slice().sort((a, b) => {
      const sa = sinais(a);
      const sb = sinais(b);
      const ga = sa.venceHoje || sa.atrasada ? 0 : 1;
      const gb = sb.venceHoje || sb.atrasada ? 0 : 1;
      if (ga !== gb) return ga - gb;
      const pa = dayOf(a.prazo);
      const pb = dayOf(b.prazo);
      if (pa !== pb) return pa < pb ? -1 : 1;
      return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
    });

    const inicio = (page - 1) * pageSize;
    const pagina = ordenadas.slice(inicio, inicio + pageSize);
    const hasMore = ordenadas.length > inicio + pageSize;

    const listaCache = new Map<string, ListaResumo>();
    const membroCache = new Map<string, MembroResumo>();

    const items: TarefaEquipeItem[] = [];
    for (const t of pagina) {
      let lista = listaCache.get(t.listaId);
      if (!lista) {
        const l = await getLista({ id: t.listaId }, ctx);
        lista = { id: l.id, nome: l.nome };
        listaCache.set(t.listaId, lista);
      }
      let responsavel = membroCache.get(t.responsavelId);
      if (!responsavel) {
        responsavel = await membroResumo(ctx, t.responsavelId);
        membroCache.set(t.responsavelId, responsavel);
      }
      const itens = await listarChecklist(ctx, t.id);
      const s = sinais(t);
      items.push({
        id: t.id,
        titulo: t.titulo,
        listaId: t.listaId,
        lista,
        responsavelId: t.responsavelId,
        responsavel,
        prioridade: t.prioridade as TarefaEquipeItem['prioridade'],
        prazo: t.prazo,
        status: t.status as TarefaEquipeItem['status'],
        details: {
          venceHoje: s.venceHoje,
          atrasada: s.atrasada,
          progressoChecklist: progresso(itens),
        },
      });
    }

    return { tarefas: { items, page, pageSize, hasMore } };
  },

  "tarefas.tarefas_equipe.obterTarefa": async function (input, ctx) {
    const tarefa = await getTarefa({ id: String(input.tarefaId) }, ctx);
    return { tarefa: await montarDetalhe(ctx, tarefa) };
  },

  "tarefas.tarefas_equipe.reatribuirTarefa": async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const atual = await getTarefa({ id: String(input.id) }, bound);
      const actorId = bound.sessionContext.actorId;

      // editarSomenteTarefaVisivel: the gestor sees every task; others only the ones they created or are responsible for.
      if (!isGestor(bound) && actorId !== atual.criadorId && actorId !== atual.responsavelId) {
        throw new AppError('FORBIDDEN', 'A tarefa não é visível para quem chama.', 403, { ruleId: 'editarSomenteTarefaVisivel' });
      }
      if (!isGestor(bound) && actorId !== atual.criadorId) {
        throw new AppError('FORBIDDEN', 'Somente o criador da tarefa ou o gestor pode trocar o responsável.', 403, { ruleId: 'reatribuicaoPorCriadorOuGestor' });
      }
      const novo = await getMembroEquipe({ id: String(input.responsavelId) }, bound);
      if (novo.details.identification.status !== 'Active') {
        throw new AppError('RESPONSAVEL_INATIVO', 'O novo responsável deve ser um membro ativo da equipe.', 422, { ruleId: 'responsavelDeveSerMembroAtivo' });
      }
      checkVersion(atual.version, input.version);

      const resultado = await reatribuirQuemAge({ id: atual.id, novoResponsavelId: novo.id }, bound);
      // edicaoNaoMudaSituacao: only responsavelId changes; the status must stay the same.
      if (resultado.tarefa.status !== atual.status) {
        throw new AppError('SITUACAO_ALTERADA', 'A reatribuição não pode alterar a situação da tarefa.', 409, { ruleId: 'edicaoNaoMudaSituacao' });
      }
      return { tarefa: await montarDetalhe(bound, resultado.tarefa) };
    });
  },

  "tarefas.tarefas_equipe.cancelarTarefa": async function (input, ctx) {
    return ctx.data.moduleData.runInTransaction(async (tx) => {
      const bound: RequestContext = { ...ctx, data: { ...ctx.data, moduleData: tx } };
      const atual = await getTarefa({ id: String(input.id) }, bound);
      const actorId = bound.sessionContext.actorId;

      if (atual.status === 'concluida' || atual.status === 'cancelada') {
        throw new AppError('TAREFA_ENCERRADA', 'Tarefa concluída ou cancelada não muda mais de situação.', 409, { ruleId: 'tarefaEncerradaNaoTransiciona' });
      }
      if (!isGestor(bound) && actorId !== atual.criadorId) {
        throw new AppError('FORBIDDEN', 'Somente o criador da tarefa ou o gestor pode cancelá-la.', 403, { ruleId: 'cancelamentoPorCriadorOuGestor' });
      }
      if (!isAberta(atual.status)) {
        throw new AppError('TRANSICAO_INVALIDA', 'A tarefa só pode ser cancelada a fazer, em andamento ou em revisão.', 409, { ruleId: 'cancelamentoPorCriadorOuGestor' });
      }
      checkVersion(atual.version, input.version);

      const resultado = await avancarEtapaTarefa({ id: atual.id, transicao: 'cancelar' }, bound);
      return { tarefa: await montarDetalhe(bound, resultado.tarefa) };
    });
  },
};

/// <mls fileReference="_102047_/l1/controleEstoque/layer_2_application/usecases/createMovimentacaoEstoque.defs.ts" enhancement="_blank"/>

export const definition = {
  "schemaVersion": "2026-09-24-d1-definition-v2",
  "artifactType": "usecase",
  "artifactId": "createMovimentacaoEstoque",
  "moduleName": "controleEstoque",
  "status": "generated",
  "dependencies": [
    "_102047_/l1/controleEstoque/layer_2_application/ports/movimentacaoEstoqueRepository.defs.ts",
    "_102047_/l1/controleEstoque/layer_3_domain/entities/movimentacaoEstoque.defs.ts",
    "_102047_/l4/controleEstoque/ontology/MovimentacaoEstoque.defs.ts",
    "_102047_/l4/controleEstoque/rules.defs.ts"
  ],
  "data": {
    "usecaseId": "createMovimentacaoEstoque",
    "entityId": "MovimentacaoEstoque",
    "operation": "create",
    "ports": [
      "MovimentacaoEstoqueRepository"
    ],
    "rulesApplied": [],
    "functions": [
      {
        "functionName": "createMovimentacaoEstoque",
        "input": [
          {
            "name": "produtoId",
            "type": "record",
            "fieldRef": "MovimentacaoEstoque.produtoId"
          },
          {
            "name": "movimentadoEm",
            "type": "timestamp",
            "fieldRef": "MovimentacaoEstoque.movimentadoEm"
          },
          {
            "name": "details",
            "type": "object",
            "fieldRef": "MovimentacaoEstoque.details"
          },
          {
            "name": "details.tipo",
            "type": "enum",
            "fieldRef": "MovimentacaoEstoque.details.tipo"
          },
          {
            "name": "details.quantidade",
            "type": "integer",
            "fieldRef": "MovimentacaoEstoque.details.quantidade"
          }
        ],
        "output": [
          {
            "name": "id",
            "type": "uuid",
            "fieldRef": "MovimentacaoEstoque.id"
          },
          {
            "name": "version",
            "type": "integer",
            "fieldRef": "MovimentacaoEstoque.version"
          },
          {
            "name": "produtoId",
            "type": "record",
            "fieldRef": "MovimentacaoEstoque.produtoId"
          },
          {
            "name": "movimentadoEm",
            "type": "timestamp",
            "fieldRef": "MovimentacaoEstoque.movimentadoEm"
          },
          {
            "name": "details",
            "type": "object",
            "fieldRef": "MovimentacaoEstoque.details"
          },
          {
            "name": "details.tipo",
            "type": "enum",
            "fieldRef": "MovimentacaoEstoque.details.tipo"
          },
          {
            "name": "details.quantidade",
            "type": "integer",
            "fieldRef": "MovimentacaoEstoque.details.quantidade"
          }
        ]
      }
    ],
    "portCalls": [
      "create"
    ],
    "transactional": false,
    "effects": [],
    "sequence": [
      {
        "kind": "context",
        "source": "ctx"
      },
      {
        "kind": "port",
        "call": "create",
        "port": "MovimentacaoEstoqueRepository"
      }
    ],
    "uses": [],
    "rules": [],
    "rulePlan": [
      {
        "ruleId": "movimentacaoEstoqueImutavel",
        "origin": "l4/controleEstoque/rules.defs.ts#movimentacaoEstoqueImutavel",
        "consumer": "operation:create",
        "enforcement": "pending",
        "gap": "RULE_UNBOUND"
      },
      {
        "ruleId": "quantidadeMovimentadaPositiva",
        "origin": "l4/controleEstoque/rules.defs.ts#quantidadeMovimentadaPositiva",
        "consumer": "operation:create",
        "enforcement": "pending",
        "gap": "RULE_UNBOUND"
      },
      {
        "ruleId": "registroMovimentacaoAtualizaSaldo",
        "origin": "l4/controleEstoque/rules.defs.ts#registroMovimentacaoAtualizaSaldo",
        "consumer": "operation:create",
        "enforcement": "pending",
        "gap": "RULE_UNBOUND"
      }
    ],
    "transaction": {
      "boundary": "none"
    }
  }
} as const;

export default definition;

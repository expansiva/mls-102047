/// <mls fileReference="_102047_/l1/controleEstoque/layer_2_application/usecases/listMovimentacaoEstoque.defs.ts" enhancement="_blank"/>

export const definition = {
  "schemaVersion": "2026-09-24-d1-definition-v2",
  "artifactType": "usecase",
  "artifactId": "listMovimentacaoEstoque",
  "moduleName": "controleEstoque",
  "status": "generated",
  "dependencies": [
    "_102047_/l1/controleEstoque/layer_2_application/ports/movimentacaoEstoqueRepository.defs.ts",
    "_102047_/l1/controleEstoque/layer_3_domain/entities/movimentacaoEstoque.defs.ts",
    "_102047_/l4/controleEstoque/ontology/MovimentacaoEstoque.defs.ts"
  ],
  "data": {
    "usecaseId": "listMovimentacaoEstoque",
    "entityId": "MovimentacaoEstoque",
    "operation": "list",
    "ports": [
      "MovimentacaoEstoqueRepository"
    ],
    "rulesApplied": [],
    "functions": [
      {
        "functionName": "listMovimentacaoEstoque",
        "input": [
          {
            "name": "id",
            "type": "uuid",
            "fieldRef": "MovimentacaoEstoque.id"
          },
          {
            "name": "produtoId",
            "type": "record",
            "fieldRef": "MovimentacaoEstoque.produtoId"
          },
          {
            "name": "movimentadoEm",
            "type": "timestamp",
            "fieldRef": "MovimentacaoEstoque.movimentadoEm"
          },
          {
            "name": "details",
            "type": "object",
            "fieldRef": "MovimentacaoEstoque.details"
          },
          {
            "name": "details.tipo",
            "type": "enum",
            "fieldRef": "MovimentacaoEstoque.details.tipo"
          },
          {
            "name": "details.quantidade",
            "type": "integer",
            "fieldRef": "MovimentacaoEstoque.details.quantidade"
          },
          {
            "name": "page",
            "type": "number"
          },
          {
            "name": "pageSize",
            "type": "number"
          }
        ],
        "output": [
          {
            "name": "items",
            "type": "MovimentacaoEstoque"
          },
          {
            "name": "hasMore",
            "type": "boolean"
          }
        ]
      }
    ],
    "portCalls": [
      "list"
    ],
    "transactional": false,
    "effects": [],
    "sequence": [
      {
        "kind": "context",
        "source": "ctx"
      },
      {
        "kind": "port",
        "call": "list",
        "port": "MovimentacaoEstoqueRepository"
      }
    ],
    "uses": [
      {
        "path": "id",
        "role": "filter",
        "source": "input"
      }
    ],
    "rules": [],
    "rulePlan": [],
    "transaction": {
      "boundary": "none"
    }
  }
} as const;

export default definition;

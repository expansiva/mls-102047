/// <mls fileReference="_102047_/l1/controleEstoque/layer_1_external/adapters/http/controllers/produtos.defs.ts" enhancement="_blank"/>

export const definition = {
  "schemaVersion": "2026-09-24-d1-definition-v2",
  "artifactType": "httpController",
  "artifactId": "produtos",
  "moduleName": "controleEstoque",
  "status": "generated",
  "dependencies": [
    "_102047_/l1/controleEstoque/layer_1_external/auth/authorityMap.defs.ts",
    "_102047_/l1/controleEstoque/layer_2_application/requests/produtos.defs.ts",
    "_102047_/l1/controleEstoque/layer_2_application/scope/accessScope.defs.ts"
  ],
  "data": {
    "pageId": "produtos",
    "handlers": [
      {
        "route": "controleEstoque.produtos.cadastrarProduto",
        "kind": "command",
        "grantIds": [
          "gerenciarEstoque"
        ],
        "serviceFunction": "controleEstoque.produtos.cadastrarProduto",
        "contractPath": "l2/controleEstoque/web/contracts/produtos.defs.ts",
        "contractInterface": "ProdutosContracts"
      },
      {
        "route": "controleEstoque.produtos.load",
        "kind": "query",
        "grantIds": [
          "gerenciarEstoque"
        ],
        "serviceFunction": "controleEstoque.produtos.load",
        "contractPath": "l2/controleEstoque/web/contracts/produtos.defs.ts",
        "contractInterface": "ProdutosContracts"
      },
      {
        "route": "controleEstoque.produtos.loadProdutos",
        "kind": "query",
        "grantIds": [
          "gerenciarEstoque"
        ],
        "serviceFunction": "controleEstoque.produtos.loadProdutos",
        "contractPath": "l2/controleEstoque/web/contracts/produtos.defs.ts",
        "contractInterface": "ProdutosContracts"
      }
    ]
  }
} as const;

export default definition;

/// <mls fileReference="_102047_/l2/comandaRestaurante/web/mobile/page11/mesas.ts" enhancement="_102020_/l2/enhancementAura"/>

import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ComandaRestauranteMesasShared } from '/_102047_/l2/comandaRestaurante/web/shared/mesas.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start
const pageMessage_pt = {
pageTitle: 'Mesas',
listTitle: 'Mesas da casa',
createMesa: 'Cadastrar mesa',
editMesa: 'Editar mesa',
back: 'Voltar para mesas',
code: 'Código da mesa',
codePlaceholder: 'Ex.: 12',
codeHelper: 'Informe o código usado pelo garçom e pelo caixa.',
saveCreate: 'Cadastrar mesa',
saveUpdate: 'Salvar alterações',
available: 'Disponível',
occupied: 'Ocupada',
loading: 'Carregando mesas…',
empty: 'Nenhuma mesa cadastrada.',
loadError: 'Não foi possível carregar as mesas.',
retry: 'Tentar novamente',
createError: 'Não foi possível cadastrar a mesa.',
updateError: 'Não foi possível atualizar a mesa.',
saved: 'Mesa salva.'
};
type PageMessageType = typeof pageMessage_pt;
const pageMessages: Record<string, PageMessageType> = { pt: pageMessage_pt };
/// **collab_i18n_end
const formatStatus = (available: boolean, msg: PageMessageType) => available ? msg.available : msg.occupied;
@customElement('comanda-restaurante--web--mobile--page11--mesas-102047')
export class ComandaRestauranteMobilePage11MesasPage extends ComandaRestauranteMesasShared {
private msg!: PageMessageType;
private renderList() {
const loading = this.pageStatus === 'loading' || this.carregarMesasStatus === 'loading';
const loadError = this.carregarMesasError?.message || this.msg.loadError;
return html`
<main class="min-h-screen bg-[var(--page-bg,transparent)] px-4 py-5 text-[var(--text-default,currentColor)]">
<header class="mb-5">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg.pageTitle}</h1>
<p class="mt-1 text-sm text-[var(--text-muted,currentColor)]">${this.msg.listTitle}</p>
</header>
<div class="mb-4">
<grouptriggeraction--ml-button-standard
data-variant="primary"
size="lg"
.disabled=${loading}
@action=${() => { this.selectMesa(null); this.setScenario('form'); }}>
<Label>${this.msg.createMesa}</Label>
</grouptriggeraction--ml-button-standard>
</div>
${this.carregarMesasStatus === 'error' ? html`
<div class="mb-4 rounded-lg border border-[var(--status-error-text,currentColor)] bg-[var(--status-error-bg,transparent)] p-3" aria-live="polite">
<p class="text-sm text-[var(--status-error-text,currentColor)]">${loadError}</p>
<grouptriggeraction--ml-button-standard
class="mt-3"
data-variant="secondary"
size="md"
@action=${() => this.carregarMesas()}>
<Label>${this.msg.retry}</Label>
</grouptriggeraction--ml-button-standard>
</div>
` : html`
<groupviewdata--ml-vertical-record-list .loading=${loading} hoverable
@row-click=${(e: CustomEvent<{ index: number }>) => {
const mesa = this.mesas[e.detail.index];
if (mesa) { this.selectMesa(mesa.id); this.setScenario('form'); }
}}>
<Columns>
<Column field="code" header=${this.msg.code}></Column>
<Column field="status" header=${this.msg.available}></Column>
</Columns>
<Rows>
${this.mesas.map((mesa, index) => html`
<Row ?selected=${this.selectedMesa?.id === mesa.id}>
<Cell>
<div class="font-semibold text-lg text-[var(--text-strong,currentColor)]">${mesa.code}</div>
</Cell>
<Cell>
<span class="inline-flex rounded-full px-2.5 py-1 text-sm ${mesa.details.disponivel ? 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]' : 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]'}">
${formatStatus(mesa.details.disponivel, this.msg)}
</span>
</Cell>
</Row>
`)}
</Rows>
<Loading><div class="py-10 text-center text-[var(--text-muted,currentColor)]">${this.msg.loading}</div></Loading>
<Empty><div class="py-10 text-center text-[var(--text-muted,currentColor)]">${this.msg.empty}</div></Empty>
</groupviewdata--ml-vertical-record-list>
`}
</main>
`;
}
private renderForm() {
const editing = this.selectedMesa !== null;
const commandStatus = editing ? this.atualizarMesaStatus : this.criarMesaStatus;
const commandError = editing ? this.atualizarMesaError : this.criarMesaError;
const loading = commandStatus === 'loading';
const value = this.mesaFormDraft.code || '';
return html`
<section class="min-h-screen bg-[var(--page-bg,transparent)] px-4 py-5 text-[var(--text-default,currentColor)]">
<div class="mb-6">
<p class="mb-2 text-sm text-[var(--text-muted,currentColor)]">${editing ? this.msg.editMesa : this.msg.createMesa}</p>
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${editing ? this.selectedMesa?.code : this.msg.createMesa}</h1>
</div>
<div data-organism-id="mesaForm" class="rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4">
<groupentertext--ml-enter-text
.value=${value}
name="code"
placeholder=${this.msg.codePlaceholder}
required
?loading=${loading}
@input=${(e: CustomEvent<{ value: string }>) => this.setMesaForm({ code: e.detail.value })}
@change=${(e: CustomEvent<{ value: string }>) => this.setMesaForm({ code: e.detail.value })}>
<Label>${this.msg.code}</Label>
<Helper>${this.msg.codeHelper}</Helper>
</groupentertext--ml-enter-text>
${commandError ? html`<p class="mt-4 text-sm text-[var(--status-error-text,currentColor)]" aria-live="polite">${commandError.message || (editing ? this.msg.updateError : this.msg.createError)}</p>` : nothing}
<div class="mt-6">
<grouptriggeraction--ml-button-standard
data-variant="primary"
size="lg"
.disabled=${loading || !value}
.loading=${loading}
@action=${() => editing ? this.atualizarMesa() : this.criarMesa()}>
<Label>${editing ? this.msg.saveUpdate : this.msg.saveCreate}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</div>
</section>
`;
}
render() {
this.msg = pageMessages[this.getMessageKey(pageMessages)];
return html`
<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'list'}
backLabel=${this.msg.back}
@change=${(e: CustomEvent<{ value: string }>) => { if (e.target === e.currentTarget) this.setScenario(e.detail.value); }}>
<Scene value="list" title=${this.msg.listTitle}>
<div data-organism-id="mesasList">${this.renderList()}</div>
</Scene>
<Scene value="form" title=${this.selectedMesa ? this.msg.editMesa : this.msg.createMesa} nav="back" backTo="list">
${this.renderForm()}
</Scene>
</molecules--ml-scenary-102020>
`;
}
}

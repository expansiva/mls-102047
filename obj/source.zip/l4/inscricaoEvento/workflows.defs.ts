/// <mls fileReference="_102047_/l4/inscricaoEvento/workflows.defs.ts" enhancement="_blank"/>

import type { Ns5WorkflowsArtifact } from '/_102035_/l2/solution/types.js';

export const inscricaoEventoWorkflows = {
  "schemaVersion": "2026-09-17-ns5-workflows-v3",
  "moduleName": "inscricaoEvento",
  "processes": [
    {
      "processId": "promoverListaEsperaAposCancelamento",
      "title": "Promover lista de espera após cancelamento",
      "description": "Promove automaticamente o primeiro inscrito da lista de espera quando um cancelamento libera uma vaga.",
      "trigger": {
        "kind": "event",
        "event": "Inscricao.cancelarInscricao"
      },
      "tasks": [
        {
          "taskId": "promoverPrimeiraInscricaoEmEspera",
          "kind": "mechanical",
          "entityRef": "Inscricao",
          "effect": "transition",
          "transitionRef": "promoverDaListaEspera",
          "next": [],
          "description": "Quando o cancelamento liberar uma vaga, promove a primeira inscrição da lista de espera pela ordem de chegada."
        }
      ]
    }
  ],
  "journeyDecisions": [
    {
      "journeyId": "cadastrarEpublicarEvento",
      "inProcess": false
    },
    {
      "journeyId": "inscreverSeEmEvento",
      "inProcess": false
    },
    {
      "journeyId": "cancelarInscricao",
      "inProcess": false
    },
    {
      "journeyId": "acompanharEexportarInscricoes",
      "inProcess": false
    }
  ]
} as const satisfies Ns5WorkflowsArtifact;

export type InscricaoEventoWorkflowsType = typeof inscricaoEventoWorkflows;

export default inscricaoEventoWorkflows;

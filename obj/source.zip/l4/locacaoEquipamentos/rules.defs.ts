/// <mls fileReference="_102047_/l4/locacaoEquipamentos/rules.defs.ts" enhancement="_blank"/>

import type { Ns5RulesArtifactV2 } from '/_102035_/l2/solution/types.js';

export const locacaoEquipamentosRules = {
  "schemaVersion": "2026-09-16-ns5-rules-v2",
  "moduleName": "locacaoEquipamentos",
  "rules": {
    "periodosLocacaoSemSobreposicao": "Um mesmo equipamento não pode constar em contratos de locação cujos períodos, da data de retirada à data prevista de devolução, sejam sobrepostos.",
    "equipamentoEmManutencaoNaoPodeSerLocado": "Equipamento em manutenção não pode ser incluído em uma locação.",
    "multaAtrasoLocacao": "Quando a devolução real for posterior à data prevista, a multa do contrato deve ser a soma, para cada equipamento locado, da diária aplicável multiplicada pelos dias de atraso e por 1,5.",
    "ruleForeignNamespaceRefused": "Dados pertencentes a outro módulo não podem ser registrados como dados próprios deste módulo.",
    "ruleDocumentShapeValidated": "O documento de identificação do cliente deve atender à estrutura aplicável ao seu tipo e país.",
    "ruleIdentityNeverInNamespace": "A identidade mestre do cliente não pode ser mantida nos dados específicos deste módulo.",
    "rulePersonPrivacyConsentRequiredBrEu": "O cliente pessoa física deve possuir consentimento de privacidade quando exigido no Brasil ou na União Europeia.",
    "contratoComPeloMenosUmEquipamento": "Todo contrato de locação deve incluir pelo menos um equipamento.",
    "equipamentoSemPeriodosSobrepostos": "A inclusão de um equipamento em contrato somente é permitida quando não houver locação desse equipamento em período sobreposto.",
    "equipamentoSemSobreposicao": "Um equipamento não pode ser reservado em mais de uma locação para datas coincidentes.",
    "calcularMultaAtraso": "A multa por atraso de cada equipamento deve ser calculada pela diária aplicável multiplicada pelos dias de atraso e por 1,5."
  }
} as const satisfies Ns5RulesArtifactV2;

export type LocacaoEquipamentosRulesType = typeof locacaoEquipamentosRules;

export default locacaoEquipamentosRules;

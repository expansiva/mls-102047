/// <mls fileReference="_102047_/l4/locacaoEquipamentos/rules.defs.ts" enhancement="_blank"/>

import type { Ns5RulesArtifactV2 } from '/_102035_/l2/solution/types.js';

export const locacaoEquipamentosRules = {
  "schemaVersion": "2026-09-16-ns5-rules-v2",
  "moduleName": "locacaoEquipamentos",
  "rules": {
    "devolucaoAposRetirada": "A data real de devolução não pode ser anterior à data de retirada do contrato.",
    "multaPorAtraso": "A multa total do contrato é zero quando não há atraso e, quando há atraso, corresponde à soma das diárias contratadas dos itens multiplicada pelos dias de atraso e por 1,5.",
    "ruleForeignNamespaceRefused": "Dados pertencentes a outro domínio não podem ser gravados no espaço de dados deste módulo.",
    "ruleDocumentShapeValidated": "Os dados documentais do cliente devem respeitar a estrutura exigida para o seu tipo de identificação.",
    "ruleIdentityNeverInNamespace": "A identidade mestre do cliente não pode ser mantida no espaço de dados deste módulo.",
    "rulePersonPrivacyConsentRequiredBrEu": "O consentimento de privacidade do cliente deve estar presente quando exigido pelas regras de proteção de dados aplicáveis no Brasil ou na União Europeia.",
    "periodosLocacaoNaoSobrepostos": "Os períodos de locação de um mesmo equipamento não podem se sobrepor.",
    "situacaoOperacionalEquipamento": "A situação operacional do equipamento é em manutenção quando houver manutenção em andamento, locado quando houver locação vigente e disponível quando não houver nenhuma dessas condições.",
    "contratoComPeloMenosUmItem": "Todo contrato de locação deve conter pelo menos um item de locação.",
    "periodoLocacaoValido": "A data prevista de devolução não pode ser anterior à data de retirada.",
    "equipamentoSemSobreposicao": "Um equipamento incluído em um contrato não pode estar vinculado a outro contrato com período de locação coincidente.",
    "itemEquipamentoUnicoNoContrato": "Um equipamento pode constar apenas uma vez entre os itens do mesmo contrato de locação.",
    "calcularMultaAtraso": "Quando houver atraso, a multa de cada item de locação corresponde à diária contratada multiplicada pelos dias de atraso e por 1,5.",
    "maintenanceDatesValid": "A data de fim da manutenção não pode ser anterior à sua data de início.",
    "maintenanceDoesNotOverlapRental": "O período de manutenção de um equipamento não pode se sobrepor a um período de locação desse equipamento."
  }
} as const satisfies Ns5RulesArtifactV2;

export type LocacaoEquipamentosRulesType = typeof locacaoEquipamentosRules;

export default locacaoEquipamentosRules;

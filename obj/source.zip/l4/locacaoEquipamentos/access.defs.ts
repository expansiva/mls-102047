/// <mls fileReference="_102047_/l4/locacaoEquipamentos/access.defs.ts" enhancement="_blank"/>

import type { Ns5AccessArtifact } from '/_102035_/l2/solution/types.js';

export const locacaoEquipamentosAccess = {
  "schemaVersion": "2026-09-12-ns5-access-v3",
  "moduleName": "locacaoEquipamentos",
  "actors": [
    {
      "actorId": "atendente",
      "kind": "internal",
      "origin": "named",
      "title": "Atendente",
      "description": "Cria contratos de locação para clientes e registra a devolução dos equipamentos."
    },
    {
      "actorId": "gerente",
      "kind": "internal",
      "origin": "named",
      "title": "Gerente",
      "description": "Acompanha a disponibilidade, locação e manutenção dos equipamentos."
    }
  ],
  "grants": [
    {
      "grantId": "atendenteLocacoes",
      "actorRef": "atendente",
      "title": "Atender locações e devoluções",
      "description": "Permite localizar clientes e equipamentos, registrar contratos de locação e registrar devoluções em toda a organização.",
      "entityRefs": [
        "Cliente",
        "Equipamento",
        "ContratoLocacao",
        "ItemContratoLocacao"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Abrange os clientes, equipamentos, contratos e itens de contrato da organização necessários ao atendimento de locações e devoluções."
      },
      "disclosure": {
        "mode": "fieldsOnly",
        "description": "Exibe a identificação do cliente, os dados comerciais e operacionais dos equipamentos e todos os dados necessários dos contratos e de seus itens; não expõe dados pessoais adicionais do cadastro mestre do cliente.",
        "allowedFields": [
          "Cliente.details.identification",
          "Equipamento.id",
          "Equipamento.version",
          "Equipamento.code",
          "Equipamento.status",
          "Equipamento.details",
          "ContratoLocacao.id",
          "ContratoLocacao.version",
          "ContratoLocacao.clienteId",
          "ContratoLocacao.status",
          "ContratoLocacao.dataRetirada",
          "ContratoLocacao.dataPrevistaDevolucao",
          "ContratoLocacao.dataRealDevolucao",
          "ContratoLocacao.details",
          "ItemContratoLocacao.id",
          "ItemContratoLocacao.version",
          "ItemContratoLocacao.contratoLocacaoId",
          "ItemContratoLocacao.equipamentoId",
          "ItemContratoLocacao.details"
        ]
      }
    },
    {
      "grantId": "gerenteEquipamentos",
      "actorRef": "gerente",
      "title": "Acompanhar equipamentos",
      "description": "Permite acompanhar a disponibilidade, locação e manutenção dos equipamentos da organização.",
      "entityRefs": [
        "Equipamento"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Abrange todos os equipamentos cadastrados na organização para acompanhamento gerencial."
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Exibe integralmente o cadastro operacional e comercial de cada equipamento."
      }
    }
  ]
} as const satisfies Ns5AccessArtifact;

export type LocacaoEquipamentosAccessType = typeof locacaoEquipamentosAccess;

export default locacaoEquipamentosAccess;

/// <mls fileReference="_102047_/l4/controleEstoque/rules.defs.ts" enhancement="_blank"/>

import type { Ns5RulesArtifactV2 } from '/_102035_/l2/solution/types.js';

export const controleEstoqueRules = {
  "schemaVersion": "2026-09-16-ns5-rules-v2",
  "moduleName": "controleEstoque",
  "rules": {
    "ruleForeignNamespaceRefused": "Um produto pertencente a outro namespace não pode ser aceito no controle de estoque.",
    "ruleDocumentShapeValidated": "Os dados do produto devem atender à estrutura de cadastro mestre aplicável antes de serem usados no controle de estoque.",
    "ruleIdentityNeverInNamespace": "A identidade mestre do produto não pode ser criada nem mantida no namespace do controle de estoque.",
    "saldoMinimoNaoNegativo": "O saldo mínimo configurado para um produto não pode ser negativo.",
    "saldoAtualCalculadoPelasMovimentacoes": "O saldo atual de cada produto deve ser calculado pelas entradas registradas menos as saídas registradas.",
    "avisoDeSaldoBaixo": "Deve haver aviso de reposição quando o saldo atual calculado de um produto for inferior ao seu saldo mínimo configurado.",
    "movimentacaoEstoqueImutavel": "Uma movimentação de estoque não pode ser alterada depois de registrada.",
    "quantidadeMovimentacaoPositiva": "A quantidade registrada em uma movimentação de estoque deve ser positiva."
  }
} as const satisfies Ns5RulesArtifactV2;

export type ControleEstoqueRulesType = typeof controleEstoqueRules;

export default controleEstoqueRules;

/// <mls fileReference="_102047_/l4/financeiro/rules.defs.ts" enhancement="_blank"/>

import type { Ns5RulesArtifactV2 } from '/_102035_/l2/solution/types.js';

export const financeiroRules = {
  "schemaVersion": "2026-09-16-ns5-rules-v2",
  "moduleName": "financeiro",
  "rules": {
    "sameDayReversal": "Um recebimento somente pode ser estornado na mesma data em que foi registrado.",
    "receiptReversalRecomposesTitleBalance": "O estorno de um recebimento deve recompor o saldo em aberto do título correspondente pela exclusão do valor estornado dos recebimentos válidos.",
    "ruleForeignNamespaceRefused": "Dados próprios de um módulo não podem ser gravados no espaço de dados de outro módulo.",
    "ruleDocumentShapeValidated": "Cada documento deve respeitar a estrutura definida para o respectivo tipo de registro.",
    "ruleIdentityNeverInNamespace": "Dados de identidade da pessoa não podem ser mantidos no espaço de dados específico do módulo.",
    "rulePersonPrivacyConsentRequiredBrEu": "O consentimento de privacidade da pessoa é obrigatório quando seu país é Brasil ou integrante da União Europeia.",
    "rulePersonSsnUniqueForUs": "O número de seguridade social deve identificar unicamente cada pessoa cujo país é os Estados Unidos.",
    "tituloOrigemUnico": "Uma mesma cobrança identificada pelo módulo e pelo registro de origem só pode gerar um título a receber.",
    "saldoTituloCalculado": "O saldo em aberto do título deve ser igual ao valor original menos a soma dos recebimentos não estornados vinculados a ele.",
    "valorRecebimentoNaoExcedeSaldo": "A soma dos recebimentos não estornados de um título não pode exceder seu valor original.",
    "receiptTitleMustBeOpen": "Um recebimento somente pode ser registrado para um título que possua saldo em aberto.",
    "receivedAmountPositive": "O valor de cada recebimento deve ser maior que zero.",
    "receivedAmountDoesNotExceedTitleBalance": "O valor de um novo recebimento não pode exceder o saldo em aberto do título no momento do registro.",
    "cardPaymentRequiresStripePaymentId": "Todo recebimento por cartão deve informar o identificador do pagamento por cartão.",
    "numeroExtratoUnico": "O número de cada extrato de pagador deve ser único.",
    "periodoExtratoValido": "A data inicial do período do extrato não pode ser posterior à data final.",
    "movimentacoesDoPagadorNoPeriodo": "O extrato deve apresentar somente títulos e recebimentos do pagador selecionado que pertençam ao período solicitado.",
    "situacaoTituloCalculada": "A situação do título deve ser em aberto sem recebimentos, parcialmente recebido quando o saldo for menor que o valor original e quitado quando o saldo for zero.",
    "tituloVencidoComSaldo": "Um título é vencido quando possui saldo em aberto e sua data de vencimento é anterior à data atual.",
    "formaRecebimentoPermitida": "Um recebimento deve ser registrado por dinheiro, Pix ou cartão.",
    "stripePaymentIdUnico": "Um mesmo identificador de pagamento por cartão não pode ser associado a mais de um recebimento.",
    "painelRecebiveisCalculado": "O painel de recebíveis deve consolidar, por período e origem, as quantidades e os valores em aberto, recebidos e vencidos dos títulos correspondentes.",
    "totaisExtratoCalculados": "Os totais do extrato devem corresponder às somas dos valores originais dos títulos, dos recebimentos apresentados e dos saldos em aberto apresentados no momento da emissão."
  }
} as const satisfies Ns5RulesArtifactV2;

export type FinanceiroRulesType = typeof financeiroRules;

export default financeiroRules;

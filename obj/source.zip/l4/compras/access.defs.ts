/// <mls fileReference="_102047_/l4/compras/access.defs.ts" enhancement="_blank"/>

import type { Ns5AccessArtifact, Ns5Readonly } from '/_102035_/l2/solution/types.js';

export const comprasAccess = {
  "schemaVersion": "2026-09-12-ns5-access-v3",
  "moduleName": "compras",
  "actors": [
    {
      "actorId": "comprador",
      "kind": "internal",
      "origin": "named",
      "title": "Comprador",
      "description": "Cadastra fornecedores e os produtos que cada um fornece com preço combinado, abre pedidos de compra com itens, quantidades e preços e os envia.",
      "personEntity": "Comprador"
    },
    {
      "actorId": "gerenteCompras",
      "kind": "internal",
      "origin": "named",
      "title": "Gerente de compras",
      "description": "Aprova ou rejeita pedidos de compra acima do valor limite e acompanha o painel de pedidos em aberto, atrasados e o total comprado por fornecedor no mês.",
      "personEntity": ""
    },
    {
      "actorId": "almoxarife",
      "kind": "internal",
      "origin": "named",
      "title": "Almoxarife",
      "description": "Registra o recebimento total ou parcial dos pedidos que chegam, o que dá entrada no estoque dos produtos recebidos.",
      "personEntity": ""
    }
  ],
  "grants": [
    {
      "grantId": "compradorCadastroFornecedores",
      "actorRef": "comprador",
      "title": "Cadastro de fornecedores, contatos e produtos",
      "description": "O comprador localiza, cadastra e mantém os fornecedores da organização, seus canais de contato e os produtos do catálogo comprados.",
      "entityRefs": [
        "Fornecedor",
        "ContatoFornecedor",
        "Produto"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Todos os fornecedores, contatos e produtos da organização, para evitar duplicidade e escolher o fornecedor do pedido."
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Registro completo do fornecedor, do contato e do produto."
      }
    },
    {
      "grantId": "compradorProdutosFornecidos",
      "actorRef": "comprador",
      "title": "Meus produtos fornecidos e preços combinados",
      "description": "O comprador cadastra e atualiza os produtos que cada fornecedor fornece com o preço combinado que ele mantém.",
      "entityRefs": [
        "ProdutoFornecido"
      ],
      "dataScope": {
        "mode": "own",
        "description": "Produtos fornecidos cadastrados e mantidos pelo próprio comprador.",
        "anchorEntity": "Comprador"
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Todos os dados do preço combinado."
      }
    },
    {
      "grantId": "compradorPedidos",
      "actorRef": "comprador",
      "title": "Meus pedidos de compra",
      "description": "O comprador abre, inclui itens, revisa e envia os pedidos de compra que abriu, e acompanha os recebimentos deles.",
      "entityRefs": [
        "PedidoCompra",
        "ItemPedido",
        "Recebimento"
      ],
      "dataScope": {
        "mode": "own",
        "description": "Pedidos abertos pelo próprio comprador, seus itens e recebimentos.",
        "anchorEntity": "Comprador"
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Registro completo do pedido, dos itens e dos recebimentos."
      }
    },
    {
      "grantId": "compradorProprioCadastro",
      "actorRef": "comprador",
      "title": "Meu cadastro de comprador",
      "description": "O comprador consulta o próprio registro de pessoa no módulo compras.",
      "entityRefs": [
        "Comprador"
      ],
      "dataScope": {
        "mode": "own",
        "description": "Apenas o registro da própria pessoa logada.",
        "anchorEntity": "Comprador"
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Todo o próprio registro."
      }
    },
    {
      "grantId": "gerenteAprovacaoPedidos",
      "actorRef": "gerenteCompras",
      "title": "Aprovação e acompanhamento de pedidos",
      "description": "O gerente de compras analisa, aprova ou rejeita pedidos acima do valor limite e detalha pedidos, itens, recebimentos e entradas de estoque.",
      "entityRefs": [
        "PedidoCompra",
        "ItemPedido",
        "Recebimento",
        "EntradaEstoque"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Todos os pedidos de compra da organização."
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Registro completo dos pedidos, itens, recebimentos e entradas."
      }
    },
    {
      "grantId": "gerenteCadastros",
      "actorRef": "gerenteCompras",
      "title": "Fornecedores, produtos e compradores",
      "description": "O gerente consulta fornecedores, contatos, produtos e preços combinados e mantém o cadastro dos compradores.",
      "entityRefs": [
        "Fornecedor",
        "ContatoFornecedor",
        "Produto",
        "ProdutoFornecido",
        "Comprador"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Todos os registros da organização."
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Registro completo."
      }
    },
    {
      "grantId": "gerentePainel",
      "actorRef": "gerenteCompras",
      "title": "Painel de compras",
      "description": "O gerente vê pedidos em aberto, atrasados e o total comprado por fornecedor no mês.",
      "entityRefs": [
        "PainelCompras"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Indicadores de toda a organização."
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Os campos do painel já são os totais."
      }
    },
    {
      "grantId": "almoxarifePedidos",
      "actorRef": "almoxarife",
      "title": "Conferência de pedidos a receber",
      "description": "O almoxarife localiza pedidos liberados e confere itens e quantidades pendentes, sem dados financeiros nem da decisão.",
      "entityRefs": [
        "PedidoCompra",
        "ItemPedido"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Pedidos de compra da organização."
      },
      "disclosure": {
        "mode": "fieldsOnly",
        "description": "Oculta preços, valores, condição de pagamento e decisão do gerente.",
        "deniedFields": [
          "PedidoCompra.details.condicaoPagamento",
          "PedidoCompra.details.decisao",
          "PedidoCompra.details.valorTotal",
          "ItemPedido.details.precoUnitario",
          "ItemPedido.details.valorTotalItem"
        ]
      }
    },
    {
      "grantId": "almoxarifeRecebimentos",
      "actorRef": "almoxarife",
      "title": "Registro de recebimentos e entradas de estoque",
      "description": "O almoxarife registra recebimentos totais ou parciais, que geram as entradas no estoque.",
      "entityRefs": [
        "Recebimento",
        "EntradaEstoque"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Recebimentos e entradas de toda a organização."
      },
      "disclosure": {
        "mode": "fullRecord",
        "description": "Registro completo."
      }
    },
    {
      "grantId": "almoxarifeConsultaCadastros",
      "actorRef": "almoxarife",
      "title": "Consulta de fornecedores e produtos",
      "description": "O almoxarife identifica o fornecedor e o produto recebido.",
      "entityRefs": [
        "Fornecedor",
        "Produto"
      ],
      "dataScope": {
        "mode": "organization",
        "description": "Fornecedores e produtos da organização."
      },
      "disclosure": {
        "mode": "fieldsOnly",
        "description": "Identificação e dados de empresa do fornecedor; identificação e catálogo do produto.",
        "allowedFields": [
          "Fornecedor.details.identification",
          "Fornecedor.details.company",
          "Produto.details.identification",
          "Produto.details.product"
        ]
      }
    }
  ]
} as const satisfies Ns5Readonly<Ns5AccessArtifact>;

export type ComprasAccessType = typeof comprasAccess;

export default comprasAccess;

/// <mls fileReference="_102047_/l4/compras/workflows.defs.ts" enhancement="_blank"/>

import type { Ns5WorkflowsArtifact, Ns5Readonly } from '/_102035_/l2/solution/types.js';

export const comprasWorkflows = {
  "schemaVersion": "2026-09-17-ns5-workflows-v3",
  "moduleName": "compras",
  "processes": [
    {
      "processId": "cicloPedidoCompra",
      "title": "Ciclo do pedido de compra",
      "description": "Do pedido aberto e enviado pelo comprador, passando pela aprovação do gerente de compras quando acima do valor limite, até o recebimento total ou parcial pelo almoxarife com entrada no estoque.",
      "trigger": {
        "kind": "manual",
        "actorRef": "comprador"
      },
      "tasks": [
        {
          "taskId": "abrirEnviarPedido",
          "kind": "human",
          "actorRef": "comprador",
          "journeyRef": "abrirEnviarPedido",
          "next": [
            "aprovarPedido",
            "aguardarChegada"
          ],
          "description": "O comprador abre o pedido para o fornecedor com os itens e o envia; acima do valor limite segue para aprovação, senão segue ao fornecedor."
        },
        {
          "taskId": "aprovarPedido",
          "kind": "human",
          "actorRef": "gerenteCompras",
          "journeyRef": "aprovarPedido",
          "next": [
            "aguardarChegada"
          ],
          "description": "O gerente de compras aprova ou rejeita o pedido acima do valor limite; se rejeitado, o processo termina."
        },
        {
          "taskId": "aguardarChegada",
          "kind": "wait",
          "next": [
            "registrarRecebimento"
          ],
          "description": "Aguarda a chegada da mercadoria do pedido aprovado ou dos itens ainda pendentes."
        },
        {
          "taskId": "registrarRecebimento",
          "kind": "human",
          "actorRef": "almoxarife",
          "journeyRef": "registrarRecebimento",
          "next": [
            "darEntradaEstoque"
          ],
          "description": "O almoxarife registra as quantidades recebidas de cada item, total ou parcialmente."
        },
        {
          "taskId": "darEntradaEstoque",
          "kind": "mechanical",
          "entityRef": "EntradaEstoque",
          "effect": "create",
          "next": [
            "aguardarChegada"
          ],
          "description": "O sistema dá entrada no estoque dos produtos recebidos e, se o recebimento foi parcial, volta a aguardar os itens pendentes."
        }
      ]
    }
  ],
  "journeyDecisions": [
    {
      "journeyId": "cadastrarFornecedor",
      "inProcess": false
    },
    {
      "journeyId": "atualizarPrecoCombinado",
      "inProcess": false
    },
    {
      "journeyId": "abrirEnviarPedido",
      "inProcess": true,
      "processId": "cicloPedidoCompra"
    },
    {
      "journeyId": "aprovarPedido",
      "inProcess": true,
      "processId": "cicloPedidoCompra"
    },
    {
      "journeyId": "registrarRecebimento",
      "inProcess": true,
      "processId": "cicloPedidoCompra"
    },
    {
      "journeyId": "acompanharPainel",
      "inProcess": false
    }
  ]
} as const satisfies Ns5Readonly<Ns5WorkflowsArtifact>;

export type ComprasWorkflowsType = typeof comprasWorkflows;

export default comprasWorkflows;

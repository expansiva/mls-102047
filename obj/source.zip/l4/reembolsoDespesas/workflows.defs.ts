/// <mls fileReference="_102047_/l4/reembolsoDespesas/workflows.defs.ts" enhancement="_blank"/>

import type { Ns5WorkflowsArtifact } from '/_102035_/l2/solution/types.js';

export const reembolsoDespesasWorkflows = {
  "schemaVersion": "2026-09-17-ns5-workflows-v3",
  "moduleName": "reembolsoDespesas",
  "processes": [
    {
      "processId": "submeterEAvaliarDespesa",
      "title": "Submeter e avaliar despesa",
      "description": "Orquestra o envio de uma despesa pelo colaborador e sua avaliação pelo gestor da equipe.",
      "trigger": {
        "kind": "manual",
        "actorRef": "colaborador"
      },
      "tasks": [
        {
          "taskId": "registrarEnviarDespesa",
          "kind": "human",
          "actorRef": "colaborador",
          "journeyRef": "registrarEenviarDespesa",
          "next": [
            "avaliarDespesaEquipe"
          ],
          "description": "O colaborador registra sua despesa e a encaminha para aprovação do gestor da equipe."
        },
        {
          "taskId": "avaliarDespesaEquipe",
          "kind": "human",
          "actorRef": "gestorEquipe",
          "journeyRef": "avaliarDespesaDaEquipe",
          "next": [],
          "description": "O gestor da equipe avalia a despesa encaminhada e registra a aprovação ou rejeição com o motivo."
        }
      ]
    },
    {
      "processId": "reavaliarDespesaReenviada",
      "title": "Reavaliar despesa reenviada",
      "description": "Encaminha uma despesa corrigida e reenviada para nova avaliação do gestor da equipe.",
      "trigger": {
        "kind": "event",
        "event": "Despesa.reenviarParaAprovacao"
      },
      "tasks": [
        {
          "taskId": "avaliarDespesaReenviada",
          "kind": "human",
          "actorRef": "gestorEquipe",
          "journeyRef": "avaliarDespesaDaEquipe",
          "next": [],
          "description": "O gestor da equipe avalia a despesa corrigida e reenviada e registra a nova decisão."
        }
      ]
    },
    {
      "processId": "registrarPagamentoDespesaAprovada",
      "title": "Registrar pagamento de despesa aprovada",
      "description": "Permite ao financeiro registrar o pagamento de uma despesa que foi aprovada.",
      "trigger": {
        "kind": "event",
        "event": "Despesa.registrarDecisaoDaDespesa"
      },
      "tasks": [
        {
          "taskId": "registrarPagamentoDespesa",
          "kind": "human",
          "actorRef": "financeiro",
          "journeyRef": "registrarPagamentoDeDespesa",
          "next": [],
          "description": "O financeiro localiza a despesa aprovada e registra a respectiva data de pagamento."
        }
      ]
    }
  ],
  "journeyDecisions": [
    {
      "journeyId": "registrarEenviarDespesa",
      "inProcess": true,
      "processId": "submeterEAvaliarDespesa"
    },
    {
      "journeyId": "consultarPropriasDespesas",
      "inProcess": false
    },
    {
      "journeyId": "corrigirEreenviarDespesa",
      "inProcess": false
    },
    {
      "journeyId": "avaliarDespesaDaEquipe",
      "inProcess": true,
      "processId": "submeterEAvaliarDespesa"
    },
    {
      "journeyId": "registrarPagamentoDeDespesa",
      "inProcess": true,
      "processId": "registrarPagamentoDespesaAprovada"
    }
  ]
} as const satisfies Ns5WorkflowsArtifact;

export type ReembolsoDespesasWorkflowsType = typeof reembolsoDespesasWorkflows;

export default reembolsoDespesasWorkflows;

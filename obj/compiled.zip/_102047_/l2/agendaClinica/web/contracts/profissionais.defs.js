/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/profissionais.defs.ts" enhancement="_blank"/>
export {};

export const createConsultaRoute = "agendaClinica.profissionais.cmdCreateConsulta";
export const listConsultaRoute = "agendaClinica.profissionais.qryListConsulta";
export const listPacienteRoute = "agendaClinica.profissionais.qryListPaciente";
export const listProfissionalRoute = "agendaClinica.profissionais.qryListProfissional";

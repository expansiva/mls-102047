export const createProfissionalRoute = "agendaClinica.dados_profissional.cmdCreateProfissional";
export const updateProfissionalRoute = "agendaClinica.dados_profissional.cmdUpdateProfissional";
export const listProfissionalRoute = "agendaClinica.dados_profissional.qryListProfissional";

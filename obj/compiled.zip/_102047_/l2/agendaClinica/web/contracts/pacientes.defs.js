/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/pacientes.defs.ts" enhancement="_blank"/>
export const createPacienteRoute = "agendaClinica.pacientes.cmdCreatePaciente";
export const listPacienteRoute = "agendaClinica.pacientes.qryListPaciente";

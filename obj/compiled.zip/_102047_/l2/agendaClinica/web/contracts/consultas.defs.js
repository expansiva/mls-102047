/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/consultas.defs.ts" enhancement="_blank"/>
export {};

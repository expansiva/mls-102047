/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/consultas.defs.ts" enhancement="_blank"/>
export const createConsultaRoute = "agendaClinica.consultas.cmdCreateConsulta";
export const registrarFaltaRoute = "agendaClinica.consultas.cmdRegistrarFalta";
export const updateConsultaRoute = "agendaClinica.consultas.cmdUpdateConsulta";
export const listConsultaRoute = "agendaClinica.consultas.qryListConsulta";
export const listPacienteRoute = "agendaClinica.consultas.qryListPaciente";
export const listProfissionalRoute = "agendaClinica.consultas.qryListProfissional";

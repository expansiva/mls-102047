export const confirmarConsultaRoute = "agendaClinica.consultas_recepcionista.cmdConfirmarConsulta";
export const createConsultaRoute = "agendaClinica.consultas_recepcionista.cmdCreateConsulta";
export const registrarFaltaRoute = "agendaClinica.consultas_recepcionista.cmdRegistrarFalta";
export const listConsultaRoute = "agendaClinica.consultas_recepcionista.qryListConsulta";
export const listPacienteRoute = "agendaClinica.consultas_recepcionista.qryListPaciente";
export const listProfissionalRoute = "agendaClinica.consultas_recepcionista.qryListProfissional";

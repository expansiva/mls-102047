/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/profissionais_recepcao.defs.ts" enhancement="_blank"/>
export {};

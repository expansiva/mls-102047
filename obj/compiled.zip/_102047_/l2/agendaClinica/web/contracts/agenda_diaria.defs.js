/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/agenda_diaria.defs.ts" enhancement="_blank"/>
export {};

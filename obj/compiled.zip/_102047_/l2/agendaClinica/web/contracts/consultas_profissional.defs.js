export const registrarAtendimentoRoute = "agendaClinica.consultas_profissional.cmdRegistrarAtendimento";
export const listConsultaRoute = "agendaClinica.consultas_profissional.qryListConsulta";

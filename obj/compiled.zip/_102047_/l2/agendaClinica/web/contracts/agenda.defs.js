/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/agenda.defs.ts" enhancement="_blank"/>
export const registrarAtendimentoRoute = "agendaClinica.agenda.cmdRegistrarAtendimento";
export const listConsultaRoute = "agendaClinica.agenda.qryListConsulta";

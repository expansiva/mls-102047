export const registrarAtendimentoRoute = "agendaClinica.agenda.cmdRegistrarAtendimento";
export const listConsultaRoute = "agendaClinica.agenda.qryListConsulta";

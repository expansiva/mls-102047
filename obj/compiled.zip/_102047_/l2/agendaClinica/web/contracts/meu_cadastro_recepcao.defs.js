/// <mls fileReference="_102047_/l2/agendaClinica/web/contracts/meu_cadastro_recepcao.defs.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102047_/l2/agendaClinica/web/shared/agenda_diaria.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.agendaClinica.agenda_diaria.carregarAgendaDiariaConsultas': 'carregarAgendaDiariaConsultas',
    'ui.agendaClinica.agenda_diaria.carregarMaisConsultasDoDiaConsultas': 'carregarMaisConsultasDoDiaConsultas',
    'ui.agendaClinica.agenda_diaria.registrarAtendimentoConsulta': 'registrarAtendimentoConsulta',
    'ui.agendaClinica.agenda_diaria.carregarConsultaSelecionadaConsulta': 'carregarConsultaSelecionadaConsulta',
    'ui.agendaClinica.agenda_diaria.selectedConsulta': 'selectedConsulta',
    'ui.agendaClinica.agenda_diaria.page': 'page',
    'ui.agendaClinica.agenda_diaria.pageStatus': 'pageStatus',
    'ui.agendaClinica.agenda_diaria.carregarAgendaDiariaStatus': 'carregarAgendaDiariaStatus',
    'ui.agendaClinica.agenda_diaria.carregarAgendaDiariaError': 'carregarAgendaDiariaError',
    'ui.agendaClinica.agenda_diaria.carregarMaisConsultasDoDiaStatus': 'carregarMaisConsultasDoDiaStatus',
    'ui.agendaClinica.agenda_diaria.carregarMaisConsultasDoDiaError': 'carregarMaisConsultasDoDiaError',
    'ui.agendaClinica.agenda_diaria.carregarConsultaSelecionadaStatus': 'carregarConsultaSelecionadaStatus',
    'ui.agendaClinica.agenda_diaria.carregarConsultaSelecionadaError': 'carregarConsultaSelecionadaError',
    'ui.agendaClinica.agenda_diaria.registrarAtendimentoStatus': 'registrarAtendimentoStatus',
    'ui.agendaClinica.agenda_diaria.registrarAtendimentoError': 'registrarAtendimentoError',
    'ui.agendaClinica.agenda_diaria.registerAttendanceDraft': 'registerAttendanceDraft',
    'ui.agendaClinica.agenda_diaria.scenary': 'scenary'
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const emptyRegisterAttendanceDraft = () => ({ id: null, version: null, details: { attendanceNote: null } });
export class AgendaClinicaAgenda_diariaShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state carregarAgendaDiariaConsultas — Linha resumida da agenda diária do profissional.; source carregarAgendaDiaria.consultas; organism dayConsultations */
        this.carregarAgendaDiariaConsultas = null;
        /** state carregarMaisConsultasDoDiaConsultas — Linha resumida da agenda diária do profissional.; source carregarMaisConsultasDoDia.consultas; organism dayConsultations */
        this.carregarMaisConsultasDoDiaConsultas = null;
        /** state registrarAtendimentoConsulta — Consulta aberta pelo profissional, com paciente, profissional e anotação para conferência e registro.; source registrarAtendimento.consulta; organism attendanceActions */
        this.registrarAtendimentoConsulta = null;
        /** state carregarConsultaSelecionadaConsulta — Consulta aberta pelo profissional, com paciente, profissional e anotação para conferência e registro.; source carregarConsultaSelecionada.consulta; organism consultationSummary */
        this.carregarConsultaSelecionadaConsulta = null;
        /** state selectedConsulta — Consulta aberta pelo profissional, com paciente, profissional e anotação para conferência e registro.; source entry.params.consultaId; organism consultationSummary; persisted */
        this.selectedConsulta = null;
        /** state page — the requested agenda page filter; source entry.params.page; organism dayConsultations; persisted */
        this.page = null;
        /** state pageStatus — the overall loading state of the page; source pageStatus */
        this.pageStatus = 'idle';
        /** state carregarAgendaDiariaStatus — the status of the initial agenda query; source carregarAgendaDiariaStatus */
        this.carregarAgendaDiariaStatus = 'idle';
        /** state carregarAgendaDiariaError — the error of the initial agenda query; source carregarAgendaDiariaError */
        this.carregarAgendaDiariaError = null;
        /** state carregarMaisConsultasDoDiaStatus — the status of the next-page agenda query; source carregarMaisConsultasDoDiaStatus */
        this.carregarMaisConsultasDoDiaStatus = 'idle';
        /** state carregarMaisConsultasDoDiaError — the error of the next-page agenda query; source carregarMaisConsultasDoDiaError */
        this.carregarMaisConsultasDoDiaError = null;
        /** state carregarConsultaSelecionadaStatus — the status of the selected consultation query; source carregarConsultaSelecionadaStatus */
        this.carregarConsultaSelecionadaStatus = 'idle';
        /** state carregarConsultaSelecionadaError — the error of the selected consultation query; source carregarConsultaSelecionadaError */
        this.carregarConsultaSelecionadaError = null;
        /** state registrarAtendimentoStatus — the status of the attendance command; source registrarAtendimentoStatus */
        this.registrarAtendimentoStatus = 'idle';
        /** state registrarAtendimentoError — the error of the attendance command; source registrarAtendimentoError */
        this.registrarAtendimentoError = null;
        /** state registerAttendanceDraft — the attendance command draft; source registrarAtendimento.input; organism attendanceForm */
        this.registerAttendanceDraft = emptyRegisterAttendanceDraft();
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.agendaClinica.agenda_diaria.${member}`, value);
        if (member === 'page' || member === 'selectedConsulta') {
            try {
                const key = member === 'page' ? 'agendaClinica.agenda_diaria.page' : 'agendaClinica.agenda_diaria.consultaId';
                if (value === null || value === '') {
                    localStorage.removeItem(key);
                }
                else {
                    localStorage.setItem(key, String(value));
                }
            }
            catch {
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member) {
            this[member] = value;
        }
    }
    errorState(error, name) {
        if (error) {
            return { code: error.code ?? 'client.unexpected', message: error.message ?? '', details: error.details };
        }
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('registerAttendanceDraft', emptyRegisterAttendanceDraft());
        this.publish('carregarAgendaDiariaStatus', 'idle');
        this.publish('carregarAgendaDiariaError', null);
        this.publish('carregarMaisConsultasDoDiaStatus', 'idle');
        this.publish('carregarMaisConsultasDoDiaError', null);
        this.publish('carregarConsultaSelecionadaStatus', 'idle');
        this.publish('carregarConsultaSelecionadaError', null);
        this.publish('registrarAtendimentoStatus', 'idle');
        this.publish('registrarAtendimentoError', null);
    }
    connectedCallback() {
        super.connectedCallback();
        for (const key of STATE_KEYS) {
            const member = STATE_MEMBER_BY_KEY[key];
            if (member !== 'pageStatus' && member !== 'scenary' && !member.endsWith('Status') && !member.endsWith('Error') && member !== 'registerAttendanceDraft') {
                const value = getState(key);
                if (value !== undefined) {
                    this.assignState(key, value);
                }
            }
        }
        this.resetVisit();
        subscribe(STATE_KEYS, this);
        this.applyEntryParams();
        void this.initialLoad();
    }
    disconnectedCallback() {
        unsubscribe(STATE_KEYS, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_MEMBER_BY_KEY[key]) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined) {
            return;
        }
        this.assignState(key, value);
        this.requestUpdate();
    }
    applyEntryParams() {
        const params = new URLSearchParams(window.location.search);
        const pageRaw = params.get('page') ?? this.storageValue('agendaClinica.agenda_diaria.page');
        const pageValue = pageRaw === null ? null : Number(pageRaw);
        this.publish('page', pageValue !== null && Number.isFinite(pageValue) ? pageValue : null);
        const consultaId = params.get('consultaId') ?? this.storageValue('agendaClinica.agenda_diaria.consultaId');
        this.publish('selectedConsulta', consultaId);
        if (consultaId !== null) {
            void this.carregarConsultaSelecionada(consultaId);
        }
    }
    storageValue(key) {
        try {
            return localStorage.getItem(key);
        }
        catch {
            return null;
        }
    }
    async initialLoad() {
        this.publish('pageStatus', 'loading');
        await this.carregarAgendaDiaria();
        if (this.carregarAgendaDiariaStatus === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        const list = this.carregarAgendaDiariaConsultas;
        this.publish('pageStatus', list && list.items.length === 0 ? 'empty' : 'success');
    }
    /** function carregarAgendaDiaria — Loads the first page of today's authenticated professional agenda; redraws carregarAgendaDiariaConsultas by replacement. No arguments. */
    async carregarAgendaDiaria() {
        if (this.carregarAgendaDiariaStatus === 'loading') {
            return;
        }
        this.publish('carregarAgendaDiariaStatus', 'loading');
        this.publish('carregarAgendaDiariaError', null);
        const input = { page: this.page ?? 1, pageSize: 20 };
        try {
            const response = await execBff('agendaClinica.agenda_diaria.carregarAgendaDiaria', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarAgendaDiariaError', this.errorState(response.error, 'carregarAgendaDiaria'));
                this.publish('carregarAgendaDiariaStatus', 'error');
                return;
            }
            this.publish('carregarAgendaDiariaConsultas', response.data.consultas);
            this.publish('carregarAgendaDiariaStatus', 'success');
        }
        catch (error) {
            this.publish('carregarAgendaDiariaError', { code: 'client.unexpected', message: '', details: { name: error instanceof Error ? error.name : 'carregarAgendaDiaria' } });
            this.publish('carregarAgendaDiariaStatus', 'error');
        }
    }
    /** function carregarMaisConsultasDoDia — Fetches the next page of today's agenda; redraws carregarMaisConsultasDoDiaConsultas by replacement and carregarAgendaDiariaConsultas.items by append. No arguments. */
    async carregarMaisConsultasDoDia() {
        if (this.carregarMaisConsultasDoDiaStatus === 'loading') {
            return;
        }
        const current = this.carregarAgendaDiariaConsultas;
        if (!current || !current.hasMore) {
            return;
        }
        this.publish('carregarMaisConsultasDoDiaStatus', 'loading');
        this.publish('carregarMaisConsultasDoDiaError', null);
        const input = { page: current.page + 1, pageSize: current.pageSize };
        try {
            const response = await execBff('agendaClinica.agenda_diaria.carregarMaisConsultasDoDia', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarMaisConsultasDoDiaError', this.errorState(response.error, 'carregarMaisConsultasDoDia'));
                this.publish('carregarMaisConsultasDoDiaStatus', 'error');
                return;
            }
            this.publish('carregarMaisConsultasDoDiaConsultas', response.data.consultas);
            this.publish('carregarAgendaDiariaConsultas', { ...response.data.consultas, items: [...current.items, ...response.data.consultas.items] });
            this.publish('carregarMaisConsultasDoDiaStatus', 'success');
        }
        catch (error) {
            this.publish('carregarMaisConsultasDoDiaError', { code: 'client.unexpected', message: '', details: { name: error instanceof Error ? error.name : 'carregarMaisConsultasDoDia' } });
            this.publish('carregarMaisConsultasDoDiaStatus', 'error');
        }
    }
    /** function carregarConsultaSelecionada — Opens the selected agenda consultation; redraws carregarConsultaSelecionadaConsulta by replacement. consultaId is the selected consultation identifier. */
    async carregarConsultaSelecionada(consultaId) {
        if (this.carregarConsultaSelecionadaStatus === 'loading') {
            return;
        }
        this.publish('carregarConsultaSelecionadaStatus', 'loading');
        this.publish('carregarConsultaSelecionadaError', null);
        const input = { consultaId };
        try {
            const response = await execBff('agendaClinica.agenda_diaria.carregarConsultaSelecionada', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarConsultaSelecionadaError', this.errorState(response.error, 'carregarConsultaSelecionada'));
                this.publish('carregarConsultaSelecionadaStatus', 'error');
                return;
            }
            this.publish('carregarConsultaSelecionadaConsulta', response.data.consulta);
            this.publish('carregarConsultaSelecionadaStatus', 'success');
        }
        catch (error) {
            this.publish('carregarConsultaSelecionadaError', { code: 'client.unexpected', message: '', details: { name: error instanceof Error ? error.name : 'carregarConsultaSelecionada' } });
            this.publish('carregarConsultaSelecionadaStatus', 'error');
        }
    }
    /** function registrarAtendimento — Registers the completed attendance; redraws registrarAtendimentoConsulta and carregarConsultaSelecionadaConsulta by upsert, and carregarAgendaDiariaConsultas.items by upsert. */
    async registrarAtendimento() {
        const draft = this.registerAttendanceDraft;
        const selected = this.carregarConsultaSelecionadaConsulta ?? this.registrarAtendimentoConsulta;
        const note = draft.details?.attendanceNote;
        if (!selected || selected.id === '' || selected.version === undefined || note === null || note === undefined || note === '') {
            this.publish('registrarAtendimentoError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['registerAttendanceDraft', 'carregarConsultaSelecionadaConsulta'] } });
            this.publish('registrarAtendimentoStatus', 'error');
            return;
        }
        this.publish('registrarAtendimentoStatus', 'loading');
        this.publish('registrarAtendimentoError', null);
        const input = { id: selected.id, version: selected.version, details: { details: { attendanceNote: note } } };
        try {
            const result = await runBlockingUiAction(signal => execBff('agendaClinica.agenda_diaria.registrarAtendimento', input, { mode: 'blocking', signal }));
            if (!result) {
                this.publish('registrarAtendimentoError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('registrarAtendimentoStatus', 'error');
                return;
            }
            if (!result.ok || !result.data) {
                this.publish('registrarAtendimentoError', this.errorState(result.error, 'registrarAtendimento'));
                this.publish('registrarAtendimentoStatus', 'error');
                return;
            }
            const consultation = result.data.consulta;
            this.publish('registrarAtendimentoConsulta', consultation);
            this.publish('carregarConsultaSelecionadaConsulta', consultation);
            const list = this.carregarAgendaDiariaConsultas;
            if (list) {
                this.publish('carregarAgendaDiariaConsultas', { ...list, items: list.items.map(item => item.id === consultation.id ? { ...item, status: consultation.status } : item) });
            }
            this.publish('registerAttendanceDraft', emptyRegisterAttendanceDraft());
            this.publish('registrarAtendimentoStatus', 'success');
        }
        catch (error) {
            this.publish('registrarAtendimentoError', { code: 'client.unexpected', message: '', details: { name: error instanceof Error ? error.name : 'registrarAtendimento' } });
            this.publish('registrarAtendimentoStatus', 'error');
        }
    }
    /** draft — Sets the attendance form command draft. value contains the attendance note and command context. */
    setRegisterAttendance(value) {
        this.publish('registerAttendanceDraft', value);
    }
    /** select — Selects a consultation id, clears it when null, and loads the selected consultation when an id is supplied. */
    selectConsultaId(value) {
        this.publish('selectedConsulta', value);
        if (value === null) {
            this.publish('carregarConsultaSelecionadaConsulta', null);
            return;
        }
        void this.carregarConsultaSelecionada(value);
    }
    /** Sets the visible page scene. */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** Returns the selected consultation record for the consultation summary. */
    get consultationSummary() {
        return this.carregarConsultaSelecionadaConsulta ?? this.registrarAtendimentoConsulta;
    }
    /** Returns the consultation row selected in the loaded agenda list. */
    get dayConsultationsSelection() {
        const rows = this.carregarAgendaDiariaConsultas?.items ?? [];
        return rows.find(row => row.id === this.selectedConsulta) ?? null;
    }
}
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarAgendaDiariaConsultas", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarMaisConsultasDoDiaConsultas", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "registrarAtendimentoConsulta", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarConsultaSelecionadaConsulta", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "selectedConsulta", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "page", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarAgendaDiariaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarAgendaDiariaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarMaisConsultasDoDiaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarMaisConsultasDoDiaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarConsultaSelecionadaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "carregarConsultaSelecionadaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "registrarAtendimentoStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "registrarAtendimentoError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "registerAttendanceDraft", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaAgenda_diariaShared.prototype, "scenary", void 0);

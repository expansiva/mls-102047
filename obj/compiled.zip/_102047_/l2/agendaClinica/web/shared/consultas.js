/// <mls fileReference="_102047_/l2/agendaClinica/web/shared/consultas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { createConsultaRoute, registrarFaltaRoute, updateConsultaRoute, listConsultaRoute, listPacienteRoute, listProfissionalRoute, } from '../contracts/consultas.defs.js';
const K = {
    pageStatus: 'ui.consultas.pageStatus', scenary: 'ui.consultas.scenary',
    createPaciente: 'ui.consultas.createConsulta.input.pacienteId', createProfissional: 'ui.consultas.createConsulta.input.profissionalId', createScheduled: 'ui.consultas.createConsulta.input.scheduledAt', createConfirmed: 'ui.consultas.createConsulta.input.details.telephoneConfirmation.confirmedAt', createStatus: 'ui.consultas.createConsulta.status', createError: 'ui.consultas.createConsulta.error', createResult: 'ui.consultas.createConsulta.result',
    faltaId: 'ui.consultas.registrarFalta.input.id', faltaStatus: 'ui.consultas.registrarFalta.status', faltaError: 'ui.consultas.registrarFalta.error', faltaResult: 'ui.consultas.registrarFalta.result',
    updateId: 'ui.consultas.updateConsulta.input.id', updatePaciente: 'ui.consultas.updateConsulta.input.pacienteId', updateProfissional: 'ui.consultas.updateConsulta.input.profissionalId', updateScheduled: 'ui.consultas.updateConsulta.input.scheduledAt', updateConfirmed: 'ui.consultas.updateConsulta.input.details.telephoneConfirmation.confirmedAt', updateStatus: 'ui.consultas.updateConsulta.status', updateError: 'ui.consultas.updateConsulta.error', updateResult: 'ui.consultas.updateConsulta.result',
    listId: 'ui.consultas.listConsulta.input.id', listPaciente: 'ui.consultas.listConsulta.input.pacienteId', listProfissional: 'ui.consultas.listConsulta.input.profissionalId', listScheduled: 'ui.consultas.listConsulta.input.scheduledAt', listInputStatus: 'ui.consultas.listConsulta.input.status', listPage: 'ui.consultas.listConsulta.input.page', listStatus: 'ui.consultas.listConsulta.status', listError: 'ui.consultas.listConsulta.error', listResult: 'ui.consultas.listConsulta.result',
    pacienteId: 'ui.consultas.listPaciente.input.id', pacienteSubtype: 'ui.consultas.listPaciente.input.details.identification.subtype', pacienteName: 'ui.consultas.listPaciente.input.details.identification.name', pacienteDocType: 'ui.consultas.listPaciente.input.details.identification.docType', pacienteDocId: 'ui.consultas.listPaciente.input.details.identification.docId', pacienteCountry: 'ui.consultas.listPaciente.input.details.identification.countryCode', pacientePage: 'ui.consultas.listPaciente.input.page', pacienteStatus: 'ui.consultas.listPaciente.status', pacienteError: 'ui.consultas.listPaciente.error', pacienteResult: 'ui.consultas.listPaciente.result',
    profissionalId: 'ui.consultas.listProfissional.input.id', profissionalSubtype: 'ui.consultas.listProfissional.input.details.identification.subtype', profissionalName: 'ui.consultas.listProfissional.input.details.identification.name', profissionalStatusInput: 'ui.consultas.listProfissional.input.details.identification.status', profissionalDocType: 'ui.consultas.listProfissional.input.details.identification.docType', profissionalDocId: 'ui.consultas.listProfissional.input.details.identification.docId', profissionalCountry: 'ui.consultas.listProfissional.input.details.identification.countryCode', profissionalPage: 'ui.consultas.listProfissional.input.page', profissionalStatus: 'ui.consultas.listProfissional.status', profissionalError: 'ui.consultas.listProfissional.error', profissionalResult: 'ui.consultas.listProfissional.result',
};
const listConsultaInputStatusMember = 'stateListConsultaStatusX00007300007400006100007400006500003a00007500006900002e00006300006f00006e00007300007500006c00007400006100007300002e00006c00006900007300007400004300006f00006e00007300007500006c00007400006100002e00006900006e00007000007500007400002e000073000074000061000074000075000073';
const listConsultaStatusMember = 'stateListConsultaStatusX00007300007400006100007400006500003a00007500006900002e00006300006f00006e00007300007500006c00007400006100007300002e00006c00006900007300007400004300006f00006e00007300007500006c00007400006100002e000073000074000061000074000075000073';
export class ConsultasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        this.pageStatus = 'idle';
        this.scenary = 'base';
        this.stateCreateConsultaPacienteId = null;
        this.stateCreateConsultaProfissionalId = null;
        this.stateCreateConsultaScheduledAt = null;
        this.stateCreateConsultaDetailsTelephoneConfirmationConfirmedAt = null;
        this.stateCreateConsultaStatus = 'idle';
        this.stateCreateConsultaError = null;
        this.stateCreateConsultaResult = null;
        this.stateRegistrarFaltaId = null;
        this.stateRegistrarFaltaStatus = 'idle';
        this.stateRegistrarFaltaError = null;
        this.stateRegistrarFaltaResult = null;
        this.stateUpdateConsultaId = null;
        this.stateUpdateConsultaPacienteId = null;
        this.stateUpdateConsultaProfissionalId = null;
        this.stateUpdateConsultaScheduledAt = null;
        this.stateUpdateConsultaDetailsTelephoneConfirmationConfirmedAt = null;
        this.stateUpdateConsultaStatus = 'idle';
        this.stateUpdateConsultaError = null;
        this.stateUpdateConsultaResult = null;
        this.stateListConsultaId = null;
        this.stateListConsultaPacienteId = null;
        this.stateListConsultaProfissionalId = null;
        this.stateListConsultaScheduledAt = null;
        this.stateListConsultaStatusX00007300007400006100007400006500003a00007500006900002e00006300006f00006e00007300007500006c00007400006100007300002e00006c00006900007300007400004300006f00006e00007300007500006c00007400006100002e00006900006e00007000007500007400002e000073000074000061000074000075000073 = null;
        this.stateListConsultaPage = null;
        this.stateListConsultaStatusX00007300007400006100007400006500003a00007500006900002e00006300006f00006e00007300007500006c00007400006100007300002e00006c00006900007300007400004300006f00006e00007300007500006c00007400006100002e000073000074000061000074000075000073 = 'idle';
        this.stateListConsultaError = null;
        this.stateListConsultaResult = [];
        this.stateListPacienteId = null;
        this.stateListPacienteDetailsIdentificationSubtype = null;
        this.stateListPacienteDetailsIdentificationName = null;
        this.stateListPacienteDetailsIdentificationDocType = null;
        this.stateListPacienteDetailsIdentificationDocId = null;
        this.stateListPacienteDetailsIdentificationCountryCode = null;
        this.stateListPacientePage = null;
        this.stateListPacienteStatus = 'idle';
        this.stateListPacienteError = null;
        this.stateListPacienteResult = [];
        this.stateListProfissionalId = null;
        this.stateListProfissionalDetailsIdentificationSubtype = null;
        this.stateListProfissionalDetailsIdentificationName = null;
        this.stateListProfissionalDetailsIdentificationStatus = null;
        this.stateListProfissionalDetailsIdentificationDocType = null;
        this.stateListProfissionalDetailsIdentificationDocId = null;
        this.stateListProfissionalDetailsIdentificationCountryCode = null;
        this.stateListProfissionalPage = null;
        this.stateListProfissionalStatus = 'idle';
        this.stateListProfissionalError = null;
        this.stateListProfissionalResult = [];
        this.subscribedKeys = Object.values(K);
        this.loading = new Set();
    }
    connectedCallback() { super.connectedCallback(); this.hydrate(); this.subscribedKeys.forEach((key) => subscribe([key], this)); void this.runListConsulta(); void this.runListPaciente(); void this.runListProfissional(); }
    disconnectedCallback() { this.subscribedKeys.forEach((key) => unsubscribe([key], this)); super.disconnectedCallback(); }
    handleIcaStateChange(key, value) { if (value === undefined)
        return; const map = { [K.pageStatus]: 'pageStatus', [K.scenary]: 'scenary', [K.createPaciente]: 'stateCreateConsultaPacienteId', [K.createProfissional]: 'stateCreateConsultaProfissionalId', [K.createScheduled]: 'stateCreateConsultaScheduledAt', [K.createConfirmed]: 'stateCreateConsultaDetailsTelephoneConfirmationConfirmedAt', [K.createStatus]: 'stateCreateConsultaStatus', [K.createError]: 'stateCreateConsultaError', [K.createResult]: 'stateCreateConsultaResult', [K.faltaId]: 'stateRegistrarFaltaId', [K.faltaStatus]: 'stateRegistrarFaltaStatus', [K.faltaError]: 'stateRegistrarFaltaError', [K.faltaResult]: 'stateRegistrarFaltaResult', [K.updateId]: 'stateUpdateConsultaId', [K.updatePaciente]: 'stateUpdateConsultaPacienteId', [K.updateProfissional]: 'stateUpdateConsultaProfissionalId', [K.updateScheduled]: 'stateUpdateConsultaScheduledAt', [K.updateConfirmed]: 'stateUpdateConsultaDetailsTelephoneConfirmationConfirmedAt', [K.updateStatus]: 'stateUpdateConsultaStatus', [K.updateError]: 'stateUpdateConsultaError', [K.updateResult]: 'stateUpdateConsultaResult', [K.listId]: 'stateListConsultaId', [K.listPaciente]: 'stateListConsultaPacienteId', [K.listProfissional]: 'stateListConsultaProfissionalId', [K.listScheduled]: 'stateListConsultaScheduledAt', [K.listInputStatus]: listConsultaInputStatusMember, [K.listPage]: 'stateListConsultaPage', [K.listStatus]: listConsultaStatusMember, [K.listError]: 'stateListConsultaError', [K.listResult]: 'stateListConsultaResult', [K.pacienteId]: 'stateListPacienteId', [K.pacienteSubtype]: 'stateListPacienteDetailsIdentificationSubtype', [K.pacienteName]: 'stateListPacienteDetailsIdentificationName', [K.pacienteDocType]: 'stateListPacienteDetailsIdentificationDocType', [K.pacienteDocId]: 'stateListPacienteDetailsIdentificationDocId', [K.pacienteCountry]: 'stateListPacienteDetailsIdentificationCountryCode', [K.pacientePage]: 'stateListPacientePage', [K.pacienteStatus]: 'stateListPacienteStatus', [K.pacienteError]: 'stateListPacienteError', [K.pacienteResult]: 'stateListPacienteResult', [K.profissionalId]: 'stateListProfissionalId', [K.profissionalSubtype]: 'stateListProfissionalDetailsIdentificationSubtype', [K.profissionalName]: 'stateListProfissionalDetailsIdentificationName', [K.profissionalStatusInput]: 'stateListProfissionalDetailsIdentificationStatus', [K.profissionalDocType]: 'stateListProfissionalDetailsIdentificationDocType', [K.profissionalDocId]: 'stateListProfissionalDetailsIdentificationDocId', [K.profissionalCountry]: 'stateListProfissionalDetailsIdentificationCountryCode', [K.profissionalPage]: 'stateListProfissionalPage', [K.profissionalStatus]: 'stateListProfissionalStatus', [K.profissionalError]: 'stateListProfissionalError', [K.profissionalResult]: 'stateListProfissionalResult' }; const member = map[key]; if (member) {
        this[member] = value;
        this.requestUpdate();
    } }
    hydrate() { this.subscribedKeys.forEach((key) => { const value = getState(key); if (value !== undefined)
        this.handleIcaStateChange(key, value); }); }
    publish(key, member, value) { setState(key, value); this[member] = value; this.requestUpdate(); }
    has(value) { return value !== null && value !== undefined && !(typeof value === 'string' && value.length === 0); }
    feedback(error, fallback) { if (error && typeof error === 'object' && 'message' in error && typeof error.message === 'string') {
        const e = error;
        return { code: typeof e.code === 'string' ? e.code : 'UNEXPECTED_ERROR', message: e.message, details: e.details };
    } return { code: 'UNEXPECTED_ERROR', message: fallback }; }
    required(values) { const missing = values.find((entry) => !this.has(entry[1])); return missing ? { code: 'MISSING_REQUIRED_INPUT', message: `Informe ${missing[0]}.` } : null; }
    async call(route, params, options) { return execBff(route, params, options); }
    confirm(title, description) { return typeof window === 'undefined' || window.confirm(`${title}\n\n${description}`); }
    setScenario(value) { this.publish(K.scenary, 'scenary', value); }
    selectCreateConsultaPacienteId(id) { this.select(K.createPaciente, 'stateCreateConsultaPacienteId', id, K.pacienteResult); }
    selectCreateConsultaProfissionalId(id) { this.select(K.createProfissional, 'stateCreateConsultaProfissionalId', id, K.profissionalResult); }
    setCreateConsultaScheduledAt(value) { this.publish(K.createScheduled, 'stateCreateConsultaScheduledAt', value); }
    setCreateConsultaDetailsTelephoneConfirmationConfirmedAt(value) { this.publish(K.createConfirmed, 'stateCreateConsultaDetailsTelephoneConfirmationConfirmedAt', value); }
    selectRegistrarFaltaId(id) { this.select(K.faltaId, 'stateRegistrarFaltaId', id, K.listResult); }
    selectUpdateConsultaId(id) { this.select(K.updateId, 'stateUpdateConsultaId', id, K.listResult); }
    selectUpdateConsultaPacienteId(id) { this.select(K.updatePaciente, 'stateUpdateConsultaPacienteId', id, K.pacienteResult); }
    selectUpdateConsultaProfissionalId(id) { this.select(K.updateProfissional, 'stateUpdateConsultaProfissionalId', id, K.profissionalResult); }
    setUpdateConsultaScheduledAt(value) { this.publish(K.updateScheduled, 'stateUpdateConsultaScheduledAt', value); }
    setUpdateConsultaDetailsTelephoneConfirmationConfirmedAt(value) { this.publish(K.updateConfirmed, 'stateUpdateConsultaDetailsTelephoneConfirmationConfirmedAt', value); }
    select(key, member, id, resultKey) { if (id === null) {
        this.publish(key, member, null);
        return;
    } const rows = getState(resultKey); if (rows?.some((row) => row.id === id))
        this.publish(key, member, id); }
    setListConsultaId(value) { this.publish(K.listId, 'stateListConsultaId', value); }
    selectListConsultaPacienteId(id) { this.select(K.listPaciente, 'stateListConsultaPacienteId', id, K.pacienteResult); }
    selectListConsultaProfissionalId(id) { this.select(K.listProfissional, 'stateListConsultaProfissionalId', id, K.profissionalResult); }
    setListConsultaScheduledAt(value) { this.publish(K.listScheduled, 'stateListConsultaScheduledAt', value); }
    setListConsultaStatus(value) { this.publish(K.listInputStatus, listConsultaInputStatusMember, value); }
    setListPacienteId(value) { this.publish(K.pacienteId, 'stateListPacienteId', value); }
    setListPacienteDetailsIdentificationSubtype(value) { this.publish(K.pacienteSubtype, 'stateListPacienteDetailsIdentificationSubtype', value); }
    setListPacienteDetailsIdentificationName(value) { this.publish(K.pacienteName, 'stateListPacienteDetailsIdentificationName', value); }
    setListPacienteDetailsIdentificationDocType(value) { this.publish(K.pacienteDocType, 'stateListPacienteDetailsIdentificationDocType', value); }
    setListPacienteDetailsIdentificationDocId(value) { this.publish(K.pacienteDocId, 'stateListPacienteDetailsIdentificationDocId', value); }
    setListPacienteDetailsIdentificationCountryCode(value) { this.publish(K.pacienteCountry, 'stateListPacienteDetailsIdentificationCountryCode', value); }
    setListProfissionalId(value) { this.publish(K.profissionalId, 'stateListProfissionalId', value); }
    setListProfissionalDetailsIdentificationSubtype(value) { this.publish(K.profissionalSubtype, 'stateListProfissionalDetailsIdentificationSubtype', value); }
    setListProfissionalDetailsIdentificationName(value) { this.publish(K.profissionalName, 'stateListProfissionalDetailsIdentificationName', value); }
    setListProfissionalDetailsIdentificationStatus(value) { this.publish(K.profissionalStatusInput, 'stateListProfissionalDetailsIdentificationStatus', value); }
    setListProfissionalDetailsIdentificationDocType(value) { this.publish(K.profissionalDocType, 'stateListProfissionalDetailsIdentificationDocType', value); }
    setListProfissionalDetailsIdentificationDocId(value) { this.publish(K.profissionalDocId, 'stateListProfissionalDetailsIdentificationDocId', value); }
    setListProfissionalDetailsIdentificationCountryCode(value) { this.publish(K.profissionalCountry, 'stateListProfissionalDetailsIdentificationCountryCode', value); }
    async runCreateConsulta() { if (this.loading.has('createConsulta'))
        return; const missing = this.required([['Paciente', this.stateCreateConsultaPacienteId], ['Profissional', this.stateCreateConsultaProfissionalId], ['Data e horário', this.stateCreateConsultaScheduledAt], ['Confirmação telefônica', this.stateCreateConsultaDetailsTelephoneConfirmationConfirmedAt]]); if (missing) {
        this.publish(K.createError, 'stateCreateConsultaError', missing);
        this.publish(K.createStatus, 'stateCreateConsultaStatus', 'error');
        return;
    } const params = { pacienteId: this.stateCreateConsultaPacienteId, profissionalId: this.stateCreateConsultaProfissionalId, scheduledAt: this.stateCreateConsultaScheduledAt, details: { telephoneConfirmation: { confirmedAt: this.stateCreateConsultaDetailsTelephoneConfirmationConfirmedAt } } }; await this.command('createConsulta', K.createStatus, 'stateCreateConsultaStatus', K.createError, 'stateCreateConsultaError', K.createResult, 'stateCreateConsultaResult', createConsultaRoute, params, ['runListConsulta']); }
    async runRegistrarFalta() { if (!this.confirm('Registrar falta do paciente', 'Confirme que o paciente não compareceu à consulta agendada. A consulta será marcada como falta.'))
        return; const missing = this.required([['Id', this.stateRegistrarFaltaId]]); if (missing) {
        this.publish(K.faltaError, 'stateRegistrarFaltaError', missing);
        this.publish(K.faltaStatus, 'stateRegistrarFaltaStatus', 'error');
        return;
    } await this.command('registrarFalta', K.faltaStatus, 'stateRegistrarFaltaStatus', K.faltaError, 'stateRegistrarFaltaError', K.faltaResult, 'stateRegistrarFaltaResult', registrarFaltaRoute, { id: this.stateRegistrarFaltaId }, ['runListConsulta']); }
    async runUpdateConsulta() { const missing = this.required([['Id', this.stateUpdateConsultaId], ['Paciente', this.stateUpdateConsultaPacienteId], ['Profissional', this.stateUpdateConsultaProfissionalId], ['Data e horário', this.stateUpdateConsultaScheduledAt], ['Confirmação telefônica', this.stateUpdateConsultaDetailsTelephoneConfirmationConfirmedAt]]); if (missing) {
        this.publish(K.updateError, 'stateUpdateConsultaError', missing);
        this.publish(K.updateStatus, 'stateUpdateConsultaStatus', 'error');
        return;
    } const params = { id: this.stateUpdateConsultaId, pacienteId: this.stateUpdateConsultaPacienteId, profissionalId: this.stateUpdateConsultaProfissionalId, scheduledAt: this.stateUpdateConsultaScheduledAt, details: { telephoneConfirmation: { confirmedAt: this.stateUpdateConsultaDetailsTelephoneConfirmationConfirmedAt } } }; await this.command('updateConsulta', K.updateStatus, 'stateUpdateConsultaStatus', K.updateError, 'stateUpdateConsultaError', K.updateResult, 'stateUpdateConsultaResult', updateConsultaRoute, params, ['runListConsulta']); }
    async command(name, statusKey, statusMember, errorKey, errorMember, resultKey, resultMember, route, params, refresh) { if (this.loading.has(name))
        return; this.loading.add(name); this.publish(errorKey, errorMember, null); this.publish(statusKey, statusMember, 'loading'); try {
        const response = await runBlockingUiAction((signal) => this.call(route, params, { mode: 'blocking', signal }), { mode: 'blocking' });
        if (!response)
            throw new Error('Ação interrompida.');
        if (response.ok && response.data !== null) {
            this.publish(resultKey, resultMember, response.data);
            this.publish(statusKey, statusMember, 'success');
            for (const action of refresh)
                if (action === 'runListConsulta')
                    await this.runListConsulta();
        }
        else {
            const envelope = response.error;
            const feedback = this.feedback(envelope && typeof envelope === 'object' && 'message' in envelope && typeof envelope.message === 'string' ? envelope : 'Não foi possível concluir a ação.', 'Não foi possível concluir a ação.');
            this.publish(errorKey, errorMember, feedback);
            this.publish(statusKey, statusMember, 'error');
        }
    }
    catch (error) {
        const feedback = this.feedback(error, 'Não foi possível concluir a ação.');
        this.publish(errorKey, errorMember, feedback);
        this.publish(statusKey, statusMember, 'error');
    }
    finally {
        this.loading.delete(name);
    } }
    async runListConsulta() { const params = {}; if (this.has(this.stateListConsultaId))
        params.id = this.stateListConsultaId; if (this.has(this.stateListConsultaPacienteId))
        params.pacienteId = this.stateListConsultaPacienteId; if (this.has(this.stateListConsultaProfissionalId))
        params.profissionalId = this.stateListConsultaProfissionalId; if (this.has(this.stateListConsultaScheduledAt))
        params.scheduledAt = this.stateListConsultaScheduledAt; const status = this.stateListConsultaStatusX00007300007400006100007400006500003a00007500006900002e00006300006f00006e00007300007500006c00007400006100007300002e00006c00006900007300007400004300006f00006e00007300007500006c00007400006100002e00006900006e00007000007500007400002e000073000074000061000074000075000073; if (status !== null)
        params.status = status; if (this.stateListConsultaPage !== null)
        params.page = this.stateListConsultaPage; await this.query(K.listStatus, listConsultaStatusMember, K.listError, 'stateListConsultaError', K.listResult, 'stateListConsultaResult', listConsultaRoute, params); }
    async runListPaciente() { const params = {}; if (this.has(this.stateListPacienteId))
        params.id = this.stateListPacienteId; const identification = {}; if (this.stateListPacienteDetailsIdentificationSubtype !== null)
        identification.subtype = this.stateListPacienteDetailsIdentificationSubtype; if (this.has(this.stateListPacienteDetailsIdentificationName))
        identification.name = this.stateListPacienteDetailsIdentificationName; if (this.stateListPacienteDetailsIdentificationDocType !== null)
        identification.docType = this.stateListPacienteDetailsIdentificationDocType; if (this.has(this.stateListPacienteDetailsIdentificationDocId))
        identification.docId = this.stateListPacienteDetailsIdentificationDocId; if (this.has(this.stateListPacienteDetailsIdentificationCountryCode))
        identification.countryCode = this.stateListPacienteDetailsIdentificationCountryCode; if (Object.keys(identification).length)
        params.details = { identification }; if (this.stateListPacientePage !== null)
        params.page = this.stateListPacientePage; await this.query(K.pacienteStatus, 'stateListPacienteStatus', K.pacienteError, 'stateListPacienteError', K.pacienteResult, 'stateListPacienteResult', listPacienteRoute, params); }
    async runListProfissional() { const params = {}; if (this.has(this.stateListProfissionalId))
        params.id = this.stateListProfissionalId; const identification = {}; if (this.stateListProfissionalDetailsIdentificationSubtype !== null)
        identification.subtype = this.stateListProfissionalDetailsIdentificationSubtype; if (this.has(this.stateListProfissionalDetailsIdentificationName))
        identification.name = this.stateListProfissionalDetailsIdentificationName; if (this.stateListProfissionalDetailsIdentificationStatus !== null)
        identification.status = this.stateListProfissionalDetailsIdentificationStatus; if (this.stateListProfissionalDetailsIdentificationDocType !== null)
        identification.docType = this.stateListProfissionalDetailsIdentificationDocType; if (this.has(this.stateListProfissionalDetailsIdentificationDocId))
        identification.docId = this.stateListProfissionalDetailsIdentificationDocId; if (this.has(this.stateListProfissionalDetailsIdentificationCountryCode))
        identification.countryCode = this.stateListProfissionalDetailsIdentificationCountryCode; if (Object.keys(identification).length)
        params.details = { identification }; if (this.stateListProfissionalPage !== null)
        params.page = this.stateListProfissionalPage; await this.query(K.profissionalStatus, 'stateListProfissionalStatus', K.profissionalError, 'stateListProfissionalError', K.profissionalResult, 'stateListProfissionalResult', listProfissionalRoute, params); }
    async query(statusKey, statusMember, errorKey, errorMember, resultKey, resultMember, route, params) { this.publish(statusKey, statusMember, 'loading'); this.publish(errorKey, errorMember, null); try {
        const response = await this.call(route, params, { mode: 'silent' });
        if (response.ok && response.data !== null) {
            this.publish(resultKey, resultMember, response.data);
            this.publish(statusKey, statusMember, Array.isArray(response.data) && response.data.length === 0 ? 'empty' : 'success');
        }
        else {
            const feedback = this.feedback(response.error, 'Não foi possível carregar os dados.');
            this.publish(errorKey, errorMember, feedback);
            this.publish(statusKey, statusMember, 'error');
        }
    }
    catch (error) {
        this.publish(errorKey, errorMember, this.feedback(error, 'Não foi possível carregar os dados.'));
        this.publish(statusKey, statusMember, 'error');
    } }
    enterBaseScenario() { this.setScenario('base'); }
    enterDetailConsultaScenario() { this.setScenario('detailConsulta'); }
    enterCreateConsultaScenario() { this.setScenario('createConsulta'); }
    enterUpdateConsultaScenario() { if (this.stateUpdateConsultaId === null) {
        this.publish(K.updateError, 'stateUpdateConsultaError', { code: 'MISSING_REQUIRED_INPUT', message: 'Selecione uma consulta antes de editar.' });
        return;
    } this.setScenario('updateConsulta'); }
    /** setter for state ui.consultas.scenary */
    setUiScenary(value) {
        const allowed = ['base', 'detailConsulta', 'createConsulta', 'updateConsulta'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        if (value === 'updateConsulta' && (!this.id))
            next = 'base';
        this.scenary = next;
        setState('ui.consultas.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const rawId = params.get('id') || '';
        if (rawId) {
            if (!this.id) {
                this.id = rawId;
                setState('ui.consultas.updateConsulta.input.id', rawId);
            }
        }
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
}

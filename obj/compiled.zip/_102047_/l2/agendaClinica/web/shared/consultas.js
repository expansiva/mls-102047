/// <mls fileReference="_102047_/l2/agendaClinica/web/shared/consultas.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.agendaClinica.consultas.cabecalho': 'cabecalho', 'ui.agendaClinica.consultas.quantidadePendentes': 'quantidadePendentes', 'ui.agendaClinica.consultas.agenda': 'agenda', 'ui.agendaClinica.consultas.consulta': 'consulta', 'ui.agendaClinica.consultas.pacientes': 'pacientes', 'ui.agendaClinica.consultas.profissionais': 'profissionais', 'ui.agendaClinica.consultas.selectedConsulta': 'selectedConsulta', 'ui.agendaClinica.consultas.dataAgenda': 'dataAgenda', 'ui.agendaClinica.consultas.status': 'status', 'ui.agendaClinica.consultas.page': 'page', 'ui.agendaClinica.consultas.id': 'id', 'ui.agendaClinica.consultas.termo': 'termo', 'ui.agendaClinica.consultas.pacienteId': 'pacienteId', 'ui.agendaClinica.consultas.consultaId': 'consultaId', 'ui.agendaClinica.consultas.profissionalId': 'profissionalId', 'ui.agendaClinica.consultas.agendarConsultaDraft': 'agendarConsultaDraft', 'ui.agendaClinica.consultas.pageStatus': 'pageStatus', 'ui.agendaClinica.consultas.scenary': 'scenary',
    'ui.agendaClinica.consultas.carregarAgendaStatus': 'carregarAgendaStatus', 'ui.agendaClinica.consultas.carregarAgendaError': 'carregarAgendaError', 'ui.agendaClinica.consultas.filtrarAgendaStatus': 'filtrarAgendaStatus', 'ui.agendaClinica.consultas.filtrarAgendaError': 'filtrarAgendaError', 'ui.agendaClinica.consultas.carregarMaisAgendaStatus': 'carregarMaisAgendaStatus', 'ui.agendaClinica.consultas.carregarMaisAgendaError': 'carregarMaisAgendaError', 'ui.agendaClinica.consultas.consultarConsultaSelecionadaStatus': 'consultarConsultaSelecionadaStatus', 'ui.agendaClinica.consultas.consultarConsultaSelecionadaError': 'consultarConsultaSelecionadaError', 'ui.agendaClinica.consultas.localizarPacientesParaAgendamentoStatus': 'localizarPacientesParaAgendamentoStatus', 'ui.agendaClinica.consultas.localizarPacientesParaAgendamentoError': 'localizarPacientesParaAgendamentoError', 'ui.agendaClinica.consultas.carregarMaisPacientesParaAgendamentoStatus': 'carregarMaisPacientesParaAgendamentoStatus', 'ui.agendaClinica.consultas.carregarMaisPacientesParaAgendamentoError': 'carregarMaisPacientesParaAgendamentoError', 'ui.agendaClinica.consultas.localizarProfissionaisParaAgendamentoStatus': 'localizarProfissionaisParaAgendamentoStatus', 'ui.agendaClinica.consultas.localizarProfissionaisParaAgendamentoError': 'localizarProfissionaisParaAgendamentoError', 'ui.agendaClinica.consultas.carregarMaisProfissionaisParaAgendamentoStatus': 'carregarMaisProfissionaisParaAgendamentoStatus', 'ui.agendaClinica.consultas.carregarMaisProfissionaisParaAgendamentoError': 'carregarMaisProfissionaisParaAgendamentoError', 'ui.agendaClinica.consultas.agendarConsultaStatus': 'agendarConsultaStatus', 'ui.agendaClinica.consultas.agendarConsultaError': 'agendarConsultaError', 'ui.agendaClinica.consultas.confirmarConsultaStatus': 'confirmarConsultaStatus', 'ui.agendaClinica.consultas.confirmarConsultaError': 'confirmarConsultaError', 'ui.agendaClinica.consultas.registrarFaltaStatus': 'registrarFaltaStatus', 'ui.agendaClinica.consultas.registrarFaltaError': 'registrarFaltaError'
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const EMPTY_DRAFT = () => ({ pacienteId: null, profissionalId: null, scheduledAt: null });
export class AgendaClinicaConsultasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state cabecalho — Cabeçalho da agenda no dia consultado.; source carregarAgenda.cabecalho; organisms listaAgenda */
        this.cabecalho = null;
        /** state quantidadePendentes — Devolve o cabeçalho da data, o indicador já calculado e uma página de linhas de agenda prontas para exibição.; source carregarAgenda.quantidadePendentes; organisms listaAgenda */
        this.quantidadePendentes = null;
        /** state agenda — Linha pronta para a agenda, com os nomes resolvidos do paciente e do profissional.; source carregarAgenda.agenda; organisms listaAgenda */
        this.agenda = null;
        /** state consulta — Consulta selecionada, composta com paciente e profissional, para conferência, ações e preenchimento do formulário.; source consultarConsultaSelecionada.consulta; organisms acoesConsulta, detalheConsulta, formularioConsulta */
        this.consulta = null;
        /** state pacientes — Paciente identificado em uma linha de agenda ou opção de agendamento.; source localizarPacientesParaAgendamento.pacientes; organisms formularioConsulta */
        this.pacientes = null;
        /** state profissionais — Profissional identificado em uma linha de agenda ou opção de agendamento.; source localizarProfissionaisParaAgendamento.profissionais; organisms formularioConsulta */
        this.profissionais = null;
        /** state selectedConsulta — Consulta selecionada, composta com paciente e profissional, para conferência, ações e preenchimento do formulário.; source entry.params.consultaId; organisms detalheConsulta, listaAgenda */
        this.selectedConsulta = null;
        this.dataAgenda = null;
        this.status = null;
        this.page = null;
        this.id = '';
        this.termo = null;
        this.pacienteId = null;
        this.consultaId = null;
        this.profissionalId = null;
        this.agendarConsultaDraft = EMPTY_DRAFT();
        this.pageStatus = 'idle';
        this.scenary = '';
        this.carregarAgendaStatus = 'idle';
        this.carregarAgendaError = null;
        this.filtrarAgendaStatus = 'idle';
        this.filtrarAgendaError = null;
        this.carregarMaisAgendaStatus = 'idle';
        this.carregarMaisAgendaError = null;
        this.consultarConsultaSelecionadaStatus = 'idle';
        this.consultarConsultaSelecionadaError = null;
        this.localizarPacientesParaAgendamentoStatus = 'idle';
        this.localizarPacientesParaAgendamentoError = null;
        this.carregarMaisPacientesParaAgendamentoStatus = 'idle';
        this.carregarMaisPacientesParaAgendamentoError = null;
        this.localizarProfissionaisParaAgendamentoStatus = 'idle';
        this.localizarProfissionaisParaAgendamentoError = null;
        this.carregarMaisProfissionaisParaAgendamentoStatus = 'idle';
        this.carregarMaisProfissionaisParaAgendamentoError = null;
        this.agendarConsultaStatus = 'idle';
        this.agendarConsultaError = null;
        this.confirmarConsultaStatus = 'idle';
        this.confirmarConsultaError = null;
        this.registrarFaltaStatus = 'idle';
        this.registrarFaltaError = null;
    }
    publish(member, value) { this[member] = value; setState(`ui.agendaClinica.consultas.${member}`, value); }
    publishDynamic(member, value) { this[member] = value; setState(`ui.agendaClinica.consultas.${member}`, value); }
    assignState(key, value) { const member = STATE_MEMBER_BY_KEY[key]; if (member)
        this[member] = value; }
    error(name, _error) { return { code: 'client.unexpected', message: '', details: { name } }; }
    async query(request, input, status, errorState) { if (this[status] === 'loading')
        return null; this.publishDynamic(status, 'loading'); this.publishDynamic(errorState, null); try {
        const response = await execBff(request, input, { mode: 'silent' });
        if (!response.ok || !response.data) {
            this.publishDynamic(errorState, response.error);
            this.publishDynamic(status, 'error');
            return null;
        }
        this.publishDynamic(status, 'success');
        return response.data;
    }
    catch (caught) {
        this.publishDynamic(errorState, this.error(request, caught));
        this.publishDynamic(status, 'error');
        return null;
    } }
    currentStatus() { const value = this.status; if (value === 'scheduled' || value === 'confirmed' || value === 'noShow' || value === 'attended')
        return value; return undefined; }
    agendaInput(page) { if (!this.dataAgenda)
        return null; const status = this.currentStatus(); return { dataAgenda: this.dataAgenda, page, pageSize: 20, ...(status ? { status } : {}) }; }
    async applyAgenda(output) { this.publish('cabecalho', output.cabecalho); this.publish('quantidadePendentes', output.quantidadePendentes); this.publish('agenda', output.agenda); }
    async carregarAgenda() { this.publish('pageStatus', 'loading'); const input = this.agendaInput(this.page && this.page > 0 ? this.page : 1); if (!input) {
        this.publish('pageStatus', 'error');
        return;
    } const output = await this.query('agendaClinica.consultas.carregarAgenda', input, 'carregarAgendaStatus', 'carregarAgendaError'); if (!output) {
        this.publish('pageStatus', 'error');
        return;
    } await this.applyAgenda(output); this.publish('pageStatus', output.agenda.items.length === 0 ? 'empty' : 'success'); }
    async filtrarAgenda() { const input = this.agendaInput(1); if (!input)
        return; const output = await this.query('agendaClinica.consultas.filtrarAgenda', input, 'filtrarAgendaStatus', 'filtrarAgendaError'); if (output)
        await this.applyAgenda(output); }
    async carregarMaisAgenda() { if (!this.agenda || !this.agenda.hasMore)
        return; const input = this.agendaInput(this.agenda.page + 1); if (!input)
        return; const output = await this.query('agendaClinica.consultas.carregarMaisAgenda', input, 'carregarMaisAgendaStatus', 'carregarMaisAgendaError'); if (!output)
        return; this.publish('agenda', { ...output.agenda, items: [...this.agenda.items, ...output.agenda.items] }); }
    async consultarConsultaSelecionada() { const selected = this.selectedConsulta ?? this.consultaId ?? (this.id || null); if (!selected)
        return; const output = await this.query('agendaClinica.consultas.consultarConsultaSelecionada', { id: selected }, 'consultarConsultaSelecionadaStatus', 'consultarConsultaSelecionadaError'); if (output)
        this.publish('consulta', output.consulta); }
    async localizarPacientesParaAgendamento() { const output = await this.query('agendaClinica.consultas.localizarPacientesParaAgendamento', { termo: this.termo ?? '', page: 1, pageSize: 20 }, 'localizarPacientesParaAgendamentoStatus', 'localizarPacientesParaAgendamentoError'); if (output)
        this.publish('pacientes', output.pacientes); }
    async carregarMaisPacientesParaAgendamento() { if (!this.pacientes || !this.pacientes.hasMore)
        return; const output = await this.query('agendaClinica.consultas.carregarMaisPacientesParaAgendamento', { termo: this.termo ?? '', page: this.pacientes.page + 1, pageSize: 20 }, 'carregarMaisPacientesParaAgendamentoStatus', 'carregarMaisPacientesParaAgendamentoError'); if (!output || !this.pacientes)
        return; this.publish('pacientes', { ...output.pacientes, items: [...this.pacientes.items, ...output.pacientes.items] }); }
    async localizarProfissionaisParaAgendamento() { const output = await this.query('agendaClinica.consultas.localizarProfissionaisParaAgendamento', { termo: this.termo ?? '', page: 1, pageSize: 20 }, 'localizarProfissionaisParaAgendamentoStatus', 'localizarProfissionaisParaAgendamentoError'); if (output)
        this.publish('profissionais', output.profissionais); }
    async carregarMaisProfissionaisParaAgendamento() { if (!this.profissionais || !this.profissionais.hasMore)
        return; const output = await this.query('agendaClinica.consultas.carregarMaisProfissionaisParaAgendamento', { termo: this.termo ?? '', page: this.profissionais.page + 1, pageSize: 20 }, 'carregarMaisProfissionaisParaAgendamentoStatus', 'carregarMaisProfissionaisParaAgendamentoError'); if (!output || !this.profissionais)
        return; this.publish('profissionais', { ...output.profissionais, items: [...this.profissionais.items, ...output.profissionais.items] }); }
    setAgendarConsultaDraft(value) { this.publish('agendarConsultaDraft', value); }
    async selectConsulta(value) { this.publish('consultaId', value); this.publish('selectedConsulta', value); if (value)
        await this.consultarConsultaSelecionada(); }
    async command(request, input, status, errorState) { this.publishDynamic(status, 'loading'); this.publishDynamic(errorState, null); const result = await runBlockingUiAction(signal => execBff(request, input, { mode: 'blocking', signal })); if (!result) {
        this.publishDynamic(errorState, { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
        this.publishDynamic(status, 'error');
        return null;
    } if (!result.ok || !result.data) {
        this.publishDynamic(errorState, result.error);
        this.publishDynamic(status, 'error');
        return null;
    } this.publishDynamic(status, 'success'); return result.data; }
    commandAgenda() { if (!this.dataAgenda)
        return null; const status = this.currentStatus(); return { dataAgenda: this.dataAgenda, page: this.agenda?.page ?? 1, pageSize: 20, ...(status ? { statusAgenda: status } : {}) }; }
    async agendarConsulta() { const draft = this.agendarConsultaDraft; const context = this.commandAgenda(); const pacienteId = draft.pacienteId; const profissionalId = draft.profissionalId; const scheduledAt = draft.scheduledAt; const missing = []; if (!pacienteId)
        missing.push('agendarConsultaDraft.pacienteId'); if (!profissionalId)
        missing.push('agendarConsultaDraft.profissionalId'); if (!scheduledAt)
        missing.push('agendarConsultaDraft.scheduledAt'); if (!context)
        missing.push('dataAgenda'); if (missing.length > 0 || !pacienteId || !profissionalId || !scheduledAt || !context) {
        this.publish('agendarConsultaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
        this.publish('agendarConsultaStatus', 'error');
        return;
    } const output = await this.command('agendaClinica.consultas.agendarConsulta', { pacienteId, profissionalId, scheduledAt, ...context }, 'agendarConsultaStatus', 'agendarConsultaError'); if (!output)
        return; this.publish('consulta', output.consulta); await this.applyAgenda(output); this.publish('agendarConsultaDraft', EMPTY_DRAFT()); }
    async confirmarConsulta() { const context = this.commandAgenda(); if (!this.consulta || !context)
        return; const output = await this.command('agendaClinica.consultas.confirmarConsulta', { id: this.consulta.id, version: this.consulta.version, ...context }, 'confirmarConsultaStatus', 'confirmarConsultaError'); if (output) {
        this.publish('consulta', output.consulta);
        await this.applyAgenda(output);
    } }
    async registrarFalta() { const context = this.commandAgenda(); if (!this.consulta || !context)
        return; const output = await this.command('agendaClinica.consultas.registrarFalta', { id: this.consulta.id, version: this.consulta.version, ...context }, 'registrarFaltaStatus', 'registrarFaltaError'); if (output) {
        this.publish('consulta', output.consulta);
        await this.applyAgenda(output);
    } }
    setScenario(value) { this.publish('scenary', value); }
    connectedCallback() { super.connectedCallback(); this.resetVisit(); for (const key of STATE_KEYS) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (!['pageStatus', 'scenary', 'agendarConsultaDraft'].includes(member) && !member.endsWith('Status') && !member.endsWith('Error')) {
            const value = getState(key);
            if (value !== undefined)
                this.assignState(key, value);
        }
    } subscribe(STATE_KEYS, this); this.applyEntryParams(); void this.carregarAgenda(); }
    disconnectedCallback() { unsubscribe(STATE_KEYS, this); super.disconnectedCallback(); }
    resetVisit() { this.publish('pageStatus', 'idle'); this.publish('scenary', ''); this.publish('agendarConsultaDraft', EMPTY_DRAFT()); this.publish('filtrarAgendaStatus', 'idle'); this.publish('filtrarAgendaError', null); this.publish('carregarMaisAgendaStatus', 'idle'); this.publish('carregarMaisAgendaError', null); this.publish('consultarConsultaSelecionadaStatus', 'idle'); this.publish('consultarConsultaSelecionadaError', null); this.publish('localizarPacientesParaAgendamentoStatus', 'idle'); this.publish('localizarPacientesParaAgendamentoError', null); this.publish('carregarMaisPacientesParaAgendamentoStatus', 'idle'); this.publish('carregarMaisPacientesParaAgendamentoError', null); this.publish('localizarProfissionaisParaAgendamentoStatus', 'idle'); this.publish('localizarProfissionaisParaAgendamentoError', null); this.publish('carregarMaisProfissionaisParaAgendamentoStatus', 'idle'); this.publish('carregarMaisProfissionaisParaAgendamentoError', null); this.publish('agendarConsultaStatus', 'idle'); this.publish('agendarConsultaError', null); this.publish('confirmarConsultaStatus', 'idle'); this.publish('confirmarConsultaError', null); this.publish('registrarFaltaStatus', 'idle'); this.publish('registrarFaltaError', null); }
    applyEntryParams() { const params = new URLSearchParams(window.location.search); const names = ['dataAgenda', 'status', 'page', 'id', 'termo', 'pacienteId', 'consultaId', 'profissionalId']; for (const name of names) {
        let raw = params.get(name);
        if (raw === null) {
            try {
                raw = localStorage.getItem(`agendaClinica.consultas.${name}`);
            }
            catch {
                raw = null;
            }
        }
        if (name === 'page') {
            const numberValue = raw === null ? null : Number(raw);
            if (numberValue !== null && Number.isFinite(numberValue))
                this.publish('page', numberValue);
        }
        else if (name === 'consultaId') {
            this.publish('consultaId', raw);
            this.publish('selectedConsulta', raw);
        }
        else if (name === 'dataAgenda')
            this.publish('dataAgenda', raw);
        else if (name === 'status')
            this.publish('status', raw);
        else if (name === 'id') {
            if (raw !== null)
                this.publish('id', raw);
        }
        else if (name === 'termo')
            this.publish('termo', raw);
        else if (name === 'pacienteId')
            this.publish('pacienteId', raw);
        else if (name === 'profissionalId') {
            this.publish('profissionalId', raw);
            const draft = this.agendarConsultaDraft;
            this.publish('agendarConsultaDraft', { ...draft, profissionalId: raw });
        }
    } }
    handleIcaStateChange(key, value) { if (!STATE_MEMBER_BY_KEY[key]) {
        super.handleIcaStateChange(key, value);
        return;
    } if (value === undefined)
        return; this.assignState(key, value); this.requestUpdate(); }
}
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "cabecalho", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "quantidadePendentes", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "agenda", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "consulta", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "pacientes", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "profissionais", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "selectedConsulta", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "dataAgenda", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "status", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "page", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "id", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "termo", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "pacienteId", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "consultaId", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "profissionalId", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "agendarConsultaDraft", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "scenary", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarAgendaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarAgendaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "filtrarAgendaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "filtrarAgendaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarMaisAgendaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarMaisAgendaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "consultarConsultaSelecionadaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "consultarConsultaSelecionadaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "localizarPacientesParaAgendamentoStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "localizarPacientesParaAgendamentoError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarMaisPacientesParaAgendamentoStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarMaisPacientesParaAgendamentoError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "localizarProfissionaisParaAgendamentoStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "localizarProfissionaisParaAgendamentoError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarMaisProfissionaisParaAgendamentoStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "carregarMaisProfissionaisParaAgendamentoError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "agendarConsultaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "agendarConsultaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "confirmarConsultaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "confirmarConsultaError", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "registrarFaltaStatus", void 0);
__decorate([
    property({ attribute: false })
], AgendaClinicaConsultasShared.prototype, "registrarFaltaError", void 0);

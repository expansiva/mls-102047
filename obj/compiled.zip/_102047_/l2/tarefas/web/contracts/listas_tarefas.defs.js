/// <mls fileReference="_102047_/l2/tarefas/web/contracts/listas_tarefas.defs.ts" enhancement="_blank"/>
export {};

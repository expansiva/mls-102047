/// <mls fileReference="_102047_/l2/tarefas/web/contracts/listas.defs.ts" enhancement="_blank"/>
export {};

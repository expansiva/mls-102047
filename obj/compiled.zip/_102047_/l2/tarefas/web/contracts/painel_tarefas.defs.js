/// <mls fileReference="_102047_/l2/tarefas/web/contracts/painel_tarefas.defs.ts" enhancement="_blank"/>
export {};

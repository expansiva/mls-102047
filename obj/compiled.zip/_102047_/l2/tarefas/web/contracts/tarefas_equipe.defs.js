/// <mls fileReference="_102047_/l2/tarefas/web/contracts/tarefas_equipe.defs.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102047_/l2/tarefas/web/contracts/inicio_gestor.defs.ts" enhancement="_blank"/>
export {};

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/meus_avisos.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.meus_avisos.avisos': 'avisos',
    'ui.tarefas.meus_avisos.avisoAtual': 'avisoAtual',
    'ui.tarefas.meus_avisos.selectedAvisoVencimento': 'selectedAvisoVencimento',
    'ui.tarefas.meus_avisos.filtroDataInicio': 'filtroDataInicio',
    'ui.tarefas.meus_avisos.filtroDataFim': 'filtroDataFim',
    'ui.tarefas.meus_avisos.pageStatus': 'pageStatus',
    'ui.tarefas.meus_avisos.qryPaginaMeusAvisosStatus': 'qryPaginaMeusAvisosStatus',
    'ui.tarefas.meus_avisos.qryPaginaMeusAvisosError': 'qryPaginaMeusAvisosError',
    'ui.tarefas.meus_avisos.qryListarMeusAvisosStatus': 'qryListarMeusAvisosStatus',
    'ui.tarefas.meus_avisos.qryListarMeusAvisosError': 'qryListarMeusAvisosError',
    'ui.tarefas.meus_avisos.qryAvisoPorIdStatus': 'qryAvisoPorIdStatus',
    'ui.tarefas.meus_avisos.qryAvisoPorIdError': 'qryAvisoPorIdError',
    'ui.tarefas.meus_avisos.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_SIZE = 20;
const SELECTED_PARAM = 'avisoVencimentoId';
function emptyAvisosPage() {
    return { items: [], page: 1, pageSize: PAGE_SIZE, hasMore: false };
}
export class TarefasMeus_avisosShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state avisos — the list of daily due-date notices of the signed-in person, with reference date, delivery status, totals and generation/finish record; source qryPaginaMeusAvisos.avisos; organisms historicoAvisos, listaAvisos */
        this.avisos = emptyAvisosPage();
        /** state avisoAtual — the notice shown in the detail (latest completed notice on load, or the one selected) with its totals and task lines; source qryPaginaMeusAvisos.avisoAtual (also written by qryAvisoPorId); organism avisoDoDia */
        this.avisoAtual = null;
        /** state selectedAvisoVencimento — the id of the AvisoVencimento selected in listaAvisos; source entry.params.avisoVencimentoId; organisms avisoDoDia, listaAvisos; lives in the URL */
        this.selectedAvisoVencimento = null;
        /** state filtroDataInicio — draft: inclusive start of the reference-date period used to filter listaAvisos (ISO date) or null; used by qryListarMeusAvisos; organism listaAvisos */
        this.filtroDataInicio = null;
        /** state filtroDataFim — draft: inclusive end of the reference-date period used to filter listaAvisos (ISO date) or null; used by qryListarMeusAvisos; organism listaAvisos */
        this.filtroDataFim = null;
        /** state pageStatus — overall status of the page: loading while the initial load runs, error if it failed, empty when there are no notices, success otherwise */
        this.pageStatus = 'idle';
        /** state qryPaginaMeusAvisosStatus — status of the initial load request */
        this.qryPaginaMeusAvisosStatus = 'idle';
        /** state qryPaginaMeusAvisosError — error of the initial load request, null when none */
        this.qryPaginaMeusAvisosError = null;
        /** state qryListarMeusAvisosStatus — status of the period list request */
        this.qryListarMeusAvisosStatus = 'idle';
        /** state qryListarMeusAvisosError — error of the period list request, null when none */
        this.qryListarMeusAvisosError = null;
        /** state qryAvisoPorIdStatus — status of the open-one-notice request */
        this.qryAvisoPorIdStatus = 'idle';
        /** state qryAvisoPorIdError — error of the open-one-notice request, null when none */
        this.qryAvisoPorIdError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.subscribed = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.meus_avisos.${member}`, value);
        if (member === 'selectedAvisoVencimento') {
            try {
                const url = new URL(window.location.href);
                if (value === null || value === undefined || value === '') {
                    url.searchParams.delete(SELECTED_PARAM);
                }
                else {
                    url.searchParams.set(SELECTED_PARAM, String(value));
                }
                history.replaceState(history.state, '', `${url.pathname}${url.search}${url.hash}`);
            }
            catch {
                // URL not writable: the state stays in memory
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        if (!this.subscribed) {
            subscribe([...STATE_KEYS], this);
            this.subscribed = true;
        }
        this.applyEntryParams();
        void this.startVisit();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        this.subscribed = false;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const dataKeys = ['ui.tarefas.meus_avisos.avisos', 'ui.tarefas.meus_avisos.avisoAtual'];
        for (const key of dataKeys) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('filtroDataInicio', null);
        this.publish('filtroDataFim', null);
        this.publish('qryPaginaMeusAvisosStatus', 'idle');
        this.publish('qryPaginaMeusAvisosError', null);
        this.publish('qryListarMeusAvisosStatus', 'idle');
        this.publish('qryListarMeusAvisosError', null);
        this.publish('qryAvisoPorIdStatus', 'idle');
        this.publish('qryAvisoPorIdError', null);
    }
    applyEntryParams() {
        const raw = new URLSearchParams(window.location.search).get(SELECTED_PARAM);
        const value = raw !== null && raw !== '' ? raw : null;
        this.publish('selectedAvisoVencimento', value);
    }
    async startVisit() {
        await this.qryPaginaMeusAvisos();
        if (this.selectedAvisoVencimento !== null) {
            await this.qryAvisoPorId();
        }
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    /** scene — publishes the visible scene of the page; scene is a free scene name, '' for none */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** draft — sets the start of the reference-date period filter (ISO date, null clears it); only stores it, call qryListarMeusAvisos() afterwards to apply */
    setFiltroDataInicio(value) {
        this.publish('filtroDataInicio', value !== null && value !== '' ? value : null);
    }
    /** draft — sets the end of the reference-date period filter (ISO date, null clears it); only stores it, call qryListarMeusAvisos() afterwards to apply */
    setFiltroDataFim(value) {
        this.publish('filtroDataFim', value !== null && value !== '' ? value : null);
    }
    /** select — selects the notice with this id in listaAvisos (null clears the selection); publishes selectedAvisoVencimento, keeps it in the URL and, for an id, loads the notice into avisoAtual through qryAvisoPorId; a null clears avisoAtual */
    selectAvisoVencimento(id) {
        const value = id !== null && id !== '' ? id : null;
        this.publish('selectedAvisoVencimento', value);
        if (value === null) {
            this.publish('avisoAtual', null);
            this.publish('qryAvisoPorIdError', null);
            this.publish('qryAvisoPorIdStatus', 'idle');
            return;
        }
        void this.qryAvisoPorId();
    }
    /** request qryPaginaMeusAvisos — initial load: a page of the signed-in person's daily notices plus the latest completed notice with its task lines; redraws avisos (replace, or append items when append is true; page and hasMore stay in the list) and avisoAtual (replace, only when not appending and no notice is selected); page: page to load (default 1); append: true adds the next page to the current items (does nothing when there is no more); also the method to reload the page */
    async qryPaginaMeusAvisos(page = 1, append = false) {
        if (this.qryPaginaMeusAvisosStatus === 'loading')
            return;
        if (append && !this.avisos.hasMore)
            return;
        this.publish('qryPaginaMeusAvisosStatus', 'loading');
        this.publish('qryPaginaMeusAvisosError', null);
        if (!append)
            this.publish('pageStatus', 'loading');
        const input = { page, pageSize: PAGE_SIZE };
        try {
            const response = await execBff('tarefas.meus_avisos.qryPaginaMeusAvisos', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryPaginaMeusAvisosError', response.error ?? this.unexpectedError(null));
                this.publish('qryPaginaMeusAvisosStatus', 'error');
                if (!append)
                    this.publish('pageStatus', 'error');
                return;
            }
            const output = response.data;
            if (append) {
                this.publish('avisos', {
                    items: [...this.avisos.items, ...output.avisos.items],
                    page: output.avisos.page,
                    pageSize: output.avisos.pageSize,
                    hasMore: output.avisos.hasMore,
                });
            }
            else {
                this.publish('avisos', output.avisos);
                if (this.selectedAvisoVencimento === null) {
                    this.publish('avisoAtual', output.avisoAtual ?? null);
                }
            }
            this.publish('qryPaginaMeusAvisosStatus', 'success');
            if (!append) {
                this.publish('pageStatus', this.avisos.items.length === 0 ? 'empty' : 'success');
            }
        }
        catch (error) {
            this.publish('qryPaginaMeusAvisosError', this.unexpectedError(error));
            this.publish('qryPaginaMeusAvisosStatus', 'error');
            if (!append)
                this.publish('pageStatus', 'error');
        }
    }
    /** request qryListarMeusAvisos — lists the signed-in person's daily notices in the period held by filtroDataInicio and filtroDataFim, page by page; redraws avisos (replace, or append items when append is true; page and hasMore stay in the list); page: page to load (default 1, use 1 after a filter change); append: true adds the next page (does nothing when there is no more) */
    async qryListarMeusAvisos(page = 1, append = false) {
        if (this.qryListarMeusAvisosStatus === 'loading')
            return;
        if (append && !this.avisos.hasMore)
            return;
        this.publish('qryListarMeusAvisosStatus', 'loading');
        this.publish('qryListarMeusAvisosError', null);
        const inicio = this.filtroDataInicio;
        const fim = this.filtroDataFim;
        const input = {
            ...(inicio !== null && inicio !== '' ? { dataInicio: inicio } : {}),
            ...(fim !== null && fim !== '' ? { dataFim: fim } : {}),
            page,
            pageSize: PAGE_SIZE,
        };
        try {
            const response = await execBff('tarefas.meus_avisos.qryListarMeusAvisos', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryListarMeusAvisosError', response.error ?? this.unexpectedError(null));
                this.publish('qryListarMeusAvisosStatus', 'error');
                return;
            }
            const output = response.data;
            if (append) {
                this.publish('avisos', {
                    items: [...this.avisos.items, ...output.avisos.items],
                    page: output.avisos.page,
                    pageSize: output.avisos.pageSize,
                    hasMore: output.avisos.hasMore,
                });
            }
            else {
                this.publish('avisos', output.avisos);
            }
            this.publish('qryListarMeusAvisosStatus', 'success');
        }
        catch (error) {
            this.publish('qryListarMeusAvisosError', this.unexpectedError(error));
            this.publish('qryListarMeusAvisosStatus', 'error');
        }
    }
    /** request qryAvisoPorId — opens the selected notice (selectedAvisoVencimento) with its totals and task lines; redraws avisoAtual (replace); takes no argument: call selectAvisoVencimento(id) to choose the notice, which calls this */
    async qryAvisoPorId() {
        if (this.qryAvisoPorIdStatus === 'loading')
            return;
        const id = this.selectedAvisoVencimento;
        if (id === null || id === '') {
            this.publish('qryAvisoPorIdError', {
                code: 'client.requiredMissing',
                message: '',
                details: { stateKeys: ['ui.tarefas.meus_avisos.selectedAvisoVencimento'] },
            });
            this.publish('qryAvisoPorIdStatus', 'error');
            return;
        }
        this.publish('qryAvisoPorIdStatus', 'loading');
        this.publish('qryAvisoPorIdError', null);
        const input = { id };
        try {
            const response = await execBff('tarefas.meus_avisos.qryAvisoPorId', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryAvisoPorIdError', response.error ?? this.unexpectedError(null));
                this.publish('qryAvisoPorIdStatus', 'error');
                return;
            }
            this.publish('avisoAtual', response.data.aviso);
            this.publish('qryAvisoPorIdStatus', 'success');
        }
        catch (error) {
            this.publish('qryAvisoPorIdError', this.unexpectedError(error));
            this.publish('qryAvisoPorIdStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "avisos", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "avisoAtual", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "selectedAvisoVencimento", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "filtroDataInicio", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "filtroDataFim", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryPaginaMeusAvisosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryPaginaMeusAvisosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryListarMeusAvisosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryListarMeusAvisosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryAvisoPorIdStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryAvisoPorIdError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "scenary", void 0);

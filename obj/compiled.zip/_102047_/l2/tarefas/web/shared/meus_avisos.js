var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/meus_avisos.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.meus_avisos.avisos': 'avisos',
    'ui.tarefas.meus_avisos.avisoAtual': 'avisoAtual',
    'ui.tarefas.meus_avisos.selectedAvisoVencimento': 'selectedAvisoVencimento',
    'ui.tarefas.meus_avisos.filtroDataInicio': 'filtroDataInicio',
    'ui.tarefas.meus_avisos.filtroDataFim': 'filtroDataFim',
    'ui.tarefas.meus_avisos.pageStatus': 'pageStatus',
    'ui.tarefas.meus_avisos.qryPaginaMeusAvisosStatus': 'qryPaginaMeusAvisosStatus',
    'ui.tarefas.meus_avisos.qryPaginaMeusAvisosError': 'qryPaginaMeusAvisosError',
    'ui.tarefas.meus_avisos.qryListarMeusAvisosStatus': 'qryListarMeusAvisosStatus',
    'ui.tarefas.meus_avisos.qryListarMeusAvisosError': 'qryListarMeusAvisosError',
    'ui.tarefas.meus_avisos.qryAvisoPorIdStatus': 'qryAvisoPorIdStatus',
    'ui.tarefas.meus_avisos.qryAvisoPorIdError': 'qryAvisoPorIdError',
    'ui.tarefas.meus_avisos.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_SIZE = 20;
const PARAM_STORAGE_KEY = 'tarefas.meus_avisos.avisoVencimentoId';
function emptyAvisosPage() {
    return { items: [], page: 1, pageSize: PAGE_SIZE, hasMore: false };
}
export class TarefasMeus_avisosShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state avisos — the list of daily due-date notices of the signed-in person, with reference date, delivery status, totals and generation/finish record; source qryPaginaMeusAvisos.avisos; organisms historicoAvisos, listaAvisos */
        this.avisos = emptyAvisosPage();
        /** state avisoAtual — the notice shown in detail with its totals and task rows (the latest one on opening, the picked one after a selection); source qryPaginaMeusAvisos.avisoAtual; organism avisoDoDia */
        this.avisoAtual = null;
        /** state selectedAvisoVencimento — the id of the notice selected in listaAvisos; source entry.params.avisoVencimentoId; organisms avisoDoDia, listaAvisos; persisted */
        this.selectedAvisoVencimento = null;
        /** state filtroDataInicio — inclusive start of the reference-date period filter of the list (null = no limit); set by qryListarMeusAvisos; source client filter */
        this.filtroDataInicio = null;
        /** state filtroDataFim — inclusive end of the reference-date period filter of the list (null = no limit); set by qryListarMeusAvisos; source client filter */
        this.filtroDataFim = null;
        /** state pageStatus — overall status of the page opening: idle, loading, empty (no notices), success or error */
        this.pageStatus = 'idle';
        /** state qryPaginaMeusAvisosStatus — status of the opening load request */
        this.qryPaginaMeusAvisosStatus = 'idle';
        /** state qryPaginaMeusAvisosError — error of the opening load request, null when none */
        this.qryPaginaMeusAvisosError = null;
        /** state qryListarMeusAvisosStatus — status of the period list request */
        this.qryListarMeusAvisosStatus = 'idle';
        /** state qryListarMeusAvisosError — error of the period list request, null when none */
        this.qryListarMeusAvisosError = null;
        /** state qryAvisoPorIdStatus — status of the request that opens one notice */
        this.qryAvisoPorIdStatus = 'idle';
        /** state qryAvisoPorIdError — error of the request that opens one notice, null when none */
        this.qryAvisoPorIdError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.meus_avisos.${member}`, value);
        if (member === 'selectedAvisoVencimento') {
            try {
                if (value === null || value === undefined) {
                    localStorage.removeItem(PARAM_STORAGE_KEY);
                }
                else {
                    localStorage.setItem(PARAM_STORAGE_KEY, String(value));
                }
            }
            catch {
                // storage unavailable: the selection simply is not persisted
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.startVisit();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const avisos = getState('ui.tarefas.meus_avisos.avisos');
        if (avisos !== undefined)
            this.assignState('ui.tarefas.meus_avisos.avisos', avisos);
        const atual = getState('ui.tarefas.meus_avisos.avisoAtual');
        if (atual !== undefined)
            this.assignState('ui.tarefas.meus_avisos.avisoAtual', atual);
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('qryPaginaMeusAvisosStatus', 'idle');
        this.publish('qryPaginaMeusAvisosError', null);
        this.publish('qryListarMeusAvisosStatus', 'idle');
        this.publish('qryListarMeusAvisosError', null);
        this.publish('qryAvisoPorIdStatus', 'idle');
        this.publish('qryAvisoPorIdError', null);
        this.publish('filtroDataInicio', null);
        this.publish('filtroDataFim', null);
        this.publish('scenary', '');
    }
    readUrlParam(name) {
        try {
            const search = typeof window !== 'undefined' && window.location ? window.location.search : '';
            if (!search)
                return null;
            return new URLSearchParams(search).get(name);
        }
        catch {
            return null;
        }
    }
    applyEntryParams() {
        let value = this.readUrlParam('avisoVencimentoId');
        if (value === null || value === '') {
            value = null;
            try {
                const stored = localStorage.getItem(PARAM_STORAGE_KEY);
                if (stored !== null && stored !== '')
                    value = stored;
            }
            catch {
                value = null;
            }
        }
        this.publish('selectedAvisoVencimento', value);
    }
    async startVisit() {
        await this.qryPaginaMeusAvisos();
        if (this.qryPaginaMeusAvisosStatus !== 'success')
            return;
        const id = this.selectedAvisoVencimento;
        if (id !== null)
            await this.qryAvisoPorId(id);
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    /** setScenario — publishes the visible scene of the page (scenary); no backend call */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** select — selects the notice shown in avisoDoDia by its id (or null to clear the selection); a non-null id opens it through qryAvisoPorId and redraws avisoAtual; null only clears selectedAvisoVencimento and keeps the notice already shown */
    selectAvisoVencimento(id) {
        if (id === null || id === '') {
            this.publish('selectedAvisoVencimento', null);
            return;
        }
        void this.qryAvisoPorId(id);
    }
    /** request qryPaginaMeusAvisos — opening load: first page of the signed-in person's daily notices and the most recent completed notice with its tasks; redraws avisos (replace) and avisoAtual (replace, null when the person has no notice) and pageStatus; no arguments, also the method to reload the page */
    async qryPaginaMeusAvisos() {
        if (this.qryPaginaMeusAvisosStatus === 'loading')
            return;
        this.publish('qryPaginaMeusAvisosStatus', 'loading');
        this.publish('qryPaginaMeusAvisosError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = { page: 1, pageSize: PAGE_SIZE };
            const response = await execBff('tarefas.meus_avisos.qryPaginaMeusAvisos', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryPaginaMeusAvisosError', response.error);
                this.publish('qryPaginaMeusAvisosStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const output = response.data;
            this.publish('avisos', output.avisos);
            this.publish('avisoAtual', output.avisoAtual ?? null);
            this.publish('qryPaginaMeusAvisosStatus', 'success');
            this.publish('pageStatus', output.avisos.items.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('qryPaginaMeusAvisosError', this.unexpectedError(error));
            this.publish('qryPaginaMeusAvisosStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request qryListarMeusAvisos — lists the person's daily notices in a period, page by page; redraws avisos (replace, or append the next page when append is true; append does nothing when avisos.hasMore is false); arguments: dataInicio and dataFim are the inclusive reference-date limits (string, null = no limit, undefined = keep the current filter; a new filter should be loaded with page 1), page is the page to load (default 1), append adds the page to the items (load more) */
    async qryListarMeusAvisos(dataInicio, dataFim, page = 1, append = false) {
        if (this.qryListarMeusAvisosStatus === 'loading')
            return;
        if (append && !this.avisos.hasMore)
            return;
        if (dataInicio !== undefined)
            this.publish('filtroDataInicio', dataInicio === '' ? null : dataInicio);
        if (dataFim !== undefined)
            this.publish('filtroDataFim', dataFim === '' ? null : dataFim);
        this.publish('qryListarMeusAvisosStatus', 'loading');
        this.publish('qryListarMeusAvisosError', null);
        try {
            const inicio = this.filtroDataInicio;
            const fim = this.filtroDataFim;
            const input = {
                ...(inicio !== null && inicio !== '' ? { dataInicio: inicio } : {}),
                ...(fim !== null && fim !== '' ? { dataFim: fim } : {}),
                page,
                pageSize: PAGE_SIZE,
            };
            const response = await execBff('tarefas.meus_avisos.qryListarMeusAvisos', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryListarMeusAvisosError', response.error);
                this.publish('qryListarMeusAvisosStatus', 'error');
                return;
            }
            const loaded = response.data.avisos;
            if (append) {
                this.publish('avisos', {
                    items: [...this.avisos.items, ...loaded.items],
                    page: loaded.page,
                    pageSize: loaded.pageSize,
                    hasMore: loaded.hasMore,
                });
            }
            else {
                this.publish('avisos', loaded);
            }
            this.publish('qryListarMeusAvisosStatus', 'success');
        }
        catch (error) {
            this.publish('qryListarMeusAvisosError', this.unexpectedError(error));
            this.publish('qryListarMeusAvisosStatus', 'error');
        }
    }
    /** request qryAvisoPorId — opens one daily notice with its totals and task rows; selects it (selectedAvisoVencimento, persisted) and redraws avisoAtual (replace); argument id is the id of the chosen notice (a row of avisos) */
    async qryAvisoPorId(id) {
        if (this.qryAvisoPorIdStatus === 'loading')
            return;
        if (id === '') {
            this.publish('qryAvisoPorIdError', { code: 'client.requiredMissing', message: '', details: { params: ['id'] } });
            this.publish('qryAvisoPorIdStatus', 'error');
            return;
        }
        this.publish('qryAvisoPorIdStatus', 'loading');
        this.publish('qryAvisoPorIdError', null);
        try {
            const input = { id };
            const response = await execBff('tarefas.meus_avisos.qryAvisoPorId', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryAvisoPorIdError', response.error);
                this.publish('qryAvisoPorIdStatus', 'error');
                return;
            }
            this.publish('selectedAvisoVencimento', id);
            this.publish('avisoAtual', response.data.aviso);
            this.publish('qryAvisoPorIdStatus', 'success');
        }
        catch (error) {
            this.publish('qryAvisoPorIdError', this.unexpectedError(error));
            this.publish('qryAvisoPorIdStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "avisos", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "avisoAtual", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "selectedAvisoVencimento", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "filtroDataInicio", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "filtroDataFim", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryPaginaMeusAvisosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryPaginaMeusAvisosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryListarMeusAvisosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryListarMeusAvisosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryAvisoPorIdStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "qryAvisoPorIdError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMeus_avisosShared.prototype, "scenary", void 0);

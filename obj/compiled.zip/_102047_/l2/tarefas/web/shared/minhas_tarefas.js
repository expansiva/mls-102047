var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/minhas_tarefas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.minhas_tarefas.tarefas': 'tarefas',
    'ui.tarefas.minhas_tarefas.tarefa': 'tarefa',
    'ui.tarefas.minhas_tarefas.listas': 'listas',
    'ui.tarefas.minhas_tarefas.membros': 'membros',
    'ui.tarefas.minhas_tarefas.selectedTarefa': 'selectedTarefa',
    'ui.tarefas.minhas_tarefas.filtro': 'filtro',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaDraft': 'cmdCriarTarefaDraft',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoDraft': 'cmdSalvarEdicaoDraft',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistDraft': 'cmdSalvarChecklistDraft',
    'ui.tarefas.minhas_tarefas.cmdDevolverDraft': 'cmdDevolverDraft',
    'ui.tarefas.minhas_tarefas.pageStatus': 'pageStatus',
    'ui.tarefas.minhas_tarefas.scenary': 'scenary',
    'ui.tarefas.minhas_tarefas.qryMinhasTarefasStatus': 'qryMinhasTarefasStatus',
    'ui.tarefas.minhas_tarefas.qryMinhasTarefasError': 'qryMinhasTarefasError',
    'ui.tarefas.minhas_tarefas.qryTarefaStatus': 'qryTarefaStatus',
    'ui.tarefas.minhas_tarefas.qryTarefaError': 'qryTarefaError',
    'ui.tarefas.minhas_tarefas.qryListasAtivasStatus': 'qryListasAtivasStatus',
    'ui.tarefas.minhas_tarefas.qryListasAtivasError': 'qryListasAtivasError',
    'ui.tarefas.minhas_tarefas.qryBuscarMembrosStatus': 'qryBuscarMembrosStatus',
    'ui.tarefas.minhas_tarefas.qryBuscarMembrosError': 'qryBuscarMembrosError',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaStatus': 'cmdCriarTarefaStatus',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaError': 'cmdCriarTarefaError',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoStatus': 'cmdSalvarEdicaoStatus',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoError': 'cmdSalvarEdicaoError',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistStatus': 'cmdSalvarChecklistStatus',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistError': 'cmdSalvarChecklistError',
    'ui.tarefas.minhas_tarefas.cmdIniciarStatus': 'cmdIniciarStatus',
    'ui.tarefas.minhas_tarefas.cmdIniciarError': 'cmdIniciarError',
    'ui.tarefas.minhas_tarefas.cmdEnviarRevisaoStatus': 'cmdEnviarRevisaoStatus',
    'ui.tarefas.minhas_tarefas.cmdEnviarRevisaoError': 'cmdEnviarRevisaoError',
    'ui.tarefas.minhas_tarefas.cmdAceitarStatus': 'cmdAceitarStatus',
    'ui.tarefas.minhas_tarefas.cmdAceitarError': 'cmdAceitarError',
    'ui.tarefas.minhas_tarefas.cmdDevolverStatus': 'cmdDevolverStatus',
    'ui.tarefas.minhas_tarefas.cmdDevolverError': 'cmdDevolverError',
    'ui.tarefas.minhas_tarefas.cmdCancelarStatus': 'cmdCancelarStatus',
    'ui.tarefas.minhas_tarefas.cmdCancelarError': 'cmdCancelarError',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const DATA_KEYS = [
    'ui.tarefas.minhas_tarefas.tarefas',
    'ui.tarefas.minhas_tarefas.tarefa',
    'ui.tarefas.minhas_tarefas.listas',
    'ui.tarefas.minhas_tarefas.membros',
];
const PAGE_SIZE = 20;
function emptyCriarDraft() {
    return {
        chaveCriacao: crypto.randomUUID(),
        listaId: null,
        titulo: null,
        details: { descricao: null },
        prioridade: null,
        prazo: null,
        responsavelId: null,
        checklist: [],
    };
}
function emptyEdicaoDraft() {
    return {
        id: null,
        version: null,
        listaId: null,
        titulo: null,
        details: { descricao: null },
        prioridade: null,
        prazo: null,
        responsavelId: null,
    };
}
function emptyChecklistDraft() {
    return { itens: [] };
}
function emptyDevolverDraft() {
    return { details: { motivoDevolucao: null } };
}
function isBlank(value) {
    return value === null || value.trim() === '';
}
function parseFiltro(raw) {
    if (raw === 'criadasPorMim')
        return 'criadasPorMim';
    if (raw === 'atribuidasAMim')
        return 'atribuidasAMim';
    if (raw === 'emRevisao')
        return 'emRevisao';
    if (raw === 'devolvidas')
        return 'devolvidas';
    return null;
}
export class TarefasMinhas_tarefasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state tarefas — page of my tasks (summary with list, owner, creator, due date, status and indicators); source qryMinhasTarefas.tarefas; organism listaTarefas */
        this.tarefas = null;
        /** state tarefa — the open task in full (list, creator, owner, status, cycle milestones, return reason, my role and ordered checklist); source qryTarefa.tarefa; organisms acoesTarefa, detalheTarefa, formTarefa, historicoTarefa */
        this.tarefa = null;
        /** state listas — active lists that can receive tasks (id, name, type); source qryListasAtivas.listas; organism formTarefa */
        this.listas = [];
        /** state membros — active team members found by name, to choose or change the owner; source qryBuscarMembros.membros; organism formTarefa */
        this.membros = [];
        /** state selectedTarefa — the id of the task selected in listaTarefas (the record itself is in `tarefa`); source entry.params.tarefaId; organisms detalheTarefa, listaTarefas */
        this.selectedTarefa = null;
        /** state filtro — the quick filter of the task list (null = all my tasks); source entry.params.filtro; organism listaTarefas; persisted */
        this.filtro = null;
        /** state cmdCriarTarefaDraft — form draft to create a task (prefilled by listaId/responsavelId params; holds the creation key); source cmdCriarTarefa.input; organism formTarefa */
        this.cmdCriarTarefaDraft = emptyCriarDraft();
        /** state cmdSalvarEdicaoDraft — form draft to edit the open task, filled from `tarefa`; source cmdSalvarEdicao.input; organism formTarefa */
        this.cmdSalvarEdicaoDraft = emptyEdicaoDraft();
        /** state cmdSalvarChecklistDraft — form draft of the checklist of the open task, filled from `tarefa`; source cmdSalvarChecklist.input; organism formTarefa */
        this.cmdSalvarChecklistDraft = emptyChecklistDraft();
        /** state cmdDevolverDraft — draft with the reason to send the task back for adjustment; source cmdDevolver.input; organism acoesTarefa */
        this.cmdDevolverDraft = emptyDevolverDraft();
        /** state pageStatus — overall status of the page load */
        this.pageStatus = 'idle';
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        /** state qryMinhasTarefasStatus — status of the request qryMinhasTarefas */
        this.qryMinhasTarefasStatus = 'idle';
        /** state qryMinhasTarefasError — error of the request qryMinhasTarefas; null when none */
        this.qryMinhasTarefasError = null;
        /** state qryTarefaStatus — status of the request qryTarefa */
        this.qryTarefaStatus = 'idle';
        /** state qryTarefaError — error of the request qryTarefa; null when none */
        this.qryTarefaError = null;
        /** state qryListasAtivasStatus — status of the request qryListasAtivas */
        this.qryListasAtivasStatus = 'idle';
        /** state qryListasAtivasError — error of the request qryListasAtivas; null when none */
        this.qryListasAtivasError = null;
        /** state qryBuscarMembrosStatus — status of the request qryBuscarMembros */
        this.qryBuscarMembrosStatus = 'idle';
        /** state qryBuscarMembrosError — error of the request qryBuscarMembros; null when none */
        this.qryBuscarMembrosError = null;
        /** state cmdCriarTarefaStatus — status of the command cmdCriarTarefa */
        this.cmdCriarTarefaStatus = 'idle';
        /** state cmdCriarTarefaError — error of the command cmdCriarTarefa; null when none */
        this.cmdCriarTarefaError = null;
        /** state cmdSalvarEdicaoStatus — status of the command cmdSalvarEdicao */
        this.cmdSalvarEdicaoStatus = 'idle';
        /** state cmdSalvarEdicaoError — error of the command cmdSalvarEdicao; null when none */
        this.cmdSalvarEdicaoError = null;
        /** state cmdSalvarChecklistStatus — status of the command cmdSalvarChecklist */
        this.cmdSalvarChecklistStatus = 'idle';
        /** state cmdSalvarChecklistError — error of the command cmdSalvarChecklist; null when none */
        this.cmdSalvarChecklistError = null;
        /** state cmdIniciarStatus — status of the command cmdIniciar */
        this.cmdIniciarStatus = 'idle';
        /** state cmdIniciarError — error of the command cmdIniciar; null when none */
        this.cmdIniciarError = null;
        /** state cmdEnviarRevisaoStatus — status of the command cmdEnviarRevisao */
        this.cmdEnviarRevisaoStatus = 'idle';
        /** state cmdEnviarRevisaoError — error of the command cmdEnviarRevisao; null when none */
        this.cmdEnviarRevisaoError = null;
        /** state cmdAceitarStatus — status of the command cmdAceitar */
        this.cmdAceitarStatus = 'idle';
        /** state cmdAceitarError — error of the command cmdAceitar; null when none */
        this.cmdAceitarError = null;
        /** state cmdDevolverStatus — status of the command cmdDevolver */
        this.cmdDevolverStatus = 'idle';
        /** state cmdDevolverError — error of the command cmdDevolver; null when none */
        this.cmdDevolverError = null;
        /** state cmdCancelarStatus — status of the command cmdCancelar */
        this.cmdCancelarStatus = 'idle';
        /** state cmdCancelarError — error of the command cmdCancelar; null when none */
        this.cmdCancelarError = null;
        this.subscribed = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.minhas_tarefas.${member}`, value);
        if (member === 'filtro') {
            this.persistParam('filtro', value);
        }
        if (member === 'selectedTarefa') {
            this.syncUrlParam('tarefaId', value);
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    persistParam(name, value) {
        try {
            const storageKey = `tarefas.minhas_tarefas.${name}`;
            if (value === null) {
                localStorage.removeItem(storageKey);
            }
            else {
                localStorage.setItem(storageKey, value);
            }
        }
        catch {
            // storage unavailable: the value just is not persisted
        }
    }
    syncUrlParam(name, value) {
        try {
            const url = new URL(window.location.href);
            if (value === null) {
                url.searchParams.delete(name);
            }
            else {
                url.searchParams.set(name, value);
            }
            history.replaceState(null, '', url.toString());
        }
        catch {
            // URL not writable: the state still holds the value
        }
    }
    readParam(name, fromStorage) {
        const raw = new URLSearchParams(window.location.search).get(name);
        if (raw !== null && raw !== '')
            return raw;
        if (fromStorage) {
            try {
                const stored = localStorage.getItem(`tarefas.minhas_tarefas.${name}`);
                if (stored !== null && stored !== '')
                    return stored;
            }
            catch {
                // storage unavailable: no stored value
            }
        }
        return null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.resetVisit();
        this.hydrateData();
        if (!this.subscribed) {
            subscribe([...STATE_KEYS], this);
            this.subscribed = true;
        }
        this.applyEntryParams();
        void this.loadInitial();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        this.subscribed = false;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        for (const key of DATA_KEYS) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('qryMinhasTarefasStatus', 'idle');
        this.publish('qryMinhasTarefasError', null);
        this.publish('qryTarefaStatus', 'idle');
        this.publish('qryTarefaError', null);
        this.publish('qryListasAtivasStatus', 'idle');
        this.publish('qryListasAtivasError', null);
        this.publish('qryBuscarMembrosStatus', 'idle');
        this.publish('qryBuscarMembrosError', null);
        this.publish('cmdCriarTarefaDraft', emptyCriarDraft());
        this.publish('cmdSalvarEdicaoDraft', emptyEdicaoDraft());
        this.publish('cmdSalvarChecklistDraft', emptyChecklistDraft());
        this.publish('cmdDevolverDraft', emptyDevolverDraft());
        this.resetCommandResults();
    }
    applyEntryParams() {
        this.publish('filtro', parseFiltro(this.readParam('filtro', true)));
        const listaId = this.readParam('listaId', true);
        const responsavelId = this.readParam('responsavelId', true);
        if (listaId !== null || responsavelId !== null) {
            this.publish('cmdCriarTarefaDraft', {
                ...this.cmdCriarTarefaDraft,
                listaId: listaId ?? this.cmdCriarTarefaDraft.listaId,
                responsavelId: responsavelId ?? this.cmdCriarTarefaDraft.responsavelId,
            });
        }
        const tarefaId = this.readParam('tarefaId', false);
        if (tarefaId !== null) {
            void this.selectTarefa(tarefaId);
        }
        else {
            this.publish('selectedTarefa', null);
            this.publish('tarefa', null);
        }
    }
    async loadInitial() {
        this.publish('pageStatus', 'loading');
        await Promise.all([this.qryMinhasTarefas(), this.qryListasAtivas()]);
    }
    refreshPageStatus() {
        if (this.qryMinhasTarefasStatus === 'loading' || this.qryListasAtivasStatus === 'loading')
            return;
        if (this.qryMinhasTarefasStatus === 'error' || this.qryListasAtivasStatus === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        const semTarefas = !this.tarefas || this.tarefas.items.length === 0;
        if (semTarefas && this.listas.length === 0) {
            this.publish('pageStatus', 'empty');
            return;
        }
        this.publish('pageStatus', 'success');
    }
    setRequest(id, status, error) {
        this.publish(`${id}Status`, status);
        this.publish(`${id}Error`, error);
    }
    failRequest(id, code, details) {
        this.setRequest(id, 'error', { code, message: '', details });
    }
    unexpectedError(error) {
        return { code: 'client.unexpected', message: '', details: { name: error instanceof Error ? error.name : 'unknown' } };
    }
    isBusy(id) {
        return this[`${id}Status`] === 'loading';
    }
    resetCommandResults() {
        this.publish('cmdCriarTarefaError', null);
        this.publish('cmdCriarTarefaStatus', 'idle');
        this.publish('cmdSalvarEdicaoError', null);
        this.publish('cmdSalvarEdicaoStatus', 'idle');
        this.publish('cmdSalvarChecklistError', null);
        this.publish('cmdSalvarChecklistStatus', 'idle');
        this.publish('cmdIniciarError', null);
        this.publish('cmdIniciarStatus', 'idle');
        this.publish('cmdEnviarRevisaoError', null);
        this.publish('cmdEnviarRevisaoStatus', 'idle');
        this.publish('cmdAceitarError', null);
        this.publish('cmdAceitarStatus', 'idle');
        this.publish('cmdDevolverError', null);
        this.publish('cmdDevolverStatus', 'idle');
        this.publish('cmdCancelarError', null);
        this.publish('cmdCancelarStatus', 'idle');
    }
    /** Runs a command in blocking mode; returns its output, or null after publishing the error (status stays loading on success: the caller publishes success last). */
    async runCommand(id, call) {
        this.setRequest(id, 'loading', null);
        try {
            const response = await runBlockingUiAction(call);
            if (response === undefined) {
                this.setRequest(id, 'error', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                return null;
            }
            if (!response.ok || !response.data) {
                this.setRequest(id, 'error', response.error ?? this.unexpectedError(null));
                return null;
            }
            return response.data;
        }
        catch (error) {
            this.setRequest(id, 'error', this.unexpectedError(error));
            return null;
        }
    }
    fillDrafts(t) {
        this.publish('cmdSalvarEdicaoDraft', {
            id: t.id,
            version: t.version,
            listaId: t.listaId,
            titulo: t.titulo,
            details: { descricao: t.details.descricao ?? null },
            prioridade: t.prioridade,
            prazo: t.prazo,
            responsavelId: t.responsavelId,
        });
        this.publish('cmdSalvarChecklistDraft', {
            itens: t.checklist.map((item) => ({
                id: item.id,
                version: item.version,
                descricao: item.details.descricao,
                ordem: item.ordem,
                feito: item.feito,
            })),
        });
        this.publish('cmdDevolverDraft', emptyDevolverDraft());
    }
    mergeRow(row, t) {
        return {
            ...row,
            version: t.version,
            titulo: t.titulo,
            listaId: t.listaId,
            lista: t.lista,
            responsavelId: t.responsavelId,
            responsavel: t.responsavel,
            criadorId: t.criadorId,
            criador: t.criador,
            prioridade: t.prioridade,
            prazo: t.prazo,
            status: t.status,
            details: {
                ...row.details,
                ...(t.details.devolvidaEm !== undefined ? { devolvidaEm: t.details.devolvidaEm } : {}),
            },
        };
    }
    leavesList(t) {
        if (this.filtro === 'emRevisao')
            return t.status !== 'emRevisao';
        if (this.filtro === 'devolvidas')
            return t.status !== 'emAndamento' || !t.details.devolvidaEm;
        if (this.filtro === 'criadasPorMim')
            return !t.souCriador;
        if (this.filtro === 'atribuidasAMim')
            return !t.souResponsavel;
        return false;
    }
    syncListRow(t) {
        const current = this.tarefas;
        if (!current)
            return;
        const present = current.items.some((row) => row.id === t.id);
        if (!present)
            return;
        if (this.leavesList(t)) {
            this.publish('tarefas', { ...current, items: current.items.filter((row) => row.id !== t.id) });
            return;
        }
        this.publish('tarefas', {
            ...current,
            items: current.items.map((row) => (row.id === t.id ? this.mergeRow(row, t) : row)),
        });
    }
    /** Applies a task returned by a command: redraws `tarefa` and the selection, refills the edit drafts and updates the row in the list. */
    applyTarefa(t) {
        this.publish('tarefa', t);
        this.publish('selectedTarefa', t.id);
        this.fillDrafts(t);
        this.syncListRow(t);
    }
    toItemEntrada(item) {
        if (isBlank(item.descricao) || item.descricao === null)
            return null;
        if (item.ordem === null || item.feito === null)
            return null;
        return {
            ...(item.id !== null ? { id: item.id } : {}),
            ...(item.version !== null ? { version: item.version } : {}),
            details: { descricao: item.descricao },
            ordem: item.ordem,
            feito: item.feito,
        };
    }
    /** setScenario — publishes the visible scene of the page (state scenary). */
    setScenario(value) {
        this.publish('scenary', value);
        this.resetCommandResults();
    }
    /** setCmdCriarTarefaDraft — replaces the create-task form draft (keeps the creation key when the value has none). */
    setCmdCriarTarefaDraft(value) {
        const key = value.chaveCriacao ?? this.cmdCriarTarefaDraft.chaveCriacao ?? crypto.randomUUID();
        this.publish('cmdCriarTarefaDraft', { ...value, chaveCriacao: key });
        this.resetCommandResults();
    }
    /** clearCmdCriarTarefaDraft — clears the create-task form and generates a new creation key (use when the form opens or the person clears it). */
    clearCmdCriarTarefaDraft() {
        this.publish('cmdCriarTarefaDraft', emptyCriarDraft());
        this.resetCommandResults();
    }
    /** setCmdSalvarEdicaoDraft — replaces the edit-task form draft. */
    setCmdSalvarEdicaoDraft(value) {
        this.publish('cmdSalvarEdicaoDraft', value);
        this.resetCommandResults();
    }
    /** setCmdSalvarChecklistDraft — replaces the checklist form draft (add, edit, reorder or mark items). */
    setCmdSalvarChecklistDraft(value) {
        this.publish('cmdSalvarChecklistDraft', value);
        this.resetCommandResults();
    }
    /** setCmdDevolverDraft — replaces the draft with the reason to send the task back. */
    setCmdDevolverDraft(value) {
        this.publish('cmdDevolverDraft', value);
        this.resetCommandResults();
    }
    /** select — selects the task with this id (or null to clear): publishes selectedTarefa and loads the record into `tarefa` through qryTarefa; clears `tarefa` and its drafts when null. */
    async selectTarefa(tarefaId) {
        this.resetCommandResults();
        this.publish('selectedTarefa', tarefaId);
        if (tarefaId === null) {
            this.publish('tarefa', null);
            this.publish('cmdSalvarEdicaoDraft', emptyEdicaoDraft());
            this.publish('cmdSalvarChecklistDraft', emptyChecklistDraft());
            this.publish('cmdDevolverDraft', emptyDevolverDraft());
            return;
        }
        await this.qryTarefa(tarefaId);
    }
    /** request qryMinhasTarefas — lists, paged, the tasks I created or own, with the quick filter; redraws tarefas (replace, or append the next page when append is true) and the state filtro; filtro: new quick filter (null clears it, omitted keeps the current one) and starts from the first page; page: page to load; append: true for "load more" (only when tarefas.hasMore) */
    async qryMinhasTarefas(filtro, page = 1, append = false) {
        if (this.qryMinhasTarefasStatus === 'loading')
            return;
        if (append && (!this.tarefas || !this.tarefas.hasMore))
            return;
        if (filtro !== undefined) {
            this.publish('filtro', filtro);
        }
        const effective = this.filtro;
        this.setRequest('qryMinhasTarefas', 'loading', null);
        const input = {
            ...(effective !== null ? { filtro: effective } : {}),
            page,
            pageSize: PAGE_SIZE,
        };
        try {
            const response = await execBff('tarefas.minhas_tarefas.qryMinhasTarefas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.setRequest('qryMinhasTarefas', 'error', response.error ?? this.unexpectedError(null));
                this.refreshPageStatus();
                return;
            }
            const next = response.data.tarefas;
            const current = this.tarefas;
            if (append && current) {
                this.publish('tarefas', { ...next, items: [...current.items, ...next.items] });
            }
            else {
                this.publish('tarefas', next);
            }
            this.setRequest('qryMinhasTarefas', 'success', null);
        }
        catch (error) {
            this.setRequest('qryMinhasTarefas', 'error', this.unexpectedError(error));
        }
        this.refreshPageStatus();
    }
    /** request qryTarefa — opens one task with its data, checklist and cycle milestones; redraws tarefa (replace) and refills the edit, checklist and return drafts; tarefaId: id of the task to open (use selectTarefa to also publish the selection) */
    async qryTarefa(tarefaId) {
        if (this.qryTarefaStatus === 'loading')
            return;
        if (!tarefaId) {
            this.failRequest('qryTarefa', 'client.requiredMissing', { stateKeys: ['selectedTarefa'] });
            return;
        }
        this.setRequest('qryTarefa', 'loading', null);
        const input = { tarefaId };
        try {
            const response = await execBff('tarefas.minhas_tarefas.qryTarefa', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.setRequest('qryTarefa', 'error', response.error ?? this.unexpectedError(null));
                return;
            }
            this.publish('tarefa', response.data.tarefa);
            this.fillDrafts(response.data.tarefa);
            this.setRequest('qryTarefa', 'success', null);
        }
        catch (error) {
            this.setRequest('qryTarefa', 'error', this.unexpectedError(error));
        }
    }
    /** request qryListasAtivas — brings the active lists where a task can be placed; redraws listas (replace); no arguments */
    async qryListasAtivas() {
        if (this.qryListasAtivasStatus === 'loading')
            return;
        this.setRequest('qryListasAtivas', 'loading', null);
        const input = {};
        try {
            const response = await execBff('tarefas.minhas_tarefas.qryListasAtivas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.setRequest('qryListasAtivas', 'error', response.error ?? this.unexpectedError(null));
                this.refreshPageStatus();
                return;
            }
            this.publish('listas', response.data.listas);
            this.setRequest('qryListasAtivas', 'success', null);
        }
        catch (error) {
            this.setRequest('qryListasAtivas', 'error', this.unexpectedError(error));
        }
        this.refreshPageStatus();
    }
    /** request qryBuscarMembros — searches active team members by name to choose or change the owner; redraws membros (replace; an empty term just clears it without calling); termo: part of the name typed */
    async qryBuscarMembros(termo) {
        if (this.qryBuscarMembrosStatus === 'loading')
            return;
        if (termo.trim() === '') {
            this.publish('membros', []);
            this.setRequest('qryBuscarMembros', 'idle', null);
            return;
        }
        this.setRequest('qryBuscarMembros', 'loading', null);
        const input = { termo };
        try {
            const response = await execBff('tarefas.minhas_tarefas.qryBuscarMembros', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.setRequest('qryBuscarMembros', 'error', response.error ?? this.unexpectedError(null));
                return;
            }
            this.publish('membros', response.data.membros);
            this.setRequest('qryBuscarMembros', 'success', null);
        }
        catch (error) {
            this.setRequest('qryBuscarMembros', 'error', this.unexpectedError(error));
        }
    }
    /** request cmdCriarTarefa — creates a task with its initial checklist from cmdCriarTarefaDraft (same creation key on every retry); redraws tarefa and selectedTarefa with the created task, refills the edit drafts, then resets the create draft with a new key; no arguments */
    async cmdCriarTarefa() {
        if (this.isBusy('cmdCriarTarefa'))
            return;
        const draft = this.cmdCriarTarefaDraft;
        const missing = [];
        if (isBlank(draft.chaveCriacao))
            missing.push('cmdCriarTarefaDraft.chaveCriacao');
        if (isBlank(draft.listaId))
            missing.push('cmdCriarTarefaDraft.listaId');
        if (isBlank(draft.titulo))
            missing.push('cmdCriarTarefaDraft.titulo');
        if (draft.prioridade === null)
            missing.push('cmdCriarTarefaDraft.prioridade');
        if (isBlank(draft.prazo))
            missing.push('cmdCriarTarefaDraft.prazo');
        if (isBlank(draft.responsavelId))
            missing.push('cmdCriarTarefaDraft.responsavelId');
        const itens = [];
        for (const item of draft.checklist) {
            const entrada = this.toItemEntrada(item);
            if (entrada === null) {
                missing.push('cmdCriarTarefaDraft.checklist');
                break;
            }
            itens.push(entrada);
        }
        if (missing.length > 0 ||
            draft.chaveCriacao === null ||
            draft.listaId === null ||
            draft.titulo === null ||
            draft.prioridade === null ||
            draft.prazo === null ||
            draft.responsavelId === null) {
            this.failRequest('cmdCriarTarefa', 'client.requiredMissing', { stateKeys: missing });
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            chaveCriacao: draft.chaveCriacao,
            listaId: draft.listaId,
            titulo: draft.titulo,
            details: { ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
            prioridade: draft.prioridade,
            prazo: draft.prazo,
            responsavelId: draft.responsavelId,
            ...(itens.length > 0 ? { checklist: itens } : {}),
        };
        const output = await this.runCommand('cmdCriarTarefa', (signal) => execBff('tarefas.minhas_tarefas.cmdCriarTarefa', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.publish('cmdCriarTarefaDraft', emptyCriarDraft());
        this.setRequest('cmdCriarTarefa', 'success', null);
    }
    /** request cmdSalvarEdicao — saves the edited fields of the open task (including the owner swap) from cmdSalvarEdicaoDraft, never changing its status; redraws tarefa, the selection and the list row (upsert, or remove when it no longer belongs to the filter) and refills the drafts from the saved record; no arguments */
    async cmdSalvarEdicao() {
        if (this.isBusy('cmdSalvarEdicao'))
            return;
        const draft = this.cmdSalvarEdicaoDraft;
        const missing = [];
        if (isBlank(draft.id))
            missing.push('cmdSalvarEdicaoDraft.id');
        if (draft.version === null)
            missing.push('cmdSalvarEdicaoDraft.version');
        if (isBlank(draft.listaId))
            missing.push('cmdSalvarEdicaoDraft.listaId');
        if (isBlank(draft.titulo))
            missing.push('cmdSalvarEdicaoDraft.titulo');
        if (draft.prioridade === null)
            missing.push('cmdSalvarEdicaoDraft.prioridade');
        if (isBlank(draft.prazo))
            missing.push('cmdSalvarEdicaoDraft.prazo');
        if (isBlank(draft.responsavelId))
            missing.push('cmdSalvarEdicaoDraft.responsavelId');
        if (missing.length > 0 ||
            draft.id === null ||
            draft.version === null ||
            draft.listaId === null ||
            draft.titulo === null ||
            draft.prioridade === null ||
            draft.prazo === null ||
            draft.responsavelId === null) {
            this.failRequest('cmdSalvarEdicao', 'client.requiredMissing', { stateKeys: missing });
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            id: draft.id,
            version: draft.version,
            listaId: draft.listaId,
            titulo: draft.titulo,
            details: { ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
            prioridade: draft.prioridade,
            prazo: draft.prazo,
            responsavelId: draft.responsavelId,
        };
        const output = await this.runCommand('cmdSalvarEdicao', (signal) => execBff('tarefas.minhas_tarefas.cmdSalvarEdicao', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdSalvarEdicao', 'success', null);
    }
    /** request cmdSalvarChecklist — saves the checklist of the open task from cmdSalvarChecklistDraft (edit, reorder, mark items, add new ones), never changing the task status; the task id comes from selectedTarefa; redraws tarefa (with the saved checklist in order), the selection and the list row, and refills the drafts; no arguments */
    async cmdSalvarChecklist() {
        if (this.isBusy('cmdSalvarChecklist'))
            return;
        const draft = this.cmdSalvarChecklistDraft;
        const tarefaId = this.selectedTarefa;
        const missing = [];
        if (tarefaId === null || isBlank(tarefaId))
            missing.push('selectedTarefa');
        const itens = [];
        for (const item of draft.itens) {
            const entrada = this.toItemEntrada(item);
            if (entrada === null) {
                missing.push('cmdSalvarChecklistDraft.itens');
                break;
            }
            itens.push(entrada);
        }
        if (missing.length > 0 || tarefaId === null) {
            this.failRequest('cmdSalvarChecklist', 'client.requiredMissing', { stateKeys: missing });
            return;
        }
        const input = { tarefaId, itens };
        const output = await this.runCommand('cmdSalvarChecklist', (signal) => execBff('tarefas.minhas_tarefas.cmdSalvarChecklist', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdSalvarChecklist', 'success', null);
    }
    /** request cmdIniciar — starts the open task (a fazer → em andamento; only the owner); redraws tarefa, the selection and the list row from the returned task; no arguments (uses the open task id and version) */
    async cmdIniciar() {
        if (this.isBusy('cmdIniciar'))
            return;
        const current = this.tarefa;
        if (!current) {
            this.failRequest('cmdIniciar', 'client.requiredMissing', { stateKeys: ['tarefa'] });
            return;
        }
        const input = { id: current.id, version: current.version };
        const output = await this.runCommand('cmdIniciar', (signal) => execBff('tarefas.minhas_tarefas.cmdIniciar', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdIniciar', 'success', null);
    }
    /** request cmdEnviarRevisao — sends or resends the open task to the creator's review (em andamento → em revisão; only the owner); redraws tarefa, the selection and the list row from the returned task; no arguments */
    async cmdEnviarRevisao() {
        if (this.isBusy('cmdEnviarRevisao'))
            return;
        const current = this.tarefa;
        if (!current) {
            this.failRequest('cmdEnviarRevisao', 'client.requiredMissing', { stateKeys: ['tarefa'] });
            return;
        }
        const input = { id: current.id, version: current.version };
        const output = await this.runCommand('cmdEnviarRevisao', (signal) => execBff('tarefas.minhas_tarefas.cmdEnviarRevisao', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdEnviarRevisao', 'success', null);
    }
    /** request cmdAceitar — accepts the delivery and concludes the open task (em revisão → concluída; only the creator); redraws tarefa, the selection and the list row (removed when the filter no longer shows it); no arguments */
    async cmdAceitar() {
        if (this.isBusy('cmdAceitar'))
            return;
        const current = this.tarefa;
        if (!current) {
            this.failRequest('cmdAceitar', 'client.requiredMissing', { stateKeys: ['tarefa'] });
            return;
        }
        const input = { id: current.id, version: current.version };
        const output = await this.runCommand('cmdAceitar', (signal) => execBff('tarefas.minhas_tarefas.cmdAceitar', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdAceitar', 'success', null);
    }
    /** request cmdDevolver — sends the open task in review back for adjustment with the reason in cmdDevolverDraft (only the creator; back to em andamento); redraws tarefa, the selection and the list row (removed when the filter no longer shows it) and clears the reason; no arguments */
    async cmdDevolver() {
        if (this.isBusy('cmdDevolver'))
            return;
        const current = this.tarefa;
        const motivo = this.cmdDevolverDraft.details.motivoDevolucao;
        const missing = [];
        if (!current)
            missing.push('tarefa');
        if (motivo === null || motivo.trim() === '')
            missing.push('cmdDevolverDraft.details.motivoDevolucao');
        if (missing.length > 0 || !current || motivo === null) {
            this.failRequest('cmdDevolver', 'client.requiredMissing', { stateKeys: missing });
            return;
        }
        const input = {
            id: current.id,
            version: current.version,
            details: { motivoDevolucao: motivo },
        };
        const output = await this.runCommand('cmdDevolver', (signal) => execBff('tarefas.minhas_tarefas.cmdDevolver', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdDevolver', 'success', null);
    }
    /** request cmdCancelar — cancels the open task I created (only the creator, while a fazer, em andamento or em revisão); redraws tarefa, the selection and the list row (removed when the filter no longer shows it); no arguments */
    async cmdCancelar() {
        if (this.isBusy('cmdCancelar'))
            return;
        const current = this.tarefa;
        if (!current) {
            this.failRequest('cmdCancelar', 'client.requiredMissing', { stateKeys: ['tarefa'] });
            return;
        }
        const input = { id: current.id, version: current.version };
        const output = await this.runCommand('cmdCancelar', (signal) => execBff('tarefas.minhas_tarefas.cmdCancelar', input, { mode: 'blocking', signal }));
        if (!output)
            return;
        this.applyTarefa(output.tarefa);
        this.setRequest('cmdCancelar', 'success', null);
    }
}
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "tarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "membros", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "selectedTarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "filtro", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "scenary", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryMinhasTarefasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryMinhasTarefasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryListasAtivasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryListasAtivasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryBuscarMembrosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryBuscarMembrosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdIniciarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdIniciarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdEnviarRevisaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdEnviarRevisaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdAceitarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdAceitarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCancelarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCancelarError", void 0);

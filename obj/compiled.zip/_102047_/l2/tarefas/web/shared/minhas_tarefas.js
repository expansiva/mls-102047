var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/minhas_tarefas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.minhas_tarefas.tarefas': 'tarefas',
    'ui.tarefas.minhas_tarefas.tarefa': 'tarefa',
    'ui.tarefas.minhas_tarefas.listas': 'listas',
    'ui.tarefas.minhas_tarefas.membros': 'membros',
    'ui.tarefas.minhas_tarefas.selectedTarefa': 'selectedTarefa',
    'ui.tarefas.minhas_tarefas.filtro': 'filtro',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaDraft': 'cmdCriarTarefaDraft',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoDraft': 'cmdSalvarEdicaoDraft',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistDraft': 'cmdSalvarChecklistDraft',
    'ui.tarefas.minhas_tarefas.cmdDevolverDraft': 'cmdDevolverDraft',
    'ui.tarefas.minhas_tarefas.pageStatus': 'pageStatus',
    'ui.tarefas.minhas_tarefas.qryMinhasTarefasStatus': 'qryMinhasTarefasStatus',
    'ui.tarefas.minhas_tarefas.qryMinhasTarefasError': 'qryMinhasTarefasError',
    'ui.tarefas.minhas_tarefas.qryTarefaStatus': 'qryTarefaStatus',
    'ui.tarefas.minhas_tarefas.qryTarefaError': 'qryTarefaError',
    'ui.tarefas.minhas_tarefas.qryListasAtivasStatus': 'qryListasAtivasStatus',
    'ui.tarefas.minhas_tarefas.qryListasAtivasError': 'qryListasAtivasError',
    'ui.tarefas.minhas_tarefas.qryBuscarMembrosStatus': 'qryBuscarMembrosStatus',
    'ui.tarefas.minhas_tarefas.qryBuscarMembrosError': 'qryBuscarMembrosError',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaStatus': 'cmdCriarTarefaStatus',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaError': 'cmdCriarTarefaError',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoStatus': 'cmdSalvarEdicaoStatus',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoError': 'cmdSalvarEdicaoError',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistStatus': 'cmdSalvarChecklistStatus',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistError': 'cmdSalvarChecklistError',
    'ui.tarefas.minhas_tarefas.cmdIniciarStatus': 'cmdIniciarStatus',
    'ui.tarefas.minhas_tarefas.cmdIniciarError': 'cmdIniciarError',
    'ui.tarefas.minhas_tarefas.cmdEnviarRevisaoStatus': 'cmdEnviarRevisaoStatus',
    'ui.tarefas.minhas_tarefas.cmdEnviarRevisaoError': 'cmdEnviarRevisaoError',
    'ui.tarefas.minhas_tarefas.cmdAceitarStatus': 'cmdAceitarStatus',
    'ui.tarefas.minhas_tarefas.cmdAceitarError': 'cmdAceitarError',
    'ui.tarefas.minhas_tarefas.cmdDevolverStatus': 'cmdDevolverStatus',
    'ui.tarefas.minhas_tarefas.cmdDevolverError': 'cmdDevolverError',
    'ui.tarefas.minhas_tarefas.cmdCancelarStatus': 'cmdCancelarStatus',
    'ui.tarefas.minhas_tarefas.cmdCancelarError': 'cmdCancelarError',
    'ui.tarefas.minhas_tarefas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const DATA_MEMBERS = ['tarefas', 'tarefa', 'listas', 'membros'];
const PAGE_SIZE = 20;
const ROUTE_SUFFIX = '/tarefas/minhas_tarefas';
const STORAGE_PREFIX = 'tarefas.minhas_tarefas.';
function toFiltro(raw) {
    if (raw === 'criadasPorMim' || raw === 'atribuidasAMim' || raw === 'emRevisao' || raw === 'devolvidas')
        return raw;
    return null;
}
function isBlank(value) {
    return value === null || value.trim() === '';
}
function emptyCriarTarefaDraft() {
    return {
        chaveCriacao: crypto.randomUUID(),
        listaId: null,
        titulo: null,
        details: { descricao: null },
        prioridade: null,
        prazo: null,
        responsavelId: null,
        checklist: [],
    };
}
function emptyEdicaoDraft() {
    return {
        id: null,
        version: null,
        listaId: null,
        titulo: null,
        details: { descricao: null },
        prioridade: null,
        prazo: null,
        responsavelId: null,
    };
}
function emptyChecklistDraft() {
    return { tarefaId: null, itens: [] };
}
function emptyDevolverDraft() {
    return { details: { motivoDevolucao: null } };
}
function edicaoDraftFromTarefa(tarefa) {
    return {
        id: tarefa.id,
        version: tarefa.version,
        listaId: tarefa.listaId,
        titulo: tarefa.titulo,
        details: { descricao: tarefa.details.descricao ?? null },
        prioridade: tarefa.prioridade,
        prazo: tarefa.prazo,
        responsavelId: tarefa.responsavelId,
    };
}
function checklistDraftFromTarefa(tarefa) {
    return {
        tarefaId: tarefa.id,
        itens: tarefa.checklist.map((item) => ({
            id: item.id,
            version: item.version,
            details: { descricao: item.details.descricao },
            ordem: item.ordem,
            feito: item.feito,
        })),
    };
}
function toEntrada(item, index) {
    const descricao = item.details.descricao;
    if (descricao === null || descricao.trim() === '')
        return null;
    return {
        ...(item.id !== null ? { id: item.id } : {}),
        ...(item.version !== null ? { version: item.version } : {}),
        details: { descricao },
        ordem: item.ordem ?? index + 1,
        feito: item.feito ?? false,
    };
}
function toEntradas(items) {
    const result = [];
    for (let index = 0; index < items.length; index += 1) {
        const entrada = toEntrada(items[index], index);
        if (entrada === null)
            return null;
        result.push(entrada);
    }
    return result;
}
export class TarefasMinhas_tarefasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state tarefas — the page of my tasks (created by me or assigned to me), summarized with list, owner, creator, deadline, status and indicators; source qryMinhasTarefas.tarefas; organism listaTarefas */
        this.tarefas = null;
        /** state tarefa — the open task in full detail (fields, cycle milestones, return reason, my role, ordered checklist); source qryTarefa.tarefa; organisms acoesTarefa, detalheTarefa, formTarefa, historicoTarefa */
        this.tarefa = null;
        /** state listas — active lists (projects or areas) that can receive tasks; source qryListasAtivas.listas; organism formTarefa */
        this.listas = [];
        /** state membros — active team members found by name, to choose or change the owner; source qryBuscarMembros.membros; organism formTarefa */
        this.membros = [];
        /** state selectedTarefa — the id of the task selected in listaTarefas (the record itself is in tarefa); source entry.params.tarefaId; organisms detalheTarefa, listaTarefas; kept in the URL */
        this.selectedTarefa = null;
        /** state filtro — the quick filter of the list (criadasPorMim, atribuidasAMim, emRevisao, devolvidas; null means all mine); source entry.params.filtro; organism listaTarefas; persisted */
        this.filtro = null;
        /** state cmdCriarTarefaDraft — form draft to create a task (includes the generated creation key); source cmdCriarTarefa.input; organism formTarefa */
        this.cmdCriarTarefaDraft = emptyCriarTarefaDraft();
        /** state cmdSalvarEdicaoDraft — form draft to edit the open task, prefilled from it; source cmdSalvarEdicao.input; organism formTarefa */
        this.cmdSalvarEdicaoDraft = emptyEdicaoDraft();
        /** state cmdSalvarChecklistDraft — form draft of the checklist of the open task, prefilled from it; source cmdSalvarChecklist.input; organism formTarefa */
        this.cmdSalvarChecklistDraft = emptyChecklistDraft();
        /** state cmdDevolverDraft — draft with the reason to send the open task back for adjustment; source cmdDevolver.input; organism acoesTarefa */
        this.cmdDevolverDraft = emptyDevolverDraft();
        /** state pageStatus — overall status of the page load: loading while the initial requests run, error if one failed, empty when the loaded lists are empty, success otherwise */
        this.pageStatus = 'idle';
        /** state qryMinhasTarefasStatus — status of the request qryMinhasTarefas; source status */
        this.qryMinhasTarefasStatus = 'idle';
        /** state qryMinhasTarefasError — error of the request qryMinhasTarefas, null when none; source status */
        this.qryMinhasTarefasError = null;
        /** state qryTarefaStatus — status of the request qryTarefa; source status */
        this.qryTarefaStatus = 'idle';
        /** state qryTarefaError — error of the request qryTarefa, null when none; source status */
        this.qryTarefaError = null;
        /** state qryListasAtivasStatus — status of the request qryListasAtivas; source status */
        this.qryListasAtivasStatus = 'idle';
        /** state qryListasAtivasError — error of the request qryListasAtivas, null when none; source status */
        this.qryListasAtivasError = null;
        /** state qryBuscarMembrosStatus — status of the request qryBuscarMembros; source status */
        this.qryBuscarMembrosStatus = 'idle';
        /** state qryBuscarMembrosError — error of the request qryBuscarMembros, null when none; source status */
        this.qryBuscarMembrosError = null;
        /** state cmdCriarTarefaStatus — status of the command cmdCriarTarefa; source status */
        this.cmdCriarTarefaStatus = 'idle';
        /** state cmdCriarTarefaError — error of the command cmdCriarTarefa, null when none; source status */
        this.cmdCriarTarefaError = null;
        /** state cmdSalvarEdicaoStatus — status of the command cmdSalvarEdicao; source status */
        this.cmdSalvarEdicaoStatus = 'idle';
        /** state cmdSalvarEdicaoError — error of the command cmdSalvarEdicao, null when none; source status */
        this.cmdSalvarEdicaoError = null;
        /** state cmdSalvarChecklistStatus — status of the command cmdSalvarChecklist; source status */
        this.cmdSalvarChecklistStatus = 'idle';
        /** state cmdSalvarChecklistError — error of the command cmdSalvarChecklist, null when none; source status */
        this.cmdSalvarChecklistError = null;
        /** state cmdIniciarStatus — status of the command cmdIniciar; source status */
        this.cmdIniciarStatus = 'idle';
        /** state cmdIniciarError — error of the command cmdIniciar, null when none; source status */
        this.cmdIniciarError = null;
        /** state cmdEnviarRevisaoStatus — status of the command cmdEnviarRevisao; source status */
        this.cmdEnviarRevisaoStatus = 'idle';
        /** state cmdEnviarRevisaoError — error of the command cmdEnviarRevisao, null when none; source status */
        this.cmdEnviarRevisaoError = null;
        /** state cmdAceitarStatus — status of the command cmdAceitar; source status */
        this.cmdAceitarStatus = 'idle';
        /** state cmdAceitarError — error of the command cmdAceitar, null when none; source status */
        this.cmdAceitarError = null;
        /** state cmdDevolverStatus — status of the command cmdDevolver; source status */
        this.cmdDevolverStatus = 'idle';
        /** state cmdDevolverError — error of the command cmdDevolver, null when none; source status */
        this.cmdDevolverError = null;
        /** state cmdCancelarStatus — status of the command cmdCancelar; source status */
        this.cmdCancelarStatus = 'idle';
        /** state cmdCancelarError — error of the command cmdCancelar, null when none; source status */
        this.cmdCancelarError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.prefillListaId = null;
        this.prefillResponsavelId = null;
        this.tarefaSeq = 0;
        this.membrosSeq = 0;
        this.onPopState = () => {
            if (window.location.pathname.endsWith(ROUTE_SUFFIX)) {
                this.resetVisit();
                this.enterPage();
            }
        };
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.minhas_tarefas.${member}`, value);
        if (member === 'filtro') {
            this.persistFiltro(this.filtro);
        }
        if (member === 'selectedTarefa') {
            this.syncSelectedUrl(this.selectedTarefa);
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    persistFiltro(value) {
        try {
            if (value === null) {
                localStorage.removeItem(`${STORAGE_PREFIX}filtro`);
            }
            else {
                localStorage.setItem(`${STORAGE_PREFIX}filtro`, value);
            }
        }
        catch {
            // storage unavailable: the filter just does not persist
        }
    }
    syncSelectedUrl(value) {
        try {
            const url = new URL(window.location.href);
            if (value === null) {
                url.searchParams.delete('tarefaId');
            }
            else {
                url.searchParams.set('tarefaId', value);
            }
            history.replaceState(history.state, '', `${url.pathname}${url.search}${url.hash}`);
        }
        catch {
            // URL not writable: the selection just stays out of the query
        }
    }
    readParam(name, useLocalStorage) {
        const raw = new URLSearchParams(window.location.search).get(name);
        if (raw !== null && raw !== '')
            return raw;
        if (useLocalStorage) {
            try {
                const stored = localStorage.getItem(`${STORAGE_PREFIX}${name}`);
                if (stored !== null && stored !== '')
                    return stored;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        window.addEventListener('popstate', this.onPopState);
        this.enterPage();
    }
    disconnectedCallback() {
        window.removeEventListener('popstate', this.onPopState);
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        for (const member of DATA_MEMBERS) {
            const key = `ui.tarefas.minhas_tarefas.${member}`;
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    /** Starts a fresh visit: transient members go back to their initial value. */
    resetVisit() {
        this.tarefaSeq += 1;
        this.membrosSeq += 1;
        this.publish('cmdCriarTarefaDraft', emptyCriarTarefaDraft());
        this.publish('cmdSalvarEdicaoDraft', emptyEdicaoDraft());
        this.publish('cmdSalvarChecklistDraft', emptyChecklistDraft());
        this.publish('cmdDevolverDraft', emptyDevolverDraft());
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.resetQueryResults();
        this.resetCommandResults();
    }
    enterPage() {
        this.applyEntryParams();
        void this.initialLoad();
    }
    applyEntryParams() {
        this.publish('filtro', toFiltro(this.readParam('filtro', true)));
        this.prefillListaId = this.readParam('listaId', true);
        this.prefillResponsavelId = this.readParam('responsavelId', true);
        this.publish('cmdCriarTarefaDraft', this.prefilledCriarDraft());
        const tarefaId = this.readParam('tarefaId', false);
        this.publish('selectedTarefa', tarefaId);
        if (tarefaId === null) {
            this.publish('tarefa', null);
        }
    }
    prefilledCriarDraft() {
        return {
            ...emptyCriarTarefaDraft(),
            listaId: this.prefillListaId,
            responsavelId: this.prefillResponsavelId,
        };
    }
    async initialLoad() {
        const selected = this.selectedTarefa;
        await Promise.all([
            this.qryMinhasTarefas(),
            this.qryListasAtivas(),
            selected !== null ? this.qryTarefa(selected) : Promise.resolve(),
        ]);
    }
    refreshPageStatus() {
        const tarefasStatus = this.qryMinhasTarefasStatus;
        const listasStatus = this.qryListasAtivasStatus;
        if (tarefasStatus === 'loading' || listasStatus === 'loading') {
            this.publish('pageStatus', 'loading');
            return;
        }
        if (tarefasStatus === 'error' || listasStatus === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        const tarefasCount = this.tarefas === null ? 0 : this.tarefas.items.length;
        if (tarefasCount === 0 && this.listas.length === 0) {
            this.publish('pageStatus', 'empty');
            return;
        }
        this.publish('pageStatus', 'success');
    }
    // ---- status helpers ----
    setStatus(request, status) {
        this.publish(`${request}Status`, status);
    }
    setError(request, error) {
        this.publish(`${request}Error`, error);
    }
    statusOf(request) {
        return this[`${request}Status`];
    }
    fail(request, error) {
        this.setError(request, error);
        this.setStatus(request, 'error');
    }
    failRequired(request, stateKeys) {
        this.fail(request, { code: 'client.requiredMissing', message: '', details: { stateKeys } });
    }
    toError(error) {
        if (error !== null)
            return error;
        return { code: 'client.unexpected', message: '', details: { name: 'noResponse' } };
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    /** Query results go back to idle at the start of a visit. */
    resetQueryResults() {
        this.publish('qryMinhasTarefasError', null);
        this.publish('qryMinhasTarefasStatus', 'idle');
        this.publish('qryTarefaError', null);
        this.publish('qryTarefaStatus', 'idle');
        this.publish('qryListasAtivasError', null);
        this.publish('qryListasAtivasStatus', 'idle');
        this.publish('qryBuscarMembrosError', null);
        this.publish('qryBuscarMembrosStatus', 'idle');
    }
    /** Within the visit a command result lives until the person changes what it acted on. */
    resetCommandResults() {
        this.publish('cmdCriarTarefaError', null);
        this.publish('cmdCriarTarefaStatus', 'idle');
        this.publish('cmdSalvarEdicaoError', null);
        this.publish('cmdSalvarEdicaoStatus', 'idle');
        this.publish('cmdSalvarChecklistError', null);
        this.publish('cmdSalvarChecklistStatus', 'idle');
        this.publish('cmdIniciarError', null);
        this.publish('cmdIniciarStatus', 'idle');
        this.publish('cmdEnviarRevisaoError', null);
        this.publish('cmdEnviarRevisaoStatus', 'idle');
        this.publish('cmdAceitarError', null);
        this.publish('cmdAceitarStatus', 'idle');
        this.publish('cmdDevolverError', null);
        this.publish('cmdDevolverStatus', 'idle');
        this.publish('cmdCancelarError', null);
        this.publish('cmdCancelarStatus', 'idle');
    }
    // ---- scene, selection, drafts ----
    /** scene — publishes the visible scene of the page (value is the scene id; '' for none). */
    setScenario(value) {
        this.publish('scenary', value);
        this.resetCommandResults();
    }
    /** select — opens a task: publishes its id in selectedTarefa and loads the record into tarefa (and fills the edit and checklist drafts from it). Pass null (or '') to clear the selection and the open task. */
    async selectDetalheTarefa(id) {
        const next = id === '' ? null : id;
        this.resetCommandResults();
        this.publish('selectedTarefa', next);
        if (next === null) {
            this.tarefaSeq += 1;
            this.publish('tarefa', null);
            this.publish('cmdSalvarEdicaoDraft', emptyEdicaoDraft());
            this.publish('cmdSalvarChecklistDraft', emptyChecklistDraft());
            this.publish('cmdDevolverDraft', emptyDevolverDraft());
            return;
        }
        await this.qryTarefa(next);
    }
    /** draft — replaces the create-task draft (title, description, list, priority, deadline, owner, checklist). The creation key of the draft is kept. */
    setCmdCriarTarefaDraft(value) {
        this.publish('cmdCriarTarefaDraft', { ...value, chaveCriacao: this.cmdCriarTarefaDraft.chaveCriacao });
        this.resetCommandResults();
    }
    /** draft — clears the create-task draft (as when the form opens) and generates a new creation key. */
    clearCmdCriarTarefaDraft() {
        this.publish('cmdCriarTarefaDraft', emptyCriarTarefaDraft());
        this.resetCommandResults();
    }
    /** draft — replaces the edit draft of the open task (list, title, description, priority, deadline, owner); keep id and version from the draft. */
    setCmdSalvarEdicaoDraft(value) {
        this.publish('cmdSalvarEdicaoDraft', value);
        this.resetCommandResults();
    }
    /** draft — replaces the checklist draft of the open task (edit descriptions, order, mark items done, add items without id). */
    setCmdSalvarChecklistDraft(value) {
        this.publish('cmdSalvarChecklistDraft', value);
        this.resetCommandResults();
    }
    /** draft — replaces the draft with the reason to send the open task back for adjustment. */
    setCmdDevolverDraft(value) {
        this.publish('cmdDevolverDraft', value);
        this.resetCommandResults();
    }
    // ---- queries ----
    /** request qryMinhasTarefas — lists, paged, the tasks I created or own, with the quick filter; redraws tarefas (replace, or append the next page when append is true; page, pageSize and hasMore live in the list); filtro: the quick filter (omit to keep the current one, null for all mine; a new value is published and loads from the first page); page: page to load (default 1); append: true for a load-more (does nothing unless tarefas.hasMore) */
    async qryMinhasTarefas(filtro = this.filtro, page = 1, append = false) {
        if (this.qryMinhasTarefasStatus === 'loading')
            return;
        const current = this.tarefas;
        if (append && (current === null || !current.hasMore))
            return;
        if (filtro !== this.filtro) {
            this.publish('filtro', filtro);
        }
        this.setStatus('qryMinhasTarefas', 'loading');
        this.setError('qryMinhasTarefas', null);
        if (!append) {
            this.refreshPageStatus();
        }
        try {
            const input = {
                ...(filtro !== null ? { filtro } : {}),
                page,
                pageSize: PAGE_SIZE,
            };
            const response = await execBff('tarefas.minhas_tarefas.qryMinhasTarefas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.fail('qryMinhasTarefas', this.toError(response.error));
            }
            else {
                const loaded = response.data.tarefas;
                const base = this.tarefas;
                if (append && base !== null) {
                    this.publish('tarefas', { ...loaded, items: [...base.items, ...loaded.items] });
                }
                else {
                    this.publish('tarefas', loaded);
                }
                this.setStatus('qryMinhasTarefas', 'success');
            }
        }
        catch (error) {
            this.fail('qryMinhasTarefas', this.unexpectedError(error));
        }
        this.refreshPageStatus();
    }
    /** request qryTarefa — reads one task with checklist and cycle milestones; redraws tarefa (replace) and refills the edit and checklist drafts from it; tarefaId: id of the task. Prefer selectDetalheTarefa to open a task. A newer call discards the answer of an older one. */
    async qryTarefa(tarefaId) {
        this.tarefaSeq += 1;
        const seq = this.tarefaSeq;
        this.setStatus('qryTarefa', 'loading');
        this.setError('qryTarefa', null);
        try {
            const input = { tarefaId };
            const response = await execBff('tarefas.minhas_tarefas.qryTarefa', input, { mode: 'silent' });
            if (seq !== this.tarefaSeq)
                return;
            if (!response.ok || !response.data) {
                this.fail('qryTarefa', this.toError(response.error));
                return;
            }
            const loaded = response.data.tarefa;
            this.publish('tarefa', loaded);
            this.publish('cmdSalvarEdicaoDraft', edicaoDraftFromTarefa(loaded));
            this.publish('cmdSalvarChecklistDraft', checklistDraftFromTarefa(loaded));
            this.publish('cmdDevolverDraft', emptyDevolverDraft());
            this.setStatus('qryTarefa', 'success');
        }
        catch (error) {
            if (seq !== this.tarefaSeq)
                return;
            this.fail('qryTarefa', this.unexpectedError(error));
        }
    }
    /** request qryListasAtivas — brings the active lists that can receive a task; redraws listas (replace); no arguments */
    async qryListasAtivas() {
        if (this.qryListasAtivasStatus === 'loading')
            return;
        this.setStatus('qryListasAtivas', 'loading');
        this.setError('qryListasAtivas', null);
        this.refreshPageStatus();
        try {
            const input = {};
            const response = await execBff('tarefas.minhas_tarefas.qryListasAtivas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.fail('qryListasAtivas', this.toError(response.error));
            }
            else {
                this.publish('listas', response.data.listas);
                this.setStatus('qryListasAtivas', 'success');
            }
        }
        catch (error) {
            this.fail('qryListasAtivas', this.unexpectedError(error));
        }
        this.refreshPageStatus();
    }
    /** request qryBuscarMembros — searches active team members by name to choose or change the owner; redraws membros (replace; an empty term clears it without calling); termo: part of the name typed. A newer call discards the answer of an older one. */
    async qryBuscarMembros(termo) {
        this.membrosSeq += 1;
        const seq = this.membrosSeq;
        if (termo.trim() === '') {
            this.publish('membros', []);
            this.setStatus('qryBuscarMembros', 'idle');
            this.setError('qryBuscarMembros', null);
            return;
        }
        this.setStatus('qryBuscarMembros', 'loading');
        this.setError('qryBuscarMembros', null);
        try {
            const input = { termo };
            const response = await execBff('tarefas.minhas_tarefas.qryBuscarMembros', input, { mode: 'silent' });
            if (seq !== this.membrosSeq)
                return;
            if (!response.ok || !response.data) {
                this.fail('qryBuscarMembros', this.toError(response.error));
                return;
            }
            this.publish('membros', response.data.membros);
            this.setStatus('qryBuscarMembros', 'success');
        }
        catch (error) {
            if (seq !== this.membrosSeq)
                return;
            this.fail('qryBuscarMembros', this.unexpectedError(error));
        }
    }
    // ---- commands ----
    async runCommand(request, call, onSuccess) {
        if (this.statusOf(request) === 'loading')
            return;
        this.setStatus(request, 'loading');
        this.setError(request, null);
        try {
            const response = await runBlockingUiAction(call);
            if (response === undefined) {
                this.fail(request, { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                return;
            }
            if (!response.ok || !response.data) {
                this.fail(request, this.toError(response.error));
                return;
            }
            onSuccess(response.data.tarefa);
            this.setStatus(request, 'success');
        }
        catch (error) {
            this.fail(request, this.unexpectedError(error));
        }
    }
    currentTarefa(request) {
        if (this.tarefa === null) {
            this.failRequired(request, ['tarefa']);
            return null;
        }
        return this.tarefa;
    }
    /** Whether a returned task still belongs to the list under the current quick filter (rules of the list route). */
    belongsToList(tarefa) {
        switch (this.filtro) {
            case null:
                return true;
            case 'criadasPorMim':
                return tarefa.souCriador;
            case 'atribuidasAMim':
                return tarefa.souResponsavel;
            case 'emRevisao':
                return tarefa.status === 'emRevisao';
            case 'devolvidas':
                return tarefa.details.devolvidaEm !== undefined && tarefa.status === 'emAndamento';
            default:
                return true;
        }
    }
    /** Updates the loaded row of the task by id, or removes it when it no longer belongs to the list. */
    applyRow(tarefa) {
        const page = this.tarefas;
        if (page === null)
            return;
        const current = page.items.find((row) => row.id === tarefa.id);
        if (current === undefined)
            return;
        if (!this.belongsToList(tarefa)) {
            this.publish('tarefas', { ...page, items: page.items.filter((row) => row.id !== tarefa.id) });
            return;
        }
        const updated = {
            id: tarefa.id,
            version: tarefa.version,
            titulo: tarefa.titulo,
            listaId: tarefa.listaId,
            lista: tarefa.lista,
            responsavelId: tarefa.responsavelId,
            responsavel: tarefa.responsavel,
            criadorId: tarefa.criadorId,
            criador: tarefa.criador,
            prioridade: tarefa.prioridade,
            prazo: tarefa.prazo,
            status: tarefa.status,
            details: {
                quantidadeSubtarefas: current.details.quantidadeSubtarefas,
                progressoChecklist: current.details.progressoChecklist,
                venceHoje: current.details.venceHoje,
                atrasada: current.details.atrasada,
                ...(tarefa.details.devolvidaEm !== undefined ? { devolvidaEm: tarefa.details.devolvidaEm } : {}),
            },
        };
        this.publish('tarefas', { ...page, items: page.items.map((row) => (row.id === tarefa.id ? updated : row)) });
    }
    /** Applies a task returned by a command: redraws tarefa, its loaded row, and the drafts that edit it. */
    applyTarefa(tarefa, refill) {
        this.publish('tarefa', tarefa);
        this.applyRow(tarefa);
        if (refill === 'edit' || refill === 'both') {
            this.publish('cmdSalvarEdicaoDraft', edicaoDraftFromTarefa(tarefa));
        }
        else if (this.cmdSalvarEdicaoDraft.id === tarefa.id) {
            this.publish('cmdSalvarEdicaoDraft', { ...this.cmdSalvarEdicaoDraft, version: tarefa.version });
        }
        if (refill === 'checklist' || refill === 'both') {
            this.publish('cmdSalvarChecklistDraft', checklistDraftFromTarefa(tarefa));
        }
    }
    /** request cmdCriarTarefa — creates a task with its initial checklist from cmdCriarTarefaDraft (idempotent through the creation key kept in the draft); redraws tarefa with the created task and selects it (selectedTarefa), refills the edit and checklist drafts, and resets cmdCriarTarefaDraft to a new empty draft; requires list, title, priority, deadline and owner in the draft; no arguments */
    async cmdCriarTarefa() {
        const draft = this.cmdCriarTarefaDraft;
        const missing = [];
        if (isBlank(draft.listaId))
            missing.push('cmdCriarTarefaDraft.listaId');
        if (isBlank(draft.titulo))
            missing.push('cmdCriarTarefaDraft.titulo');
        if (draft.prioridade === null)
            missing.push('cmdCriarTarefaDraft.prioridade');
        if (isBlank(draft.prazo))
            missing.push('cmdCriarTarefaDraft.prazo');
        if (isBlank(draft.responsavelId))
            missing.push('cmdCriarTarefaDraft.responsavelId');
        const itens = toEntradas(draft.checklist);
        if (itens === null)
            missing.push('cmdCriarTarefaDraft.checklist');
        const { listaId, titulo, prioridade, prazo, responsavelId } = draft;
        if (missing.length > 0 ||
            listaId === null ||
            titulo === null ||
            prioridade === null ||
            prazo === null ||
            responsavelId === null ||
            itens === null) {
            this.failRequired('cmdCriarTarefa', missing);
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            chaveCriacao: draft.chaveCriacao,
            listaId,
            titulo,
            details: { ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
            prioridade,
            prazo,
            responsavelId,
            ...(itens.length > 0 ? { checklist: itens } : {}),
        };
        await this.runCommand('cmdCriarTarefa', (signal) => execBff('tarefas.minhas_tarefas.cmdCriarTarefa', input, { mode: 'blocking', signal }), (created) => {
            this.applyTarefa(created, 'both');
            this.publish('selectedTarefa', created.id);
            this.publish('cmdCriarTarefaDraft', emptyCriarTarefaDraft());
        });
    }
    /** request cmdSalvarEdicao — saves the edited fields of the open task (including owner change) from cmdSalvarEdicaoDraft; editing never changes the status; redraws tarefa, updates its row in tarefas by id and refills cmdSalvarEdicaoDraft from the saved task; requires id, version, list, title, priority, deadline and owner in the draft; no arguments */
    async cmdSalvarEdicao() {
        const draft = this.cmdSalvarEdicaoDraft;
        const missing = [];
        if (draft.id === null)
            missing.push('cmdSalvarEdicaoDraft.id');
        if (draft.version === null)
            missing.push('cmdSalvarEdicaoDraft.version');
        if (isBlank(draft.listaId))
            missing.push('cmdSalvarEdicaoDraft.listaId');
        if (isBlank(draft.titulo))
            missing.push('cmdSalvarEdicaoDraft.titulo');
        if (draft.prioridade === null)
            missing.push('cmdSalvarEdicaoDraft.prioridade');
        if (isBlank(draft.prazo))
            missing.push('cmdSalvarEdicaoDraft.prazo');
        if (isBlank(draft.responsavelId))
            missing.push('cmdSalvarEdicaoDraft.responsavelId');
        const { id, version, listaId, titulo, prioridade, prazo, responsavelId } = draft;
        if (missing.length > 0 ||
            id === null ||
            version === null ||
            listaId === null ||
            titulo === null ||
            prioridade === null ||
            prazo === null ||
            responsavelId === null) {
            this.failRequired('cmdSalvarEdicao', missing);
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            id,
            version,
            listaId,
            titulo,
            details: { ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
            prioridade,
            prazo,
            responsavelId,
        };
        await this.runCommand('cmdSalvarEdicao', (signal) => execBff('tarefas.minhas_tarefas.cmdSalvarEdicao', input, { mode: 'blocking', signal }), (saved) => {
            this.applyTarefa(saved, 'edit');
        });
    }
    /** request cmdSalvarChecklist — saves the checklist of the open task from cmdSalvarChecklistDraft (edit, reorder, mark done, add items without id); never changes the status; redraws tarefa with the saved checklist and refills cmdSalvarChecklistDraft from it; requires the task id and a description in every item; no arguments */
    async cmdSalvarChecklist() {
        const draft = this.cmdSalvarChecklistDraft;
        const missing = [];
        if (draft.tarefaId === null)
            missing.push('cmdSalvarChecklistDraft.tarefaId');
        const itens = toEntradas(draft.itens);
        if (itens === null)
            missing.push('cmdSalvarChecklistDraft.itens');
        const tarefaId = draft.tarefaId;
        if (missing.length > 0 || tarefaId === null || itens === null) {
            this.failRequired('cmdSalvarChecklist', missing);
            return;
        }
        const input = { tarefaId, itens };
        await this.runCommand('cmdSalvarChecklist', (signal) => execBff('tarefas.minhas_tarefas.cmdSalvarChecklist', input, { mode: 'blocking', signal }), (saved) => {
            this.applyTarefa(saved, 'checklist');
        });
    }
    /** request cmdIniciar — the owner starts the open task (a fazer to em andamento); redraws tarefa and updates or removes its row in tarefas by id; no arguments (uses the open task and its version) */
    async cmdIniciar() {
        const current = this.currentTarefa('cmdIniciar');
        if (!current)
            return;
        const input = { id: current.id, version: current.version };
        await this.runCommand('cmdIniciar', (signal) => execBff('tarefas.minhas_tarefas.cmdIniciar', input, { mode: 'blocking', signal }), (updated) => {
            this.applyTarefa(updated, 'none');
        });
    }
    /** request cmdEnviarRevisao — the owner sends or resends the open task to the creator's review (em andamento to em revisao); redraws tarefa and updates or removes its row in tarefas by id; no arguments (uses the open task and its version) */
    async cmdEnviarRevisao() {
        const current = this.currentTarefa('cmdEnviarRevisao');
        if (!current)
            return;
        const input = { id: current.id, version: current.version };
        await this.runCommand('cmdEnviarRevisao', (signal) => execBff('tarefas.minhas_tarefas.cmdEnviarRevisao', input, { mode: 'blocking', signal }), (updated) => {
            this.applyTarefa(updated, 'none');
        });
    }
    /** request cmdAceitar — the creator accepts the delivery and concludes the open task (em revisao to concluida); redraws tarefa and updates or removes its row in tarefas by id; no arguments (uses the open task and its version) */
    async cmdAceitar() {
        const current = this.currentTarefa('cmdAceitar');
        if (!current)
            return;
        const input = { id: current.id, version: current.version };
        await this.runCommand('cmdAceitar', (signal) => execBff('tarefas.minhas_tarefas.cmdAceitar', input, { mode: 'blocking', signal }), (updated) => {
            this.applyTarefa(updated, 'none');
        });
    }
    /** request cmdDevolver — the creator sends the open task in review back for adjustment with the reason typed in cmdDevolverDraft (back to em andamento); redraws tarefa and updates or removes its row in tarefas by id, then resets cmdDevolverDraft; requires a non-empty reason; no arguments */
    async cmdDevolver() {
        const current = this.currentTarefa('cmdDevolver');
        if (!current)
            return;
        const motivo = this.cmdDevolverDraft.details.motivoDevolucao;
        if (motivo === null || motivo.trim() === '') {
            this.failRequired('cmdDevolver', ['cmdDevolverDraft.details.motivoDevolucao']);
            return;
        }
        const input = {
            id: current.id,
            version: current.version,
            details: { motivoDevolucao: motivo },
        };
        await this.runCommand('cmdDevolver', (signal) => execBff('tarefas.minhas_tarefas.cmdDevolver', input, { mode: 'blocking', signal }), (updated) => {
            this.applyTarefa(updated, 'none');
            this.publish('cmdDevolverDraft', emptyDevolverDraft());
        });
    }
    /** request cmdCancelar — the creator cancels the open task (a fazer, em andamento or em revisao to cancelada); redraws tarefa and updates or removes its row in tarefas by id; no arguments (uses the open task and its version) */
    async cmdCancelar() {
        const current = this.currentTarefa('cmdCancelar');
        if (!current)
            return;
        const input = { id: current.id, version: current.version };
        await this.runCommand('cmdCancelar', (signal) => execBff('tarefas.minhas_tarefas.cmdCancelar', input, { mode: 'blocking', signal }), (updated) => {
            this.applyTarefa(updated, 'none');
        });
    }
}
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "tarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "membros", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "selectedTarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "filtro", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryMinhasTarefasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryMinhasTarefasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryListasAtivasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryListasAtivasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryBuscarMembrosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryBuscarMembrosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdIniciarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdIniciarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdEnviarRevisaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdEnviarRevisaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdAceitarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdAceitarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCancelarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCancelarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "scenary", void 0);

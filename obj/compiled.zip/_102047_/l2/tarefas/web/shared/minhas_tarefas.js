var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/minhas_tarefas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const KEY_PREFIX = 'ui.tarefas.minhas_tarefas.';
const PAGE_SIZE = 20;
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.minhas_tarefas.tarefas': 'tarefas',
    'ui.tarefas.minhas_tarefas.tarefa': 'tarefa',
    'ui.tarefas.minhas_tarefas.listas': 'listas',
    'ui.tarefas.minhas_tarefas.membros': 'membros',
    'ui.tarefas.minhas_tarefas.selectedTarefa': 'selectedTarefa',
    'ui.tarefas.minhas_tarefas.filtro': 'filtro',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaDraft': 'cmdCriarTarefaDraft',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoDraft': 'cmdSalvarEdicaoDraft',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistDraft': 'cmdSalvarChecklistDraft',
    'ui.tarefas.minhas_tarefas.cmdDevolverDraft': 'cmdDevolverDraft',
    'ui.tarefas.minhas_tarefas.pageStatus': 'pageStatus',
    'ui.tarefas.minhas_tarefas.qryMinhasTarefasStatus': 'qryMinhasTarefasStatus',
    'ui.tarefas.minhas_tarefas.qryMinhasTarefasError': 'qryMinhasTarefasError',
    'ui.tarefas.minhas_tarefas.qryTarefaStatus': 'qryTarefaStatus',
    'ui.tarefas.minhas_tarefas.qryTarefaError': 'qryTarefaError',
    'ui.tarefas.minhas_tarefas.qryListasAtivasStatus': 'qryListasAtivasStatus',
    'ui.tarefas.minhas_tarefas.qryListasAtivasError': 'qryListasAtivasError',
    'ui.tarefas.minhas_tarefas.qryBuscarMembrosStatus': 'qryBuscarMembrosStatus',
    'ui.tarefas.minhas_tarefas.qryBuscarMembrosError': 'qryBuscarMembrosError',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaStatus': 'cmdCriarTarefaStatus',
    'ui.tarefas.minhas_tarefas.cmdCriarTarefaError': 'cmdCriarTarefaError',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoStatus': 'cmdSalvarEdicaoStatus',
    'ui.tarefas.minhas_tarefas.cmdSalvarEdicaoError': 'cmdSalvarEdicaoError',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistStatus': 'cmdSalvarChecklistStatus',
    'ui.tarefas.minhas_tarefas.cmdSalvarChecklistError': 'cmdSalvarChecklistError',
    'ui.tarefas.minhas_tarefas.cmdIniciarStatus': 'cmdIniciarStatus',
    'ui.tarefas.minhas_tarefas.cmdIniciarError': 'cmdIniciarError',
    'ui.tarefas.minhas_tarefas.cmdEnviarRevisaoStatus': 'cmdEnviarRevisaoStatus',
    'ui.tarefas.minhas_tarefas.cmdEnviarRevisaoError': 'cmdEnviarRevisaoError',
    'ui.tarefas.minhas_tarefas.cmdAceitarStatus': 'cmdAceitarStatus',
    'ui.tarefas.minhas_tarefas.cmdAceitarError': 'cmdAceitarError',
    'ui.tarefas.minhas_tarefas.cmdDevolverStatus': 'cmdDevolverStatus',
    'ui.tarefas.minhas_tarefas.cmdDevolverError': 'cmdDevolverError',
    'ui.tarefas.minhas_tarefas.cmdCancelarStatus': 'cmdCancelarStatus',
    'ui.tarefas.minhas_tarefas.cmdCancelarError': 'cmdCancelarError',
    'ui.tarefas.minhas_tarefas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const DATA_MEMBERS = ['tarefas', 'tarefa', 'listas', 'membros'];
function emptyCriarTarefaDraft() {
    return {
        chaveCriacao: crypto.randomUUID(),
        listaId: null,
        titulo: null,
        details: { descricao: null },
        prioridade: null,
        prazo: null,
        responsavelId: null,
        checklist: [],
    };
}
function emptySalvarEdicaoDraft() {
    return {
        id: null,
        version: null,
        listaId: null,
        titulo: null,
        details: { descricao: null },
        prioridade: null,
        prazo: null,
        responsavelId: null,
    };
}
function emptySalvarChecklistDraft() {
    return { tarefaId: null, itens: [] };
}
function emptyDevolverDraft() {
    return { details: { motivoDevolucao: null } };
}
function parseFiltro(raw) {
    switch (raw) {
        case 'criadasPorMim':
            return 'criadasPorMim';
        case 'atribuidasAMim':
            return 'atribuidasAMim';
        case 'emRevisao':
            return 'emRevisao';
        case 'devolvidas':
            return 'devolvidas';
        default:
            return null;
    }
}
function nonEmpty(value) {
    return value !== null && value.trim() !== '' ? value : null;
}
export class TarefasMinhas_tarefasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state tarefas — the page of my tasks (created by me or assigned to me) with list, assignee, creator, deadline, status and indicators; source qryMinhasTarefas.tarefas; organism listaTarefas */
        this.tarefas = null;
        /** state tarefa — the opened task in full: list, creator, assignee, status, cycle milestones, return reason, my role and ordered checklist; source qryTarefa.tarefa; organisms acoesTarefa, detalheTarefa, formTarefa, historicoTarefa */
        this.tarefa = null;
        /** state listas — active lists (projects or areas) that can receive tasks; source qryListasAtivas.listas; organism formTarefa */
        this.listas = [];
        /** state membros — active team members found by name, to choose or change the assignee; source qryBuscarMembros.membros; organism formTarefa */
        this.membros = [];
        /** state selectedTarefa — the id of the task selected in listaTarefas (the record itself is in tarefa); source entry.params.tarefaId; organisms detalheTarefa, listaTarefas; persisted */
        this.selectedTarefa = null;
        /** state filtro — the quick filter of the task list, null for all my tasks; source entry.params.filtro; organism listaTarefas; persisted */
        this.filtro = null;
        /** state cmdCriarTarefaDraft — form draft to create a task (list, title, description, priority, deadline, assignee, initial checklist) with the idempotency key; source cmdCriarTarefa.input; organism formTarefa */
        this.cmdCriarTarefaDraft = emptyCriarTarefaDraft();
        /** state cmdSalvarEdicaoDraft — form draft to edit the fields of the opened task, filled from it; source cmdSalvarEdicao.input; organism formTarefa */
        this.cmdSalvarEdicaoDraft = emptySalvarEdicaoDraft();
        /** state cmdSalvarChecklistDraft — form draft of the checklist of the opened task (edit, reorder, mark, add items), filled from it; source cmdSalvarChecklist.input; organism formTarefa */
        this.cmdSalvarChecklistDraft = emptySalvarChecklistDraft();
        /** state cmdDevolverDraft — draft with the reason to return the task in review for adjustment; source cmdDevolver.input; organism acoesTarefa */
        this.cmdDevolverDraft = emptyDevolverDraft();
        /** state pageStatus — overall status of the page initial load: idle, loading, empty (every loaded list empty), success or error */
        this.pageStatus = 'idle';
        /** state qryMinhasTarefasStatus — status of the request qryMinhasTarefas */
        this.qryMinhasTarefasStatus = 'idle';
        /** state qryMinhasTarefasError — error of the request qryMinhasTarefas, null when none */
        this.qryMinhasTarefasError = null;
        /** state qryTarefaStatus — status of the request qryTarefa */
        this.qryTarefaStatus = 'idle';
        /** state qryTarefaError — error of the request qryTarefa, null when none */
        this.qryTarefaError = null;
        /** state qryListasAtivasStatus — status of the request qryListasAtivas */
        this.qryListasAtivasStatus = 'idle';
        /** state qryListasAtivasError — error of the request qryListasAtivas, null when none */
        this.qryListasAtivasError = null;
        /** state qryBuscarMembrosStatus — status of the request qryBuscarMembros */
        this.qryBuscarMembrosStatus = 'idle';
        /** state qryBuscarMembrosError — error of the request qryBuscarMembros, null when none */
        this.qryBuscarMembrosError = null;
        /** state cmdCriarTarefaStatus — status of the command cmdCriarTarefa */
        this.cmdCriarTarefaStatus = 'idle';
        /** state cmdCriarTarefaError — error of the command cmdCriarTarefa, null when none */
        this.cmdCriarTarefaError = null;
        /** state cmdSalvarEdicaoStatus — status of the command cmdSalvarEdicao */
        this.cmdSalvarEdicaoStatus = 'idle';
        /** state cmdSalvarEdicaoError — error of the command cmdSalvarEdicao, null when none */
        this.cmdSalvarEdicaoError = null;
        /** state cmdSalvarChecklistStatus — status of the command cmdSalvarChecklist */
        this.cmdSalvarChecklistStatus = 'idle';
        /** state cmdSalvarChecklistError — error of the command cmdSalvarChecklist, null when none */
        this.cmdSalvarChecklistError = null;
        /** state cmdIniciarStatus — status of the command cmdIniciar */
        this.cmdIniciarStatus = 'idle';
        /** state cmdIniciarError — error of the command cmdIniciar, null when none */
        this.cmdIniciarError = null;
        /** state cmdEnviarRevisaoStatus — status of the command cmdEnviarRevisao */
        this.cmdEnviarRevisaoStatus = 'idle';
        /** state cmdEnviarRevisaoError — error of the command cmdEnviarRevisao, null when none */
        this.cmdEnviarRevisaoError = null;
        /** state cmdAceitarStatus — status of the command cmdAceitar */
        this.cmdAceitarStatus = 'idle';
        /** state cmdAceitarError — error of the command cmdAceitar, null when none */
        this.cmdAceitarError = null;
        /** state cmdDevolverStatus — status of the command cmdDevolver */
        this.cmdDevolverStatus = 'idle';
        /** state cmdDevolverError — error of the command cmdDevolver, null when none */
        this.cmdDevolverError = null;
        /** state cmdCancelarStatus — status of the command cmdCancelar */
        this.cmdCancelarStatus = 'idle';
        /** state cmdCancelarError — error of the command cmdCancelar, null when none */
        this.cmdCancelarError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.subscribed = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.minhas_tarefas.${member}`, value);
        this.persistParam(member, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    persistParam(member, value) {
        let name = null;
        if (member === 'filtro')
            name = 'filtro';
        if (member === 'selectedTarefa')
            name = 'tarefaId';
        if (name === null)
            return;
        try {
            const key = `tarefas.minhas_tarefas.${name}`;
            if (typeof value === 'string' && value !== '') {
                localStorage.setItem(key, value);
            }
            else {
                localStorage.removeItem(key);
            }
        }
        catch {
            // storage unavailable: the param simply is not persisted
        }
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        if (!this.subscribed) {
            subscribe([...STATE_KEYS], this);
            this.subscribed = true;
        }
        this.applyEntryParams();
        void this.startVisit();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        this.subscribed = false;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        for (const member of DATA_MEMBERS) {
            const stored = getState(`${KEY_PREFIX}${member}`);
            if (stored !== undefined)
                this.assignState(`${KEY_PREFIX}${member}`, stored);
        }
    }
    /** Transient members start every visit from their initial value. */
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('qryMinhasTarefasStatus', 'idle');
        this.publish('qryMinhasTarefasError', null);
        this.publish('qryTarefaStatus', 'idle');
        this.publish('qryTarefaError', null);
        this.publish('qryListasAtivasStatus', 'idle');
        this.publish('qryListasAtivasError', null);
        this.publish('qryBuscarMembrosStatus', 'idle');
        this.publish('qryBuscarMembrosError', null);
        this.resetCommandResults(true);
        this.publish('cmdCriarTarefaDraft', emptyCriarTarefaDraft());
        this.publish('cmdSalvarEdicaoDraft', emptySalvarEdicaoDraft());
        this.publish('cmdSalvarChecklistDraft', emptySalvarChecklistDraft());
        this.publish('cmdDevolverDraft', emptyDevolverDraft());
    }
    resetCommandResults(force = false) {
        if (force || this.cmdCriarTarefaStatus !== 'idle')
            this.publish('cmdCriarTarefaStatus', 'idle');
        if (force || this.cmdCriarTarefaError !== null)
            this.publish('cmdCriarTarefaError', null);
        if (force || this.cmdSalvarEdicaoStatus !== 'idle')
            this.publish('cmdSalvarEdicaoStatus', 'idle');
        if (force || this.cmdSalvarEdicaoError !== null)
            this.publish('cmdSalvarEdicaoError', null);
        if (force || this.cmdSalvarChecklistStatus !== 'idle')
            this.publish('cmdSalvarChecklistStatus', 'idle');
        if (force || this.cmdSalvarChecklistError !== null)
            this.publish('cmdSalvarChecklistError', null);
        if (force || this.cmdIniciarStatus !== 'idle')
            this.publish('cmdIniciarStatus', 'idle');
        if (force || this.cmdIniciarError !== null)
            this.publish('cmdIniciarError', null);
        if (force || this.cmdEnviarRevisaoStatus !== 'idle')
            this.publish('cmdEnviarRevisaoStatus', 'idle');
        if (force || this.cmdEnviarRevisaoError !== null)
            this.publish('cmdEnviarRevisaoError', null);
        if (force || this.cmdAceitarStatus !== 'idle')
            this.publish('cmdAceitarStatus', 'idle');
        if (force || this.cmdAceitarError !== null)
            this.publish('cmdAceitarError', null);
        if (force || this.cmdDevolverStatus !== 'idle')
            this.publish('cmdDevolverStatus', 'idle');
        if (force || this.cmdDevolverError !== null)
            this.publish('cmdDevolverError', null);
        if (force || this.cmdCancelarStatus !== 'idle')
            this.publish('cmdCancelarStatus', 'idle');
        if (force || this.cmdCancelarError !== null)
            this.publish('cmdCancelarError', null);
    }
    readParam(name) {
        let search = '';
        try {
            search = typeof window !== 'undefined' && window.location ? window.location.search : '';
        }
        catch {
            search = '';
        }
        const raw = new URLSearchParams(search).get(name);
        if (raw !== null && raw !== '')
            return raw;
        try {
            const stored = localStorage.getItem(`tarefas.minhas_tarefas.${name}`);
            if (stored !== null && stored !== '')
                return stored;
        }
        catch {
            return null;
        }
        return null;
    }
    applyEntryParams() {
        const rawFiltro = this.readParam('filtro');
        this.publish('filtro', rawFiltro !== null ? parseFiltro(rawFiltro) : null);
        const tarefaId = this.readParam('tarefaId');
        this.publish('selectedTarefa', tarefaId);
        if (tarefaId === null)
            this.publish('tarefa', null);
        const listaId = this.readParam('listaId');
        const responsavelId = this.readParam('responsavelId');
        if (listaId !== null || responsavelId !== null) {
            const draft = this.cmdCriarTarefaDraft;
            this.publish('cmdCriarTarefaDraft', {
                ...draft,
                listaId: listaId ?? draft.listaId,
                responsavelId: responsavelId ?? draft.responsavelId,
            });
        }
    }
    async startVisit() {
        this.publish('pageStatus', 'loading');
        const tarefaId = this.selectedTarefa;
        if (tarefaId !== null)
            void this.qryTarefa(tarefaId);
        await Promise.all([this.qryMinhasTarefas(), this.qryListasAtivas()]);
        this.refreshPageStatus();
    }
    refreshPageStatus() {
        if (this.qryMinhasTarefasStatus === 'loading' || this.qryListasAtivasStatus === 'loading')
            return;
        if (this.qryMinhasTarefasStatus === 'error' || this.qryListasAtivasStatus === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        const tarefasVazia = this.tarefas === null || this.tarefas.items.length === 0;
        this.publish('pageStatus', tarefasVazia && this.listas.length === 0 ? 'empty' : 'success');
    }
    unexpectedError(error) {
        return {
            code: 'client.unexpected',
            message: '',
            details: { name: error instanceof Error ? error.name : 'unknown' },
        };
    }
    /** Options of a blocking command; the abort signal is sent only when the runtime provides one. */
    blockingOptions(signal) {
        return signal ? { mode: 'blocking', signal } : { mode: 'blocking' };
    }
    async runQuery(statusMember, errorMember, call) {
        this.publish(statusMember, 'loading');
        this.publish(errorMember, null);
        try {
            const response = await call();
            if (!response.ok || !response.data) {
                this.publish(errorMember, response.error ?? this.unexpectedError(null));
                this.publish(statusMember, 'error');
                return null;
            }
            return response.data;
        }
        catch (error) {
            this.publish(errorMember, this.unexpectedError(error));
            this.publish(statusMember, 'error');
            return null;
        }
    }
    async runCommand(statusMember, errorMember, call) {
        if (this[statusMember] === 'loading')
            return null;
        this.publish(statusMember, 'loading');
        this.publish(errorMember, null);
        try {
            const response = await runBlockingUiAction((signal) => call(signal));
            if (response === undefined) {
                this.publish(errorMember, { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish(statusMember, 'error');
                return null;
            }
            if (!response.ok || !response.data) {
                this.publish(errorMember, response.error ?? this.unexpectedError(null));
                this.publish(statusMember, 'error');
                return null;
            }
            return response.data;
        }
        catch (error) {
            this.publish(errorMember, this.unexpectedError(error));
            this.publish(statusMember, 'error');
            return null;
        }
    }
    failRequired(statusMember, errorMember, stateKeys) {
        this.publish(errorMember, { code: 'client.requiredMissing', message: '', details: { stateKeys } });
        this.publish(statusMember, 'error');
    }
    missingKeys(draftName, fields) {
        return Object.entries(fields)
            .filter(([, value]) => value === null)
            .map(([name]) => `${KEY_PREFIX}${draftName}.${name}`);
    }
    buildItens(items, draftName) {
        const itens = [];
        const invalidKeys = [];
        items.forEach((item, index) => {
            const descricao = nonEmpty(item.details.descricao);
            const ordem = item.ordem;
            if (descricao === null || ordem === null) {
                invalidKeys.push(`${KEY_PREFIX}${draftName}.itens[${index}]`);
                return;
            }
            itens.push({
                ...(item.id !== null ? { id: item.id } : {}),
                ...(item.version !== null ? { version: item.version } : {}),
                details: { descricao },
                ordem,
                feito: item.feito ?? false,
            });
        });
        return { itens, invalidKeys };
    }
    fillEditDraft(tarefa) {
        this.publish('cmdSalvarEdicaoDraft', {
            id: tarefa.id,
            version: tarefa.version,
            listaId: tarefa.listaId,
            titulo: tarefa.titulo,
            details: { descricao: tarefa.details.descricao ?? null },
            prioridade: tarefa.prioridade,
            prazo: tarefa.prazo,
            responsavelId: tarefa.responsavelId,
        });
    }
    fillChecklistDraft(tarefa) {
        this.publish('cmdSalvarChecklistDraft', {
            tarefaId: tarefa.id,
            itens: tarefa.checklist.map((item) => ({
                id: item.id,
                version: item.version,
                details: { descricao: item.details.descricao },
                ordem: item.ordem,
                feito: item.feito,
            })),
        });
    }
    syncEditVersion(tarefa) {
        const draft = this.cmdSalvarEdicaoDraft;
        if (draft.id === tarefa.id)
            this.publish('cmdSalvarEdicaoDraft', { ...draft, version: tarefa.version });
    }
    belongsToFilter(tarefa) {
        if (this.filtro === 'emRevisao')
            return tarefa.status === 'emRevisao';
        if (this.filtro === 'devolvidas') {
            return tarefa.status === 'emAndamento' && tarefa.details.devolvidaEm !== undefined;
        }
        return true;
    }
    /** Updates the row of the list that shows this task (or removes it when it no longer belongs to the filter); indicators stay as loaded. */
    upsertRow(tarefa) {
        const page = this.tarefas;
        if (!page)
            return;
        const index = page.items.findIndex((row) => row.id === tarefa.id);
        if (index < 0)
            return;
        if (!this.belongsToFilter(tarefa)) {
            this.publish('tarefas', { ...page, items: page.items.filter((row) => row.id !== tarefa.id) });
            return;
        }
        const current = page.items[index];
        const row = {
            ...current,
            version: tarefa.version,
            titulo: tarefa.titulo,
            listaId: tarefa.listaId,
            lista: tarefa.lista,
            responsavelId: tarefa.responsavelId,
            responsavel: tarefa.responsavel,
            criadorId: tarefa.criadorId,
            criador: tarefa.criador,
            prioridade: tarefa.prioridade,
            prazo: tarefa.prazo,
            status: tarefa.status,
            details: {
                ...current.details,
                ...(tarefa.details.devolvidaEm !== undefined ? { devolvidaEm: tarefa.details.devolvidaEm } : {}),
            },
        };
        this.publish('tarefas', { ...page, items: page.items.map((item) => (item.id === tarefa.id ? row : item)) });
    }
    /** Applies the record a command returned: redraws the opened task, the selection, the list row and the edit version. */
    applyTarefa(tarefa) {
        this.publish('tarefa', tarefa);
        if (this.selectedTarefa !== tarefa.id)
            this.publish('selectedTarefa', tarefa.id);
        this.upsertRow(tarefa);
        this.syncEditVersion(tarefa);
    }
    requireTarefa(statusMember, errorMember) {
        const tarefa = this.tarefa;
        if (!tarefa) {
            this.failRequired(statusMember, errorMember, [`${KEY_PREFIX}tarefa`]);
            return null;
        }
        return tarefa;
    }
    /** scene — publishes the visible scene of the page; clears the results of earlier commands. */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the creation form draft (keeps the generated key when the value carries none); clears earlier command results. */
    setCmdCriarTarefaDraft(value) {
        this.resetCommandResults();
        const chaveCriacao = value.chaveCriacao ?? this.cmdCriarTarefaDraft.chaveCriacao ?? crypto.randomUUID();
        this.publish('cmdCriarTarefaDraft', { ...value, chaveCriacao });
    }
    /** draft — clears the creation form draft and generates a new creation key (use when the person discards or reopens the form). */
    clearCmdCriarTarefaDraft() {
        this.resetCommandResults();
        this.publish('cmdCriarTarefaDraft', emptyCriarTarefaDraft());
    }
    /** draft — replaces the edit form draft of the opened task; clears earlier command results. */
    setCmdSalvarEdicaoDraft(value) {
        this.resetCommandResults();
        this.publish('cmdSalvarEdicaoDraft', value);
    }
    /** draft — replaces the checklist draft of the opened task; clears earlier command results. */
    setCmdSalvarChecklistDraft(value) {
        this.resetCommandResults();
        this.publish('cmdSalvarChecklistDraft', value);
    }
    /** draft — replaces the return-reason draft; clears earlier command results. */
    setCmdDevolverDraft(value) {
        this.resetCommandResults();
        this.publish('cmdDevolverDraft', value);
    }
    /** request qryMinhasTarefas — lists, paged, the tasks I created or am responsible for, with the quick filter; redraws tarefas (replace, or append the next page when append is true) and filtro; arguments: filtro the quick filter (omit to keep the current one, null for all my tasks; a new value loads from the first page), page the page to load (default 1), append true to add the next page to the items for a "load more" (pass tarefas.page + 1; does nothing unless tarefas.hasMore) */
    async qryMinhasTarefas(filtro = this.filtro, page = 1, append = false) {
        if (this.qryMinhasTarefasStatus === 'loading')
            return;
        if (append && (!this.tarefas || !this.tarefas.hasMore))
            return;
        if (filtro !== this.filtro)
            this.publish('filtro', filtro);
        const input = {
            ...(filtro !== null ? { filtro } : {}),
            page,
            pageSize: PAGE_SIZE,
        };
        const output = await this.runQuery('qryMinhasTarefasStatus', 'qryMinhasTarefasError', () => execBff('tarefas.minhas_tarefas.qryMinhasTarefas', input, {
            mode: 'silent',
        }));
        if (output) {
            const current = this.tarefas;
            const next = append && current ? { ...output.tarefas, items: [...current.items, ...output.tarefas.items] } : output.tarefas;
            this.publish('tarefas', next);
            this.publish('qryMinhasTarefasStatus', 'success');
        }
        this.refreshPageStatus();
    }
    /** request qryTarefa — opens (selects) a task with its data, checklist and cycle milestones; redraws selectedTarefa and tarefa (replace) and fills the edit and checklist drafts from it; argument: tarefaId the id of the task to open, or null to clear the selection */
    async qryTarefa(tarefaId) {
        this.resetCommandResults();
        if (tarefaId === null) {
            this.publish('selectedTarefa', null);
            this.publish('tarefa', null);
            this.publish('cmdSalvarEdicaoDraft', emptySalvarEdicaoDraft());
            this.publish('cmdSalvarChecklistDraft', emptySalvarChecklistDraft());
            this.publish('cmdDevolverDraft', emptyDevolverDraft());
            this.publish('qryTarefaStatus', 'idle');
            this.publish('qryTarefaError', null);
            return;
        }
        if (this.qryTarefaStatus === 'loading')
            return;
        this.publish('selectedTarefa', tarefaId);
        const input = { tarefaId };
        const output = await this.runQuery('qryTarefaStatus', 'qryTarefaError', () => execBff('tarefas.minhas_tarefas.qryTarefa', input, {
            mode: 'silent',
        }));
        if (!output)
            return;
        this.publish('tarefa', output.tarefa);
        this.fillEditDraft(output.tarefa);
        this.fillChecklistDraft(output.tarefa);
        this.publish('cmdDevolverDraft', emptyDevolverDraft());
        this.publish('qryTarefaStatus', 'success');
    }
    /** request qryListasAtivas — brings the active lists where a task can be placed; redraws listas (replace); no arguments, also the method to reload the lists */
    async qryListasAtivas() {
        if (this.qryListasAtivasStatus === 'loading')
            return;
        const input = {};
        const output = await this.runQuery('qryListasAtivasStatus', 'qryListasAtivasError', () => execBff('tarefas.minhas_tarefas.qryListasAtivas', input, {
            mode: 'silent',
        }));
        if (output) {
            this.publish('listas', output.listas);
            this.publish('qryListasAtivasStatus', 'success');
        }
        this.refreshPageStatus();
    }
    /** request qryBuscarMembros — searches active team members by name to choose or change the assignee; redraws membros (replace; an empty term clears it without calling); argument: termo the typed part of the name (debounce it in the page) */
    async qryBuscarMembros(termo) {
        if (this.qryBuscarMembrosStatus === 'loading')
            return;
        const trimmed = termo.trim();
        if (trimmed === '') {
            this.publish('membros', []);
            this.publish('qryBuscarMembrosStatus', 'idle');
            this.publish('qryBuscarMembrosError', null);
            return;
        }
        const input = { termo: trimmed };
        const output = await this.runQuery('qryBuscarMembrosStatus', 'qryBuscarMembrosError', () => execBff('tarefas.minhas_tarefas.qryBuscarMembros', input, {
            mode: 'silent',
        }));
        if (!output)
            return;
        this.publish('membros', output.membros);
        this.publish('qryBuscarMembrosStatus', 'success');
    }
    /** request cmdCriarTarefa — creates a task with its initial checklist from cmdCriarTarefaDraft (the same creation key is sent on every retry); redraws tarefa and selectedTarefa with the created task, fills the edit and checklist drafts from it, and resets the creation draft with a new key; no arguments */
    async cmdCriarTarefa() {
        const draft = this.cmdCriarTarefaDraft;
        const chaveCriacao = nonEmpty(draft.chaveCriacao);
        const listaId = nonEmpty(draft.listaId);
        const titulo = nonEmpty(draft.titulo);
        const prioridade = draft.prioridade;
        const prazo = nonEmpty(draft.prazo);
        const responsavelId = nonEmpty(draft.responsavelId);
        const built = this.buildItens(draft.checklist, 'cmdCriarTarefaDraft');
        if (chaveCriacao === null ||
            listaId === null ||
            titulo === null ||
            prioridade === null ||
            prazo === null ||
            responsavelId === null ||
            built.invalidKeys.length > 0) {
            const keys = this.missingKeys('cmdCriarTarefaDraft', {
                chaveCriacao,
                listaId,
                titulo,
                prioridade,
                prazo,
                responsavelId,
            });
            this.failRequired('cmdCriarTarefaStatus', 'cmdCriarTarefaError', [...keys, ...built.invalidKeys]);
            return;
        }
        const descricao = nonEmpty(draft.details.descricao);
        const input = {
            chaveCriacao,
            listaId,
            titulo,
            details: descricao !== null ? { descricao } : {},
            prioridade,
            prazo,
            responsavelId,
            ...(built.itens.length > 0 ? { checklist: built.itens } : {}),
        };
        const data = await this.runCommand('cmdCriarTarefaStatus', 'cmdCriarTarefaError', (signal) => execBff('tarefas.minhas_tarefas.cmdCriarTarefa', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.fillEditDraft(data.tarefa);
        this.fillChecklistDraft(data.tarefa);
        this.publish('cmdCriarTarefaDraft', emptyCriarTarefaDraft());
        this.publish('cmdCriarTarefaStatus', 'success');
    }
    /** request cmdSalvarEdicao — saves the edited fields of the task (including the assignee change) from cmdSalvarEdicaoDraft, never changing its status; redraws tarefa and the list row, and fills the edit draft again from the saved record; no arguments */
    async cmdSalvarEdicao() {
        const draft = this.cmdSalvarEdicaoDraft;
        const id = nonEmpty(draft.id);
        const version = draft.version;
        const listaId = nonEmpty(draft.listaId);
        const titulo = nonEmpty(draft.titulo);
        const prioridade = draft.prioridade;
        const prazo = nonEmpty(draft.prazo);
        const responsavelId = nonEmpty(draft.responsavelId);
        if (id === null ||
            version === null ||
            listaId === null ||
            titulo === null ||
            prioridade === null ||
            prazo === null ||
            responsavelId === null) {
            const keys = this.missingKeys('cmdSalvarEdicaoDraft', {
                id,
                version,
                listaId,
                titulo,
                prioridade,
                prazo,
                responsavelId,
            });
            this.failRequired('cmdSalvarEdicaoStatus', 'cmdSalvarEdicaoError', keys);
            return;
        }
        const descricao = nonEmpty(draft.details.descricao);
        const input = {
            id,
            version,
            listaId,
            titulo,
            details: descricao !== null ? { descricao } : {},
            prioridade,
            prazo,
            responsavelId,
        };
        const data = await this.runCommand('cmdSalvarEdicaoStatus', 'cmdSalvarEdicaoError', (signal) => execBff('tarefas.minhas_tarefas.cmdSalvarEdicao', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.fillEditDraft(data.tarefa);
        this.publish('cmdSalvarEdicaoStatus', 'success');
    }
    /** request cmdSalvarChecklist — saves the checklist of the opened task (edit description and order, mark or unmark items, add new ones) from cmdSalvarChecklistDraft, never changing the task status; redraws tarefa and the list row, and fills the checklist draft again from the saved record; no arguments */
    async cmdSalvarChecklist() {
        const draft = this.cmdSalvarChecklistDraft;
        const tarefaId = nonEmpty(draft.tarefaId);
        const built = this.buildItens(draft.itens, 'cmdSalvarChecklistDraft');
        if (tarefaId === null || built.invalidKeys.length > 0) {
            const keys = this.missingKeys('cmdSalvarChecklistDraft', { tarefaId });
            this.failRequired('cmdSalvarChecklistStatus', 'cmdSalvarChecklistError', [...keys, ...built.invalidKeys]);
            return;
        }
        const input = { tarefaId, itens: built.itens };
        const data = await this.runCommand('cmdSalvarChecklistStatus', 'cmdSalvarChecklistError', (signal) => execBff('tarefas.minhas_tarefas.cmdSalvarChecklist', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.fillChecklistDraft(data.tarefa);
        this.publish('cmdSalvarChecklistStatus', 'success');
    }
    /** request cmdIniciar — the assignee starts the opened task (to do → in progress); redraws tarefa and the list row with the returned record; no arguments (id and version come from tarefa) */
    async cmdIniciar() {
        const tarefa = this.requireTarefa('cmdIniciarStatus', 'cmdIniciarError');
        if (!tarefa)
            return;
        const input = { id: tarefa.id, version: tarefa.version };
        const data = await this.runCommand('cmdIniciarStatus', 'cmdIniciarError', (signal) => execBff('tarefas.minhas_tarefas.cmdIniciar', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.publish('cmdIniciarStatus', 'success');
    }
    /** request cmdEnviarRevisao — the assignee sends or resends the opened task to the creator's review; redraws tarefa and the list row with the returned record; no arguments (id and version come from tarefa) */
    async cmdEnviarRevisao() {
        const tarefa = this.requireTarefa('cmdEnviarRevisaoStatus', 'cmdEnviarRevisaoError');
        if (!tarefa)
            return;
        const input = { id: tarefa.id, version: tarefa.version };
        const data = await this.runCommand('cmdEnviarRevisaoStatus', 'cmdEnviarRevisaoError', (signal) => execBff('tarefas.minhas_tarefas.cmdEnviarRevisao', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.publish('cmdEnviarRevisaoStatus', 'success');
    }
    /** request cmdAceitar — the creator accepts the delivery and concludes the opened task; redraws tarefa and the list row (removed from the list when the filter no longer matches); no arguments (id and version come from tarefa) */
    async cmdAceitar() {
        const tarefa = this.requireTarefa('cmdAceitarStatus', 'cmdAceitarError');
        if (!tarefa)
            return;
        const input = { id: tarefa.id, version: tarefa.version };
        const data = await this.runCommand('cmdAceitarStatus', 'cmdAceitarError', (signal) => execBff('tarefas.minhas_tarefas.cmdAceitar', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.publish('cmdAceitarStatus', 'success');
    }
    /** request cmdDevolver — the creator returns the task in review for adjustment with the reason typed in cmdDevolverDraft; redraws tarefa and the list row (removed when the filter no longer matches) and clears the reason draft; no arguments (id and version come from tarefa) */
    async cmdDevolver() {
        const tarefa = this.requireTarefa('cmdDevolverStatus', 'cmdDevolverError');
        if (!tarefa)
            return;
        const motivoDevolucao = nonEmpty(this.cmdDevolverDraft.details.motivoDevolucao);
        if (motivoDevolucao === null) {
            this.failRequired('cmdDevolverStatus', 'cmdDevolverError', [
                `${KEY_PREFIX}cmdDevolverDraft.details.motivoDevolucao`,
            ]);
            return;
        }
        const input = {
            id: tarefa.id,
            version: tarefa.version,
            details: { motivoDevolucao },
        };
        const data = await this.runCommand('cmdDevolverStatus', 'cmdDevolverError', (signal) => execBff('tarefas.minhas_tarefas.cmdDevolver', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.publish('cmdDevolverDraft', emptyDevolverDraft());
        this.publish('cmdDevolverStatus', 'success');
    }
    /** request cmdCancelar — the creator cancels the opened task; redraws tarefa and the list row (removed when the filter no longer matches); no arguments (id and version come from tarefa) */
    async cmdCancelar() {
        const tarefa = this.requireTarefa('cmdCancelarStatus', 'cmdCancelarError');
        if (!tarefa)
            return;
        const input = { id: tarefa.id, version: tarefa.version };
        const data = await this.runCommand('cmdCancelarStatus', 'cmdCancelarError', (signal) => execBff('tarefas.minhas_tarefas.cmdCancelar', input, this.blockingOptions(signal)));
        if (!data)
            return;
        this.applyTarefa(data.tarefa);
        this.publish('cmdCancelarStatus', 'success');
    }
}
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "tarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "membros", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "selectedTarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "filtro", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryMinhasTarefasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryMinhasTarefasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryListasAtivasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryListasAtivasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryBuscarMembrosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "qryBuscarMembrosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCriarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarEdicaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdSalvarChecklistError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdIniciarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdIniciarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdEnviarRevisaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdEnviarRevisaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdAceitarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdAceitarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdDevolverError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCancelarStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "cmdCancelarError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMinhas_tarefasShared.prototype, "scenary", void 0);

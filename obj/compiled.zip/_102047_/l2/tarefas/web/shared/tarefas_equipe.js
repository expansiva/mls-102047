var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/tarefas_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
function emptyReatribuirTarefaDraft() {
    return { responsavelId: null };
}
const PAGE_SIZE = 20;
const STATUS_VALUES = ['aFazer', 'emAndamento', 'emRevisao', 'concluida', 'cancelada'];
const PRIORIDADE_VALUES = ['low', 'medium', 'high'];
function isStatus(value) {
    return STATUS_VALUES.some(item => item === value);
}
function isPrioridade(value) {
    return PRIORIDADE_VALUES.some(item => item === value);
}
function blank(value) {
    if (value === null || value === '')
        return null;
    return value;
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.tarefas_equipe.tarefas': 'tarefas',
    'ui.tarefas.tarefas_equipe.listas': 'listas',
    'ui.tarefas.tarefas_equipe.membros': 'membros',
    'ui.tarefas.tarefas_equipe.tarefa': 'tarefa',
    'ui.tarefas.tarefas_equipe.selectedTarefa': 'selectedTarefa',
    'ui.tarefas.tarefas_equipe.filtroListaId': 'filtroListaId',
    'ui.tarefas.tarefas_equipe.filtroResponsavelId': 'filtroResponsavelId',
    'ui.tarefas.tarefas_equipe.filtroPrioridade': 'filtroPrioridade',
    'ui.tarefas.tarefas_equipe.filtroPrazo': 'filtroPrazo',
    'ui.tarefas.tarefas_equipe.filtroStatus': 'filtroStatus',
    'ui.tarefas.tarefas_equipe.filtroTitulo': 'filtroTitulo',
    'ui.tarefas.tarefas_equipe.filtroPagina': 'filtroPagina',
    'ui.tarefas.tarefas_equipe.filtroNomeMembro': 'filtroNomeMembro',
    'ui.tarefas.tarefas_equipe.filtroSomenteAtivos': 'filtroSomenteAtivos',
    'ui.tarefas.tarefas_equipe.cmdReatribuirTarefaDraft': 'cmdReatribuirTarefaDraft',
    'ui.tarefas.tarefas_equipe.pageStatus': 'pageStatus',
    'ui.tarefas.tarefas_equipe.qryTarefasEquipeStatus': 'qryTarefasEquipeStatus',
    'ui.tarefas.tarefas_equipe.qryTarefasEquipeError': 'qryTarefasEquipeError',
    'ui.tarefas.tarefas_equipe.qryListasFiltroStatus': 'qryListasFiltroStatus',
    'ui.tarefas.tarefas_equipe.qryListasFiltroError': 'qryListasFiltroError',
    'ui.tarefas.tarefas_equipe.qryBuscarMembrosStatus': 'qryBuscarMembrosStatus',
    'ui.tarefas.tarefas_equipe.qryBuscarMembrosError': 'qryBuscarMembrosError',
    'ui.tarefas.tarefas_equipe.qryDetalheTarefaStatus': 'qryDetalheTarefaStatus',
    'ui.tarefas.tarefas_equipe.qryDetalheTarefaError': 'qryDetalheTarefaError',
    'ui.tarefas.tarefas_equipe.cmdReatribuirTarefaStatus': 'cmdReatribuirTarefaStatus',
    'ui.tarefas.tarefas_equipe.cmdReatribuirTarefaError': 'cmdReatribuirTarefaError',
    'ui.tarefas.tarefas_equipe.cmdCancelarTarefaStatus': 'cmdCancelarTarefaStatus',
    'ui.tarefas.tarefas_equipe.cmdCancelarTarefaError': 'cmdCancelarTarefaError',
    'ui.tarefas.tarefas_equipe.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
// persisted states and the entry param each one is stored under (localStorage key tarefas.tarefas_equipe.<param>)
const PERSIST_PARAM = {
    filtroListaId: 'listaId',
    filtroResponsavelId: 'responsavelId',
    filtroPrioridade: 'prioridade',
    filtroPrazo: 'prazo',
    filtroStatus: 'status',
    filtroTitulo: 'titulo',
    filtroPagina: 'page',
    filtroNomeMembro: 'name',
    filtroSomenteAtivos: 'somenteAtivos',
    selectedTarefa: 'tarefaId',
};
export class TarefasTarefas_equipeShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state tarefas — page of the team task board rows (items, page, pageSize, hasMore); source qryTarefasEquipe.tarefas; organism quadroTarefasEquipe */
        this.tarefas = null;
        /** state listas — lists (id and name) offered by the list filter; source qryListasFiltro.listas; organism quadroTarefasEquipe */
        this.listas = [];
        /** state membros — team members found by name, used as responsible option (reassignment) or responsible filter; source qryBuscarMembros.membros; organisms acoesGestorTarefa, quadroTarefasEquipe */
        this.membros = [];
        /** state tarefa — the selected task in full (list, responsible, creator, parent task, checklist, history milestones, version); source qryDetalheTarefa.tarefa; organisms acoesGestorTarefa, detalheTarefa, historicoTarefa */
        this.tarefa = null;
        /** state selectedTarefa — id of the task chosen on the board (the record itself is in tarefa); source entry.params.tarefaId; organisms detalheTarefa, quadroTarefasEquipe; persisted */
        this.selectedTarefa = null;
        /** state filtroListaId — id of the list the board is filtered/selected by, null for all lists; source entry.params.listaId; organism quadroTarefasEquipe; persisted */
        this.filtroListaId = null;
        /** state filtroResponsavelId — id of the responsible member the board is filtered by, null for all; source entry.params.responsavelId; organism quadroTarefasEquipe; persisted */
        this.filtroResponsavelId = null;
        /** state filtroPrioridade — priority the board is filtered by, null for all; source entry.params.prioridade; organism quadroTarefasEquipe; persisted */
        this.filtroPrioridade = null;
        /** state filtroPrazo — due date the board is filtered by (date string), null for any; source entry.params.prazo; organism quadroTarefasEquipe; persisted */
        this.filtroPrazo = null;
        /** state filtroStatus — situations the board is filtered by, empty for all; source entry.params.status; organism quadroTarefasEquipe; persisted */
        this.filtroStatus = [];
        /** state filtroTitulo — title fragment searched on the board, null for none; source entry.params.titulo; organism quadroTarefasEquipe; persisted */
        this.filtroTitulo = null;
        /** state filtroPagina — page of the board the person went to with a pager (a load more never writes it); source entry.params.page; organism quadroTarefasEquipe; persisted */
        this.filtroPagina = null;
        /** state filtroNomeMembro — name fragment typed to search members; source entry.params.name; organism quadroTarefasEquipe; persisted */
        this.filtroNomeMembro = null;
        /** state filtroSomenteAtivos — true to search only active members (new responsible choice); source entry.params.somenteAtivos; organism quadroTarefasEquipe; persisted */
        this.filtroSomenteAtivos = null;
        /** state cmdReatribuirTarefaDraft — draft of the reassignment form (the member chosen as new responsible); source cmdReatribuirTarefa.input; organism acoesGestorTarefa */
        this.cmdReatribuirTarefaDraft = emptyReatribuirTarefaDraft();
        /** state pageStatus — overall status of the page load: idle, loading, empty, success or error */
        this.pageStatus = 'idle';
        /** state qryTarefasEquipeStatus — status of the board load */
        this.qryTarefasEquipeStatus = 'idle';
        /** state qryTarefasEquipeError — error of the board load, null when none */
        this.qryTarefasEquipeError = null;
        /** state qryListasFiltroStatus — status of the list filter options load */
        this.qryListasFiltroStatus = 'idle';
        /** state qryListasFiltroError — error of the list filter options load (also client.selectionInvalid of a list selection), null when none */
        this.qryListasFiltroError = null;
        /** state qryBuscarMembrosStatus — status of the member search */
        this.qryBuscarMembrosStatus = 'idle';
        /** state qryBuscarMembrosError — error of the member search, null when none */
        this.qryBuscarMembrosError = null;
        /** state qryDetalheTarefaStatus — status of the selected task detail load */
        this.qryDetalheTarefaStatus = 'idle';
        /** state qryDetalheTarefaError — error of the selected task detail load, null when none */
        this.qryDetalheTarefaError = null;
        /** state cmdReatribuirTarefaStatus — status of the reassignment command; success stays until the person changes something */
        this.cmdReatribuirTarefaStatus = 'idle';
        /** state cmdReatribuirTarefaError — error of the reassignment command, null when none */
        this.cmdReatribuirTarefaError = null;
        /** state cmdCancelarTarefaStatus — status of the cancel command; success stays until the person changes something */
        this.cmdCancelarTarefaStatus = 'idle';
        /** state cmdCancelarTarefaError — error of the cancel command, null when none */
        this.cmdCancelarTarefaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.tarefas_equipe.${member}`, value);
        const param = PERSIST_PARAM[member];
        if (param !== undefined) {
            try {
                const storageKey = `tarefas.tarefas_equipe.${param}`;
                const raw = this.serializeParam(value);
                if (raw === null) {
                    window.localStorage.removeItem(storageKey);
                }
                else {
                    window.localStorage.setItem(storageKey, raw);
                }
            }
            catch {
                // storage unavailable: the value stays in memory only
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    serializeParam(value) {
        if (value === null || value === undefined)
            return null;
        if (Array.isArray(value))
            return value.length > 0 ? value.join(',') : null;
        if (typeof value === 'string')
            return value === '' ? null : value;
        if (typeof value === 'number' || typeof value === 'boolean')
            return String(value);
        return null;
    }
    readParam(name) {
        const fromUrl = new URLSearchParams(window.location.search).get(name);
        if (fromUrl !== null && fromUrl !== '')
            return fromUrl;
        try {
            const stored = window.localStorage.getItem(`tarefas.tarefas_equipe.${name}`);
            if (stored !== null && stored !== '')
                return stored;
        }
        catch {
            // storage unavailable
        }
        return null;
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        if (this.selectedTarefa === null)
            this.publish('tarefa', null);
        void this.qryTarefasEquipe(this.filtroPagina ?? 1, false);
        void this.qryListasFiltro();
        if (this.selectedTarefa !== null)
            void this.qryDetalheTarefa();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const dataKeys = [
            'ui.tarefas.tarefas_equipe.tarefas',
            'ui.tarefas.tarefas_equipe.listas',
            'ui.tarefas.tarefas_equipe.membros',
            'ui.tarefas.tarefas_equipe.tarefa',
        ];
        for (const key of dataKeys) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('qryTarefasEquipeStatus', 'idle');
        this.publish('qryTarefasEquipeError', null);
        this.publish('qryListasFiltroStatus', 'idle');
        this.publish('qryListasFiltroError', null);
        this.publish('qryBuscarMembrosStatus', 'idle');
        this.publish('qryBuscarMembrosError', null);
        this.publish('qryDetalheTarefaStatus', 'idle');
        this.publish('qryDetalheTarefaError', null);
        this.publish('cmdReatribuirTarefaStatus', 'idle');
        this.publish('cmdReatribuirTarefaError', null);
        this.publish('cmdCancelarTarefaStatus', 'idle');
        this.publish('cmdCancelarTarefaError', null);
        this.publish('cmdReatribuirTarefaDraft', emptyReatribuirTarefaDraft());
    }
    resetCommandResults() {
        this.publish('cmdReatribuirTarefaStatus', 'idle');
        this.publish('cmdReatribuirTarefaError', null);
        this.publish('cmdCancelarTarefaStatus', 'idle');
        this.publish('cmdCancelarTarefaError', null);
    }
    applyEntryParams() {
        this.publish('filtroListaId', this.readParam('listaId'));
        this.publish('filtroResponsavelId', this.readParam('responsavelId'));
        const prioridade = this.readParam('prioridade');
        this.publish('filtroPrioridade', prioridade !== null && isPrioridade(prioridade) ? prioridade : null);
        this.publish('filtroPrazo', this.readParam('prazo'));
        const statusRaw = this.readParam('status');
        this.publish('filtroStatus', statusRaw === null ? [] : statusRaw.split(',').filter(isStatus));
        this.publish('filtroTitulo', this.readParam('titulo'));
        const pageRaw = this.readParam('page');
        const pageNumber = pageRaw === null ? Number.NaN : Number(pageRaw);
        this.publish('filtroPagina', Number.isFinite(pageNumber) && pageNumber >= 1 ? pageNumber : null);
        this.publish('filtroNomeMembro', this.readParam('name'));
        const somenteAtivosRaw = this.readParam('somenteAtivos');
        this.publish('filtroSomenteAtivos', somenteAtivosRaw === null ? null : somenteAtivosRaw === 'true');
        this.publish('selectedTarefa', this.readParam('tarefaId'));
    }
    refreshPageStatus() {
        const board = this.qryTarefasEquipeStatus;
        const options = this.qryListasFiltroStatus;
        if (board === 'loading' || options === 'loading') {
            this.publish('pageStatus', 'loading');
            return;
        }
        if (board === 'error' || options === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        if (board === 'success' && options === 'success') {
            const boardEmpty = (this.tarefas?.items.length ?? 0) === 0;
            const optionsEmpty = this.listas.length === 0;
            this.publish('pageStatus', boardEmpty && optionsEmpty ? 'empty' : 'success');
        }
    }
    /** getter lista — the list currently selected as filter (row of listas with id filtroListaId), null when none or not loaded */
    get lista() {
        const found = this.listas.find(item => item.id === this.filtroListaId);
        return found ?? null;
    }
    /** setScenario — publishes the visible scene of the page (value: scene name) */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** setCmdReatribuirTarefaDraft — draft: replaces the reassignment form draft (responsavelId = id of the member chosen from membros) */
    setCmdReatribuirTarefaDraft(value) {
        this.resetCommandResults();
        this.publish('cmdReatribuirTarefaDraft', value);
    }
    /** selecionarTarefa — select: chooses the task whose detail and actions are shown (id of a board row) or clears the selection (null); loads the detail into tarefa and empties the reassignment draft */
    selecionarTarefa(id) {
        this.resetCommandResults();
        this.publish('cmdReatribuirTarefaDraft', emptyReatribuirTarefaDraft());
        const value = blank(id);
        this.publish('selectedTarefa', value);
        if (value === null) {
            this.publish('tarefa', null);
            this.publish('qryDetalheTarefaStatus', 'idle');
            this.publish('qryDetalheTarefaError', null);
            return;
        }
        void this.qryDetalheTarefa();
    }
    /** selecionarLista — select: selects a list from listas as the board filter (id) or clears it (null); an id not found in the loaded listas publishes client.selectionInvalid in qryListasFiltroError; reloads the board from the first page */
    async selecionarLista(id) {
        const value = blank(id);
        if (value !== null && this.listas.length > 0 && !this.listas.some(item => item.id === value)) {
            this.publish('qryListasFiltroError', { code: 'client.selectionInvalid', message: '', details: { id: value } });
            return;
        }
        this.publish('filtroListaId', value);
        await this.qryTarefasEquipe(1, false);
    }
    /** filtrarPorResponsavel — filter: sets the responsible filter (member id, null for all) and reloads the board from the first page */
    async filtrarPorResponsavel(responsavelId) {
        this.publish('filtroResponsavelId', blank(responsavelId));
        await this.qryTarefasEquipe(1, false);
    }
    /** filtrarPorPrioridade — filter: sets the priority filter (null for all) and reloads the board from the first page */
    async filtrarPorPrioridade(prioridade) {
        this.publish('filtroPrioridade', prioridade);
        await this.qryTarefasEquipe(1, false);
    }
    /** filtrarPorPrazo — filter: sets the due date filter (date string, null for any) and reloads the board from the first page */
    async filtrarPorPrazo(prazo) {
        this.publish('filtroPrazo', blank(prazo));
        await this.qryTarefasEquipe(1, false);
    }
    /** filtrarPorStatus — filter: sets the situations the board shows (empty array for all) and reloads the board from the first page */
    async filtrarPorStatus(status) {
        this.publish('filtroStatus', [...status]);
        await this.qryTarefasEquipe(1, false);
    }
    /** buscarPorTitulo — filter: sets the title search fragment (null or empty for none) and reloads the board from the first page */
    async buscarPorTitulo(titulo) {
        this.publish('filtroTitulo', blank(titulo));
        await this.qryTarefasEquipe(1, false);
    }
    /** limparFiltros — filter: clears every board filter (list, responsible, priority, due date, situations, title) and reloads the board from the first page */
    async limparFiltros() {
        this.publish('filtroListaId', null);
        this.publish('filtroResponsavelId', null);
        this.publish('filtroPrioridade', null);
        this.publish('filtroPrazo', null);
        this.publish('filtroStatus', []);
        this.publish('filtroTitulo', null);
        await this.qryTarefasEquipe(1, false);
    }
    /** request qryTarefasEquipe — loads the team board already filtered and paged (opening, filter, search, page change); redraws tarefas (replace, or append items when append is true) and, when not appending, filtroPagina; arguments: page = page to load (default 1; for a load more pass tarefas.page + 1), append = add the page to the current items instead of replacing them (only when tarefas.hasMore) */
    async qryTarefasEquipe(page = 1, append = false) {
        if (this.qryTarefasEquipeStatus === 'loading')
            return;
        const current = this.tarefas;
        if (append && (current === null || !current.hasMore))
            return;
        this.publish('qryTarefasEquipeStatus', 'loading');
        this.publish('qryTarefasEquipeError', null);
        if (!append)
            this.refreshPageStatus();
        const input = {
            ...(this.filtroListaId !== null && this.filtroListaId !== '' ? { listaId: this.filtroListaId } : {}),
            ...(this.filtroResponsavelId !== null && this.filtroResponsavelId !== '' ? { responsavelId: this.filtroResponsavelId } : {}),
            ...(this.filtroPrioridade !== null ? { prioridade: this.filtroPrioridade } : {}),
            ...(this.filtroPrazo !== null && this.filtroPrazo !== '' ? { prazo: this.filtroPrazo } : {}),
            ...(this.filtroStatus.length > 0 ? { status: this.filtroStatus } : {}),
            ...(this.filtroTitulo !== null && this.filtroTitulo !== '' ? { titulo: this.filtroTitulo } : {}),
            page,
            pageSize: PAGE_SIZE,
        };
        try {
            const response = await execBff('tarefas.tarefas_equipe.qryTarefasEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryTarefasEquipeError', response.error);
                this.publish('qryTarefasEquipeStatus', 'error');
                this.refreshPageStatus();
                return;
            }
            const incoming = response.data.tarefas;
            const base = this.tarefas;
            if (append && base !== null) {
                this.publish('tarefas', { ...incoming, items: [...base.items, ...incoming.items] });
            }
            else {
                this.publish('tarefas', incoming);
                this.publish('filtroPagina', page);
            }
            this.publish('qryTarefasEquipeStatus', 'success');
            this.refreshPageStatus();
        }
        catch (error) {
            this.publish('qryTarefasEquipeError', this.unexpectedError(error));
            this.publish('qryTarefasEquipeStatus', 'error');
            this.refreshPageStatus();
        }
    }
    /** request qryListasFiltro — loads the lists (active and inactive) offered by the list filter; redraws listas (replace); no arguments */
    async qryListasFiltro() {
        if (this.qryListasFiltroStatus === 'loading')
            return;
        this.publish('qryListasFiltroStatus', 'loading');
        this.publish('qryListasFiltroError', null);
        this.refreshPageStatus();
        try {
            const response = await execBff('tarefas.tarefas_equipe.qryListasFiltro', {}, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryListasFiltroError', response.error);
                this.publish('qryListasFiltroStatus', 'error');
                this.refreshPageStatus();
                return;
            }
            this.publish('listas', response.data.listas);
            this.publish('qryListasFiltroStatus', 'success');
            this.refreshPageStatus();
        }
        catch (error) {
            this.publish('qryListasFiltroError', this.unexpectedError(error));
            this.publish('qryListasFiltroStatus', 'error');
            this.refreshPageStatus();
        }
    }
    /** request qryBuscarMembros — searches team members by name to choose the new responsible or the responsible filter; redraws membros (replace); arguments: nome = typed name fragment (empty for none), somenteAtivos = true to return only active members (new responsible choice) */
    async qryBuscarMembros(nome, somenteAtivos = false) {
        if (this.qryBuscarMembrosStatus === 'loading')
            return;
        this.publish('qryBuscarMembrosStatus', 'loading');
        this.publish('qryBuscarMembrosError', null);
        const typed = blank(nome);
        this.publish('filtroNomeMembro', typed);
        this.publish('filtroSomenteAtivos', somenteAtivos);
        const input = {
            details: { identification: { ...(typed !== null ? { name: typed } : {}) } },
            ...(somenteAtivos ? { somenteAtivos: true } : {}),
        };
        try {
            const response = await execBff('tarefas.tarefas_equipe.qryBuscarMembros', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryBuscarMembrosError', response.error);
                this.publish('qryBuscarMembrosStatus', 'error');
                return;
            }
            this.publish('membros', response.data.membros);
            this.publish('qryBuscarMembrosStatus', 'success');
        }
        catch (error) {
            this.publish('qryBuscarMembrosError', this.unexpectedError(error));
            this.publish('qryBuscarMembrosStatus', 'error');
        }
    }
    /** request qryDetalheTarefa — loads the selected task in full (detail, actions, history); redraws tarefa (replace); no arguments, it reads selectedTarefa (use selecionarTarefa to choose a task); without a selection it fails with client.requiredMissing */
    async qryDetalheTarefa() {
        if (this.qryDetalheTarefaStatus === 'loading')
            return;
        const tarefaId = this.selectedTarefa;
        if (tarefaId === null || tarefaId === '') {
            this.publish('qryDetalheTarefaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['selectedTarefa'] } });
            this.publish('qryDetalheTarefaStatus', 'error');
            return;
        }
        this.publish('qryDetalheTarefaStatus', 'loading');
        this.publish('qryDetalheTarefaError', null);
        try {
            const response = await execBff('tarefas.tarefas_equipe.qryDetalheTarefa', { tarefaId }, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryDetalheTarefaError', response.error);
                this.publish('qryDetalheTarefaStatus', 'error');
                return;
            }
            this.publish('tarefa', response.data.tarefa);
            this.publish('qryDetalheTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('qryDetalheTarefaError', this.unexpectedError(error));
            this.publish('qryDetalheTarefaStatus', 'error');
        }
    }
    /** applies a board row returned by a command: updates the row by id, or removes it when it no longer matches the situation or responsible filters; rows not loaded are left alone */
    applyItemQuadro(item) {
        const list = this.tarefas;
        if (list === null)
            return;
        if (!list.items.some(row => row.id === item.id))
            return;
        const statusMatches = this.filtroStatus.length === 0 || this.filtroStatus.some(status => status === item.status);
        const responsavelMatches = this.filtroResponsavelId === null || this.filtroResponsavelId === item.responsavelId;
        const items = statusMatches && responsavelMatches
            ? list.items.map(row => (row.id === item.id ? item : row))
            : list.items.filter(row => row.id !== item.id);
        this.publish('tarefas', { ...list, items });
    }
    /** request cmdReatribuirTarefa — replaces the responsible of the selected task by the member in the draft and notifies them; redraws tarefa (replace with the returned task, new version) and tarefas (the returned row is updated by id, or removed when it leaves the active filters), then empties cmdReatribuirTarefaDraft; no arguments: it reads tarefa (id, version) and cmdReatribuirTarefaDraft.responsavelId (fill it with setCmdReatribuirTarefaDraft); missing values fail with client.requiredMissing */
    async cmdReatribuirTarefa() {
        if (this.cmdReatribuirTarefaStatus === 'loading')
            return;
        const tarefa = this.tarefa;
        const responsavelId = blank(this.cmdReatribuirTarefaDraft.responsavelId);
        if (tarefa === null || responsavelId === null) {
            const stateKeys = [];
            if (tarefa === null)
                stateKeys.push('tarefa');
            if (responsavelId === null)
                stateKeys.push('cmdReatribuirTarefaDraft');
            this.publish('cmdReatribuirTarefaError', { code: 'client.requiredMissing', message: '', details: { stateKeys } });
            this.publish('cmdReatribuirTarefaStatus', 'error');
            return;
        }
        this.publish('cmdReatribuirTarefaStatus', 'loading');
        this.publish('cmdReatribuirTarefaError', null);
        const input = { id: tarefa.id, version: tarefa.version, responsavelId };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.tarefas_equipe.cmdReatribuirTarefa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdReatribuirTarefaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdReatribuirTarefaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdReatribuirTarefaError', response.error);
                this.publish('cmdReatribuirTarefaStatus', 'error');
                return;
            }
            const output = response.data;
            this.publish('tarefa', output.tarefa);
            this.applyItemQuadro(output.itemQuadro);
            this.publish('cmdReatribuirTarefaDraft', emptyReatribuirTarefaDraft());
            this.publish('cmdReatribuirTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('cmdReatribuirTarefaError', this.unexpectedError(error));
            this.publish('cmdReatribuirTarefaStatus', 'error');
        }
    }
    /** request cmdCancelarTarefa — cancels the selected task (the page asks the person to confirm before calling); redraws tarefa (replace with the returned task, with canceladaEm) and tarefas (the returned row is updated by id, or removed when its new situation is not among the filtered ones); no arguments: it reads tarefa (id, version); without a selected task it fails with client.requiredMissing */
    async cmdCancelarTarefa() {
        if (this.cmdCancelarTarefaStatus === 'loading')
            return;
        const tarefa = this.tarefa;
        if (tarefa === null) {
            this.publish('cmdCancelarTarefaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['tarefa'] } });
            this.publish('cmdCancelarTarefaStatus', 'error');
            return;
        }
        this.publish('cmdCancelarTarefaStatus', 'loading');
        this.publish('cmdCancelarTarefaError', null);
        const input = { id: tarefa.id, version: tarefa.version };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.tarefas_equipe.cmdCancelarTarefa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdCancelarTarefaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdCancelarTarefaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdCancelarTarefaError', response.error);
                this.publish('cmdCancelarTarefaStatus', 'error');
                return;
            }
            const output = response.data;
            this.publish('tarefa', output.tarefa);
            this.applyItemQuadro(output.itemQuadro);
            this.publish('cmdCancelarTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('cmdCancelarTarefaError', this.unexpectedError(error));
            this.publish('cmdCancelarTarefaStatus', 'error');
        }
    }
    /** reatribuirTarefa — page intent of the actions organism: reassigns the selected task to the member in cmdReatribuirTarefaDraft; same as cmdReatribuirTarefa */
    async reatribuirTarefa() {
        await this.cmdReatribuirTarefa();
    }
    /** cancelarTarefa — page intent of the actions organism: cancels the selected task (ask for confirmation first); same as cmdCancelarTarefa */
    async cancelarTarefa() {
        await this.cmdCancelarTarefa();
    }
}
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "membros", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "tarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "selectedTarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroListaId", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroResponsavelId", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroPrioridade", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroPrazo", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroTitulo", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroPagina", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroNomeMembro", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "filtroSomenteAtivos", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cmdReatribuirTarefaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryTarefasEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryTarefasEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryListasFiltroStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryListasFiltroError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryBuscarMembrosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryBuscarMembrosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryDetalheTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "qryDetalheTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cmdReatribuirTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cmdReatribuirTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cmdCancelarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cmdCancelarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "scenary", void 0);

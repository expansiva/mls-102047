var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/tarefas_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
export function emptyReatribuirTarefaDraft() {
    return { responsavelId: null };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.tarefas_equipe.tarefas': 'tarefas',
    'ui.tarefas.tarefas_equipe.listas': 'listas',
    'ui.tarefas.tarefas_equipe.membros': 'membros',
    'ui.tarefas.tarefas_equipe.tarefa': 'tarefa',
    'ui.tarefas.tarefas_equipe.selectedTarefa': 'selectedTarefa',
    'ui.tarefas.tarefas_equipe.listaId': 'listaId',
    'ui.tarefas.tarefas_equipe.responsavelId': 'responsavelId',
    'ui.tarefas.tarefas_equipe.prioridade': 'prioridade',
    'ui.tarefas.tarefas_equipe.status': 'status',
    'ui.tarefas.tarefas_equipe.prazoDe': 'prazoDe',
    'ui.tarefas.tarefas_equipe.prazoAte': 'prazoAte',
    'ui.tarefas.tarefas_equipe.venceHoje': 'venceHoje',
    'ui.tarefas.tarefas_equipe.atrasada': 'atrasada',
    'ui.tarefas.tarefas_equipe.reatribuirTarefaDraft': 'reatribuirTarefaDraft',
    'ui.tarefas.tarefas_equipe.pageStatus': 'pageStatus',
    'ui.tarefas.tarefas_equipe.carregarOpcoesEquipeStatus': 'carregarOpcoesEquipeStatus',
    'ui.tarefas.tarefas_equipe.carregarOpcoesEquipeError': 'carregarOpcoesEquipeError',
    'ui.tarefas.tarefas_equipe.listarTarefasEquipeStatus': 'listarTarefasEquipeStatus',
    'ui.tarefas.tarefas_equipe.listarTarefasEquipeError': 'listarTarefasEquipeError',
    'ui.tarefas.tarefas_equipe.obterTarefaStatus': 'obterTarefaStatus',
    'ui.tarefas.tarefas_equipe.obterTarefaError': 'obterTarefaError',
    'ui.tarefas.tarefas_equipe.reatribuirTarefaStatus': 'reatribuirTarefaStatus',
    'ui.tarefas.tarefas_equipe.reatribuirTarefaError': 'reatribuirTarefaError',
    'ui.tarefas.tarefas_equipe.cancelarTarefaStatus': 'cancelarTarefaStatus',
    'ui.tarefas.tarefas_equipe.cancelarTarefaError': 'cancelarTarefaError',
    'ui.tarefas.tarefas_equipe.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const DATA_KEYS = [
    'ui.tarefas.tarefas_equipe.tarefas',
    'ui.tarefas.tarefas_equipe.listas',
    'ui.tarefas.tarefas_equipe.membros',
    'ui.tarefas.tarefas_equipe.tarefa',
];
/** Members that are persisted entry params (filters), stored in localStorage under tarefas.tarefas_equipe.<name>. */
const PERSISTED_MEMBERS = [
    'listaId',
    'responsavelId',
    'prioridade',
    'status',
    'prazoDe',
    'prazoAte',
    'venceHoje',
    'atrasada',
];
const PAGE_SIZE = 20;
function parsePrioridade(raw) {
    if (raw === 'low' || raw === 'medium' || raw === 'high')
        return raw;
    return null;
}
function parseSituacao(raw) {
    if (raw === 'aFazer' || raw === 'emAndamento' || raw === 'emRevisao' || raw === 'concluida' || raw === 'cancelada')
        return raw;
    return null;
}
function parseBoolean(raw) {
    if (raw === null)
        return null;
    return raw === 'true';
}
function emptyToNull(value) {
    if (value === null || value === '')
        return null;
    return value;
}
export class TarefasTarefas_equipeShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state tarefas — the page of team tasks (title, list, responsible, priority, due date, status and indicators); source listarTarefasEquipe.tarefas; organism tarefasEquipe */
        this.tarefas = null;
        /** state listas — the lists (projects or areas) identified by name, used by the list filter; source carregarOpcoesEquipe.listas; organism tarefasEquipe */
        this.listas = [];
        /** state membros — the team members with name and registry status (only Active ones can be chosen as responsible); source carregarOpcoesEquipe.membros; organisms acoesGestor, tarefasEquipe */
        this.membros = [];
        /** state tarefa — the selected task in full (creator, responsible, history milestones, checklist, version); source obterTarefa.tarefa; organisms acoesGestor, detalheTarefa, historicoTarefa */
        this.tarefa = null;
        /** state selectedTarefa — the id of the task selected in tarefasEquipe; source entry.params.tarefaId; organisms detalheTarefa, tarefasEquipe; lives in the URL */
        this.selectedTarefa = null;
        /** state listaId — filter of the board by list id; source entry.params.listaId; organism tarefasEquipe; persisted */
        this.listaId = null;
        /** state responsavelId — filter of the board by responsible member id; source entry.params.responsavelId; organism tarefasEquipe; persisted */
        this.responsavelId = null;
        /** state prioridade — filter of the board by priority (low, medium, high); source entry.params.prioridade; organism tarefasEquipe; persisted */
        this.prioridade = null;
        /** state status — filter of the board by task status; source entry.params.status; organism tarefasEquipe; persisted */
        this.status = null;
        /** state prazoDe — filter of the board: start of the due date range; source entry.params.prazoDe; organism tarefasEquipe; persisted */
        this.prazoDe = null;
        /** state prazoAte — filter of the board: end of the due date range; source entry.params.prazoAte; organism tarefasEquipe; persisted */
        this.prazoAte = null;
        /** state venceHoje — filter of the board: when true only open tasks due today; source entry.params.venceHoje; organism tarefasEquipe; persisted */
        this.venceHoje = null;
        /** state atrasada — filter of the board: when true only open overdue tasks; source entry.params.atrasada; organism tarefasEquipe; persisted */
        this.atrasada = null;
        /** state reatribuirTarefaDraft — draft of the reassign command: the member chosen as new responsible; source reatribuirTarefa.input; organism acoesGestor */
        this.reatribuirTarefaDraft = emptyReatribuirTarefaDraft();
        /** state pageStatus — overall status of the page (loading while the initial queries run, empty when every loaded list is empty); source onLoad requests */
        this.pageStatus = 'idle';
        /** state carregarOpcoesEquipeStatus — status of the request carregarOpcoesEquipe */
        this.carregarOpcoesEquipeStatus = 'idle';
        /** state carregarOpcoesEquipeError — error of the request carregarOpcoesEquipe, null when none */
        this.carregarOpcoesEquipeError = null;
        /** state listarTarefasEquipeStatus — status of the request listarTarefasEquipe */
        this.listarTarefasEquipeStatus = 'idle';
        /** state listarTarefasEquipeError — error of the request listarTarefasEquipe, null when none */
        this.listarTarefasEquipeError = null;
        /** state obterTarefaStatus — status of the request obterTarefa (opening the selected task) */
        this.obterTarefaStatus = 'idle';
        /** state obterTarefaError — error of the request obterTarefa, null when none */
        this.obterTarefaError = null;
        /** state reatribuirTarefaStatus — status of the command reatribuirTarefa */
        this.reatribuirTarefaStatus = 'idle';
        /** state reatribuirTarefaError — error of the command reatribuirTarefa, null when none */
        this.reatribuirTarefaError = null;
        /** state cancelarTarefaStatus — status of the command cancelarTarefa */
        this.cancelarTarefaStatus = 'idle';
        /** state cancelarTarefaError — error of the command cancelarTarefa, null when none */
        this.cancelarTarefaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.reloadPending = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.tarefas_equipe.${member}`, value);
        if (PERSISTED_MEMBERS.includes(member)) {
            try {
                const storageKey = `tarefas.tarefas_equipe.${member}`;
                if (value === null) {
                    localStorage.removeItem(storageKey);
                }
                else {
                    localStorage.setItem(storageKey, String(value));
                }
            }
            catch {
                // storage unavailable: the value stays only in memory
            }
        }
        if (member === 'selectedTarefa') {
            try {
                const url = new URL(window.location.href);
                if (value === null) {
                    url.searchParams.delete('tarefaId');
                }
                else {
                    url.searchParams.set('tarefaId', String(value));
                }
                history.replaceState(history.state, '', url.toString());
            }
            catch {
                // URL not writable: the selection stays only in memory
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.startLoad();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_KEYS.includes(key)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        for (const key of DATA_KEYS) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.reloadPending = false;
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('carregarOpcoesEquipeStatus', 'idle');
        this.publish('carregarOpcoesEquipeError', null);
        this.publish('listarTarefasEquipeStatus', 'idle');
        this.publish('listarTarefasEquipeError', null);
        this.publish('obterTarefaStatus', 'idle');
        this.publish('obterTarefaError', null);
        this.publish('reatribuirTarefaStatus', 'idle');
        this.publish('reatribuirTarefaError', null);
        this.publish('cancelarTarefaStatus', 'idle');
        this.publish('cancelarTarefaError', null);
        this.publish('reatribuirTarefaDraft', emptyReatribuirTarefaDraft());
    }
    resetCommandResults() {
        this.publish('reatribuirTarefaStatus', 'idle');
        this.publish('reatribuirTarefaError', null);
        this.publish('cancelarTarefaStatus', 'idle');
        this.publish('cancelarTarefaError', null);
    }
    readParam(name, useStorage) {
        const raw = new URLSearchParams(window.location.search).get(name);
        if (raw !== null && raw !== '')
            return raw;
        if (!useStorage)
            return null;
        try {
            const stored = localStorage.getItem(`tarefas.tarefas_equipe.${name}`);
            if (stored !== null && stored !== '')
                return stored;
        }
        catch {
            // storage unavailable
        }
        return null;
    }
    applyEntryParams() {
        this.publish('listaId', this.readParam('listaId', true));
        this.publish('responsavelId', this.readParam('responsavelId', true));
        this.publish('prioridade', parsePrioridade(this.readParam('prioridade', true)));
        this.publish('status', parseSituacao(this.readParam('status', true)));
        this.publish('prazoDe', this.readParam('prazoDe', true));
        this.publish('prazoAte', this.readParam('prazoAte', true));
        this.publish('venceHoje', parseBoolean(this.readParam('venceHoje', true)));
        this.publish('atrasada', parseBoolean(this.readParam('atrasada', true)));
        this.publish('selectedTarefa', this.readParam('tarefaId', false));
    }
    async startLoad() {
        await Promise.all([this.carregarOpcoesEquipe(), this.listarTarefasEquipe()]);
        const selected = this.selectedTarefa;
        if (selected !== null)
            await this.obterTarefa(selected);
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    refreshPageStatus() {
        const statuses = [this.carregarOpcoesEquipeStatus, this.listarTarefasEquipeStatus];
        if (statuses.includes('loading')) {
            this.publish('pageStatus', 'loading');
            return;
        }
        if (statuses.includes('error')) {
            this.publish('pageStatus', 'error');
            return;
        }
        if (statuses.includes('idle'))
            return;
        const rows = this.tarefas ? this.tarefas.items : [];
        if (rows.length === 0 && this.listas.length === 0 && this.membros.length === 0) {
            this.publish('pageStatus', 'empty');
            return;
        }
        this.publish('pageStatus', 'success');
    }
    /** setScenario — publishes the visible scene of the page; resets the result of every command. */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the reassign command (the member chosen as new responsible); resets the result of every command. */
    setReatribuirTarefaDraft(value) {
        this.resetCommandResults();
        this.publish('reatribuirTarefaDraft', value);
    }
    /** request carregarOpcoesEquipe — loads the lists and the team members used by the board filters and by the choice of the new responsible; redraws listas and membros (replace); no arguments, also the method to reload the options */
    async carregarOpcoesEquipe() {
        if (this.carregarOpcoesEquipeStatus === 'loading')
            return;
        this.publish('carregarOpcoesEquipeStatus', 'loading');
        this.publish('carregarOpcoesEquipeError', null);
        this.publish('pageStatus', 'loading');
        try {
            const response = await execBff('tarefas.tarefas_equipe.carregarOpcoesEquipe', {}, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarOpcoesEquipeError', response.error ?? this.unexpectedError(null));
                this.publish('carregarOpcoesEquipeStatus', 'error');
                this.refreshPageStatus();
                return;
            }
            this.publish('listas', response.data.listas);
            this.publish('membros', response.data.membros);
            this.publish('carregarOpcoesEquipeStatus', 'success');
        }
        catch (error) {
            this.publish('carregarOpcoesEquipeError', this.unexpectedError(error));
            this.publish('carregarOpcoesEquipeStatus', 'error');
        }
        this.refreshPageStatus();
    }
    applyFilterChange(filters) {
        let changed = false;
        if (filters.listaId !== undefined) {
            this.publish('listaId', emptyToNull(filters.listaId));
            changed = true;
        }
        if (filters.responsavelId !== undefined) {
            this.publish('responsavelId', emptyToNull(filters.responsavelId));
            changed = true;
        }
        if (filters.prioridade !== undefined) {
            this.publish('prioridade', filters.prioridade);
            changed = true;
        }
        if (filters.status !== undefined) {
            this.publish('status', filters.status);
            changed = true;
        }
        if (filters.prazoDe !== undefined) {
            this.publish('prazoDe', emptyToNull(filters.prazoDe));
            changed = true;
        }
        if (filters.prazoAte !== undefined) {
            this.publish('prazoAte', emptyToNull(filters.prazoAte));
            changed = true;
        }
        if (filters.venceHoje !== undefined) {
            this.publish('venceHoje', filters.venceHoje);
            changed = true;
        }
        if (filters.atrasada !== undefined) {
            this.publish('atrasada', filters.atrasada);
            changed = true;
        }
        return changed;
    }
    /** request listarTarefasEquipe — loads the paged board of every team task with the current filters; redraws tarefas (replace, or append the next page when append is true); filters: values the person changed (omitted keeps, null clears; any change reloads from the first page; with no argument it reloads the current view); page: page to load (default 1); append: true for "load more", only when tarefas.hasMore */
    async listarTarefasEquipe(filters = {}, page = 1, append = false) {
        const changed = this.applyFilterChange(filters);
        const pageToLoad = changed ? 1 : page;
        const appendRows = changed ? false : append;
        if (this.listarTarefasEquipeStatus === 'loading') {
            if (changed)
                this.reloadPending = true;
            return;
        }
        const current = this.tarefas;
        if (appendRows && (current === null || !current.hasMore))
            return;
        this.publish('listarTarefasEquipeStatus', 'loading');
        this.publish('listarTarefasEquipeError', null);
        this.publish('pageStatus', 'loading');
        const input = {
            ...(this.listaId !== null && this.listaId !== '' ? { listaId: this.listaId } : {}),
            ...(this.responsavelId !== null && this.responsavelId !== '' ? { responsavelId: this.responsavelId } : {}),
            ...(this.prioridade !== null ? { prioridade: this.prioridade } : {}),
            ...(this.status !== null ? { status: this.status } : {}),
            ...(this.prazoDe !== null && this.prazoDe !== '' ? { prazoDe: this.prazoDe } : {}),
            ...(this.prazoAte !== null && this.prazoAte !== '' ? { prazoAte: this.prazoAte } : {}),
            details: {
                ...(this.venceHoje === true ? { venceHoje: true } : {}),
                ...(this.atrasada === true ? { atrasada: true } : {}),
            },
            page: pageToLoad,
            pageSize: PAGE_SIZE,
        };
        try {
            const response = await execBff('tarefas.tarefas_equipe.listarTarefasEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarTarefasEquipeError', response.error ?? this.unexpectedError(null));
                this.publish('listarTarefasEquipeStatus', 'error');
            }
            else {
                const incoming = response.data.tarefas;
                const base = this.tarefas;
                const next = appendRows && base !== null ? { ...incoming, items: [...base.items, ...incoming.items] } : incoming;
                this.publish('tarefas', next);
                this.publish('listarTarefasEquipeStatus', 'success');
            }
        }
        catch (error) {
            this.publish('listarTarefasEquipeError', this.unexpectedError(error));
            this.publish('listarTarefasEquipeStatus', 'error');
        }
        this.refreshPageStatus();
        if (this.reloadPending) {
            this.reloadPending = false;
            void this.listarTarefasEquipe();
        }
    }
    /** request obterTarefa — selects a task and opens it in full (detail, checklist and history milestones); redraws selectedTarefa (replace, kept in the URL) and tarefa (replace); tarefaId: id of the picked task, or null to clear the selection */
    async obterTarefa(tarefaId) {
        if (tarefaId === null || tarefaId === '') {
            this.resetCommandResults();
            this.publish('selectedTarefa', null);
            this.publish('tarefa', null);
            this.publish('reatribuirTarefaDraft', emptyReatribuirTarefaDraft());
            this.publish('obterTarefaError', null);
            this.publish('obterTarefaStatus', 'idle');
            return;
        }
        if (this.obterTarefaStatus === 'loading')
            return;
        this.resetCommandResults();
        if (tarefaId !== this.selectedTarefa) {
            this.publish('reatribuirTarefaDraft', emptyReatribuirTarefaDraft());
        }
        this.publish('selectedTarefa', tarefaId);
        this.publish('obterTarefaStatus', 'loading');
        this.publish('obterTarefaError', null);
        try {
            const response = await execBff('tarefas.tarefas_equipe.obterTarefa', { tarefaId }, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('tarefa', null);
                this.publish('obterTarefaError', response.error ?? this.unexpectedError(null));
                this.publish('obterTarefaStatus', 'error');
                return;
            }
            this.publish('tarefa', response.data.tarefa);
            this.publish('obterTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('tarefa', null);
            this.publish('obterTarefaError', this.unexpectedError(error));
            this.publish('obterTarefaStatus', 'error');
        }
    }
    /** Applies the returned task to its board row (upsert by id, never inserted when absent); removes the row when it no longer matches the active filters. */
    patchRow(updated) {
        const current = this.tarefas;
        if (current === null)
            return;
        const matchesResponsavel = this.responsavelId === null || this.responsavelId === updated.responsavelId;
        const matchesStatus = this.status === null || this.status === updated.status;
        const matchesOpen = (this.venceHoje !== true && this.atrasada !== true) || updated.details.aberta;
        const stays = matchesResponsavel && matchesStatus && matchesOpen;
        const items = [];
        for (const row of current.items) {
            if (row.id !== updated.id) {
                items.push(row);
            }
            else if (stays) {
                items.push({
                    ...row,
                    titulo: updated.titulo,
                    responsavelId: updated.responsavelId,
                    responsavel: updated.responsavel,
                    prioridade: updated.prioridade,
                    prazo: updated.prazo,
                    status: updated.status,
                });
            }
        }
        this.publish('tarefas', { ...current, items });
    }
    /** request reatribuirTarefa — swaps the responsible of the selected task for the member in reatribuirTarefaDraft (must be an Active member); redraws tarefa (replace with the returned task, new version) and the matching row of tarefas (upsert), then clears the draft; no arguments, reads the selected tarefa (id, version) and the draft */
    async reatribuirTarefa() {
        if (this.reatribuirTarefaStatus === 'loading')
            return;
        const tarefa = this.tarefa;
        const responsavelId = this.reatribuirTarefaDraft.responsavelId;
        if (tarefa === null || responsavelId === null || responsavelId === '') {
            const stateKeys = [];
            if (tarefa === null)
                stateKeys.push('ui.tarefas.tarefas_equipe.tarefa');
            if (responsavelId === null || responsavelId === '')
                stateKeys.push('ui.tarefas.tarefas_equipe.reatribuirTarefaDraft');
            this.publish('reatribuirTarefaError', { code: 'client.requiredMissing', message: '', details: { stateKeys } });
            this.publish('reatribuirTarefaStatus', 'error');
            return;
        }
        this.publish('reatribuirTarefaStatus', 'loading');
        this.publish('reatribuirTarefaError', null);
        const input = {
            id: tarefa.id,
            version: tarefa.version,
            responsavelId,
        };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.tarefas_equipe.reatribuirTarefa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('reatribuirTarefaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('reatribuirTarefaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('reatribuirTarefaError', response.error ?? this.unexpectedError(null));
                this.publish('reatribuirTarefaStatus', 'error');
                return;
            }
            const updated = response.data.tarefa;
            this.publish('tarefa', updated);
            this.patchRow(updated);
            this.publish('reatribuirTarefaDraft', emptyReatribuirTarefaDraft());
            this.publish('reatribuirTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('reatribuirTarefaError', this.unexpectedError(error));
            this.publish('reatribuirTarefaStatus', 'error');
        }
    }
    /** request cancelarTarefa — cancels the selected task while it is still open; redraws tarefa (replace with the returned cancelled task, new version) and the matching row of tarefas (upsert, or remove when it no longer matches the filters); no arguments, reads the selected tarefa (id, version) */
    async cancelarTarefa() {
        if (this.cancelarTarefaStatus === 'loading')
            return;
        const tarefa = this.tarefa;
        if (tarefa === null) {
            this.publish('cancelarTarefaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['ui.tarefas.tarefas_equipe.tarefa'] } });
            this.publish('cancelarTarefaStatus', 'error');
            return;
        }
        this.publish('cancelarTarefaStatus', 'loading');
        this.publish('cancelarTarefaError', null);
        const input = {
            id: tarefa.id,
            version: tarefa.version,
        };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.tarefas_equipe.cancelarTarefa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cancelarTarefaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cancelarTarefaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cancelarTarefaError', response.error ?? this.unexpectedError(null));
                this.publish('cancelarTarefaStatus', 'error');
                return;
            }
            const updated = response.data.tarefa;
            this.publish('tarefa', updated);
            this.patchRow(updated);
            this.publish('cancelarTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('cancelarTarefaError', this.unexpectedError(error));
            this.publish('cancelarTarefaStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "membros", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "tarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "selectedTarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "listaId", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "responsavelId", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "prioridade", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "status", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "prazoDe", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "prazoAte", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "venceHoje", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "atrasada", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "reatribuirTarefaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "carregarOpcoesEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "carregarOpcoesEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "listarTarefasEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "listarTarefasEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "obterTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "obterTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "reatribuirTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "reatribuirTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cancelarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "cancelarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasTarefas_equipeShared.prototype, "scenary", void 0);

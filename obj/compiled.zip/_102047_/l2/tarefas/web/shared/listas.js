var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/listas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
function emptyCriarListaDraft() {
    return { nome: null, details: { tipo: null, descricao: null }, ativa: null };
}
function emptySalvarListaDraft() {
    return { id: null, version: null, nome: null, details: { tipo: null, descricao: null }, ativa: null };
}
function draftFromLista(lista) {
    return {
        id: lista.id,
        version: lista.version,
        nome: lista.nome,
        details: {
            tipo: lista.details.tipo,
            descricao: lista.details.descricao !== undefined ? lista.details.descricao : null,
        },
        ativa: lista.ativa,
    };
}
function buildDetails(details, tipo) {
    const descricao = details.descricao;
    return {
        tipo,
        ...(descricao !== null && descricao !== '' ? { descricao } : {}),
    };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.listas.listas': 'listas',
    'ui.tarefas.listas.selectedLista': 'selectedLista',
    'ui.tarefas.listas.busca': 'busca',
    'ui.tarefas.listas.criarListaDraft': 'criarListaDraft',
    'ui.tarefas.listas.salvarListaDraft': 'salvarListaDraft',
    'ui.tarefas.listas.pageStatus': 'pageStatus',
    'ui.tarefas.listas.listarListasStatus': 'listarListasStatus',
    'ui.tarefas.listas.listarListasError': 'listarListasError',
    'ui.tarefas.listas.buscarListasStatus': 'buscarListasStatus',
    'ui.tarefas.listas.buscarListasError': 'buscarListasError',
    'ui.tarefas.listas.criarListaStatus': 'criarListaStatus',
    'ui.tarefas.listas.criarListaError': 'criarListaError',
    'ui.tarefas.listas.salvarListaStatus': 'salvarListaStatus',
    'ui.tarefas.listas.salvarListaError': 'salvarListaError',
    'ui.tarefas.listas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const LOCAL_STORAGE_LISTA_ID = 'tarefas.listas.listaId';
export class TarefasListasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state listas — the lists of tasks (projects or areas) with editable data, version and open-task count; source listarListas.listas; organism formularioLista, listasCadastradas */
        this.listas = [];
        /** state selectedLista — the id of the Lista selected in listasCadastradas (the row is read through the formularioLista getter); source entry.params.listaId; organism formularioLista, listasCadastradas; persisted */
        this.selectedLista = null;
        /** state busca — the name fragment last used to search the lists ('' lists all); filter held by the page for buscarListas; source buscarListas.input */
        this.busca = '';
        /** state criarListaDraft — draft of the form that creates a new list (nome, details.tipo, details.descricao, ativa); source criarLista.input; organism formularioLista */
        this.criarListaDraft = emptyCriarListaDraft();
        /** state salvarListaDraft — draft of the form that edits the selected list, prefilled from it (id, version, nome, details, ativa); source salvarLista.input; organism formularioLista */
        this.salvarListaDraft = emptySalvarListaDraft();
        /** state pageStatus — overall status of the page load: idle, loading, empty, success or error; written only by the initial load */
        this.pageStatus = 'idle';
        /** state listarListasStatus — status of the request listarListas */
        this.listarListasStatus = 'idle';
        /** state listarListasError — error of the request listarListas (also client.selectionInvalid when the selected id matches no row); null when none */
        this.listarListasError = null;
        /** state buscarListasStatus — status of the request buscarListas */
        this.buscarListasStatus = 'idle';
        /** state buscarListasError — error of the request buscarListas; null when none */
        this.buscarListasError = null;
        /** state criarListaStatus — status of the command criarLista; stays on success until the person changes something */
        this.criarListaStatus = 'idle';
        /** state criarListaError — error of the command criarLista; null when none */
        this.criarListaError = null;
        /** state salvarListaStatus — status of the command salvarLista; stays on success until the person changes something */
        this.salvarListaStatus = 'idle';
        /** state salvarListaError — error of the command salvarLista; null when none */
        this.salvarListaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.listas.${member}`, value);
        if (member === 'selectedLista') {
            try {
                if (value === null || value === undefined) {
                    localStorage.removeItem(LOCAL_STORAGE_LISTA_ID);
                }
                else {
                    localStorage.setItem(LOCAL_STORAGE_LISTA_ID, String(value));
                }
            }
            catch {
                // storage unavailable: the selection simply is not persisted
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        const storedListas = getState('ui.tarefas.listas.listas');
        if (storedListas !== undefined)
            this.assignState('ui.tarefas.listas.listas', storedListas);
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.listarListas();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('listarListasStatus', 'idle');
        this.publish('listarListasError', null);
        this.publish('buscarListasStatus', 'idle');
        this.publish('buscarListasError', null);
        this.publish('criarListaStatus', 'idle');
        this.publish('criarListaError', null);
        this.publish('salvarListaStatus', 'idle');
        this.publish('salvarListaError', null);
        this.publish('scenary', '');
        this.publish('busca', '');
        this.publish('criarListaDraft', emptyCriarListaDraft());
        this.publish('salvarListaDraft', emptySalvarListaDraft());
        // the persisted selection must survive the reset: it is read again by applyEntryParams
        this.selectedLista = null;
        setState('ui.tarefas.listas.selectedLista', null);
    }
    resetCommandResults() {
        this.publish('criarListaStatus', 'idle');
        this.publish('criarListaError', null);
        this.publish('salvarListaStatus', 'idle');
        this.publish('salvarListaError', null);
    }
    applyEntryParams() {
        let raw = new URLSearchParams(window.location.search).get('listaId');
        if (raw === null) {
            try {
                raw = localStorage.getItem(LOCAL_STORAGE_LISTA_ID);
            }
            catch {
                raw = null;
            }
        }
        if (raw !== null && raw !== '') {
            // the row is resolved once the list is loaded
            this.publish('selectedLista', raw);
        }
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    upsertLista(lista) {
        const exists = this.listas.some(row => row.id === lista.id);
        const next = exists ? this.listas.map(row => (row.id === lista.id ? lista : row)) : [...this.listas, lista];
        this.publish('listas', next);
    }
    /** The row of the loaded lists whose id is selectedLista (the selected record of formularioLista); null when nothing is selected or the row is not loaded */
    get formularioLista() {
        const id = this.selectedLista;
        if (id === null)
            return null;
        const row = this.listas.find(item => item.id === id);
        return row !== undefined ? row : null;
    }
    /** select — selects the list (by id) that formularioLista edits, or clears the selection with null; fills salvarListaDraft from the row; an id with no loaded row publishes client.selectionInvalid in listarListasError; id: the list id or null */
    selectFormularioLista(id) {
        this.resetCommandResults();
        this.publish('selectedLista', id);
        this.applySelection();
    }
    applySelection() {
        const id = this.selectedLista;
        if (id === null) {
            this.publish('salvarListaDraft', emptySalvarListaDraft());
            return;
        }
        const row = this.listas.find(item => item.id === id);
        if (row !== undefined) {
            this.publish('salvarListaDraft', draftFromLista(row));
            return;
        }
        if (this.listarListasStatus === 'success' || this.buscarListasStatus === 'success') {
            this.publish('salvarListaDraft', emptySalvarListaDraft());
            this.publish('listarListasError', {
                code: 'client.selectionInvalid',
                message: '',
                details: { listaId: id },
            });
        }
    }
    /** draft — replaces the draft of the new-list form (criarLista); value: the whole draft with nome, details.tipo, details.descricao and ativa */
    setCriarListaDraft(value) {
        this.resetCommandResults();
        this.publish('criarListaDraft', value);
    }
    /** draft — replaces the draft of the edit-list form (salvarLista); value: the whole draft with id, version, nome, details and ativa */
    setSalvarListaDraft(value) {
        this.resetCommandResults();
        this.publish('salvarListaDraft', value);
    }
    /** Publishes the visible scene of the page; value: the scene id ('' for none) */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** request listarListas — loads every list of the organization (active and inactive, ordered by name, with open-task count); redraws listas (replace), then resolves the selected list and sets pageStatus; no arguments; also the method to reload the page */
    async listarListas() {
        if (this.listarListasStatus === 'loading')
            return;
        this.publish('listarListasStatus', 'loading');
        this.publish('listarListasError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = {};
            const response = await execBff('tarefas.listas.listarListas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarListasError', response.error ?? this.unexpectedError(null));
                this.publish('listarListasStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const listas = response.data.listas;
            this.publish('listas', listas);
            this.publish('listarListasStatus', 'success');
            this.applySelection();
            this.publish('pageStatus', listas.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('listarListasError', this.unexpectedError(error));
            this.publish('listarListasStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request buscarListas — searches the lists whose name contains the typed fragment (case-insensitive, ordered by name); redraws listas (replace) and keeps the fragment in busca; busca: the name fragment, '' lists all */
    async buscarListas(busca) {
        if (this.buscarListasStatus === 'loading')
            return;
        this.publish('busca', busca);
        this.publish('buscarListasStatus', 'loading');
        this.publish('buscarListasError', null);
        try {
            const input = { busca };
            const response = await execBff('tarefas.listas.buscarListas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('buscarListasError', response.error ?? this.unexpectedError(null));
                this.publish('buscarListasStatus', 'error');
                return;
            }
            this.publish('listas', response.data.listas);
            this.publish('buscarListasStatus', 'success');
        }
        catch (error) {
            this.publish('buscarListasError', this.unexpectedError(error));
            this.publish('buscarListasStatus', 'error');
        }
    }
    /** request criarLista — creates a new list (project or area) from criarListaDraft; redraws listas (upsert of the returned list by id) and clears criarListaDraft; no arguments, the person fills the draft with setCriarListaDraft */
    async criarLista() {
        const draft = this.criarListaDraft;
        const missing = [];
        if (draft.nome === null || draft.nome === '')
            missing.push('criarListaDraft.nome');
        if (draft.details.tipo === null)
            missing.push('criarListaDraft.details.tipo');
        if (draft.ativa === null)
            missing.push('criarListaDraft.ativa');
        if (draft.nome === null || draft.details.tipo === null || draft.ativa === null || missing.length > 0) {
            this.publish('criarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('criarListaStatus', 'error');
            return;
        }
        const input = {
            nome: draft.nome,
            details: buildDetails(draft.details, draft.details.tipo),
            ativa: draft.ativa,
        };
        this.publish('criarListaStatus', 'loading');
        this.publish('criarListaError', null);
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.listas.criarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('criarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('criarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('criarListaError', response.error ?? this.unexpectedError(null));
                this.publish('criarListaStatus', 'error');
                return;
            }
            this.upsertLista(response.data.lista);
            this.publish('criarListaDraft', emptyCriarListaDraft());
            this.publish('criarListaStatus', 'success');
        }
        catch (error) {
            this.publish('criarListaError', this.unexpectedError(error));
            this.publish('criarListaStatus', 'error');
        }
    }
    /** request salvarLista — saves the edits of the selected list from salvarListaDraft (id and version come from the draft, filled by selectFormularioLista); redraws listas (upsert of the returned list by id) and refills salvarListaDraft from the saved list with its new version; no arguments */
    async salvarLista() {
        const draft = this.salvarListaDraft;
        const missing = [];
        if (draft.id === null || draft.id === '')
            missing.push('salvarListaDraft.id');
        if (draft.version === null)
            missing.push('salvarListaDraft.version');
        if (draft.nome === null || draft.nome === '')
            missing.push('salvarListaDraft.nome');
        if (draft.details.tipo === null)
            missing.push('salvarListaDraft.details.tipo');
        if (draft.ativa === null)
            missing.push('salvarListaDraft.ativa');
        if (draft.id === null ||
            draft.version === null ||
            draft.nome === null ||
            draft.details.tipo === null ||
            draft.ativa === null ||
            missing.length > 0) {
            this.publish('salvarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('salvarListaStatus', 'error');
            return;
        }
        const input = {
            id: draft.id,
            version: draft.version,
            nome: draft.nome,
            details: buildDetails(draft.details, draft.details.tipo),
            ativa: draft.ativa,
        };
        this.publish('salvarListaStatus', 'loading');
        this.publish('salvarListaError', null);
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.listas.salvarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('salvarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('salvarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('salvarListaError', response.error ?? this.unexpectedError(null));
                this.publish('salvarListaStatus', 'error');
                return;
            }
            const lista = response.data.lista;
            this.upsertLista(lista);
            this.publish('salvarListaDraft', draftFromLista(lista));
            this.publish('salvarListaStatus', 'success');
        }
        catch (error) {
            this.publish('salvarListaError', this.unexpectedError(error));
            this.publish('salvarListaStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "selectedLista", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "busca", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listarListasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listarListasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "buscarListasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "buscarListasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "scenary", void 0);

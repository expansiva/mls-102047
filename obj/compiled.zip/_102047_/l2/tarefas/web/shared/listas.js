var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/listas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
function emptyCriarListaDraft() {
    return { nome: null, details: { tipo: null, descricao: null }, ativa: true };
}
function emptySalvarListaDraft() {
    return { id: null, version: null, nome: null, details: { tipo: null, descricao: null }, ativa: null };
}
function draftFromLista(lista) {
    return {
        id: lista.id,
        version: lista.version,
        nome: lista.nome,
        details: { tipo: lista.details.tipo, descricao: lista.details.descricao ?? null },
        ativa: lista.ativa,
    };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.listas.listas': 'listas',
    'ui.tarefas.listas.selectedLista': 'selectedLista',
    'ui.tarefas.listas.busca': 'busca',
    'ui.tarefas.listas.criarListaDraft': 'criarListaDraft',
    'ui.tarefas.listas.salvarListaDraft': 'salvarListaDraft',
    'ui.tarefas.listas.pageStatus': 'pageStatus',
    'ui.tarefas.listas.listarListasStatus': 'listarListasStatus',
    'ui.tarefas.listas.listarListasError': 'listarListasError',
    'ui.tarefas.listas.buscarListasStatus': 'buscarListasStatus',
    'ui.tarefas.listas.buscarListasError': 'buscarListasError',
    'ui.tarefas.listas.criarListaStatus': 'criarListaStatus',
    'ui.tarefas.listas.criarListaError': 'criarListaError',
    'ui.tarefas.listas.salvarListaStatus': 'salvarListaStatus',
    'ui.tarefas.listas.salvarListaError': 'salvarListaError',
    'ui.tarefas.listas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class TarefasListasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state listas — the list of Lista de tarefas de um projeto ou área, com seus dados editáveis, versão e a quantidade de tarefas abertas; source listarListas.listas; organism formularioLista, listasCadastradas */
        this.listas = [];
        /** state selectedLista — the id of the Lista selected in listasCadastradas (null when none); source entry.params.listaId; organism formularioLista, listasCadastradas; lives in the URL (listaId) */
        this.selectedLista = null;
        /** state busca — filter: the name fragment last searched through buscarListas ('' lists everything); source buscarListas.input; organism listasCadastradas */
        this.busca = '';
        /** state criarListaDraft — draft of the new lista form (nome, details.tipo, details.descricao, ativa); source criarLista.input; organism formularioLista */
        this.criarListaDraft = emptyCriarListaDraft();
        /** state salvarListaDraft — draft of the edit form, filled from the selected lista (id, version, nome, details, ativa); source salvarLista.input; organism formularioLista */
        this.salvarListaDraft = emptySalvarListaDraft();
        /** state pageStatus — overall status of the page: loading while the initial load runs, empty when there is no lista, error when it failed */
        this.pageStatus = 'idle';
        /** state listarListasStatus — status of the initial load of every lista */
        this.listarListasStatus = 'idle';
        /** state listarListasError — error of the initial load (also client.selectionInvalid when the listaId param matches no lista); null when none */
        this.listarListasError = null;
        /** state buscarListasStatus — status of the search by name */
        this.buscarListasStatus = 'idle';
        /** state buscarListasError — error of the search by name; null when none */
        this.buscarListasError = null;
        /** state criarListaStatus — status of the creation of a lista; success stays until the person changes something */
        this.criarListaStatus = 'idle';
        /** state criarListaError — error of the creation (client.requiredMissing or a backend rule such as listaNomeUnico); null when none */
        this.criarListaError = null;
        /** state salvarListaStatus — status of the update of a lista; success stays until the person changes something */
        this.salvarListaStatus = 'idle';
        /** state salvarListaError — error of the update (client.requiredMissing or a backend rule such as listaNomeUnico or a version conflict); null when none */
        this.salvarListaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    /** selected formularioLista — the loaded lista whose id is in selectedLista, or null when nothing is selected or the row is not in the loaded list */
    get formularioLista() {
        const id = this.selectedLista;
        if (id === null)
            return null;
        return this.listas.find((row) => row.id === id) ?? null;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.listas.${member}`, value);
        if (member === 'selectedLista') {
            try {
                const url = new URL(window.location.href);
                if (value === null) {
                    url.searchParams.delete('listaId');
                }
                else {
                    url.searchParams.set('listaId', String(value));
                }
                history.replaceState(null, '', url.toString());
            }
            catch {
                // the URL could not be updated; the state stays published
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        const storedListas = getState('ui.tarefas.listas.listas');
        if (storedListas !== undefined)
            this.assignState('ui.tarefas.listas.listas', storedListas);
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.listarListas().then(() => this.applySelection());
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('listarListasStatus', 'idle');
        this.publish('listarListasError', null);
        this.publish('buscarListasStatus', 'idle');
        this.publish('buscarListasError', null);
        this.publish('criarListaStatus', 'idle');
        this.publish('criarListaError', null);
        this.publish('salvarListaStatus', 'idle');
        this.publish('salvarListaError', null);
        this.publish('scenary', '');
        this.publish('busca', '');
        this.publish('criarListaDraft', emptyCriarListaDraft());
        this.publish('salvarListaDraft', emptySalvarListaDraft());
    }
    resetCommandResults() {
        this.publish('criarListaStatus', 'idle');
        this.publish('criarListaError', null);
        this.publish('salvarListaStatus', 'idle');
        this.publish('salvarListaError', null);
    }
    applyEntryParams() {
        const raw = new URLSearchParams(window.location.search).get('listaId');
        this.publish('selectedLista', raw !== null && raw !== '' ? raw : null);
    }
    /** Applied after the load: the selected id wins over the filters; it fills the edit draft or reports client.selectionInvalid. */
    applySelection() {
        const id = this.selectedLista;
        if (id === null)
            return;
        if (this.listarListasStatus !== 'success')
            return;
        const row = this.listas.find((item) => item.id === id);
        if (!row) {
            this.publish('listarListasError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        this.publish('salvarListaDraft', draftFromLista(row));
    }
    unexpected(error) {
        return { code: 'client.unexpected', message: '', details: { name: error instanceof Error ? error.name : 'unknown' } };
    }
    upsertLista(lista) {
        const exists = this.listas.some((row) => row.id === lista.id);
        const next = exists ? this.listas.map((row) => (row.id === lista.id ? lista : row)) : [...this.listas, lista];
        this.publish('listas', next);
    }
    /** request listarListas — initial load of every lista of the organization (active and inactive) with its open task count; redraws listas (replace), pageStatus and, when listaId is in the URL, the edit draft; no arguments; call it again to reload without a filter */
    async listarListas() {
        if (this.listarListasStatus === 'loading')
            return;
        this.publish('listarListasStatus', 'loading');
        this.publish('listarListasError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = {};
            const response = await execBff('tarefas.listas.listarListas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarListasError', response.error ?? this.unexpected(null));
                this.publish('listarListasStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            this.publish('listas', response.data.listas);
            this.publish('listarListasStatus', 'success');
            this.publish('pageStatus', response.data.listas.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('listarListasError', this.unexpected(error));
            this.publish('listarListasStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request buscarListas — search the listas whose name contains a fragment (case-insensitive, '' returns all); redraws listas (replace) and busca; argument busca = the fragment typed by the gestor */
    async buscarListas(busca) {
        if (this.buscarListasStatus === 'loading')
            return;
        this.publish('busca', busca);
        this.publish('buscarListasStatus', 'loading');
        this.publish('buscarListasError', null);
        try {
            const input = { busca };
            const response = await execBff('tarefas.listas.buscarListas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('buscarListasError', response.error ?? this.unexpected(null));
                this.publish('buscarListasStatus', 'error');
                return;
            }
            this.publish('listas', response.data.listas);
            this.publish('buscarListasStatus', 'success');
        }
        catch (error) {
            this.publish('buscarListasError', this.unexpected(error));
            this.publish('buscarListasStatus', 'error');
        }
    }
    /** select — select a lista by id (null clears the selection); publishes selectedLista, fills salvarListaDraft from the loaded row (or empties it) and clears old command results; an id with no loaded row publishes client.selectionInvalid in listarListasError */
    selectLista(id) {
        this.resetCommandResults();
        if (id === null || id === '') {
            this.publish('selectedLista', null);
            this.publish('salvarListaDraft', emptySalvarListaDraft());
            return;
        }
        const row = this.listas.find((item) => item.id === id);
        if (!row) {
            this.publish('listarListasError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        if (this.listarListasError !== null && this.listarListasError.code === 'client.selectionInvalid') {
            this.publish('listarListasError', null);
        }
        this.publish('selectedLista', id);
        this.publish('salvarListaDraft', draftFromLista(row));
    }
    /** draft — replace the whole draft of the new lista form (nome, details.tipo, details.descricao, ativa); clears old command results */
    setCriarListaDraft(value) {
        this.resetCommandResults();
        this.publish('criarListaDraft', value);
    }
    /** draft — replace the whole draft of the edit lista form (id, version, nome, details.tipo, details.descricao, ativa); clears old command results */
    setSalvarListaDraft(value) {
        this.resetCommandResults();
        this.publish('salvarListaDraft', value);
    }
    /** setScenario — publish the visible scene of the page (state scenary); clears old command results */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** request criarLista — register a new lista from criarListaDraft (nome, tipo, descricao, ativa); redraws listas (upsert of the returned lista) and empties criarListaDraft; no arguments; a missing nome or tipo publishes client.requiredMissing without calling the backend */
    async criarLista() {
        if (this.criarListaStatus === 'loading')
            return;
        const draft = this.criarListaDraft;
        const nome = draft.nome ?? '';
        const tipo = draft.details.tipo;
        const ativa = draft.ativa;
        const missing = [];
        if (nome === '')
            missing.push('ui.tarefas.listas.criarListaDraft.nome');
        if (tipo === null)
            missing.push('ui.tarefas.listas.criarListaDraft.details.tipo');
        if (ativa === null)
            missing.push('ui.tarefas.listas.criarListaDraft.ativa');
        if (nome === '' || tipo === null || ativa === null) {
            this.publish('criarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('criarListaStatus', 'error');
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            nome,
            details: { tipo, ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
            ativa,
        };
        this.publish('criarListaStatus', 'loading');
        this.publish('criarListaError', null);
        try {
            const response = await runBlockingUiAction((signal) => execBff('tarefas.listas.criarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('criarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('criarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('criarListaError', response.error ?? this.unexpected(null));
                this.publish('criarListaStatus', 'error');
                return;
            }
            this.upsertLista(response.data.lista);
            this.publish('criarListaDraft', emptyCriarListaDraft());
            this.publish('criarListaStatus', 'success');
        }
        catch (error) {
            this.publish('criarListaError', this.unexpected(error));
            this.publish('criarListaStatus', 'error');
        }
    }
    /** request salvarLista — save the changes of the selected lista from salvarListaDraft (id, version, nome, tipo, descricao, ativa); redraws listas (upsert of the returned lista) and refills salvarListaDraft from the saved record with its new version; no arguments; select a lista first, otherwise client.requiredMissing is published without calling the backend */
    async salvarLista() {
        if (this.salvarListaStatus === 'loading')
            return;
        const draft = this.salvarListaDraft;
        const id = draft.id;
        const version = draft.version;
        const nome = draft.nome ?? '';
        const tipo = draft.details.tipo;
        const ativa = draft.ativa;
        const missing = [];
        if (id === null)
            missing.push('ui.tarefas.listas.salvarListaDraft.id');
        if (version === null)
            missing.push('ui.tarefas.listas.salvarListaDraft.version');
        if (nome === '')
            missing.push('ui.tarefas.listas.salvarListaDraft.nome');
        if (tipo === null)
            missing.push('ui.tarefas.listas.salvarListaDraft.details.tipo');
        if (ativa === null)
            missing.push('ui.tarefas.listas.salvarListaDraft.ativa');
        if (id === null || version === null || nome === '' || tipo === null || ativa === null) {
            this.publish('salvarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('salvarListaStatus', 'error');
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            id,
            version,
            nome,
            details: { tipo, ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
            ativa,
        };
        this.publish('salvarListaStatus', 'loading');
        this.publish('salvarListaError', null);
        try {
            const response = await runBlockingUiAction((signal) => execBff('tarefas.listas.salvarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('salvarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('salvarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('salvarListaError', response.error ?? this.unexpected(null));
                this.publish('salvarListaStatus', 'error');
                return;
            }
            const lista = response.data.lista;
            this.upsertLista(lista);
            this.publish('salvarListaDraft', draftFromLista(lista));
            this.publish('salvarListaStatus', 'success');
        }
        catch (error) {
            this.publish('salvarListaError', this.unexpected(error));
            this.publish('salvarListaStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "selectedLista", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "busca", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listarListasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listarListasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "buscarListasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "buscarListasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/listas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
export function emptyCriarListaDraft() {
    return { nome: null, ativa: true, details: { tipo: null, descricao: null } };
}
export function emptySalvarListaDraft() {
    return { id: null, version: null, nome: null, ativa: null, details: { tipo: null, descricao: null } };
}
function draftFromRegistro(registro) {
    return {
        id: registro.id,
        version: registro.version,
        nome: registro.nome,
        ativa: registro.ativa,
        details: {
            tipo: registro.details.details.tipo,
            descricao: registro.details.details.descricao ?? null,
        },
    };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.listas.listas': 'listas',
    'ui.tarefas.listas.lista': 'lista',
    'ui.tarefas.listas.selectedLista': 'selectedLista',
    'ui.tarefas.listas.criarListaDraft': 'criarListaDraft',
    'ui.tarefas.listas.salvarListaDraft': 'salvarListaDraft',
    'ui.tarefas.listas.pageStatus': 'pageStatus',
    'ui.tarefas.listas.listarListasStatus': 'listarListasStatus',
    'ui.tarefas.listas.listarListasError': 'listarListasError',
    'ui.tarefas.listas.obterListaStatus': 'obterListaStatus',
    'ui.tarefas.listas.obterListaError': 'obterListaError',
    'ui.tarefas.listas.criarListaStatus': 'criarListaStatus',
    'ui.tarefas.listas.criarListaError': 'criarListaError',
    'ui.tarefas.listas.salvarListaStatus': 'salvarListaStatus',
    'ui.tarefas.listas.salvarListaError': 'salvarListaError',
    'ui.tarefas.listas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class TarefasListasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state listas — rows of the lists register (name, type, active flag, open task count); source listarListas.listas; organism listasCadastradas */
        this.listas = [];
        /** state lista — the list record loaded in the edit form (with its version); source obterLista.lista; organism formularioLista */
        this.lista = null;
        /** state selectedLista — id of the list chosen in the register, whose record is loaded in the form (null = none, new list); source entry.params.listaId; organisms formularioLista, listasCadastradas; persisted */
        this.selectedLista = null;
        /** state criarListaDraft — draft of the new-list form (nome, ativa, details.tipo, details.descricao); source criarLista.input; organism formularioLista */
        this.criarListaDraft = emptyCriarListaDraft();
        /** state salvarListaDraft — draft of the edit-list form, filled from the loaded record (id and version travel with it); source salvarLista.input; organism formularioLista */
        this.salvarListaDraft = emptySalvarListaDraft();
        /** state pageStatus — overall status of the page load: idle, loading, empty (no list), success or error */
        this.pageStatus = 'idle';
        /** state listarListasStatus — status of the lists query */
        this.listarListasStatus = 'idle';
        /** state listarListasError — error of the lists query, null when none */
        this.listarListasError = null;
        /** state obterListaStatus — status of the query that opens one list for editing */
        this.obterListaStatus = 'idle';
        /** state obterListaError — error of the open-one-list query, null when none */
        this.obterListaError = null;
        /** state criarListaStatus — status of the create-list command */
        this.criarListaStatus = 'idle';
        /** state criarListaError — error of the create-list command, null when none */
        this.criarListaError = null;
        /** state salvarListaStatus — status of the save-list command */
        this.salvarListaStatus = 'idle';
        /** state salvarListaError — error of the save-list command, null when none */
        this.salvarListaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.subscribed = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.listas.${member}`, value);
        if (member === 'selectedLista') {
            try {
                if (value === null || value === undefined) {
                    localStorage.removeItem('tarefas.listas.listaId');
                }
                else {
                    localStorage.setItem('tarefas.listas.listaId', String(value));
                }
            }
            catch {
                // storage unavailable: the selection simply is not persisted
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        const dataKeys = ['ui.tarefas.listas.listas', 'ui.tarefas.listas.lista'];
        for (const key of dataKeys) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
        this.resetVisit();
        if (!this.subscribed) {
            subscribe([...STATE_KEYS], this);
            this.subscribed = true;
        }
        this.applyEntryParams();
        void this.listarListas();
        if (this.selectedLista !== null) {
            void this.obterLista(this.selectedLista);
        }
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        this.subscribed = false;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('listarListasStatus', 'idle');
        this.publish('listarListasError', null);
        this.publish('obterListaStatus', 'idle');
        this.publish('obterListaError', null);
        this.publish('criarListaStatus', 'idle');
        this.publish('criarListaError', null);
        this.publish('salvarListaStatus', 'idle');
        this.publish('salvarListaError', null);
        this.publish('criarListaDraft', emptyCriarListaDraft());
        this.publish('salvarListaDraft', emptySalvarListaDraft());
        this.publish('scenary', '');
    }
    resetCommandResults() {
        this.publish('criarListaStatus', 'idle');
        this.publish('criarListaError', null);
        this.publish('salvarListaStatus', 'idle');
        this.publish('salvarListaError', null);
    }
    readParam(name) {
        const fromUrl = new URLSearchParams(window.location.search).get(name);
        if (fromUrl !== null && fromUrl !== '')
            return fromUrl;
        try {
            const stored = localStorage.getItem(`tarefas.listas.${name}`);
            if (stored !== null && stored !== '')
                return stored;
        }
        catch {
            // storage unavailable
        }
        return null;
    }
    applyEntryParams() {
        const listaId = this.readParam('listaId');
        this.publish('selectedLista', listaId);
        if (listaId === null) {
            this.publish('lista', null);
        }
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    /** scene — publishes the visible scene of the page (any string the page uses to switch scenes) */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the new-list form (nome, ativa, details.tipo, details.descricao); clears the previous command result */
    setCriarListaDraft(value) {
        this.resetCommandResults();
        this.publish('criarListaDraft', { ...value, details: { ...value.details } });
    }
    /** draft — replaces the draft of the edit-list form (keeps id and version of the loaded record); clears the previous command result */
    setSalvarListaDraft(value) {
        this.resetCommandResults();
        this.publish('salvarListaDraft', { ...value, details: { ...value.details } });
    }
    /** select — chooses a list of the register by id and loads its record into the edit form (lista, salvarListaDraft); null clears the selection and the edit draft so the form returns to creating a new list; an id that cannot be fetched is reported in obterListaError */
    selecionarLista(listaId) {
        this.resetCommandResults();
        if (listaId === null || listaId === '') {
            this.publish('selectedLista', null);
            this.publish('lista', null);
            this.publish('salvarListaDraft', emptySalvarListaDraft());
            this.publish('obterListaStatus', 'idle');
            this.publish('obterListaError', null);
            return;
        }
        this.publish('selectedLista', listaId);
        void this.obterLista(listaId);
    }
    /** request listarListas — loads every list of the organization (active and inactive, ordered by name, with open task count) when the page opens; redraws listas (replace); no arguments; call it again to reload the register */
    async listarListas() {
        if (this.listarListasStatus === 'loading')
            return;
        this.publish('listarListasStatus', 'loading');
        this.publish('listarListasError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = {};
            const response = await execBff('tarefas.listas.listarListas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarListasError', response.error);
                this.publish('listarListasStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const rows = response.data.listas;
            this.publish('listas', rows);
            this.publish('listarListasStatus', 'success');
            this.publish('pageStatus', rows.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('listarListasError', this.unexpectedError(error));
            this.publish('listarListasStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request obterLista — opens one list of the register for editing; redraws lista (replace) and fills salvarListaDraft from the record; listaId: id of the list to open (prefer selecionarLista, which also records the selection) */
    async obterLista(listaId) {
        if (this.obterListaStatus === 'loading')
            return;
        if (listaId === '') {
            this.publish('obterListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['selectedLista'] } });
            this.publish('obterListaStatus', 'error');
            return;
        }
        this.publish('obterListaStatus', 'loading');
        this.publish('obterListaError', null);
        try {
            const input = { listaId };
            const response = await execBff('tarefas.listas.obterLista', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('obterListaError', response.error);
                this.publish('obterListaStatus', 'error');
                return;
            }
            const registro = response.data.lista;
            this.publish('lista', registro);
            this.publish('salvarListaDraft', draftFromRegistro(registro));
            this.publish('obterListaStatus', 'success');
        }
        catch (error) {
            this.publish('obterListaError', this.unexpectedError(error));
            this.publish('obterListaStatus', 'error');
        }
    }
    upsertLista(row) {
        const exists = this.listas.some(item => item.id === row.id);
        if (exists)
            return this.listas.map(item => (item.id === row.id ? row : item));
        return [...this.listas, row];
    }
    /** request criarLista — registers a new project/area list from criarListaDraft (nome and details.tipo required); redraws listas (upsert of the returned row), lista and selectedLista (the new record, so the form continues in edit), salvarListaDraft (filled from the record) and resets criarListaDraft; no arguments; errors such as listaNomeUnico come in criarListaError */
    async criarLista() {
        if (this.criarListaStatus === 'loading')
            return;
        const draft = this.criarListaDraft;
        const nome = draft.nome === null ? '' : draft.nome.trim();
        const missing = [];
        if (nome === '')
            missing.push('criarListaDraft.nome');
        if (draft.ativa === null)
            missing.push('criarListaDraft.ativa');
        if (draft.details.tipo === null)
            missing.push('criarListaDraft.details.tipo');
        if (missing.length > 0 || draft.ativa === null || draft.details.tipo === null) {
            this.publish('criarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('criarListaStatus', 'error');
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            nome,
            ativa: draft.ativa,
            details: {
                tipo: draft.details.tipo,
                ...(descricao !== null && descricao !== '' ? { descricao } : {}),
            },
        };
        this.publish('criarListaStatus', 'loading');
        this.publish('criarListaError', null);
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.listas.criarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('criarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('criarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('criarListaError', response.error);
                this.publish('criarListaStatus', 'error');
                return;
            }
            const output = response.data;
            this.publish('listas', this.upsertLista(output.lista));
            this.publish('lista', output.registro);
            this.publish('selectedLista', output.registro.id);
            this.publish('salvarListaDraft', draftFromRegistro(output.registro));
            this.publish('criarListaDraft', emptyCriarListaDraft());
            this.publish('pageStatus', 'success');
            this.publish('criarListaStatus', 'success');
        }
        catch (error) {
            this.publish('criarListaError', this.unexpectedError(error));
            this.publish('criarListaStatus', 'error');
        }
    }
    /** request salvarLista — saves the edits of the selected list from salvarListaDraft (id, version, nome, ativa and details.tipo required; version guards concurrency); redraws listas (upsert of the returned row), lista (the saved record with its new version) and salvarListaDraft (filled again from it); no arguments; errors such as listaNomeUnico or a stale version come in salvarListaError */
    async salvarLista() {
        if (this.salvarListaStatus === 'loading')
            return;
        const draft = this.salvarListaDraft;
        const nome = draft.nome === null ? '' : draft.nome.trim();
        const missing = [];
        if (draft.id === null || draft.id === '')
            missing.push('salvarListaDraft.id');
        if (draft.version === null)
            missing.push('salvarListaDraft.version');
        if (nome === '')
            missing.push('salvarListaDraft.nome');
        if (draft.ativa === null)
            missing.push('salvarListaDraft.ativa');
        if (draft.details.tipo === null)
            missing.push('salvarListaDraft.details.tipo');
        if (missing.length > 0 || draft.id === null || draft.version === null || draft.ativa === null || draft.details.tipo === null) {
            this.publish('salvarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('salvarListaStatus', 'error');
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            id: draft.id,
            version: draft.version,
            nome,
            ativa: draft.ativa,
            details: {
                tipo: draft.details.tipo,
                ...(descricao !== null && descricao !== '' ? { descricao } : {}),
            },
        };
        this.publish('salvarListaStatus', 'loading');
        this.publish('salvarListaError', null);
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.listas.salvarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('salvarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('salvarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('salvarListaError', response.error);
                this.publish('salvarListaStatus', 'error');
                return;
            }
            const output = response.data;
            this.publish('listas', this.upsertLista(output.lista));
            this.publish('lista', output.registro);
            this.publish('selectedLista', output.registro.id);
            this.publish('salvarListaDraft', draftFromRegistro(output.registro));
            this.publish('salvarListaStatus', 'success');
        }
        catch (error) {
            this.publish('salvarListaError', this.unexpectedError(error));
            this.publish('salvarListaStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "lista", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "selectedLista", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listarListasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "listarListasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "obterListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "obterListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "criarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "salvarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListasShared.prototype, "scenary", void 0);

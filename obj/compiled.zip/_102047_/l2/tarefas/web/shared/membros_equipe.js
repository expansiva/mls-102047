var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/membros_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
function emptyCadastrarDraft() {
    return { details: { identification: { name: null, countryCode: null } } };
}
function emptySalvarDraft() {
    return { id: null, version: null, details: { identification: { name: null, countryCode: null } } };
}
function draftFromPessoa(pessoa) {
    return {
        id: pessoa.id,
        version: pessoa.version,
        details: {
            identification: {
                name: pessoa.details.identification.name,
                countryCode: pessoa.details.identification.countryCode,
            },
        },
    };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.membros_equipe.pessoas': 'pessoas',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaPessoa': 'cmdCadastrarPessoaPessoa',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesPessoa': 'cmdSalvarAlteracoesPessoa',
    'ui.tarefas.membros_equipe.selectedMembroEquipe': 'selectedMembroEquipe',
    'ui.tarefas.membros_equipe.busca': 'busca',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaDraft': 'cmdCadastrarPessoaDraft',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesDraft': 'cmdSalvarAlteracoesDraft',
    'ui.tarefas.membros_equipe.pageStatus': 'pageStatus',
    'ui.tarefas.membros_equipe.qryPessoasEquipeStatus': 'qryPessoasEquipeStatus',
    'ui.tarefas.membros_equipe.qryPessoasEquipeError': 'qryPessoasEquipeError',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaStatus': 'cmdCadastrarPessoaStatus',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaError': 'cmdCadastrarPessoaError',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesStatus': 'cmdSalvarAlteracoesStatus',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesError': 'cmdSalvarAlteracoesError',
    'ui.tarefas.membros_equipe.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const BUSCA_STORAGE_KEY = 'tarefas.membros_equipe.busca';
const PAGE_SIZE = 20;
export class TarefasMembros_equipeShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state pessoas — the list of team members (id, version, name, status, country, roles, contacts summary) as a page { items, page, pageSize, hasMore }; source qryPessoasEquipe.pessoas; organism pessoasEquipe */
        this.pessoas = null;
        /** state cmdCadastrarPessoaPessoa — the team member just registered by cmdCadastrarPessoa; source cmdCadastrarPessoa.pessoa; organism cadastroPessoa */
        this.cmdCadastrarPessoaPessoa = null;
        /** state cmdSalvarAlteracoesPessoa — the team member just saved by cmdSalvarAlteracoes; source cmdSalvarAlteracoes.pessoa; organism cadastroPessoa */
        this.cmdSalvarAlteracoesPessoa = null;
        /** state selectedMembroEquipe — the id of the MembroEquipe selected in pessoasEquipe (the record is the getter cadastroPessoa); source entry.params.membroEquipeId; organism cadastroPessoa, pessoasEquipe */
        this.selectedMembroEquipe = null;
        /** state busca — name search text that filters pessoasEquipe; source entry.params.busca; organism pessoasEquipe; persisted */
        this.busca = null;
        /** state cmdCadastrarPessoaDraft — draft of the new person form (name, country); source cmdCadastrarPessoa.input; organism cadastroPessoa */
        this.cmdCadastrarPessoaDraft = emptyCadastrarDraft();
        /** state cmdSalvarAlteracoesDraft — draft of the edit form (id, version, name, country), filled from the selected person; source cmdSalvarAlteracoes.input; organism cadastroPessoa */
        this.cmdSalvarAlteracoesDraft = emptySalvarDraft();
        /** state pageStatus — overall status of the page load: idle, loading, empty, success or error; source qryPessoasEquipe */
        this.pageStatus = 'idle';
        /** state qryPessoasEquipeStatus — status of the list request; source qryPessoasEquipe */
        this.qryPessoasEquipeStatus = 'idle';
        /** state qryPessoasEquipeError — error of the list request (also client.selectionInvalid); source qryPessoasEquipe */
        this.qryPessoasEquipeError = null;
        /** state cmdCadastrarPessoaStatus — status of the register command; source cmdCadastrarPessoa */
        this.cmdCadastrarPessoaStatus = 'idle';
        /** state cmdCadastrarPessoaError — error of the register command; source cmdCadastrarPessoa */
        this.cmdCadastrarPessoaError = null;
        /** state cmdSalvarAlteracoesStatus — status of the save command; source cmdSalvarAlteracoes */
        this.cmdSalvarAlteracoesStatus = 'idle';
        /** state cmdSalvarAlteracoesError — error of the save command; source cmdSalvarAlteracoes */
        this.cmdSalvarAlteracoesError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.subscribed = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.membros_equipe.${member}`, value);
        if (member === 'busca') {
            try {
                if (value === null) {
                    localStorage.removeItem(BUSCA_STORAGE_KEY);
                }
                else {
                    localStorage.setItem(BUSCA_STORAGE_KEY, String(value));
                }
            }
            catch {
                // storage unavailable
            }
        }
        if (member === 'selectedMembroEquipe') {
            try {
                const url = new URL(window.location.href);
                if (value === null) {
                    url.searchParams.delete('membroEquipeId');
                }
                else {
                    url.searchParams.set('membroEquipeId', String(value));
                }
                history.replaceState(null, '', url.toString());
            }
            catch {
                // URL not writable
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    /** Selected person: the row of the loaded list whose id is selectedMembroEquipe, or null. */
    get cadastroPessoa() {
        const id = this.selectedMembroEquipe;
        if (id === null || this.pessoas === null)
            return null;
        const row = this.pessoas.items.find(item => item.id === id);
        return row ?? null;
    }
    connectedCallback() {
        super.connectedCallback();
        const pessoas = getState('ui.tarefas.membros_equipe.pessoas');
        if (pessoas !== undefined)
            this.assignState('ui.tarefas.membros_equipe.pessoas', pessoas);
        const cadastrada = getState('ui.tarefas.membros_equipe.cmdCadastrarPessoaPessoa');
        if (cadastrada !== undefined)
            this.assignState('ui.tarefas.membros_equipe.cmdCadastrarPessoaPessoa', cadastrada);
        const salva = getState('ui.tarefas.membros_equipe.cmdSalvarAlteracoesPessoa');
        if (salva !== undefined)
            this.assignState('ui.tarefas.membros_equipe.cmdSalvarAlteracoesPessoa', salva);
        this.resetVisit();
        if (!this.subscribed) {
            subscribe([...STATE_KEYS], this);
            this.subscribed = true;
        }
        const entry = this.applyEntryParams();
        void this.initialLoad(entry.membroEquipeId);
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        this.subscribed = false;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_MEMBER_BY_KEY[key]) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('qryPessoasEquipeStatus', 'idle');
        this.publish('qryPessoasEquipeError', null);
        this.publish('cmdCadastrarPessoaStatus', 'idle');
        this.publish('cmdCadastrarPessoaError', null);
        this.publish('cmdSalvarAlteracoesStatus', 'idle');
        this.publish('cmdSalvarAlteracoesError', null);
        this.publish('cmdCadastrarPessoaDraft', emptyCadastrarDraft());
        this.publish('cmdSalvarAlteracoesDraft', emptySalvarDraft());
        this.publish('scenary', '');
    }
    resetCommandResults() {
        this.publish('cmdCadastrarPessoaStatus', 'idle');
        this.publish('cmdCadastrarPessoaError', null);
        this.publish('cmdSalvarAlteracoesStatus', 'idle');
        this.publish('cmdSalvarAlteracoesError', null);
    }
    applyEntryParams() {
        const search = new URLSearchParams(window.location.search);
        let busca = search.get('busca');
        if (busca === null) {
            try {
                busca = localStorage.getItem(BUSCA_STORAGE_KEY);
            }
            catch {
                busca = null;
            }
        }
        this.publish('busca', busca !== null && busca !== '' ? busca : null);
        const rawId = search.get('membroEquipeId');
        const membroEquipeId = rawId !== null && rawId !== '' ? rawId : null;
        this.publish('selectedMembroEquipe', membroEquipeId);
        return { membroEquipeId };
    }
    async initialLoad(membroEquipeId) {
        await this.qryPessoasEquipe();
        if (this.qryPessoasEquipeStatus !== 'success')
            return;
        if (membroEquipeId !== null)
            this.applySelection(membroEquipeId);
    }
    applySelection(id) {
        if (id === null) {
            this.publish('selectedMembroEquipe', null);
            this.publish('cmdSalvarAlteracoesDraft', emptySalvarDraft());
            return;
        }
        const row = this.pessoas ? this.pessoas.items.find(item => item.id === id) : undefined;
        if (!row) {
            this.publish('selectedMembroEquipe', null);
            this.publish('cmdSalvarAlteracoesDraft', emptySalvarDraft());
            this.publish('qryPessoasEquipeError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        this.publish('selectedMembroEquipe', id);
        this.publish('cmdSalvarAlteracoesDraft', draftFromPessoa(row));
    }
    upsertPessoa(pessoa) {
        const current = this.pessoas;
        if (current === null)
            return;
        const exists = current.items.some(item => item.id === pessoa.id);
        const items = exists
            ? current.items.map(item => (item.id === pessoa.id ? pessoa : item))
            : [...current.items, pessoa];
        this.publish('pessoas', { ...current, items });
    }
    /** scene — publishes the visible scene of the page (no backend call); clears the results of the commands */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the new person form (name and country the person types); clears the results of the commands */
    setCmdCadastrarPessoaDraft(value) {
        this.resetCommandResults();
        this.publish('cmdCadastrarPessoaDraft', value);
    }
    /** draft — replaces the draft of the edit form (name and country of the selected person, id and version come from the record); clears the results of the commands */
    setCmdSalvarAlteracoesDraft(value) {
        this.resetCommandResults();
        this.publish('cmdSalvarAlteracoesDraft', value);
    }
    /** select — selects the person with this id in pessoasEquipe (null clears it) and fills the edit draft from that row; an id that is not in the loaded list publishes client.selectionInvalid in qryPessoasEquipeError; id: the person id or null */
    selectMembroEquipe(id) {
        this.resetCommandResults();
        this.applySelection(id);
    }
    /** request qryPessoasEquipe — lists the team members (role MembroEquipe), optionally searched by name, paged; redraws pessoas (replace, or append more items when append is true); also the method to reload, to search and to page; busca: new search text (omit to keep the current one, empty or null clears it and loads from the first page); page: page to load (default 1); append: true adds the page to the current items (load more) and does nothing when hasMore is false */
    async qryPessoasEquipe(busca, page = 1, append = false) {
        if (this.qryPessoasEquipeStatus === 'loading')
            return;
        if (busca !== undefined) {
            this.publish('busca', busca !== null && busca !== '' ? busca : null);
        }
        if (append && (this.pessoas === null || !this.pessoas.hasMore))
            return;
        this.publish('qryPessoasEquipeStatus', 'loading');
        this.publish('qryPessoasEquipeError', null);
        if (!append)
            this.publish('pageStatus', 'loading');
        const currentBusca = this.busca;
        const input = {
            page,
            pageSize: PAGE_SIZE,
            ...(currentBusca !== null && currentBusca !== '' ? { busca: currentBusca } : {}),
        };
        try {
            const response = await execBff('tarefas.membros_equipe.qryPessoasEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryPessoasEquipeError', response.error);
                this.publish('qryPessoasEquipeStatus', 'error');
                if (!append)
                    this.publish('pageStatus', 'error');
                return;
            }
            const incoming = response.data.pessoas;
            const current = this.pessoas;
            if (append && current !== null) {
                this.publish('pessoas', {
                    items: [...current.items, ...incoming.items],
                    page: incoming.page,
                    pageSize: incoming.pageSize,
                    hasMore: incoming.hasMore,
                });
            }
            else {
                this.publish('pessoas', incoming);
            }
            this.publish('qryPessoasEquipeStatus', 'success');
            const loaded = this.pessoas;
            this.publish('pageStatus', loaded !== null && loaded.items.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            const name = error instanceof Error ? error.name : 'Error';
            this.publish('qryPessoasEquipeError', { code: 'client.unexpected', message: '', details: { name } });
            this.publish('qryPessoasEquipeStatus', 'error');
            if (!append)
                this.publish('pageStatus', 'error');
        }
    }
    /** request cmdCadastrarPessoa — registers a new person in the team with the MembroEquipe role, from cmdCadastrarPessoaDraft (name, country); redraws cmdCadastrarPessoaPessoa (replace), pessoas (upsert by id) and empties the draft; takes no arguments */
    async cmdCadastrarPessoa() {
        const draft = this.cmdCadastrarPessoaDraft;
        const name = draft.details.identification.name;
        const countryCode = draft.details.identification.countryCode;
        if (name === null || name.trim() === '' || countryCode === null || countryCode.trim() === '') {
            const stateKeys = [];
            if (name === null || name.trim() === '')
                stateKeys.push('cmdCadastrarPessoaDraft.details.identification.name');
            if (countryCode === null || countryCode.trim() === '')
                stateKeys.push('cmdCadastrarPessoaDraft.details.identification.countryCode');
            this.publish('cmdCadastrarPessoaError', { code: 'client.requiredMissing', message: '', details: { stateKeys } });
            this.publish('cmdCadastrarPessoaStatus', 'error');
            return;
        }
        this.publish('cmdCadastrarPessoaStatus', 'loading');
        this.publish('cmdCadastrarPessoaError', null);
        const input = {
            details: { identification: { name, countryCode } },
        };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.membros_equipe.cmdCadastrarPessoa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdCadastrarPessoaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdCadastrarPessoaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdCadastrarPessoaError', response.error);
                this.publish('cmdCadastrarPessoaStatus', 'error');
                return;
            }
            const pessoa = response.data.pessoa;
            this.publish('cmdCadastrarPessoaPessoa', pessoa);
            this.upsertPessoa(pessoa);
            this.publish('cmdCadastrarPessoaDraft', emptyCadastrarDraft());
            this.publish('cmdCadastrarPessoaStatus', 'success');
        }
        catch (error) {
            const errorName = error instanceof Error ? error.name : 'Error';
            this.publish('cmdCadastrarPessoaError', { code: 'client.unexpected', message: '', details: { name: errorName } });
            this.publish('cmdCadastrarPessoaStatus', 'error');
        }
    }
    /** request cmdSalvarAlteracoes — corrects the name and country of the selected person, from cmdSalvarAlteracoesDraft (id and version come from the selected record); redraws cmdSalvarAlteracoesPessoa (replace), pessoas (upsert by id, so the selected record shows the new version) and refills the draft from the saved record; takes no arguments */
    async cmdSalvarAlteracoes() {
        const draft = this.cmdSalvarAlteracoesDraft;
        const id = draft.id;
        const version = draft.version;
        const name = draft.details.identification.name;
        const countryCode = draft.details.identification.countryCode;
        if (id === null || version === null || name === null || name.trim() === '' || countryCode === null || countryCode.trim() === '') {
            const stateKeys = [];
            if (id === null)
                stateKeys.push('cmdSalvarAlteracoesDraft.id');
            if (version === null)
                stateKeys.push('cmdSalvarAlteracoesDraft.version');
            if (name === null || name.trim() === '')
                stateKeys.push('cmdSalvarAlteracoesDraft.details.identification.name');
            if (countryCode === null || countryCode.trim() === '')
                stateKeys.push('cmdSalvarAlteracoesDraft.details.identification.countryCode');
            this.publish('cmdSalvarAlteracoesError', { code: 'client.requiredMissing', message: '', details: { stateKeys } });
            this.publish('cmdSalvarAlteracoesStatus', 'error');
            return;
        }
        this.publish('cmdSalvarAlteracoesStatus', 'loading');
        this.publish('cmdSalvarAlteracoesError', null);
        const input = {
            id,
            version,
            details: { identification: { name, countryCode } },
        };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.membros_equipe.cmdSalvarAlteracoes', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdSalvarAlteracoesError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdSalvarAlteracoesStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdSalvarAlteracoesError', response.error);
                this.publish('cmdSalvarAlteracoesStatus', 'error');
                return;
            }
            const pessoa = response.data.pessoa;
            this.publish('cmdSalvarAlteracoesPessoa', pessoa);
            this.upsertPessoa(pessoa);
            this.publish('cmdSalvarAlteracoesDraft', draftFromPessoa(pessoa));
            this.publish('cmdSalvarAlteracoesStatus', 'success');
        }
        catch (error) {
            const errorName = error instanceof Error ? error.name : 'Error';
            this.publish('cmdSalvarAlteracoesError', { code: 'client.unexpected', message: '', details: { name: errorName } });
            this.publish('cmdSalvarAlteracoesStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "pessoas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaPessoa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesPessoa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "selectedMembroEquipe", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "busca", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "qryPessoasEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "qryPessoasEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "scenary", void 0);

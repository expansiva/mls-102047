var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/membros_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.membros_equipe.membros': 'membros',
    'ui.tarefas.membros_equipe.membro': 'membro',
    'ui.tarefas.membros_equipe.selectedMembroEquipe': 'selectedMembroEquipe',
    'ui.tarefas.membros_equipe.busca': 'busca',
    'ui.tarefas.membros_equipe.page': 'page',
    'ui.tarefas.membros_equipe.cadastrarPessoaDraft': 'cadastrarPessoaDraft',
    'ui.tarefas.membros_equipe.salvarAlteracoesPessoaDraft': 'salvarAlteracoesPessoaDraft',
    'ui.tarefas.membros_equipe.pageStatus': 'pageStatus',
    'ui.tarefas.membros_equipe.listarMembrosEquipeStatus': 'listarMembrosEquipeStatus',
    'ui.tarefas.membros_equipe.listarMembrosEquipeError': 'listarMembrosEquipeError',
    'ui.tarefas.membros_equipe.obterMembroEquipeStatus': 'obterMembroEquipeStatus',
    'ui.tarefas.membros_equipe.obterMembroEquipeError': 'obterMembroEquipeError',
    'ui.tarefas.membros_equipe.cadastrarPessoaStatus': 'cadastrarPessoaStatus',
    'ui.tarefas.membros_equipe.cadastrarPessoaError': 'cadastrarPessoaError',
    'ui.tarefas.membros_equipe.salvarAlteracoesPessoaStatus': 'salvarAlteracoesPessoaStatus',
    'ui.tarefas.membros_equipe.salvarAlteracoesPessoaError': 'salvarAlteracoesPessoaError',
    'ui.tarefas.membros_equipe.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
/** State members that are persisted as entry params, with the param name used in localStorage. */
const PERSISTED_PARAM = {
    busca: 'busca',
    page: 'page',
    selectedMembroEquipe: 'membroEquipeId',
};
const PAGE_SIZE = 20;
function emptyCadastrarPessoaDraft() {
    return { details: { identification: { name: null, countryCode: null } } };
}
function emptySalvarAlteracoesPessoaDraft() {
    return { id: null, version: null, details: { identification: { name: null, countryCode: null } } };
}
function draftFromMembro(membro) {
    const identification = membro.details.identification.details.identification;
    return {
        id: membro.id,
        version: membro.version,
        details: { identification: { name: identification.name, countryCode: identification.countryCode } },
    };
}
function isBlank(value) {
    return value === null || value.trim() === '';
}
export class TarefasMembros_equipeShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state membros — people of the team as the list shows them (page with items, page, pageSize, hasMore); source listarMembrosEquipe.membros; organism pessoasEquipe */
        this.membros = null;
        /** state membro — the person loaded for the registration form (record with id and version); source obterMembroEquipe.membro; organism cadastroPessoa */
        this.membro = null;
        /** state selectedMembroEquipe — id of the selected person, opened in the registration form; source entry.params.membroEquipeId; organisms cadastroPessoa, pessoasEquipe; persisted */
        this.selectedMembroEquipe = null;
        /** state busca — optional name fragment that filters the list; source entry.params.busca; organism pessoasEquipe; persisted */
        this.busca = null;
        /** state page — the page of the list the person went to with a pager; source entry.params.page; organism pessoasEquipe; persisted */
        this.page = null;
        /** state cadastrarPessoaDraft — form draft of a new person (name, countryCode); source cadastrarPessoa.input; organism cadastroPessoa */
        this.cadastrarPessoaDraft = emptyCadastrarPessoaDraft();
        /** state salvarAlteracoesPessoaDraft — form draft editing the selected person (id, version, name, countryCode), filled from the loaded record; source salvarAlteracoesPessoa.input; organism cadastroPessoa */
        this.salvarAlteracoesPessoaDraft = emptySalvarAlteracoesPessoaDraft();
        /** state pageStatus — overall status of the page: idle, loading, empty, success or error */
        this.pageStatus = 'idle';
        /** state listarMembrosEquipeStatus — status of the team list request */
        this.listarMembrosEquipeStatus = 'idle';
        /** state listarMembrosEquipeError — error of the team list request, null when none */
        this.listarMembrosEquipeError = null;
        /** state obterMembroEquipeStatus — status of the request that loads the selected person */
        this.obterMembroEquipeStatus = 'idle';
        /** state obterMembroEquipeError — error of the request that loads the selected person, null when none */
        this.obterMembroEquipeError = null;
        /** state cadastrarPessoaStatus — status of the command that registers a new person */
        this.cadastrarPessoaStatus = 'idle';
        /** state cadastrarPessoaError — error of the command that registers a new person, null when none */
        this.cadastrarPessoaError = null;
        /** state salvarAlteracoesPessoaStatus — status of the command that saves the edited person */
        this.salvarAlteracoesPessoaStatus = 'idle';
        /** state salvarAlteracoesPessoaError — error of the command that saves the edited person, null when none */
        this.salvarAlteracoesPessoaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.membros_equipe.${member}`, value);
        const param = PERSISTED_PARAM[member];
        if (param) {
            try {
                const storageKey = `tarefas.membros_equipe.${param}`;
                if (value === null) {
                    window.localStorage.removeItem(storageKey);
                }
                else {
                    window.localStorage.setItem(storageKey, String(value));
                }
            }
            catch {
                // storage unavailable: the value stays in memory only
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        const membros = getState('ui.tarefas.membros_equipe.membros');
        if (membros !== undefined)
            this.assignState('ui.tarefas.membros_equipe.membros', membros);
        const membro = getState('ui.tarefas.membros_equipe.membro');
        if (membro !== undefined)
            this.assignState('ui.tarefas.membros_equipe.membro', membro);
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.initialLoad();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('listarMembrosEquipeStatus', 'idle');
        this.publish('listarMembrosEquipeError', null);
        this.publish('obterMembroEquipeStatus', 'idle');
        this.publish('obterMembroEquipeError', null);
        this.publish('cadastrarPessoaStatus', 'idle');
        this.publish('cadastrarPessoaError', null);
        this.publish('salvarAlteracoesPessoaStatus', 'idle');
        this.publish('salvarAlteracoesPessoaError', null);
        this.publish('cadastrarPessoaDraft', emptyCadastrarPessoaDraft());
        this.publish('salvarAlteracoesPessoaDraft', emptySalvarAlteracoesPessoaDraft());
        this.publish('scenary', '');
    }
    resetCommandResults() {
        this.publish('cadastrarPessoaStatus', 'idle');
        this.publish('cadastrarPessoaError', null);
        this.publish('salvarAlteracoesPessoaStatus', 'idle');
        this.publish('salvarAlteracoesPessoaError', null);
    }
    readParam(name) {
        const fromUrl = new URLSearchParams(window.location.search).get(name);
        if (fromUrl !== null)
            return fromUrl;
        try {
            return window.localStorage.getItem(`tarefas.membros_equipe.${name}`);
        }
        catch {
            return null;
        }
    }
    applyEntryParams() {
        const rawBusca = this.readParam('busca');
        this.publish('busca', rawBusca !== null && rawBusca !== '' ? rawBusca : null);
        const rawPage = this.readParam('page');
        let pageValue = null;
        if (rawPage !== null && rawPage !== '') {
            const parsed = Number(rawPage);
            if (Number.isFinite(parsed))
                pageValue = parsed;
        }
        this.publish('page', pageValue);
        const rawSelected = this.readParam('membroEquipeId');
        this.publish('selectedMembroEquipe', rawSelected !== null && rawSelected !== '' ? rawSelected : null);
        if (this.selectedMembroEquipe === null)
            this.publish('membro', null);
    }
    async initialLoad() {
        await this.listarMembrosEquipe();
        if (this.selectedMembroEquipe !== null)
            await this.obterMembroEquipe();
    }
    toError(error) {
        if (!error)
            return { code: 'client.unexpected', message: '', details: { name: 'noError' } };
        return { code: error.code, message: error.message ?? '', details: error.details };
    }
    unexpected(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    upsertMembro(membro) {
        if (!this.membros)
            return;
        const exists = this.membros.items.some((item) => item.id === membro.id);
        const items = exists
            ? this.membros.items.map((item) => (item.id === membro.id ? membro : item))
            : [...this.membros.items, membro];
        this.publish('membros', { ...this.membros, items });
    }
    /** request listarMembrosEquipe — loads the team people (role tarefas.MembroEquipe), filtered by name, one page at a time; redraws membros (replace, or append when append is true), the busca and page states and pageStatus; arguments: busca = new name filter (empty string clears it; a new filter loads from the first page), page = page to load (defaults to the current page, or the next one when appending), append = true adds the next page to the items instead of replacing them (does nothing when there is no more) */
    async listarMembrosEquipe(busca, page, append = false) {
        if (this.listarMembrosEquipeStatus === 'loading')
            return;
        let nextPage = page ?? this.page ?? 1;
        if (busca !== undefined) {
            this.publish('busca', busca !== null && busca !== '' ? busca : null);
            if (page === undefined)
                nextPage = 1;
        }
        if (append) {
            if (!this.membros || !this.membros.hasMore)
                return;
            if (page === undefined)
                nextPage = this.membros.page + 1;
        }
        else if (page !== undefined || busca !== undefined) {
            this.publish('page', nextPage);
        }
        this.publish('listarMembrosEquipeStatus', 'loading');
        this.publish('listarMembrosEquipeError', null);
        if (!append)
            this.publish('pageStatus', 'loading');
        const currentBusca = this.busca;
        const input = {
            page: nextPage,
            pageSize: PAGE_SIZE,
            ...(currentBusca !== null && currentBusca !== '' ? { busca: currentBusca } : {}),
        };
        try {
            const response = await execBff('tarefas.membros_equipe.listarMembrosEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarMembrosEquipeError', this.toError(response.error));
                this.publish('listarMembrosEquipeStatus', 'error');
                if (!append)
                    this.publish('pageStatus', 'error');
                return;
            }
            const loaded = response.data.membros;
            const previous = this.membros;
            const merged = append && previous
                ? { ...loaded, items: [...previous.items, ...loaded.items] }
                : loaded;
            this.publish('membros', merged);
            this.publish('listarMembrosEquipeStatus', 'success');
            this.publish('pageStatus', merged.items.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('listarMembrosEquipeError', this.unexpected(error));
            this.publish('listarMembrosEquipeStatus', 'error');
            if (!append)
                this.publish('pageStatus', 'error');
        }
    }
    /** select — selects the person opened in the registration form (id, or null to clear and start a new registration); publishes selectedMembroEquipe, then loads the record with obterMembroEquipe, or clears membro and the edit draft when null */
    async selectCadastroPessoa(id) {
        this.resetCommandResults();
        this.publish('selectedMembroEquipe', id !== null && id !== '' ? id : null);
        if (this.selectedMembroEquipe === null) {
            this.publish('membro', null);
            this.publish('salvarAlteracoesPessoaDraft', emptySalvarAlteracoesPessoaDraft());
            this.publish('obterMembroEquipeStatus', 'idle');
            this.publish('obterMembroEquipeError', null);
            return;
        }
        await this.obterMembroEquipe();
    }
    /** request obterMembroEquipe — loads the selected person (selectedMembroEquipe) with its current version for the registration form; redraws membro (replace) and fills salvarAlteracoesPessoaDraft from it; no arguments, reads the selection (without a selection it fails with client.requiredMissing) */
    async obterMembroEquipe() {
        if (this.obterMembroEquipeStatus === 'loading')
            return;
        const id = this.selectedMembroEquipe;
        if (id === null) {
            this.publish('obterMembroEquipeError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['ui.tarefas.membros_equipe.selectedMembroEquipe'] } });
            this.publish('obterMembroEquipeStatus', 'error');
            return;
        }
        this.publish('obterMembroEquipeStatus', 'loading');
        this.publish('obterMembroEquipeError', null);
        const input = { id };
        try {
            const response = await execBff('tarefas.membros_equipe.obterMembroEquipe', input, { mode: 'silent' });
            if (this.selectedMembroEquipe !== id) {
                this.publish('obterMembroEquipeStatus', 'idle');
                if (this.selectedMembroEquipe !== null)
                    await this.obterMembroEquipe();
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('obterMembroEquipeError', this.toError(response.error));
                this.publish('obterMembroEquipeStatus', 'error');
                return;
            }
            const loaded = response.data.membro;
            this.publish('membro', loaded);
            this.publish('salvarAlteracoesPessoaDraft', draftFromMembro(loaded));
            this.publish('obterMembroEquipeStatus', 'success');
        }
        catch (error) {
            this.publish('obterMembroEquipeError', this.unexpected(error));
            this.publish('obterMembroEquipeStatus', 'error');
        }
    }
    /** draft — replaces the form draft of a new person (name, countryCode); resets the results of the commands */
    setCadastrarPessoaDraft(value) {
        this.resetCommandResults();
        this.publish('cadastrarPessoaDraft', value);
    }
    /** draft — replaces the form draft that edits the selected person (id, version, name, countryCode); resets the results of the commands */
    setSalvarAlteracoesPessoaDraft(value) {
        this.resetCommandResults();
        this.publish('salvarAlteracoesPessoaDraft', value);
    }
    /** request cadastrarPessoa — registers a new team person from cadastrarPessoaDraft (name and countryCode required); redraws membros (inserts the returned person by id), membro and selectedMembroEquipe (the new person stays in the form), salvarAlteracoesPessoaDraft (filled from the record) and clears cadastrarPessoaDraft; no arguments */
    async cadastrarPessoa() {
        if (this.cadastrarPessoaStatus === 'loading')
            return;
        const draft = this.cadastrarPessoaDraft;
        const name = draft.details.identification.name;
        const countryCode = draft.details.identification.countryCode;
        if (name === null || countryCode === null || isBlank(name) || isBlank(countryCode)) {
            this.publish('cadastrarPessoaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['ui.tarefas.membros_equipe.cadastrarPessoaDraft'] } });
            this.publish('cadastrarPessoaStatus', 'error');
            return;
        }
        this.publish('cadastrarPessoaStatus', 'loading');
        this.publish('cadastrarPessoaError', null);
        const input = {
            details: { identification: { name: name.trim(), countryCode: countryCode.trim() } },
        };
        try {
            const response = await runBlockingUiAction((signal) => execBff('tarefas.membros_equipe.cadastrarPessoa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cadastrarPessoaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cadastrarPessoaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cadastrarPessoaError', this.toError(response.error));
                this.publish('cadastrarPessoaStatus', 'error');
                return;
            }
            const created = response.data.membro;
            this.upsertMembro(created);
            this.publish('membro', created);
            this.publish('selectedMembroEquipe', created.id);
            this.publish('salvarAlteracoesPessoaDraft', draftFromMembro(created));
            this.publish('cadastrarPessoaDraft', emptyCadastrarPessoaDraft());
            this.publish('cadastrarPessoaStatus', 'success');
        }
        catch (error) {
            this.publish('cadastrarPessoaError', this.unexpected(error));
            this.publish('cadastrarPessoaStatus', 'error');
        }
    }
    /** request salvarAlteracoesPessoa — saves the new name and country of the selected person from salvarAlteracoesPessoaDraft (id, version, name, countryCode required; stale version is refused by the backend); redraws membros (updates the row by id), membro (replace) and salvarAlteracoesPessoaDraft (filled again from the returned record with the new version); no arguments */
    async salvarAlteracoesPessoa() {
        if (this.salvarAlteracoesPessoaStatus === 'loading')
            return;
        const draft = this.salvarAlteracoesPessoaDraft;
        const id = draft.id;
        const version = draft.version;
        const name = draft.details.identification.name;
        const countryCode = draft.details.identification.countryCode;
        if (id === null || version === null || name === null || countryCode === null || isBlank(id) || isBlank(name) || isBlank(countryCode)) {
            this.publish('salvarAlteracoesPessoaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['ui.tarefas.membros_equipe.salvarAlteracoesPessoaDraft'] } });
            this.publish('salvarAlteracoesPessoaStatus', 'error');
            return;
        }
        this.publish('salvarAlteracoesPessoaStatus', 'loading');
        this.publish('salvarAlteracoesPessoaError', null);
        const input = {
            id,
            version,
            details: { identification: { name: name.trim(), countryCode: countryCode.trim() } },
        };
        try {
            const response = await runBlockingUiAction((signal) => execBff('tarefas.membros_equipe.salvarAlteracoesPessoa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('salvarAlteracoesPessoaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('salvarAlteracoesPessoaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('salvarAlteracoesPessoaError', this.toError(response.error));
                this.publish('salvarAlteracoesPessoaStatus', 'error');
                return;
            }
            const saved = response.data.membro;
            this.upsertMembro(saved);
            this.publish('membro', saved);
            this.publish('salvarAlteracoesPessoaDraft', draftFromMembro(saved));
            this.publish('salvarAlteracoesPessoaStatus', 'success');
        }
        catch (error) {
            this.publish('salvarAlteracoesPessoaError', this.unexpected(error));
            this.publish('salvarAlteracoesPessoaStatus', 'error');
        }
    }
    /** scene — publishes the visible scene of the page (scenary); resets the results of the commands */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
}
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "membros", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "membro", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "selectedMembroEquipe", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "busca", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "page", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cadastrarPessoaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "salvarAlteracoesPessoaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "listarMembrosEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "listarMembrosEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "obterMembroEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "obterMembroEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cadastrarPessoaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cadastrarPessoaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "salvarAlteracoesPessoaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "salvarAlteracoesPessoaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/membros_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
export function emptyCadastrarPessoaDraft() {
    return { details: { identification: { name: null, countryCode: null } } };
}
export function emptySalvarAlteracoesDraft() {
    return { id: null, version: null, details: { identification: { name: null, countryCode: null } } };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.membros_equipe.pessoas': 'pessoas',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaPessoa': 'cmdCadastrarPessoaPessoa',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesPessoa': 'cmdSalvarAlteracoesPessoa',
    'ui.tarefas.membros_equipe.selectedMembroEquipe': 'selectedMembroEquipe',
    'ui.tarefas.membros_equipe.busca': 'busca',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaDraft': 'cmdCadastrarPessoaDraft',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesDraft': 'cmdSalvarAlteracoesDraft',
    'ui.tarefas.membros_equipe.pageStatus': 'pageStatus',
    'ui.tarefas.membros_equipe.qryPessoasEquipeStatus': 'qryPessoasEquipeStatus',
    'ui.tarefas.membros_equipe.qryPessoasEquipeError': 'qryPessoasEquipeError',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaStatus': 'cmdCadastrarPessoaStatus',
    'ui.tarefas.membros_equipe.cmdCadastrarPessoaError': 'cmdCadastrarPessoaError',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesStatus': 'cmdSalvarAlteracoesStatus',
    'ui.tarefas.membros_equipe.cmdSalvarAlteracoesError': 'cmdSalvarAlteracoesError',
    'ui.tarefas.membros_equipe.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_SIZE = 20;
export class TarefasMembros_equipeShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state pessoas — the list of team members (page { items, page, pageSize, hasMore }) with identification, registry status, roles and contact summary; source qryPessoasEquipe.pessoas; organism pessoasEquipe */
        this.pessoas = null;
        /** state cmdCadastrarPessoaPessoa — the team member just registered by cmdCadastrarPessoa; source cmdCadastrarPessoa.pessoa; organism cadastroPessoa */
        this.cmdCadastrarPessoaPessoa = null;
        /** state cmdSalvarAlteracoesPessoa — the team member just saved by cmdSalvarAlteracoes; source cmdSalvarAlteracoes.pessoa; organism cadastroPessoa */
        this.cmdSalvarAlteracoesPessoa = null;
        /** state selectedMembroEquipe — the id of the team member selected in pessoasEquipe (the record is the getter cadastroPessoa); source entry.params.membroEquipeId; organisms cadastroPessoa, pessoasEquipe; persisted */
        this.selectedMembroEquipe = null;
        /** state busca — the name search text that filters pessoasEquipe (null = no filter); source entry.params.busca; organism pessoasEquipe; persisted */
        this.busca = null;
        /** state cmdCadastrarPessoaDraft — draft of the new-person form (name, country); source cmdCadastrarPessoa.input; organism cadastroPessoa */
        this.cmdCadastrarPessoaDraft = emptyCadastrarPessoaDraft();
        /** state cmdSalvarAlteracoesDraft — draft of the edit form (id, version, name, country), filled from the selected person; source cmdSalvarAlteracoes.input; organism cadastroPessoa */
        this.cmdSalvarAlteracoesDraft = emptySalvarAlteracoesDraft();
        /** state pageStatus — overall state of the page load: idle, loading, empty (no member), success or error */
        this.pageStatus = 'idle';
        /** state qryPessoasEquipeStatus — status of the list query: idle, loading, success or error */
        this.qryPessoasEquipeStatus = 'idle';
        /** state qryPessoasEquipeError — error of the list query (also client.selectionInvalid / client.preconditionMissing), null when none */
        this.qryPessoasEquipeError = null;
        /** state cmdCadastrarPessoaStatus — status of the register command: idle, loading, success or error */
        this.cmdCadastrarPessoaStatus = 'idle';
        /** state cmdCadastrarPessoaError — error of the register command, null when none */
        this.cmdCadastrarPessoaError = null;
        /** state cmdSalvarAlteracoesStatus — status of the save command: idle, loading, success or error */
        this.cmdSalvarAlteracoesStatus = 'idle';
        /** state cmdSalvarAlteracoesError — error of the save command, null when none */
        this.cmdSalvarAlteracoesError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.membros_equipe.${member}`, value);
        if (member === 'busca') {
            this.persistParam('busca', typeof value === 'string' ? value : null);
        }
        if (member === 'selectedMembroEquipe') {
            this.persistParam('membroEquipeId', typeof value === 'string' ? value : null);
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    persistParam(name, value) {
        try {
            const storageKey = `tarefas.membros_equipe.${name}`;
            if (value === null) {
                localStorage.removeItem(storageKey);
            }
            else {
                localStorage.setItem(storageKey, value);
            }
        }
        catch {
            // storage unavailable: the param is simply not persisted
        }
    }
    readParam(name) {
        try {
            const search = typeof window !== 'undefined' && window.location ? window.location.search : '';
            const fromUrl = new URLSearchParams(search).get(name);
            if (fromUrl !== null && fromUrl !== '')
                return fromUrl;
        }
        catch {
            // url unavailable
        }
        try {
            const stored = localStorage.getItem(`tarefas.membros_equipe.${name}`);
            if (stored !== null && stored !== '')
                return stored;
        }
        catch {
            // storage unavailable
        }
        return null;
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('qryPessoasEquipeStatus', 'idle');
        this.publish('qryPessoasEquipeError', null);
        this.publish('cmdCadastrarPessoaStatus', 'idle');
        this.publish('cmdCadastrarPessoaError', null);
        this.publish('cmdSalvarAlteracoesStatus', 'idle');
        this.publish('cmdSalvarAlteracoesError', null);
        this.publish('scenary', '');
        this.publish('cmdCadastrarPessoaDraft', emptyCadastrarPessoaDraft());
        this.publish('cmdSalvarAlteracoesDraft', emptySalvarAlteracoesDraft());
    }
    resetCommandResults() {
        this.publish('cmdCadastrarPessoaStatus', 'idle');
        this.publish('cmdCadastrarPessoaError', null);
        this.publish('cmdSalvarAlteracoesStatus', 'idle');
        this.publish('cmdSalvarAlteracoesError', null);
    }
    draftFromPessoa(pessoa) {
        return {
            id: pessoa.id,
            version: pessoa.version,
            details: {
                identification: {
                    name: pessoa.details.identification.name,
                    countryCode: pessoa.details.identification.countryCode,
                },
            },
        };
    }
    upsertPessoa(pessoa) {
        const current = this.pessoas;
        if (!current) {
            return { items: [pessoa], page: 1, pageSize: PAGE_SIZE, hasMore: false };
        }
        const exists = current.items.some(row => row.id === pessoa.id);
        const items = exists
            ? current.items.map(row => (row.id === pessoa.id ? pessoa : row))
            : [...current.items, pessoa];
        return { ...current, items };
    }
    connectedCallback() {
        super.connectedCallback();
        const pessoas = getState('ui.tarefas.membros_equipe.pessoas');
        if (pessoas !== undefined)
            this.assignState('ui.tarefas.membros_equipe.pessoas', pessoas);
        const cadastrada = getState('ui.tarefas.membros_equipe.cmdCadastrarPessoaPessoa');
        if (cadastrada !== undefined)
            this.assignState('ui.tarefas.membros_equipe.cmdCadastrarPessoaPessoa', cadastrada);
        const salva = getState('ui.tarefas.membros_equipe.cmdSalvarAlteracoesPessoa');
        if (salva !== undefined)
            this.assignState('ui.tarefas.membros_equipe.cmdSalvarAlteracoesPessoa', salva);
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.publish('busca', this.readParam('busca'));
        this.publish('selectedMembroEquipe', this.readParam('membroEquipeId'));
        void this.qryPessoasEquipe();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    /** select (record) — the team member selected in pessoasEquipe, picked from the loaded list by selectedMembroEquipe; null when nothing is selected or the id is not loaded */
    get cadastroPessoa() {
        const id = this.selectedMembroEquipe;
        if (id === null || !this.pessoas)
            return null;
        return this.pessoas.items.find(row => row.id === id) ?? null;
    }
    /** scene — publishes the visible scene of the page; value is the scene name ('' for none) */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the new-person form (name and country typed by the person) */
    setCmdCadastrarPessoaDraft(value) {
        this.resetCommandResults();
        this.publish('cmdCadastrarPessoaDraft', value);
    }
    /** draft — replaces the draft of the edit form (new name and country of the selected person; keep id and version) */
    setCmdSalvarAlteracoesDraft(value) {
        this.resetCommandResults();
        this.publish('cmdSalvarAlteracoesDraft', value);
    }
    /** select — selects the team member to edit by id (null clears the selection); the edit draft is filled from the loaded row. An id no loaded row resolves publishes client.selectionInvalid in qryPessoasEquipeError and keeps the previous selection. id: the member id or null */
    selectCadastroPessoa(id) {
        this.resetCommandResults();
        if (id === null) {
            this.publish('selectedMembroEquipe', null);
            this.publish('cmdSalvarAlteracoesDraft', emptySalvarAlteracoesDraft());
            return;
        }
        const row = this.pessoas ? this.pessoas.items.find(item => item.id === id) ?? null : null;
        if (!row) {
            this.publish('qryPessoasEquipeError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        this.publish('qryPessoasEquipeError', null);
        this.publish('selectedMembroEquipe', id);
        this.publish('cmdSalvarAlteracoesDraft', this.draftFromPessoa(row));
    }
    applySelectionAfterLoad() {
        const id = this.selectedMembroEquipe;
        if (id === null)
            return;
        const row = this.pessoas ? this.pessoas.items.find(item => item.id === id) ?? null : null;
        if (row) {
            if (this.cmdSalvarAlteracoesDraft.id !== row.id) {
                this.publish('cmdSalvarAlteracoesDraft', this.draftFromPessoa(row));
            }
            return;
        }
        if (this.cmdSalvarAlteracoesDraft.id === id)
            return;
        this.publish('qryPessoasEquipeError', { code: 'client.selectionInvalid', message: '', details: { id } });
        this.publish('qryPessoasEquipeStatus', 'error');
    }
    /** request qryPessoasEquipe — lists the team members (role tarefas.MembroEquipe) paged, optionally filtered by name, ordered by name; redraws pessoas (replace, or append more items when append is true); arguments: busca = name search text (omit to keep the current filter, '' or null clears it; a new value loads from the first page), page = page to load (default 1), append = true adds the page to the current items (load more) and does nothing when hasMore is false. Also the method to reload the list. */
    async qryPessoasEquipe(busca, page = 1, append = false) {
        if (this.qryPessoasEquipeStatus === 'loading')
            return;
        if (busca !== undefined) {
            const normalized = busca === null || busca === '' ? null : busca;
            this.publish('busca', normalized);
        }
        if (append && this.pessoas && !this.pessoas.hasMore)
            return;
        this.publish('qryPessoasEquipeStatus', 'loading');
        this.publish('qryPessoasEquipeError', null);
        this.publish('pageStatus', 'loading');
        const currentBusca = this.busca;
        const input = {
            page,
            pageSize: PAGE_SIZE,
            ...(currentBusca !== null && currentBusca !== '' ? { busca: currentBusca } : {}),
        };
        try {
            const response = await execBff('tarefas.membros_equipe.qryPessoasEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryPessoasEquipeError', response.error);
                this.publish('qryPessoasEquipeStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const incoming = response.data.pessoas;
            const previous = this.pessoas;
            const next = append && previous
                ? { items: [...previous.items, ...incoming.items], page: incoming.page, pageSize: incoming.pageSize, hasMore: incoming.hasMore }
                : incoming;
            this.publish('pessoas', next);
            this.publish('qryPessoasEquipeStatus', 'success');
            this.publish('pageStatus', next.items.length === 0 ? 'empty' : 'success');
            this.applySelectionAfterLoad();
        }
        catch (error) {
            this.publish('qryPessoasEquipeError', this.unexpectedError(error));
            this.publish('qryPessoasEquipeStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request cmdCadastrarPessoa — registers a new team member (role tarefas.MembroEquipe) from cmdCadastrarPessoaDraft (name and country required); redraws cmdCadastrarPessoaPessoa (replace) and pessoas (upsert by id, appended when new); the draft returns to empty; no arguments */
    async cmdCadastrarPessoa() {
        if (this.cmdCadastrarPessoaStatus === 'loading')
            return;
        const draft = this.cmdCadastrarPessoaDraft;
        const name = draft.details.identification.name;
        const countryCode = draft.details.identification.countryCode;
        const missing = [];
        if (name === null || name.trim() === '')
            missing.push('cmdCadastrarPessoaDraft.details.identification.name');
        if (countryCode === null || countryCode.trim() === '')
            missing.push('cmdCadastrarPessoaDraft.details.identification.countryCode');
        if (name === null || countryCode === null || missing.length > 0) {
            this.publish('cmdCadastrarPessoaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('cmdCadastrarPessoaStatus', 'error');
            return;
        }
        this.publish('cmdCadastrarPessoaStatus', 'loading');
        this.publish('cmdCadastrarPessoaError', null);
        const input = {
            details: { identification: { name: name.trim(), countryCode: countryCode.trim() } },
        };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.membros_equipe.cmdCadastrarPessoa', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdCadastrarPessoaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdCadastrarPessoaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdCadastrarPessoaError', response.error);
                this.publish('cmdCadastrarPessoaStatus', 'error');
                return;
            }
            const pessoa = response.data.pessoa;
            this.publish('cmdCadastrarPessoaPessoa', pessoa);
            this.publish('pessoas', this.upsertPessoa(pessoa));
            this.publish('cmdCadastrarPessoaDraft', emptyCadastrarPessoaDraft());
            this.publish('cmdCadastrarPessoaStatus', 'success');
        }
        catch (error) {
            this.publish('cmdCadastrarPessoaError', this.unexpectedError(error));
            this.publish('cmdCadastrarPessoaStatus', 'error');
        }
    }
    /** request cmdSalvarAlteracoes — corrects name and country of the selected team member from cmdSalvarAlteracoesDraft (id, version, name and country required; the version guards concurrent edits); redraws cmdSalvarAlteracoesPessoa (replace), pessoas (upsert by id, so the selected record cadastroPessoa updates) and refills the edit draft from the saved record; no arguments */
    async cmdSalvarAlteracoes() {
        if (this.cmdSalvarAlteracoesStatus === 'loading')
            return;
        const draft = this.cmdSalvarAlteracoesDraft;
        const id = draft.id;
        const version = draft.version;
        const name = draft.details.identification.name;
        const countryCode = draft.details.identification.countryCode;
        const missing = [];
        if (id === null || id === '')
            missing.push('cmdSalvarAlteracoesDraft.id');
        if (version === null)
            missing.push('cmdSalvarAlteracoesDraft.version');
        if (name === null || name.trim() === '')
            missing.push('cmdSalvarAlteracoesDraft.details.identification.name');
        if (countryCode === null || countryCode.trim() === '')
            missing.push('cmdSalvarAlteracoesDraft.details.identification.countryCode');
        if (id === null || version === null || name === null || countryCode === null || missing.length > 0) {
            this.publish('cmdSalvarAlteracoesError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('cmdSalvarAlteracoesStatus', 'error');
            return;
        }
        this.publish('cmdSalvarAlteracoesStatus', 'loading');
        this.publish('cmdSalvarAlteracoesError', null);
        const input = {
            id,
            version,
            details: { identification: { name: name.trim(), countryCode: countryCode.trim() } },
        };
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.membros_equipe.cmdSalvarAlteracoes', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdSalvarAlteracoesError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdSalvarAlteracoesStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdSalvarAlteracoesError', response.error);
                this.publish('cmdSalvarAlteracoesStatus', 'error');
                return;
            }
            const pessoa = response.data.pessoa;
            this.publish('cmdSalvarAlteracoesPessoa', pessoa);
            this.publish('pessoas', this.upsertPessoa(pessoa));
            this.publish('cmdSalvarAlteracoesDraft', this.draftFromPessoa(pessoa));
            this.publish('cmdSalvarAlteracoesStatus', 'success');
        }
        catch (error) {
            this.publish('cmdSalvarAlteracoesError', this.unexpectedError(error));
            this.publish('cmdSalvarAlteracoesStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "pessoas", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaPessoa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesPessoa", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "selectedMembroEquipe", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "busca", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "qryPessoasEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "qryPessoasEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdCadastrarPessoaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "cmdSalvarAlteracoesError", void 0);
__decorate([
    property({ attribute: false })
], TarefasMembros_equipeShared.prototype, "scenary", void 0);

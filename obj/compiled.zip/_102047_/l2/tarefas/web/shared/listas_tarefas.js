var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/listas_tarefas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
function emptyCriarDraft() {
    return { nome: null, details: { descricao: null } };
}
function emptySalvarDraft() {
    return { id: null, version: null, nome: null, details: { descricao: null } };
}
function draftFromLista(lista) {
    return {
        id: lista.id,
        version: lista.version,
        nome: lista.nome,
        details: { descricao: lista.details.descricao ?? null },
    };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.listas_tarefas.listas': 'listas',
    'ui.tarefas.listas_tarefas.texto': 'texto',
    'ui.tarefas.listas_tarefas.selectedListaTarefas': 'selectedListaTarefas',
    'ui.tarefas.listas_tarefas.cmdCriarListaDraft': 'cmdCriarListaDraft',
    'ui.tarefas.listas_tarefas.cmdSalvarListaDraft': 'cmdSalvarListaDraft',
    'ui.tarefas.listas_tarefas.pageStatus': 'pageStatus',
    'ui.tarefas.listas_tarefas.qryListasTarefasStatus': 'qryListasTarefasStatus',
    'ui.tarefas.listas_tarefas.qryListasTarefasError': 'qryListasTarefasError',
    'ui.tarefas.listas_tarefas.cmdCriarListaStatus': 'cmdCriarListaStatus',
    'ui.tarefas.listas_tarefas.cmdCriarListaError': 'cmdCriarListaError',
    'ui.tarefas.listas_tarefas.cmdSalvarListaStatus': 'cmdSalvarListaStatus',
    'ui.tarefas.listas_tarefas.cmdSalvarListaError': 'cmdSalvarListaError',
    'ui.tarefas.listas_tarefas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_PATH = '/tarefas/listas_tarefas';
const PAGE_SIZE = 50;
export class TarefasListas_tarefasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state listas — the lists of tasks (name, description and open task count), one page { items, page, pageSize, hasMore }; source qryListasTarefas.listas; organisms formularioLista, listasCadastradas */
        this.listas = null;
        /** state texto — the name search text that filters the lists (null when no search); source entry.params.texto; organism listasCadastradas; persisted */
        this.texto = null;
        /** state selectedListaTarefas — the id of the ListaTarefas selected in listasCadastradas (null when none); read the record through the getter formularioLista; source entry.params.listaTarefasId; organisms formularioLista, listasCadastradas */
        this.selectedListaTarefas = null;
        /** state cmdCriarListaDraft — draft of the form that creates a list (nome, details.descricao); source cmdCriarLista.input; organism formularioLista */
        this.cmdCriarListaDraft = emptyCriarDraft();
        /** state cmdSalvarListaDraft — draft of the form that edits the selected list (id, version, nome, details.descricao), filled from the selected list; source cmdSalvarLista.input; organism formularioLista */
        this.cmdSalvarListaDraft = emptySalvarDraft();
        /** state pageStatus — overall status of the page load: idle, loading, empty (no list), success or error; source page */
        this.pageStatus = 'idle';
        /** state qryListasTarefasStatus — status of the lists query; source qryListasTarefas */
        this.qryListasTarefasStatus = 'idle';
        /** state qryListasTarefasError — error of the lists query (also client.selectionInvalid), null when none; source qryListasTarefas */
        this.qryListasTarefasError = null;
        /** state cmdCriarListaStatus — status of the create list command; source cmdCriarLista */
        this.cmdCriarListaStatus = 'idle';
        /** state cmdCriarListaError — error of the create list command, null when none; source cmdCriarLista */
        this.cmdCriarListaError = null;
        /** state cmdSalvarListaStatus — status of the save list command; source cmdSalvarLista */
        this.cmdSalvarListaStatus = 'idle';
        /** state cmdSalvarListaError — error of the save list command, null when none; source cmdSalvarLista */
        this.cmdSalvarListaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.selectionPending = false;
        this.onPopState = () => {
            if (!window.location.pathname.endsWith(PAGE_PATH))
                return;
            this.resetVisit();
            this.applyEntryParams();
            void this.qryListasTarefas();
        };
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.listas_tarefas.${member}`, value);
        if (member === 'texto') {
            try {
                if (value === null || value === '') {
                    localStorage.removeItem('tarefas.listas_tarefas.texto');
                }
                else {
                    localStorage.setItem('tarefas.listas_tarefas.texto', String(value));
                }
            }
            catch {
                // storage unavailable: the value stays in memory only
            }
        }
        if (member === 'selectedListaTarefas') {
            try {
                const url = new URL(window.location.href);
                if (value === null) {
                    url.searchParams.delete('listaTarefasId');
                }
                else {
                    url.searchParams.set('listaTarefasId', String(value));
                }
                window.history.replaceState(window.history.state, '', url.toString());
            }
            catch {
                // URL not writable: the value stays in memory only
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        const stored = getState('ui.tarefas.listas_tarefas.listas');
        if (stored !== undefined)
            this.assignState('ui.tarefas.listas_tarefas.listas', stored);
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        window.addEventListener('popstate', this.onPopState);
        this.applyEntryParams();
        void this.qryListasTarefas();
    }
    disconnectedCallback() {
        window.removeEventListener('popstate', this.onPopState);
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_KEYS.includes(key)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.selectionPending = false;
        this.publish('pageStatus', 'idle');
        this.publish('qryListasTarefasStatus', 'idle');
        this.publish('qryListasTarefasError', null);
        this.publish('cmdCriarListaStatus', 'idle');
        this.publish('cmdCriarListaError', null);
        this.publish('cmdSalvarListaStatus', 'idle');
        this.publish('cmdSalvarListaError', null);
        this.publish('scenary', '');
        this.publish('cmdCriarListaDraft', emptyCriarDraft());
        this.publish('cmdSalvarListaDraft', emptySalvarDraft());
    }
    resetCommandResults() {
        this.publish('cmdCriarListaStatus', 'idle');
        this.publish('cmdCriarListaError', null);
        this.publish('cmdSalvarListaStatus', 'idle');
        this.publish('cmdSalvarListaError', null);
    }
    readParam(name, useStorage) {
        const raw = new URLSearchParams(window.location.search).get(name);
        if (raw !== null && raw !== '')
            return raw;
        if (useStorage) {
            try {
                const stored = localStorage.getItem(`tarefas.listas_tarefas.${name}`);
                if (stored !== null && stored !== '')
                    return stored;
            }
            catch {
                // storage unavailable
            }
        }
        return null;
    }
    applyEntryParams() {
        this.publish('texto', this.readParam('texto', true));
        const id = this.readParam('listaTarefasId', false);
        this.publish('selectedListaTarefas', id);
        this.selectionPending = id !== null;
    }
    findLista(id) {
        const page = this.listas;
        if (!page)
            return null;
        const row = page.items.find(item => item.id === id);
        return row ?? null;
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    upsertLista(lista) {
        const page = this.listas;
        if (!page) {
            this.publish('listas', { items: [lista], page: 1, pageSize: PAGE_SIZE, hasMore: false });
            return;
        }
        const exists = page.items.some(item => item.id === lista.id);
        const items = exists
            ? page.items.map(item => (item.id === lista.id ? lista : item))
            : [...page.items, lista];
        this.publish('listas', { ...page, items });
    }
    resolveSelection() {
        this.selectionPending = false;
        const id = this.selectedListaTarefas;
        if (id === null)
            return;
        const row = this.findLista(id);
        if (!row) {
            this.publish('selectedListaTarefas', null);
            this.publish('qryListasTarefasError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        this.publish('cmdSalvarListaDraft', draftFromLista(row));
    }
    /** The selected ListaTarefas record (the row of the loaded lists whose id is selectedListaTarefas), or null; feeds formularioLista */
    get formularioLista() {
        const id = this.selectedListaTarefas;
        if (id === null)
            return null;
        return this.findLista(id);
    }
    /** scene — publishes the visible scene of the page (scenary); clears old command results */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the create list form (cmdCriarListaDraft); clears old command results */
    setCmdCriarListaDraft(value) {
        this.resetCommandResults();
        this.publish('cmdCriarListaDraft', value);
    }
    /** draft — replaces the draft of the edit list form (cmdSalvarListaDraft); clears old command results */
    setCmdSalvarListaDraft(value) {
        this.resetCommandResults();
        this.publish('cmdSalvarListaDraft', value);
    }
    /** select — selects the list with this id (or null to clear) in listasCadastradas; the record is read through the getter formularioLista and the edit draft is filled from it; an id that is not in the loaded lists publishes client.selectionInvalid in qryListasTarefasError. Argument: id of the list, or null */
    selectListaTarefas(id) {
        this.resetCommandResults();
        if (id === null) {
            this.publish('selectedListaTarefas', null);
            this.publish('cmdSalvarListaDraft', emptySalvarDraft());
            return;
        }
        const row = this.findLista(id);
        if (!row) {
            this.publish('qryListasTarefasError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        this.publish('selectedListaTarefas', id);
        this.publish('cmdSalvarListaDraft', draftFromLista(row));
    }
    /** request qryListasTarefas — loads the lists of tasks ordered by name, searched by name, with the open task count of each; redraws listas (replace, or append the next page when append is true), texto when given; arguments: texto = new search text (omit to keep the current one; a new text loads from the first page; null or '' clears the search), page = page to load (default 1), append = true adds the page to the current items (load more) and does nothing when there is no more */
    async qryListasTarefas(texto, page = 1, append = false) {
        if (this.qryListasTarefasStatus === 'loading')
            return;
        let pageToLoad = page;
        let appendPage = append;
        if (texto !== undefined) {
            this.publish('texto', texto === null || texto === '' ? null : texto);
            pageToLoad = 1;
            appendPage = false;
        }
        const current = this.listas;
        if (appendPage && (!current || !current.hasMore))
            return;
        this.publish('qryListasTarefasStatus', 'loading');
        this.publish('qryListasTarefasError', null);
        if (!appendPage)
            this.publish('pageStatus', 'loading');
        const currentTexto = this.texto;
        const input = {
            ...(currentTexto !== null && currentTexto !== '' ? { texto: currentTexto } : {}),
            page: pageToLoad,
            pageSize: PAGE_SIZE,
        };
        try {
            const response = await execBff('tarefas.listas_tarefas.qryListasTarefas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryListasTarefasError', response.error ?? this.unexpectedError(null));
                this.publish('qryListasTarefasStatus', 'error');
                if (!appendPage)
                    this.publish('pageStatus', 'error');
                return;
            }
            const incoming = response.data.listas;
            const base = this.listas;
            const next = appendPage && base
                ? { ...incoming, items: [...base.items, ...incoming.items] }
                : incoming;
            this.publish('listas', next);
            this.publish('qryListasTarefasStatus', 'success');
            this.publish('pageStatus', next.items.length === 0 ? 'empty' : 'success');
            if (this.selectionPending)
                this.resolveSelection();
        }
        catch (error) {
            this.publish('qryListasTarefasError', this.unexpectedError(error));
            this.publish('qryListasTarefasStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request cmdCriarLista — creates a list of tasks from cmdCriarListaDraft (nome required, details.descricao optional); redraws listas (upsert of the returned list by id, appended when new) and clears cmdCriarListaDraft; no arguments; a missing nome publishes client.requiredMissing in cmdCriarListaError */
    async cmdCriarLista() {
        if (this.cmdCriarListaStatus === 'loading')
            return;
        const draft = this.cmdCriarListaDraft;
        const nome = draft.nome === null ? '' : draft.nome.trim();
        if (nome === '') {
            this.publish('cmdCriarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['cmdCriarListaDraft.nome'] } });
            this.publish('cmdCriarListaStatus', 'error');
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            nome,
            details: { ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
        };
        this.publish('cmdCriarListaStatus', 'loading');
        this.publish('cmdCriarListaError', null);
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.listas_tarefas.cmdCriarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdCriarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdCriarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdCriarListaError', response.error ?? this.unexpectedError(null));
                this.publish('cmdCriarListaStatus', 'error');
                return;
            }
            this.upsertLista(response.data.lista);
            this.publish('cmdCriarListaDraft', emptyCriarDraft());
            this.publish('cmdCriarListaStatus', 'success');
        }
        catch (error) {
            this.publish('cmdCriarListaError', this.unexpectedError(error));
            this.publish('cmdCriarListaStatus', 'error');
        }
    }
    /** request cmdSalvarLista — saves the name and description of the selected list from cmdSalvarListaDraft (id, version, nome required); redraws listas (upsert of the returned list by id, so formularioLista follows) and refills cmdSalvarListaDraft from the returned list with the new version; no arguments; missing id, version or nome publishes client.requiredMissing in cmdSalvarListaError */
    async cmdSalvarLista() {
        if (this.cmdSalvarListaStatus === 'loading')
            return;
        const draft = this.cmdSalvarListaDraft;
        const nome = draft.nome === null ? '' : draft.nome.trim();
        const missing = [];
        if (draft.id === null)
            missing.push('cmdSalvarListaDraft.id');
        if (draft.version === null)
            missing.push('cmdSalvarListaDraft.version');
        if (nome === '')
            missing.push('cmdSalvarListaDraft.nome');
        if (missing.length > 0 || draft.id === null || draft.version === null) {
            this.publish('cmdSalvarListaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            this.publish('cmdSalvarListaStatus', 'error');
            return;
        }
        const descricao = draft.details.descricao;
        const input = {
            id: draft.id,
            version: draft.version,
            nome,
            details: { ...(descricao !== null && descricao !== '' ? { descricao } : {}) },
        };
        this.publish('cmdSalvarListaStatus', 'loading');
        this.publish('cmdSalvarListaError', null);
        try {
            const response = await runBlockingUiAction(signal => execBff('tarefas.listas_tarefas.cmdSalvarLista', input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.publish('cmdSalvarListaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('cmdSalvarListaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('cmdSalvarListaError', response.error ?? this.unexpectedError(null));
                this.publish('cmdSalvarListaStatus', 'error');
                return;
            }
            const lista = response.data.lista;
            this.upsertLista(lista);
            this.publish('cmdSalvarListaDraft', draftFromLista(lista));
            this.publish('cmdSalvarListaStatus', 'success');
        }
        catch (error) {
            this.publish('cmdSalvarListaError', this.unexpectedError(error));
            this.publish('cmdSalvarListaStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "texto", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "selectedListaTarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "cmdCriarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "cmdSalvarListaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "qryListasTarefasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "qryListasTarefasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "cmdCriarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "cmdCriarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "cmdSalvarListaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "cmdSalvarListaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasListas_tarefasShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/painel_tarefas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.painel_tarefas.indicadores': 'indicadores',
    'ui.tarefas.painel_tarefas.listas': 'listas',
    'ui.tarefas.painel_tarefas.pageStatus': 'pageStatus',
    'ui.tarefas.painel_tarefas.carregarPainelTarefasStatus': 'carregarPainelTarefasStatus',
    'ui.tarefas.painel_tarefas.carregarPainelTarefasError': 'carregarPainelTarefasError',
    'ui.tarefas.painel_tarefas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class TarefasPainel_tarefasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state indicadores — the four general counts of the organization's tasks (open, due today, overdue, returned awaiting resume); source carregarPainelTarefas.indicadores; organism indicadoresTarefas */
        this.indicadores = null;
        /** state listas — the task lists (project or area) with open task count, checklist items done and total, and the open tasks that have a checklist; source carregarPainelTarefas.listas; organism tarefasPorLista */
        this.listas = [];
        /** state pageStatus — overall status of the page: idle, loading, empty (no list loaded), success or error */
        this.pageStatus = 'idle';
        /** state carregarPainelTarefasStatus — status of the request carregarPainelTarefas */
        this.carregarPainelTarefasStatus = 'idle';
        /** state carregarPainelTarefasError — error of the request carregarPainelTarefas, null when none */
        this.carregarPainelTarefasError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.popstateHandler = () => {
            const path = window.location.pathname;
            if (path.endsWith('/tarefas/painel_tarefas')) {
                this.resetVisit();
                this.applyEntryParams();
                void this.carregarPainelTarefas();
            }
        };
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.painel_tarefas.${member}`, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    hydrateData() {
        const indicadores = getState('ui.tarefas.painel_tarefas.indicadores');
        if (indicadores !== undefined)
            this.assignState('ui.tarefas.painel_tarefas.indicadores', indicadores);
        const listas = getState('ui.tarefas.painel_tarefas.listas');
        if (listas !== undefined)
            this.assignState('ui.tarefas.painel_tarefas.listas', listas);
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('carregarPainelTarefasStatus', 'idle');
        this.publish('carregarPainelTarefasError', null);
        this.publish('scenary', '');
    }
    /** The page has no entry params; kept so every visit follows the same sequence. */
    applyEntryParams() {
        return;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        window.addEventListener('popstate', this.popstateHandler);
        this.applyEntryParams();
        void this.carregarPainelTarefas();
    }
    disconnectedCallback() {
        window.removeEventListener('popstate', this.popstateHandler);
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    /** setScenario — publishes the visible scene of the page; argument value is the scene id ('' clears it) */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** request carregarPainelTarefas — loads the manager panel in one call (general indicators and open tasks per list with checklist progress); redraws indicadores and listas (replace) and pageStatus; no arguments, also used to reload the panel */
    async carregarPainelTarefas() {
        if (this.carregarPainelTarefasStatus === 'loading')
            return;
        this.publish('carregarPainelTarefasStatus', 'loading');
        this.publish('carregarPainelTarefasError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = {};
            const response = await execBff('tarefas.painel_tarefas.carregarPainelTarefas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                const error = response.error ?? { code: 'client.unexpected', message: '', details: { name: 'emptyResponse' } };
                this.publish('carregarPainelTarefasError', error);
                this.publish('carregarPainelTarefasStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const listas = [...response.data.listas];
            this.publish('indicadores', response.data.indicadores);
            this.publish('listas', listas);
            this.publish('carregarPainelTarefasStatus', 'success');
            this.publish('pageStatus', listas.length === 0 ? 'empty' : 'success');
        }
        catch (err) {
            const name = err instanceof Error ? err.name : 'unknown';
            this.publish('carregarPainelTarefasError', { code: 'client.unexpected', message: '', details: { name } });
            this.publish('carregarPainelTarefasStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** navigate — opens the team tasks page (tarefas_equipe) showing all tasks; carries nothing */
    verTodasTarefas() {
        auraNavigate('/tarefas/tarefas_equipe', { basePath: '/tarefas' });
    }
    /** navigate — opens the task lists page (listas_tarefas); optional listaId is the list to highlight there (listaTarefasId), omitted when null */
    abrirListas(listaId = null) {
        if (listaId !== null && listaId !== '') {
            auraNavigate(`/tarefas/listas_tarefas?listaTarefasId=${encodeURIComponent(listaId)}`, { basePath: '/tarefas' });
            return;
        }
        auraNavigate('/tarefas/listas_tarefas', { basePath: '/tarefas' });
    }
    /** navigate — opens the team tasks page (tarefas_equipe) filtered by one list; listaId is the id of the list row the person picked (carried as listaTarefasId); null is refused with client.preconditionMissing */
    verTarefasDaLista(listaId) {
        if (listaId === null || listaId === '') {
            this.publish('carregarPainelTarefasError', { code: 'client.preconditionMissing', message: '', details: { params: ['listaTarefasId'] } });
            return;
        }
        auraNavigate(`/tarefas/tarefas_equipe?listaTarefasId=${encodeURIComponent(listaId)}`, { basePath: '/tarefas' });
    }
}
__decorate([
    property({ attribute: false })
], TarefasPainel_tarefasShared.prototype, "indicadores", void 0);
__decorate([
    property({ attribute: false })
], TarefasPainel_tarefasShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasPainel_tarefasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasPainel_tarefasShared.prototype, "carregarPainelTarefasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasPainel_tarefasShared.prototype, "carregarPainelTarefasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasPainel_tarefasShared.prototype, "scenary", void 0);

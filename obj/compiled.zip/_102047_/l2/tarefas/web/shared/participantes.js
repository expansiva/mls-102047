var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/participantes.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
function emptyIncluirParticipanteDraft() {
    return { id: null, details: { tarefas: { aceitaTarefas: null, podeCriarTarefas: null } } };
}
function emptySalvarMarcasDraft() {
    return { id: null, version: null, details: { tarefas: { aceitaTarefas: null, podeCriarTarefas: null } } };
}
function draftFromParticipante(participante) {
    const tarefas = participante.details.tarefas;
    return {
        id: participante.id,
        version: participante.version,
        details: {
            tarefas: {
                aceitaTarefas: tarefas.aceitaTarefas ?? tarefas.aceitaTarefasEfetivo,
                podeCriarTarefas: tarefas.podeCriarTarefas ?? tarefas.podeCriarTarefasEfetivo,
            },
        },
    };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.participantes.participantes': 'participantes',
    'ui.tarefas.participantes.usuarios': 'usuarios',
    'ui.tarefas.participantes.selectedParticipante': 'selectedParticipante',
    'ui.tarefas.participantes.busca': 'busca',
    'ui.tarefas.participantes.incluirParticipanteDraft': 'incluirParticipanteDraft',
    'ui.tarefas.participantes.salvarMarcasDraft': 'salvarMarcasDraft',
    'ui.tarefas.participantes.pageStatus': 'pageStatus',
    'ui.tarefas.participantes.listarParticipantesStatus': 'listarParticipantesStatus',
    'ui.tarefas.participantes.listarParticipantesError': 'listarParticipantesError',
    'ui.tarefas.participantes.buscarUsuariosStatus': 'buscarUsuariosStatus',
    'ui.tarefas.participantes.buscarUsuariosError': 'buscarUsuariosError',
    'ui.tarefas.participantes.incluirParticipanteStatus': 'incluirParticipanteStatus',
    'ui.tarefas.participantes.incluirParticipanteError': 'incluirParticipanteError',
    'ui.tarefas.participantes.salvarMarcasStatus': 'salvarMarcasStatus',
    'ui.tarefas.participantes.salvarMarcasError': 'salvarMarcasError',
    'ui.tarefas.participantes.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_SIZE = 50;
const BUSCA_STORAGE_KEY = 'tarefas.participantes.busca';
const PAGE_PATH = '/tarefas/participantes';
function unexpectedError(error) {
    const name = error instanceof Error ? error.name : 'unknown';
    return { code: 'client.unexpected', message: '', details: { name } };
}
export class TarefasParticipantesShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state participantes — the page of participants of the tarefas module (name, status, roles, manager flags and effective flags); source listarParticipantes.participantes; organism listaParticipantes */
        this.participantes = null;
        /** state usuarios — short list of active organization users that do not participate yet, found by name; source buscarUsuarios.usuarios; organism formParticipante */
        this.usuarios = [];
        /** state selectedParticipante — the id of the Participante selected in listaParticipantes (the record is the getter formParticipante); source entry.params.participanteId; organism formParticipante, listaParticipantes */
        this.selectedParticipante = null;
        /** state busca — the name filter of the participants list (null = no filter); source entry.params.busca; organism listaParticipantes; persisted */
        this.busca = null;
        /** state incluirParticipanteDraft — form draft of the command incluirParticipante: the chosen user id and the optional manager flags; source incluirParticipante.input; organism formParticipante */
        this.incluirParticipanteDraft = emptyIncluirParticipanteDraft();
        /** state salvarMarcasDraft — form draft of the command salvarMarcas: the selected participant, its version and the two flags; source salvarMarcas.input; organism formParticipante */
        this.salvarMarcasDraft = emptySalvarMarcasDraft();
        /** state pageStatus — overall state of the page: idle, loading, empty (no participant), success or error */
        this.pageStatus = 'idle';
        /** state listarParticipantesStatus — status of the request listarParticipantes */
        this.listarParticipantesStatus = 'idle';
        /** state listarParticipantesError — error of the request listarParticipantes (also client.selectionInvalid when the selected id is not in the list) */
        this.listarParticipantesError = null;
        /** state buscarUsuariosStatus — status of the request buscarUsuarios */
        this.buscarUsuariosStatus = 'idle';
        /** state buscarUsuariosError — error of the request buscarUsuarios */
        this.buscarUsuariosError = null;
        /** state incluirParticipanteStatus — status of the command incluirParticipante */
        this.incluirParticipanteStatus = 'idle';
        /** state incluirParticipanteError — error of the command incluirParticipante */
        this.incluirParticipanteError = null;
        /** state salvarMarcasStatus — status of the command salvarMarcas */
        this.salvarMarcasStatus = 'idle';
        /** state salvarMarcasError — error of the command salvarMarcas */
        this.salvarMarcasError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.selectionPending = false;
        this.onPopState = () => {
            if (!window.location.pathname.endsWith(PAGE_PATH))
                return;
            this.resetVisit();
            this.beginVisit();
        };
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.participantes.${member}`, value);
        if (member === 'busca') {
            try {
                if (this.busca === null) {
                    localStorage.removeItem(BUSCA_STORAGE_KEY);
                }
                else {
                    localStorage.setItem(BUSCA_STORAGE_KEY, this.busca);
                }
            }
            catch {
                // storage unavailable: the value stays in memory only
            }
        }
        if (member === 'selectedParticipante') {
            try {
                const url = new URL(window.location.href);
                if (this.selectedParticipante === null) {
                    url.searchParams.delete('participanteId');
                }
                else {
                    url.searchParams.set('participanteId', this.selectedParticipante);
                }
                window.history.replaceState(window.history.state, '', url.toString());
            }
            catch {
                // URL not writable: the value stays in memory only
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        window.addEventListener('popstate', this.onPopState);
        this.beginVisit();
    }
    disconnectedCallback() {
        window.removeEventListener('popstate', this.onPopState);
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const keys = ['ui.tarefas.participantes.participantes', 'ui.tarefas.participantes.usuarios'];
        for (const key of keys) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.selectionPending = false;
        this.publish('pageStatus', 'idle');
        this.publish('listarParticipantesStatus', 'idle');
        this.publish('listarParticipantesError', null);
        this.publish('buscarUsuariosStatus', 'idle');
        this.publish('buscarUsuariosError', null);
        this.publish('incluirParticipanteStatus', 'idle');
        this.publish('incluirParticipanteError', null);
        this.publish('salvarMarcasStatus', 'idle');
        this.publish('salvarMarcasError', null);
        this.publish('incluirParticipanteDraft', emptyIncluirParticipanteDraft());
        this.publish('salvarMarcasDraft', emptySalvarMarcasDraft());
        this.publish('scenary', '');
    }
    beginVisit() {
        this.applyEntryParams();
        void this.listarParticipantes();
    }
    applyEntryParams() {
        const search = new URLSearchParams(window.location.search);
        let busca = search.get('busca');
        if (busca === null) {
            try {
                busca = localStorage.getItem(BUSCA_STORAGE_KEY);
            }
            catch {
                busca = null;
            }
        }
        const participanteId = search.get('participanteId');
        this.publish('busca', busca !== null && busca !== '' ? busca : null);
        this.publish('selectedParticipante', participanteId !== null && participanteId !== '' ? participanteId : null);
        this.selectionPending = participanteId !== null && participanteId !== '';
    }
    resetCommandResults() {
        this.publish('incluirParticipanteStatus', 'idle');
        this.publish('incluirParticipanteError', null);
        this.publish('salvarMarcasStatus', 'idle');
        this.publish('salvarMarcasError', null);
    }
    /** Resolves the selected id into a row of the loaded list and fills the marks draft from it; an id no row resolves publishes client.selectionInvalid. */
    resolveSelection(id) {
        if (id === null) {
            this.publish('selectedParticipante', null);
            this.publish('salvarMarcasDraft', emptySalvarMarcasDraft());
            return;
        }
        const rows = this.participantes ? this.participantes.items : [];
        const row = rows.find((item) => item.id === id) ?? null;
        if (!row) {
            this.publish('selectedParticipante', null);
            this.publish('salvarMarcasDraft', emptySalvarMarcasDraft());
            this.publish('listarParticipantesError', { code: 'client.selectionInvalid', message: '', details: { id } });
            return;
        }
        this.publish('selectedParticipante', id);
        this.publish('salvarMarcasDraft', draftFromParticipante(row));
    }
    /** The Participante record selected in listaParticipantes: the row of the loaded list whose id is selectedParticipante, or null. */
    get formParticipante() {
        const id = this.selectedParticipante;
        if (id === null || !this.participantes)
            return null;
        return this.participantes.items.find((item) => item.id === id) ?? null;
    }
    /** select — chooses the participant whose marks are edited in formParticipante (null clears the selection); fills salvarMarcasDraft from that row; an id that is not in the loaded list publishes client.selectionInvalid in listarParticipantesError. id: participant id or null. */
    selectParticipante(id) {
        this.resetCommandResults();
        this.resolveSelection(id);
    }
    /** draft — replaces the draft of the command incluirParticipante (chosen user id and optional flags); used by formParticipante when a user is picked or a flag is toggled. */
    setIncluirParticipanteDraft(value) {
        this.resetCommandResults();
        this.publish('incluirParticipanteDraft', value);
    }
    /** draft — replaces the draft of the command salvarMarcas (participant id, version and the two flags); used by formParticipante when a flag is toggled. */
    setSalvarMarcasDraft(value) {
        this.resetCommandResults();
        this.publish('salvarMarcasDraft', value);
    }
    /** Publishes the visible scene of the page. value: scene id. */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** request listarParticipantes — lists the participants of the tarefas module, filtered by name and ordered by the backend; redraws participantes (replace; with append=true the next page is added to items and page/hasMore follow the answer), busca (when given) and pageStatus; also the method to reload, filter and page the list. busca: new name filter (omit to keep the current one, '' or null clears it); page: page to load, 1 by default; append: true for a "load more" (does nothing unless the loaded list has more). */
    async listarParticipantes(busca, page = 1, append = false) {
        if (this.listarParticipantesStatus === 'loading')
            return;
        if (append && !(this.participantes && this.participantes.hasMore))
            return;
        if (busca !== undefined) {
            this.publish('busca', busca !== null && busca !== '' ? busca : null);
        }
        this.publish('listarParticipantesStatus', 'loading');
        this.publish('listarParticipantesError', null);
        if (!append)
            this.publish('pageStatus', 'loading');
        const currentBusca = this.busca;
        const input = {
            ...(currentBusca !== null && currentBusca !== '' ? { busca: currentBusca } : {}),
            page,
            pageSize: PAGE_SIZE,
        };
        try {
            const response = await execBff('tarefas.participantes.listarParticipantes', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarParticipantesError', response.error ?? unexpectedError(null));
                this.publish('listarParticipantesStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const loaded = response.data.participantes;
            const current = this.participantes;
            if (append && current) {
                this.publish('participantes', {
                    items: [...current.items, ...loaded.items],
                    page: loaded.page,
                    pageSize: loaded.pageSize,
                    hasMore: loaded.hasMore,
                });
            }
            else {
                this.publish('participantes', loaded);
            }
            this.publish('listarParticipantesStatus', 'success');
            if (this.selectionPending) {
                this.selectionPending = false;
                this.resolveSelection(this.selectedParticipante);
            }
            const total = this.participantes ? this.participantes.items.length : 0;
            this.publish('pageStatus', total === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('listarParticipantesError', unexpectedError(error));
            this.publish('listarParticipantesStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request buscarUsuarios — searches by name the active organization users that do not participate yet; redraws usuarios (replace). busca: part of the user name typed by the manager (required; empty publishes client.requiredMissing and does not call). */
    async buscarUsuarios(busca) {
        if (this.buscarUsuariosStatus === 'loading')
            return;
        const text = busca.trim();
        if (text === '') {
            this.publish('buscarUsuariosError', { code: 'client.requiredMissing', message: '', details: { params: ['busca'] } });
            this.publish('buscarUsuariosStatus', 'error');
            return;
        }
        this.publish('buscarUsuariosStatus', 'loading');
        this.publish('buscarUsuariosError', null);
        const input = { busca: text };
        try {
            const response = await execBff('tarefas.participantes.buscarUsuarios', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('buscarUsuariosError', response.error ?? unexpectedError(null));
                this.publish('buscarUsuariosStatus', 'error');
                return;
            }
            this.publish('usuarios', response.data.usuarios);
            this.publish('buscarUsuariosStatus', 'success');
        }
        catch (error) {
            this.publish('buscarUsuariosError', unexpectedError(error));
            this.publish('buscarUsuariosStatus', 'error');
        }
    }
    /** Inserts or updates a participant row by id in the loaded list (new rows go first). */
    upsertParticipante(participante) {
        const current = this.participantes;
        if (!current) {
            this.publish('participantes', { items: [participante], page: 1, pageSize: PAGE_SIZE, hasMore: false });
            return;
        }
        const exists = current.items.some((item) => item.id === participante.id);
        const items = exists
            ? current.items.map((item) => (item.id === participante.id ? participante : item))
            : [participante, ...current.items];
        this.publish('participantes', { ...current, items });
    }
    /** request incluirParticipante — includes the user chosen in the search (incluirParticipanteDraft.id) as participant, with the optional manager flags of the draft; redraws participantes (upsert of the returned participant by id) and usuarios (remove the included user), then clears incluirParticipanteDraft. Takes no arguments: fill the draft first with setIncluirParticipanteDraft; an empty id publishes client.requiredMissing. */
    async incluirParticipante() {
        if (this.incluirParticipanteStatus === 'loading')
            return;
        const draft = this.incluirParticipanteDraft;
        const id = draft.id;
        if (id === null || id === '') {
            this.publish('incluirParticipanteError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['incluirParticipanteDraft.id'] } });
            this.publish('incluirParticipanteStatus', 'error');
            return;
        }
        const aceita = draft.details.tarefas.aceitaTarefas;
        const pode = draft.details.tarefas.podeCriarTarefas;
        const input = {
            id,
            details: {
                tarefas: {
                    ...(aceita !== null ? { aceitaTarefas: aceita } : {}),
                    ...(pode !== null ? { podeCriarTarefas: pode } : {}),
                },
            },
        };
        this.publish('incluirParticipanteStatus', 'loading');
        this.publish('incluirParticipanteError', null);
        try {
            const response = await runBlockingUiAction((signal) => execBff('tarefas.participantes.incluirParticipante', input, { mode: 'blocking', signal }));
            if (!response) {
                this.publish('incluirParticipanteError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('incluirParticipanteStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('incluirParticipanteError', response.error ?? unexpectedError(null));
                this.publish('incluirParticipanteStatus', 'error');
                return;
            }
            const participante = response.data.participante;
            this.upsertParticipante(participante);
            this.publish('usuarios', this.usuarios.filter((usuario) => usuario.id !== participante.id));
            this.publish('incluirParticipanteDraft', emptyIncluirParticipanteDraft());
            this.publish('incluirParticipanteStatus', 'success');
        }
        catch (error) {
            this.publish('incluirParticipanteError', unexpectedError(error));
            this.publish('incluirParticipanteStatus', 'error');
        }
    }
    /** request salvarMarcas — saves the two marks (accepts tasks, can create tasks) of the selected participant using salvarMarcasDraft (id, version, flags); redraws participantes (upsert of the returned participant by id, so the selected record follows) and refills salvarMarcasDraft from the returned record. Takes no arguments: select a participant (selectParticipante) and edit the draft first; a missing leaf publishes client.requiredMissing. */
    async salvarMarcas() {
        if (this.salvarMarcasStatus === 'loading')
            return;
        const draft = this.salvarMarcasDraft;
        const id = draft.id;
        const version = draft.version;
        const aceita = draft.details.tarefas.aceitaTarefas;
        const pode = draft.details.tarefas.podeCriarTarefas;
        if (id === null || id === '' || version === null || aceita === null || pode === null) {
            const stateKeys = [];
            if (id === null || id === '')
                stateKeys.push('salvarMarcasDraft.id');
            if (version === null)
                stateKeys.push('salvarMarcasDraft.version');
            if (aceita === null)
                stateKeys.push('salvarMarcasDraft.details.tarefas.aceitaTarefas');
            if (pode === null)
                stateKeys.push('salvarMarcasDraft.details.tarefas.podeCriarTarefas');
            this.publish('salvarMarcasError', { code: 'client.requiredMissing', message: '', details: { stateKeys } });
            this.publish('salvarMarcasStatus', 'error');
            return;
        }
        const input = {
            id,
            version,
            details: { tarefas: { aceitaTarefas: aceita, podeCriarTarefas: pode } },
        };
        this.publish('salvarMarcasStatus', 'loading');
        this.publish('salvarMarcasError', null);
        try {
            const response = await runBlockingUiAction((signal) => execBff('tarefas.participantes.salvarMarcas', input, { mode: 'blocking', signal }));
            if (!response) {
                this.publish('salvarMarcasError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('salvarMarcasStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('salvarMarcasError', response.error ?? unexpectedError(null));
                this.publish('salvarMarcasStatus', 'error');
                return;
            }
            const participante = response.data.participante;
            this.upsertParticipante(participante);
            this.publish('salvarMarcasDraft', draftFromParticipante(participante));
            this.publish('salvarMarcasStatus', 'success');
        }
        catch (error) {
            this.publish('salvarMarcasError', unexpectedError(error));
            this.publish('salvarMarcasStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "participantes", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "usuarios", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "selectedParticipante", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "busca", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "incluirParticipanteDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "salvarMarcasDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "listarParticipantesStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "listarParticipantesError", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "buscarUsuariosStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "buscarUsuariosError", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "incluirParticipanteStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "incluirParticipanteError", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "salvarMarcasStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "salvarMarcasError", void 0);
__decorate([
    property({ attribute: false })
], TarefasParticipantesShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/inicio.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
function emptyDevolverTarefaDraft() {
    return { id: null, version: null, details: { motivoDevolucao: null } };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.inicio.pendencias': 'pendencias',
    'ui.tarefas.inicio.alertas': 'alertas',
    'ui.tarefas.inicio.indicadores': 'indicadores',
    'ui.tarefas.inicio.permissoes': 'permissoes',
    'ui.tarefas.inicio.devolverTarefaDraft': 'devolverTarefaDraft',
    'ui.tarefas.inicio.pageStatus': 'pageStatus',
    'ui.tarefas.inicio.carregarInicioStatus': 'carregarInicioStatus',
    'ui.tarefas.inicio.carregarInicioError': 'carregarInicioError',
    'ui.tarefas.inicio.iniciarTarefaStatus': 'iniciarTarefaStatus',
    'ui.tarefas.inicio.iniciarTarefaError': 'iniciarTarefaError',
    'ui.tarefas.inicio.enviarRevisaoStatus': 'enviarRevisaoStatus',
    'ui.tarefas.inicio.enviarRevisaoError': 'enviarRevisaoError',
    'ui.tarefas.inicio.aceitarTarefaStatus': 'aceitarTarefaStatus',
    'ui.tarefas.inicio.aceitarTarefaError': 'aceitarTarefaError',
    'ui.tarefas.inicio.devolverTarefaStatus': 'devolverTarefaStatus',
    'ui.tarefas.inicio.devolverTarefaError': 'devolverTarefaError',
    'ui.tarefas.inicio.retomarTarefaStatus': 'retomarTarefaStatus',
    'ui.tarefas.inicio.retomarTarefaError': 'retomarTarefaError',
    'ui.tarefas.inicio.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class TarefasInicioShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state pendencias — the list of tasks that depend on the person now, with status, due date, priority, list, assignee, creator, checklist progress and return reason; source carregarInicio.pendencias; organism pendenciasAgora */
        this.pendencias = [];
        /** state alertas — the list of open tasks that are due today or late, with title, due date and status; source carregarInicio.alertas; organism alertasPrazo */
        this.alertas = [];
        /** state indicadores — counters of the person's tasks: open, due today, late and returned awaiting resumption; source carregarInicio.indicadores; organism indicadoresTarefas */
        this.indicadores = null;
        /** state permissoes — the session participant with name and effective flags for accepting and creating tasks; source carregarInicio.permissoes; organism minhasPermissoes */
        this.permissoes = null;
        /** state devolverTarefaDraft — draft of the return command: the reason (details.motivoDevolucao) the creator types before returning a task in review; source devolverTarefa.input; organism pendenciasAgora */
        this.devolverTarefaDraft = emptyDevolverTarefaDraft();
        /** state pageStatus — overall status of the page: idle, loading, empty (nothing pending and no alert), success or error */
        this.pageStatus = 'idle';
        /** state carregarInicioStatus — status of the initial load request */
        this.carregarInicioStatus = 'idle';
        /** state carregarInicioError — error of the initial load request (also used by navigation refusals), null when none */
        this.carregarInicioError = null;
        /** state iniciarTarefaStatus — status of the start-task command */
        this.iniciarTarefaStatus = 'idle';
        /** state iniciarTarefaError — error of the start-task command, null when none */
        this.iniciarTarefaError = null;
        /** state enviarRevisaoStatus — status of the send-to-review command */
        this.enviarRevisaoStatus = 'idle';
        /** state enviarRevisaoError — error of the send-to-review command, null when none */
        this.enviarRevisaoError = null;
        /** state aceitarTarefaStatus — status of the accept-task command */
        this.aceitarTarefaStatus = 'idle';
        /** state aceitarTarefaError — error of the accept-task command, null when none */
        this.aceitarTarefaError = null;
        /** state devolverTarefaStatus — status of the return-task command */
        this.devolverTarefaStatus = 'idle';
        /** state devolverTarefaError — error of the return-task command, null when none */
        this.devolverTarefaError = null;
        /** state retomarTarefaStatus — status of the resume-task command */
        this.retomarTarefaStatus = 'idle';
        /** state retomarTarefaError — error of the resume-task command, null when none */
        this.retomarTarefaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.onPopState = () => {
            if (window.location.pathname.endsWith('/tarefas/inicio')) {
                this.resetVisit();
                void this.carregarInicio();
            }
        };
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.inicio.${member}`, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        window.addEventListener('popstate', this.onPopState);
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        void this.carregarInicio();
    }
    disconnectedCallback() {
        window.removeEventListener('popstate', this.onPopState);
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const dataKeys = [
            'ui.tarefas.inicio.pendencias',
            'ui.tarefas.inicio.alertas',
            'ui.tarefas.inicio.indicadores',
            'ui.tarefas.inicio.permissoes',
        ];
        for (const key of dataKeys) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('carregarInicioStatus', 'idle');
        this.publish('carregarInicioError', null);
        this.publish('iniciarTarefaStatus', 'idle');
        this.publish('iniciarTarefaError', null);
        this.publish('enviarRevisaoStatus', 'idle');
        this.publish('enviarRevisaoError', null);
        this.publish('aceitarTarefaStatus', 'idle');
        this.publish('aceitarTarefaError', null);
        this.publish('devolverTarefaStatus', 'idle');
        this.publish('devolverTarefaError', null);
        this.publish('retomarTarefaStatus', 'idle');
        this.publish('retomarTarefaError', null);
        this.publish('devolverTarefaDraft', emptyDevolverTarefaDraft());
        this.publish('scenary', '');
    }
    resetCommandResults() {
        this.publish('iniciarTarefaStatus', 'idle');
        this.publish('iniciarTarefaError', null);
        this.publish('enviarRevisaoStatus', 'idle');
        this.publish('enviarRevisaoError', null);
        this.publish('aceitarTarefaStatus', 'idle');
        this.publish('aceitarTarefaError', null);
        this.publish('devolverTarefaStatus', 'idle');
        this.publish('devolverTarefaError', null);
        this.publish('retomarTarefaStatus', 'idle');
        this.publish('retomarTarefaError', null);
    }
    /** scene — publishes the visible scene of the page (state scenary); clears the results of past commands */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the return command (state devolverTarefaDraft); the page types details.motivoDevolucao here before calling devolverTarefa */
    setDevolverTarefaDraft(value) {
        this.resetCommandResults();
        this.publish('devolverTarefaDraft', value);
    }
    /** request carregarInicio — loads the member's home in one call: pending tasks, due-date alerts, counters and effective permissions; redraws pendencias, alertas, indicadores and permissoes (replace) and sets pageStatus; no arguments, the session person is identified by the server; call it again to reload */
    async carregarInicio() {
        if (this.carregarInicioStatus === 'loading')
            return;
        this.publish('pageStatus', 'loading');
        this.publish('carregarInicioStatus', 'loading');
        this.publish('carregarInicioError', null);
        try {
            const input = {};
            const response = await execBff('tarefas.inicio.carregarInicio', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarInicioError', response.error ?? { code: 'client.unexpected', message: '', details: { name: 'unknown' } });
                this.publish('carregarInicioStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const data = response.data;
            this.publish('pendencias', [...data.pendencias]);
            this.publish('alertas', [...data.alertas]);
            this.publish('indicadores', data.indicadores);
            this.publish('permissoes', data.permissoes);
            this.publish('carregarInicioStatus', 'success');
            this.publish('pageStatus', data.pendencias.length === 0 && data.alertas.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            const name = error instanceof Error ? error.name : 'unknown';
            this.publish('carregarInicioError', { code: 'client.unexpected', message: '', details: { name } });
            this.publish('carregarInicioStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    publishCommandStatus(request, status) {
        switch (request) {
            case 'iniciarTarefa':
                this.publish('iniciarTarefaStatus', status);
                break;
            case 'enviarRevisao':
                this.publish('enviarRevisaoStatus', status);
                break;
            case 'aceitarTarefa':
                this.publish('aceitarTarefaStatus', status);
                break;
            case 'devolverTarefa':
                this.publish('devolverTarefaStatus', status);
                break;
            case 'retomarTarefa':
                this.publish('retomarTarefaStatus', status);
                break;
        }
    }
    publishCommandError(request, error) {
        switch (request) {
            case 'iniciarTarefa':
                this.publish('iniciarTarefaError', error);
                break;
            case 'enviarRevisao':
                this.publish('enviarRevisaoError', error);
                break;
            case 'aceitarTarefa':
                this.publish('aceitarTarefaError', error);
                break;
            case 'devolverTarefa':
                this.publish('devolverTarefaError', error);
                break;
            case 'retomarTarefa':
                this.publish('retomarTarefaError', error);
                break;
        }
    }
    commandStatus(request) {
        switch (request) {
            case 'iniciarTarefa':
                return this.iniciarTarefaStatus;
            case 'enviarRevisao':
                return this.enviarRevisaoStatus;
            case 'aceitarTarefa':
                return this.aceitarTarefaStatus;
            case 'devolverTarefa':
                return this.devolverTarefaStatus;
            case 'retomarTarefa':
                return this.retomarTarefaStatus;
        }
    }
    /**
     * Runs one command on a row of pendencias. The version comes from the loaded row.
     * The returned task is upserted by id in pendencias, or removed when it no longer
     * depends on the same person; indicadores is replaced by the returned counters.
     */
    async runCommand(request, id, send) {
        if (this.commandStatus(request) === 'loading')
            return;
        const row = this.pendencias.find((item) => item.id === id);
        if (!row) {
            this.publishCommandError(request, { code: 'client.requiredMissing', message: '', details: { stateKeys: ['pendencias'] } });
            this.publishCommandStatus(request, 'error');
            return;
        }
        this.publishCommandStatus(request, 'loading');
        this.publishCommandError(request, null);
        try {
            const response = await runBlockingUiAction((signal) => send(row.version, signal));
            if (response === undefined) {
                this.publishCommandError(request, { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publishCommandStatus(request, 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publishCommandError(request, response.error ?? { code: 'client.unexpected', message: '', details: { name: 'unknown' } });
                this.publishCommandStatus(request, 'error');
                return;
            }
            const updated = response.data.tarefa;
            const previousActor = row.details.quemAgeAgora;
            const nextActor = updated.details.quemAgeAgora;
            const stays = nextActor !== undefined && (previousActor === undefined || nextActor === previousActor);
            let rows;
            if (!stays) {
                rows = this.pendencias.filter((item) => item.id !== updated.id);
            }
            else if (this.pendencias.some((item) => item.id === updated.id)) {
                rows = this.pendencias.map((item) => (item.id === updated.id ? updated : item));
            }
            else {
                rows = [...this.pendencias, updated];
            }
            this.publish('pendencias', rows);
            this.publish('indicadores', response.data.indicadores);
            if (request === 'devolverTarefa')
                this.publish('devolverTarefaDraft', emptyDevolverTarefaDraft());
            this.publishCommandStatus(request, 'success');
        }
        catch (error) {
            const name = error instanceof Error ? error.name : 'unknown';
            this.publishCommandError(request, { code: 'client.unexpected', message: '', details: { name } });
            this.publishCommandStatus(request, 'error');
        }
    }
    /** request iniciarTarefa — starts a to-do task the session person is assignee of (aFazer to emAndamento); redraws pendencias (upsert the returned task by id) and indicadores (replace); argument id: the task row to start, its version is read from the loaded row */
    async iniciarTarefa(id) {
        await this.runCommand('iniciarTarefa', id, (version, signal) => {
            const input = { id, version };
            return execBff('tarefas.inicio.iniciarTarefa', input, { mode: 'blocking', signal });
        });
    }
    /** request enviarRevisao — sends an in-progress task (or resends a returned one) to review; redraws pendencias (upsert by id, or remove when the creator becomes the one who acts) and indicadores (replace); argument id: the task row to send, its version is read from the loaded row */
    async enviarRevisao(id) {
        await this.runCommand('enviarRevisao', id, (version, signal) => {
            const input = { id, version };
            return execBff('tarefas.inicio.enviarRevisao', input, { mode: 'blocking', signal });
        });
    }
    /** request aceitarTarefa — accepts the delivery of a task in review created by the session person, concluding it; redraws pendencias (the task leaves the list) and indicadores (replace); argument id: the task row to accept, its version is read from the loaded row */
    async aceitarTarefa(id) {
        await this.runCommand('aceitarTarefa', id, (version, signal) => {
            const input = { id, version };
            return execBff('tarefas.inicio.aceitarTarefa', input, { mode: 'blocking', signal });
        });
    }
    /** request devolverTarefa — returns a task in review to its assignee with a reason; the reason is read from devolverTarefaDraft.details.motivoDevolucao (required, otherwise client.requiredMissing and no call); redraws pendencias (upsert by id, or remove when the assignee becomes the one who acts), indicadores (replace) and clears the draft; argument id: the task row to return, its version is read from the loaded row */
    async devolverTarefa(id) {
        if (this.devolverTarefaStatus === 'loading')
            return;
        const rawReason = this.devolverTarefaDraft.details.motivoDevolucao;
        const motivoDevolucao = rawReason === null ? '' : rawReason.trim();
        if (motivoDevolucao === '') {
            this.publish('devolverTarefaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['devolverTarefaDraft.details.motivoDevolucao'] } });
            this.publish('devolverTarefaStatus', 'error');
            return;
        }
        await this.runCommand('devolverTarefa', id, (version, signal) => {
            const input = { id, version, details: { motivoDevolucao } };
            return execBff('tarefas.inicio.devolverTarefa', input, { mode: 'blocking', signal });
        });
    }
    /** request retomarTarefa — resumes a returned task the session person is assignee of, to continue the work; redraws pendencias (upsert the returned task by id) and indicadores (replace); argument id: the task row to resume, its version is read from the loaded row */
    async retomarTarefa(id) {
        await this.runCommand('retomarTarefa', id, (version, signal) => {
            const input = { id, version };
            return execBff('tarefas.inicio.retomarTarefa', input, { mode: 'blocking', signal });
        });
    }
    /** navigate — opens a pending task in Minhas tarefas (minhas_tarefas); argument tarefaId: id of the picked task, carried into the tarefaId param; null is refused with client.preconditionMissing */
    abrirTarefa(tarefaId) {
        if (tarefaId === null || tarefaId === '') {
            this.publish('carregarInicioError', { code: 'client.preconditionMissing', message: '', details: { params: ['tarefaId'] } });
            return;
        }
        auraNavigate(`/tarefas/minhas_tarefas?tarefaId=${encodeURIComponent(tarefaId)}`, { basePath: '/tarefas' });
    }
    /** navigate — opens a task due today or late, from the alerts, in Minhas tarefas (minhas_tarefas); argument tarefaId: id of the picked alert task, carried into the tarefaId param; null is refused with client.preconditionMissing */
    abrirTarefaVencendo(tarefaId) {
        if (tarefaId === null || tarefaId === '') {
            this.publish('carregarInicioError', { code: 'client.preconditionMissing', message: '', details: { params: ['tarefaId'] } });
            return;
        }
        auraNavigate(`/tarefas/minhas_tarefas?tarefaId=${encodeURIComponent(tarefaId)}`, { basePath: '/tarefas' });
    }
    /** navigate — opens Minhas tarefas (minhas_tarefas) from the counters; carries nothing */
    verMinhasTarefas() {
        auraNavigate('/tarefas/minhas_tarefas', { basePath: '/tarefas' });
    }
}
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "pendencias", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "alertas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "indicadores", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "permissoes", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "devolverTarefaDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "carregarInicioStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "carregarInicioError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "iniciarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "iniciarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "enviarRevisaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "enviarRevisaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "aceitarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "aceitarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "devolverTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "devolverTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "retomarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "retomarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicioShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/inicio_gestor.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.inicio_gestor.totais': 'totais',
    'ui.tarefas.inicio_gestor.listas': 'listas',
    'ui.tarefas.inicio_gestor.tarefas': 'tarefas',
    'ui.tarefas.inicio_gestor.page': 'page',
    'ui.tarefas.inicio_gestor.pageStatus': 'pageStatus',
    'ui.tarefas.inicio_gestor.qryPanoramaEquipeStatus': 'qryPanoramaEquipeStatus',
    'ui.tarefas.inicio_gestor.qryPanoramaEquipeError': 'qryPanoramaEquipeError',
    'ui.tarefas.inicio_gestor.qryTarefasPedemAcaoStatus': 'qryTarefasPedemAcaoStatus',
    'ui.tarefas.inicio_gestor.qryTarefasPedemAcaoError': 'qryTarefasPedemAcaoError',
    'ui.tarefas.inicio_gestor.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_STORAGE_KEY = 'tarefas.inicio_gestor.page';
const PAGE_SIZE = 20;
export class TarefasInicio_gestorShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state totais — team indicators already computed on the server (open, due today, overdue, checklist progress); source qryPanoramaEquipe.totais; organism destaquesEquipe */
        this.totais = null;
        /** state listas — active lists with their count of open tasks; source qryPanoramaEquipe.listas; organism destaquesEquipe */
        this.listas = [];
        /** state tarefas — page { items, page, pageSize, hasMore } of open tasks that are overdue or due today, with list and assignee; source qryTarefasPedemAcao.tarefas; organism tarefasPedemAcao */
        this.tarefas = null;
        /** state page — the page of the inbox the person went to with a pager (a "load more" never writes it); source entry.params.page; organism tarefasPedemAcao; persisted */
        this.page = null;
        /** state pageStatus — overall status of the page: loading while a request runs, error if one failed, empty when every list is empty, success otherwise; source page */
        this.pageStatus = 'idle';
        /** state qryPanoramaEquipeStatus — status of the team overview request; source qryPanoramaEquipe */
        this.qryPanoramaEquipeStatus = 'idle';
        /** state qryPanoramaEquipeError — error of the team overview request, null when none; source qryPanoramaEquipe */
        this.qryPanoramaEquipeError = null;
        /** state qryTarefasPedemAcaoStatus — status of the inbox request (also used by navigation errors); source qryTarefasPedemAcao */
        this.qryTarefasPedemAcaoStatus = 'idle';
        /** state qryTarefasPedemAcaoError — error of the inbox request, null when none; source qryTarefasPedemAcao */
        this.qryTarefasPedemAcaoError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.inicio_gestor.${member}`, value);
        if (member === 'page') {
            try {
                if (value === null || value === undefined) {
                    window.localStorage.removeItem(PAGE_STORAGE_KEY);
                }
                else {
                    window.localStorage.setItem(PAGE_STORAGE_KEY, String(value));
                }
            }
            catch {
                // storage unavailable: the value stays in memory only
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.loadInitial();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_MEMBER_BY_KEY[key]) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const totais = getState('ui.tarefas.inicio_gestor.totais');
        if (totais !== undefined)
            this.assignState('ui.tarefas.inicio_gestor.totais', totais);
        const listas = getState('ui.tarefas.inicio_gestor.listas');
        if (listas !== undefined)
            this.assignState('ui.tarefas.inicio_gestor.listas', listas);
        const tarefas = getState('ui.tarefas.inicio_gestor.tarefas');
        if (tarefas !== undefined)
            this.assignState('ui.tarefas.inicio_gestor.tarefas', tarefas);
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('qryPanoramaEquipeStatus', 'idle');
        this.publish('qryPanoramaEquipeError', null);
        this.publish('qryTarefasPedemAcaoStatus', 'idle');
        this.publish('qryTarefasPedemAcaoError', null);
        this.publish('scenary', '');
    }
    applyEntryParams() {
        let raw = new URLSearchParams(window.location.search).get('page');
        if (raw === null) {
            try {
                raw = window.localStorage.getItem(PAGE_STORAGE_KEY);
            }
            catch {
                raw = null;
            }
        }
        let value = null;
        if (raw !== null && raw !== '') {
            const parsed = Number(raw);
            if (Number.isFinite(parsed) && parsed >= 1)
                value = parsed;
        }
        this.publish('page', value);
    }
    async loadInitial() {
        await Promise.all([this.qryPanoramaEquipe(), this.qryTarefasPedemAcao()]);
    }
    updatePageStatus() {
        const a = this.qryPanoramaEquipeStatus;
        const b = this.qryTarefasPedemAcaoStatus;
        if (a === 'loading' || b === 'loading') {
            this.publish('pageStatus', 'loading');
            return;
        }
        if (a === 'error' || b === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        if (a === 'success' && b === 'success') {
            const noTasks = this.tarefas === null || this.tarefas.items.length === 0;
            this.publish('pageStatus', this.listas.length === 0 && noTasks ? 'empty' : 'success');
        }
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    /** setScenario — publishes the visible scene of the page (scenary); not persisted, not in the URL; scene: the scene name */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** request qryPanoramaEquipe — loads the team overview (totals of open, due today and overdue tasks, checklist progress, open tasks per list); redraws totais (replace) and listas (replace); no arguments; also the method to reload the overview */
    async qryPanoramaEquipe() {
        if (this.qryPanoramaEquipeStatus === 'loading')
            return;
        this.publish('qryPanoramaEquipeStatus', 'loading');
        this.publish('qryPanoramaEquipeError', null);
        this.updatePageStatus();
        try {
            const input = {};
            const response = await execBff('tarefas.inicio_gestor.qryPanoramaEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryPanoramaEquipeError', response.error ?? this.unexpectedError(null));
                this.publish('qryPanoramaEquipeStatus', 'error');
            }
            else {
                this.publish('totais', response.data.totais);
                this.publish('listas', response.data.listas);
                this.publish('qryPanoramaEquipeStatus', 'success');
            }
        }
        catch (error) {
            this.publish('qryPanoramaEquipeError', this.unexpectedError(error));
            this.publish('qryPanoramaEquipeStatus', 'error');
        }
        this.updatePageStatus();
    }
    /** request qryTarefasPedemAcao — loads the inbox of open tasks that are overdue or due today (overdue first); redraws tarefas (replace the page, or append the next page to items when append is true; append keeps page/hasMore inside tarefas and never writes the page state; a pager call with append false publishes the page state); page: page to load (default: the page state, else 1; with append, the next page); append: add the next page to the loaded items, ignored unless tarefas.hasMore */
    async qryTarefasPedemAcao(page, append = false) {
        if (this.qryTarefasPedemAcaoStatus === 'loading')
            return;
        const current = this.tarefas;
        if (append && (current === null || !current.hasMore))
            return;
        let target = 1;
        if (page !== undefined) {
            target = page;
        }
        else if (append && current !== null) {
            target = current.page + 1;
        }
        else if (this.page !== null) {
            target = this.page;
        }
        if (!Number.isFinite(target) || target < 1)
            target = 1;
        if (!append && page !== undefined)
            this.publish('page', target);
        this.publish('qryTarefasPedemAcaoStatus', 'loading');
        this.publish('qryTarefasPedemAcaoError', null);
        if (!append)
            this.updatePageStatus();
        try {
            const input = { page: target, pageSize: PAGE_SIZE };
            const response = await execBff('tarefas.inicio_gestor.qryTarefasPedemAcao', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryTarefasPedemAcaoError', response.error ?? this.unexpectedError(null));
                this.publish('qryTarefasPedemAcaoStatus', 'error');
            }
            else {
                const loaded = response.data.tarefas;
                if (append && current !== null) {
                    this.publish('tarefas', {
                        items: [...current.items, ...loaded.items],
                        page: loaded.page,
                        pageSize: loaded.pageSize,
                        hasMore: loaded.hasMore,
                    });
                }
                else {
                    this.publish('tarefas', loaded);
                }
                this.publish('qryTarefasPedemAcaoStatus', 'success');
            }
        }
        catch (error) {
            this.publish('qryTarefasPedemAcaoError', this.unexpectedError(error));
            this.publish('qryTarefasPedemAcaoStatus', 'error');
        }
        this.updatePageStatus();
    }
    /** navigate abrirTarefasEquipe — opens the team tasks page (board/list); listaId: optional list the person picked, carried as the listaId param of tarefas_equipe (omit to open it unfiltered) */
    abrirTarefasEquipe(listaId) {
        if (listaId !== undefined && listaId !== null && listaId !== '') {
            auraNavigate(`/tarefas/tarefas_equipe?listaId=${encodeURIComponent(listaId)}`, { basePath: '/tarefas' });
            return;
        }
        auraNavigate('/tarefas/tarefas_equipe', { basePath: '/tarefas' });
    }
    /** navigate abrirListas — opens the lists page; listaId: optional list the person picked, carried as the listaId param of listas (omit to just open it) */
    abrirListas(listaId) {
        if (listaId !== undefined && listaId !== null && listaId !== '') {
            auraNavigate(`/tarefas/listas?listaId=${encodeURIComponent(listaId)}`, { basePath: '/tarefas' });
            return;
        }
        auraNavigate('/tarefas/listas', { basePath: '/tarefas' });
    }
    /** navigate agirNaTarefa — opens the team tasks page on the chosen inbox task to reassign or cancel it; tarefaId: id of the task the person picked (null refuses with client.preconditionMissing in qryTarefasPedemAcaoError) */
    agirNaTarefa(tarefaId) {
        if (tarefaId === null || tarefaId === '') {
            this.publish('qryTarefasPedemAcaoError', {
                code: 'client.preconditionMissing',
                message: '',
                details: { params: ['tarefaId'] },
            });
            return;
        }
        auraNavigate(`/tarefas/tarefas_equipe?tarefaId=${encodeURIComponent(tarefaId)}`, { basePath: '/tarefas' });
    }
}
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "totais", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "page", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "qryPanoramaEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "qryPanoramaEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "qryTarefasPedemAcaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "qryTarefasPedemAcaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "scenary", void 0);

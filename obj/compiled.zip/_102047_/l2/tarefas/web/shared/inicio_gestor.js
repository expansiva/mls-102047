var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/inicio_gestor.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.inicio_gestor.listas': 'listas',
    'ui.tarefas.inicio_gestor.totalAbertas': 'totalAbertas',
    'ui.tarefas.inicio_gestor.totalVenceHoje': 'totalVenceHoje',
    'ui.tarefas.inicio_gestor.totalAtrasadas': 'totalAtrasadas',
    'ui.tarefas.inicio_gestor.progressoChecklist': 'progressoChecklist',
    'ui.tarefas.inicio_gestor.tarefas': 'tarefas',
    'ui.tarefas.inicio_gestor.selectedTarefa': 'selectedTarefa',
    'ui.tarefas.inicio_gestor.pageStatus': 'pageStatus',
    'ui.tarefas.inicio_gestor.obterPanoramaEquipeStatus': 'obterPanoramaEquipeStatus',
    'ui.tarefas.inicio_gestor.obterPanoramaEquipeError': 'obterPanoramaEquipeError',
    'ui.tarefas.inicio_gestor.listarTarefasParaAcaoStatus': 'listarTarefasParaAcaoStatus',
    'ui.tarefas.inicio_gestor.listarTarefasParaAcaoError': 'listarTarefasParaAcaoError',
    'ui.tarefas.inicio_gestor.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const DATA_KEYS = [
    'ui.tarefas.inicio_gestor.listas',
    'ui.tarefas.inicio_gestor.totalAbertas',
    'ui.tarefas.inicio_gestor.totalVenceHoje',
    'ui.tarefas.inicio_gestor.totalAtrasadas',
    'ui.tarefas.inicio_gestor.progressoChecklist',
    'ui.tarefas.inicio_gestor.tarefas',
];
const PAGE_SIZE = 20;
const TAREFA_ID_STORAGE_KEY = 'tarefas.inicio_gestor.tarefaId';
export class TarefasInicio_gestorShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state listas — the list of Lista (projeto ou área) with the count of open tasks each one has; source obterPanoramaEquipe.listas; organism destaquesEquipe */
        this.listas = [];
        /** state totalAbertas — total open tasks of the team; source obterPanoramaEquipe.totalAbertas; organism destaquesEquipe */
        this.totalAbertas = 0;
        /** state totalVenceHoje — total open tasks of the team due today; source obterPanoramaEquipe.totalVenceHoje; organism destaquesEquipe */
        this.totalVenceHoje = 0;
        /** state totalAtrasadas — total open tasks of the team that are overdue; source obterPanoramaEquipe.totalAtrasadas; organism destaquesEquipe */
        this.totalAtrasadas = 0;
        /** state progressoChecklist — overall checklist progress of the open tasks as 'done/total' text; source obterPanoramaEquipe.progressoChecklist; organism destaquesEquipe */
        this.progressoChecklist = '';
        /** state tarefas — the page { items, page, pageSize, hasMore } of team tasks that may ask for a manager decision (overdue and due today), with list name and assignee name; source listarTarefasParaAcao.tarefas; organism tarefasParaAcao */
        this.tarefas = null;
        /** state selectedTarefa — the id of the Tarefa selected in destaquesEquipe and tarefasParaAcao; the selected row is the getter tarefasParaAcao; source entry.params.tarefaId; organism destaquesEquipe, tarefasParaAcao; persisted */
        this.selectedTarefa = null;
        /** state pageStatus — overall status of the page: idle, loading, empty (every loaded list empty), success or error; written only by the initial/reload loads */
        this.pageStatus = 'idle';
        /** state obterPanoramaEquipeStatus — status of the obterPanoramaEquipe request */
        this.obterPanoramaEquipeStatus = 'idle';
        /** state obterPanoramaEquipeError — error of the obterPanoramaEquipe request, null when none */
        this.obterPanoramaEquipeError = null;
        /** state listarTarefasParaAcaoStatus — status of the listarTarefasParaAcao request */
        this.listarTarefasParaAcaoStatus = 'idle';
        /** state listarTarefasParaAcaoError — error of the listarTarefasParaAcao request (also client.selectionInvalid and client.preconditionMissing of selection and navigation), null when none */
        this.listarTarefasParaAcaoError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.inicio_gestor.${member}`, value);
        if (member === 'selectedTarefa') {
            try {
                if (value === null || value === undefined) {
                    localStorage.removeItem(TAREFA_ID_STORAGE_KEY);
                }
                else {
                    localStorage.setItem(TAREFA_ID_STORAGE_KEY, String(value));
                }
            }
            catch {
                // storage unavailable: the selection simply is not persisted
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        this.publish('pageStatus', 'loading');
        void this.obterPanoramaEquipe();
        void this.listarTarefasParaAcao();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        for (const key of DATA_KEYS) {
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('obterPanoramaEquipeStatus', 'idle');
        this.publish('obterPanoramaEquipeError', null);
        this.publish('listarTarefasParaAcaoStatus', 'idle');
        this.publish('listarTarefasParaAcaoError', null);
        this.publish('scenary', '');
    }
    applyEntryParams() {
        let raw = null;
        try {
            raw = new URLSearchParams(window.location.search).get('tarefaId');
        }
        catch {
            raw = null;
        }
        if (raw === null) {
            try {
                raw = localStorage.getItem(TAREFA_ID_STORAGE_KEY);
            }
            catch {
                raw = null;
            }
        }
        this.publish('selectedTarefa', raw !== null && raw !== '' ? raw : null);
    }
    /** setScenario — publishes the visible scene of the page (scenary) */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** select — selects the task with this id (null clears the selection); the selected row is read from the getter tarefasParaAcao; an id that no loaded row resolves publishes client.selectionInvalid in listarTarefasParaAcaoError and keeps the previous selection */
    selectTarefa(id) {
        if (id === null) {
            this.publish('selectedTarefa', null);
            return;
        }
        const loaded = this.tarefas;
        if (loaded !== null && !loaded.items.some(row => row.id === id)) {
            this.publish('listarTarefasParaAcaoError', {
                code: 'client.selectionInvalid',
                message: '',
                details: { tarefaId: id },
            });
            return;
        }
        const current = this.listarTarefasParaAcaoError;
        if (current !== null && current.code === 'client.selectionInvalid') {
            this.publish('listarTarefasParaAcaoError', null);
        }
        this.publish('selectedTarefa', id);
    }
    /** getter — the selected task: the loaded row of tarefas whose id is selectedTarefa, or null when nothing is selected or the row is not loaded */
    get tarefasParaAcao() {
        const id = this.selectedTarefa;
        const loaded = this.tarefas;
        if (id === null || loaded === null)
            return null;
        const found = loaded.items.find(row => row.id === id);
        return found !== undefined ? found : null;
    }
    refreshPageStatus() {
        const first = this.obterPanoramaEquipeStatus;
        const second = this.listarTarefasParaAcaoStatus;
        if (first === 'loading' || second === 'loading') {
            this.publish('pageStatus', 'loading');
            return;
        }
        if (first === 'error' || second === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        if (first === 'success' && second === 'success') {
            const listsEmpty = this.listas.length === 0;
            const tasksEmpty = this.tarefas === null || this.tarefas.items.length === 0;
            this.publish('pageStatus', listsEmpty && tasksEmpty ? 'empty' : 'success');
        }
    }
    /** request obterPanoramaEquipe — loads the team overview (open, due today and overdue totals, overall checklist progress and open tasks per list); redraws totalAbertas, totalVenceHoje, totalAtrasadas, progressoChecklist and listas (replace); no arguments, also the method to reload */
    async obterPanoramaEquipe() {
        if (this.obterPanoramaEquipeStatus === 'loading')
            return;
        this.publish('obterPanoramaEquipeStatus', 'loading');
        this.publish('obterPanoramaEquipeError', null);
        this.refreshPageStatus();
        try {
            const input = {};
            const response = await execBff('tarefas.inicio_gestor.obterPanoramaEquipe', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('obterPanoramaEquipeError', response.error);
                this.publish('obterPanoramaEquipeStatus', 'error');
                this.refreshPageStatus();
                return;
            }
            const output = response.data;
            this.publish('totalAbertas', output.totalAbertas);
            this.publish('totalVenceHoje', output.totalVenceHoje);
            this.publish('totalAtrasadas', output.totalAtrasadas);
            this.publish('progressoChecklist', output.progressoChecklist);
            this.publish('listas', [...output.listas]);
            this.publish('obterPanoramaEquipeStatus', 'success');
        }
        catch (error) {
            this.publish('obterPanoramaEquipeError', {
                code: 'client.unexpected',
                message: '',
                details: { name: error instanceof Error ? error.name : 'unknown' },
            });
            this.publish('obterPanoramaEquipeStatus', 'error');
        }
        this.refreshPageStatus();
    }
    /** request listarTarefasParaAcao — loads one page of team tasks that may ask for a manager decision (overdue first, then due today); redraws tarefas (replace by default; with append true the items of the page are added to the loaded ones and page/hasMore follow the response, doing nothing when tarefas.hasMore is false); arguments: page = page number starting at 1 (default 1), append = true for a "load more" */
    async listarTarefasParaAcao(page = 1, append = false) {
        if (this.listarTarefasParaAcaoStatus === 'loading')
            return;
        const previous = this.tarefas;
        if (append && (previous === null || !previous.hasMore))
            return;
        this.publish('listarTarefasParaAcaoStatus', 'loading');
        this.publish('listarTarefasParaAcaoError', null);
        this.refreshPageStatus();
        try {
            const input = {
                page,
                pageSize: previous !== null && previous.pageSize > 0 ? previous.pageSize : PAGE_SIZE,
            };
            const response = await execBff('tarefas.inicio_gestor.listarTarefasParaAcao', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarTarefasParaAcaoError', response.error);
                this.publish('listarTarefasParaAcaoStatus', 'error');
                this.refreshPageStatus();
                return;
            }
            const loaded = response.data.tarefas;
            const current = this.tarefas;
            if (append && current !== null) {
                this.publish('tarefas', {
                    items: [...current.items, ...loaded.items],
                    page: loaded.page,
                    pageSize: loaded.pageSize,
                    hasMore: loaded.hasMore,
                });
            }
            else {
                this.publish('tarefas', {
                    items: [...loaded.items],
                    page: loaded.page,
                    pageSize: loaded.pageSize,
                    hasMore: loaded.hasMore,
                });
            }
            this.publish('listarTarefasParaAcaoStatus', 'success');
            const selected = this.selectedTarefa;
            const shown = this.tarefas;
            if (selected !== null && shown !== null && !shown.items.some(row => row.id === selected)) {
                this.publish('listarTarefasParaAcaoError', {
                    code: 'client.selectionInvalid',
                    message: '',
                    details: { tarefaId: selected },
                });
            }
        }
        catch (error) {
            this.publish('listarTarefasParaAcaoError', {
                code: 'client.unexpected',
                message: '',
                details: { name: error instanceof Error ? error.name : 'unknown' },
            });
            this.publish('listarTarefasParaAcaoStatus', 'error');
        }
        this.refreshPageStatus();
    }
    /** navigate abrirTarefasEquipe — opens the team tasks page (tarefas_equipe) on the task the person picked; argument tarefaId = id of the picked task (defaults to the selected one); refuses with client.preconditionMissing in listarTarefasParaAcaoError when there is none */
    abrirTarefasEquipe(tarefaId = this.selectedTarefa) {
        if (tarefaId === null || tarefaId === '') {
            this.publish('listarTarefasParaAcaoError', {
                code: 'client.preconditionMissing',
                message: '',
                details: { params: ['tarefaId'] },
            });
            return;
        }
        auraNavigate(`/tarefas/tarefas_equipe?tarefaId=${encodeURIComponent(tarefaId)}`, { basePath: '/tarefas' });
    }
}
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "listas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "totalAbertas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "totalVenceHoje", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "totalAtrasadas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "progressoChecklist", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "tarefas", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "selectedTarefa", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "obterPanoramaEquipeStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "obterPanoramaEquipeError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "listarTarefasParaAcaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "listarTarefasParaAcaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_gestorShared.prototype, "scenary", void 0);

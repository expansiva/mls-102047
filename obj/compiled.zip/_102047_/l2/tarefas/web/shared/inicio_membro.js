var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/inicio_membro.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
function createEmptyDevolverComMotivoDraft() {
    return { id: null, version: null, details: { motivoDevolucao: null } };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.inicio_membro.resumo': 'resumo',
    'ui.tarefas.inicio_membro.avisoDoDia': 'avisoDoDia',
    'ui.tarefas.inicio_membro.esperaPorMim': 'esperaPorMim',
    'ui.tarefas.inicio_membro.devolverComMotivoDraft': 'devolverComMotivoDraft',
    'ui.tarefas.inicio_membro.pageStatus': 'pageStatus',
    'ui.tarefas.inicio_membro.carregarInicioStatus': 'carregarInicioStatus',
    'ui.tarefas.inicio_membro.carregarInicioError': 'carregarInicioError',
    'ui.tarefas.inicio_membro.iniciarTarefaStatus': 'iniciarTarefaStatus',
    'ui.tarefas.inicio_membro.iniciarTarefaError': 'iniciarTarefaError',
    'ui.tarefas.inicio_membro.enviarParaRevisaoStatus': 'enviarParaRevisaoStatus',
    'ui.tarefas.inicio_membro.enviarParaRevisaoError': 'enviarParaRevisaoError',
    'ui.tarefas.inicio_membro.aceitarEntregaStatus': 'aceitarEntregaStatus',
    'ui.tarefas.inicio_membro.aceitarEntregaError': 'aceitarEntregaError',
    'ui.tarefas.inicio_membro.devolverComMotivoStatus': 'devolverComMotivoStatus',
    'ui.tarefas.inicio_membro.devolverComMotivoError': 'devolverComMotivoError',
    'ui.tarefas.inicio_membro.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class TarefasInicio_membroShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state resumo — workload of the person: totals of open, due-today and overdue tasks and the most urgent open tasks; source carregarInicio.resumo; organism resumoMinhasTarefas */
        this.resumo = null;
        /** state avisoDoDia — daily due-date notice of the person for today, with delivery status and included tasks (null when not generated yet); source carregarInicio.avisoDoDia; organism avisoDoDia */
        this.avisoDoDia = null;
        /** state esperaPorMim — tasks that depend on the person grouped by expected action: start, send to review, review, adjust after return; source carregarInicio.esperaPorMim; organism esperaPorMim */
        this.esperaPorMim = null;
        /** state devolverComMotivoDraft — draft of the return-with-reason command (reason typed by the reviewer; id and version are filled when the command is submitted); source devolverComMotivo.input; organism esperaPorMim */
        this.devolverComMotivoDraft = createEmptyDevolverComMotivoDraft();
        /** state pageStatus — overall status of the page: idle, loading, empty (every list empty), success or error; written only by the initial load */
        this.pageStatus = 'idle';
        /** state carregarInicioStatus — status of the carregarInicio request */
        this.carregarInicioStatus = 'idle';
        /** state carregarInicioError — error of the carregarInicio request (also client errors of navigations), null when none */
        this.carregarInicioError = null;
        /** state iniciarTarefaStatus — status of the iniciarTarefa command */
        this.iniciarTarefaStatus = 'idle';
        /** state iniciarTarefaError — error of the iniciarTarefa command, null when none */
        this.iniciarTarefaError = null;
        /** state enviarParaRevisaoStatus — status of the enviarParaRevisao command */
        this.enviarParaRevisaoStatus = 'idle';
        /** state enviarParaRevisaoError — error of the enviarParaRevisao command, null when none */
        this.enviarParaRevisaoError = null;
        /** state aceitarEntregaStatus — status of the aceitarEntrega command */
        this.aceitarEntregaStatus = 'idle';
        /** state aceitarEntregaError — error of the aceitarEntrega command, null when none */
        this.aceitarEntregaError = null;
        /** state devolverComMotivoStatus — status of the devolverComMotivo command */
        this.devolverComMotivoStatus = 'idle';
        /** state devolverComMotivoError — error of the devolverComMotivo command, null when none */
        this.devolverComMotivoError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.subscribed = false;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.inicio_membro.${member}`, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    setRequestStatus(id, status) {
        switch (id) {
            case 'carregarInicio':
                this.publish('carregarInicioStatus', status);
                break;
            case 'iniciarTarefa':
                this.publish('iniciarTarefaStatus', status);
                break;
            case 'enviarParaRevisao':
                this.publish('enviarParaRevisaoStatus', status);
                break;
            case 'aceitarEntrega':
                this.publish('aceitarEntregaStatus', status);
                break;
            case 'devolverComMotivo':
                this.publish('devolverComMotivoStatus', status);
                break;
        }
    }
    setRequestError(id, error) {
        switch (id) {
            case 'carregarInicio':
                this.publish('carregarInicioError', error);
                break;
            case 'iniciarTarefa':
                this.publish('iniciarTarefaError', error);
                break;
            case 'enviarParaRevisao':
                this.publish('enviarParaRevisaoError', error);
                break;
            case 'aceitarEntrega':
                this.publish('aceitarEntregaError', error);
                break;
            case 'devolverComMotivo':
                this.publish('devolverComMotivoError', error);
                break;
        }
    }
    failRequest(id, error) {
        this.setRequestError(id, error);
        this.setRequestStatus(id, 'error');
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    resetCommandResults() {
        this.publish('iniciarTarefaStatus', 'idle');
        this.publish('iniciarTarefaError', null);
        this.publish('enviarParaRevisaoStatus', 'idle');
        this.publish('enviarParaRevisaoError', null);
        this.publish('aceitarEntregaStatus', 'idle');
        this.publish('aceitarEntregaError', null);
        this.publish('devolverComMotivoStatus', 'idle');
        this.publish('devolverComMotivoError', null);
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('carregarInicioStatus', 'idle');
        this.publish('carregarInicioError', null);
        this.resetCommandResults();
        this.publish('devolverComMotivoDraft', createEmptyDevolverComMotivoDraft());
        this.publish('scenary', '');
    }
    hydrateData() {
        const resumo = getState('ui.tarefas.inicio_membro.resumo');
        if (resumo !== undefined)
            this.assignState('ui.tarefas.inicio_membro.resumo', resumo);
        const aviso = getState('ui.tarefas.inicio_membro.avisoDoDia');
        if (aviso !== undefined)
            this.assignState('ui.tarefas.inicio_membro.avisoDoDia', aviso);
        const espera = getState('ui.tarefas.inicio_membro.esperaPorMim');
        if (espera !== undefined)
            this.assignState('ui.tarefas.inicio_membro.esperaPorMim', espera);
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        if (!this.subscribed) {
            subscribe([...STATE_KEYS], this);
            this.subscribed = true;
        }
        void Promise.resolve().then(() => {
            if (this.subscribed)
                void this.carregarInicio();
        });
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        this.subscribed = false;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    /** scene — publishes the visible scene of the page (any string; '' means no scene yet); clears the results of the commands */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the return-with-reason command (the reviewer types details.motivoDevolucao); clears the results of the commands */
    setDevolverComMotivoDraft(value) {
        this.resetCommandResults();
        this.publish('devolverComMotivoDraft', value);
    }
    /** request carregarInicio — loads the whole Início of the member: workload summary, today's daily notice and the pending tasks waiting for the person; redraws resumo, avisoDoDia and esperaPorMim (replace); no arguments, the person is the session's. Also the method to reload the page. */
    async carregarInicio() {
        if (this.carregarInicioStatus === 'loading')
            return;
        this.publish('carregarInicioStatus', 'loading');
        this.publish('carregarInicioError', null);
        this.publish('pageStatus', 'loading');
        const route = 'tarefas.inicio_membro.carregarInicio';
        const input = {};
        try {
            const response = await execBff(route, input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarInicioError', response.error);
                this.publish('carregarInicioStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const data = response.data;
            this.publish('resumo', data.resumo);
            this.publish('avisoDoDia', data.avisoDoDia ?? null);
            this.publish('esperaPorMim', data.esperaPorMim);
            const espera = data.esperaPorMim;
            const isEmpty = data.resumo.tarefas.length === 0 &&
                espera.paraIniciar.length === 0 &&
                espera.paraEnviarRevisao.length === 0 &&
                espera.paraRevisar.length === 0 &&
                espera.devolvidas.length === 0;
            this.publish('carregarInicioStatus', 'success');
            this.publish('pageStatus', isEmpty ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('carregarInicioError', this.unexpectedError(error));
            this.publish('carregarInicioStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    applyCommandOutput(output) {
        this.publish('resumo', output.resumo);
        this.publish('esperaPorMim', output.esperaPorMim);
    }
    async runTransition(requestId, route, id, version) {
        if (this.getRequestStatus(requestId) === 'loading')
            return;
        this.setRequestStatus(requestId, 'loading');
        this.setRequestError(requestId, null);
        if (!id) {
            this.failRequest(requestId, { code: 'client.requiredMissing', message: '', details: { stateKeys: ['id'] } });
            return;
        }
        const input = { id, version };
        try {
            const response = await runBlockingUiAction(signal => execBff(route, input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.failRequest(requestId, { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                return;
            }
            if (!response.ok || !response.data) {
                this.failRequest(requestId, response.error);
                return;
            }
            this.applyCommandOutput(response.data);
            this.setRequestStatus(requestId, 'success');
        }
        catch (error) {
            this.failRequest(requestId, this.unexpectedError(error));
        }
    }
    getRequestStatus(requestId) {
        switch (requestId) {
            case 'carregarInicio':
                return this.carregarInicioStatus;
            case 'iniciarTarefa':
                return this.iniciarTarefaStatus;
            case 'enviarParaRevisao':
                return this.enviarParaRevisaoStatus;
            case 'aceitarEntrega':
                return this.aceitarEntregaStatus;
            case 'devolverComMotivo':
                return this.devolverComMotivoStatus;
        }
    }
    /** request iniciarTarefa — starts a task assigned to the person (aFazer → emAndamento); redraws resumo and esperaPorMim (replace with the recalculated values); arguments: id = task to start, version = version read from the row (optimistic concurrency) */
    async iniciarTarefa(id, version) {
        await this.runTransition('iniciarTarefa', 'tarefas.inicio_membro.iniciarTarefa', id, version);
    }
    /** request enviarParaRevisao — sends an in-progress task of the person (also a returned one) to the creator's review; redraws resumo and esperaPorMim (replace with the recalculated values); arguments: id = task to send, version = version read from the row */
    async enviarParaRevisao(id, version) {
        await this.runTransition('enviarParaRevisao', 'tarefas.inicio_membro.enviarParaRevisao', id, version);
    }
    /** request aceitarEntrega — accepts the delivery of a task created by the person, completing it; redraws resumo and esperaPorMim (replace; the task leaves the to-review list); arguments: id = task in review, version = version read from the row */
    async aceitarEntrega(id, version) {
        await this.runTransition('aceitarEntrega', 'tarefas.inicio_membro.aceitarEntrega', id, version);
    }
    /** request devolverComMotivo — returns a task in review created by the person for adjustment, with the reason typed in devolverComMotivoDraft.details.motivoDevolucao; redraws resumo and esperaPorMim (replace; the task leaves the to-review list) and clears the draft; arguments: id = task in review, version = version read from the row */
    async devolverComMotivo(id, version) {
        if (this.devolverComMotivoStatus === 'loading')
            return;
        this.publish('devolverComMotivoStatus', 'loading');
        this.publish('devolverComMotivoError', null);
        const motivoRaw = this.devolverComMotivoDraft.details.motivoDevolucao;
        const motivo = motivoRaw === null ? '' : motivoRaw.trim();
        const missing = [];
        if (!id)
            missing.push('ui.tarefas.inicio_membro.devolverComMotivoDraft.id');
        if (motivo === '')
            missing.push('ui.tarefas.inicio_membro.devolverComMotivoDraft.details.motivoDevolucao');
        if (missing.length > 0) {
            this.failRequest('devolverComMotivo', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            return;
        }
        const route = 'tarefas.inicio_membro.devolverComMotivo';
        const input = { id, version, details: { motivoDevolucao: motivo } };
        try {
            const response = await runBlockingUiAction(signal => execBff(route, input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.failRequest('devolverComMotivo', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                return;
            }
            if (!response.ok || !response.data) {
                this.failRequest('devolverComMotivo', response.error);
                return;
            }
            this.applyCommandOutput(response.data);
            this.publish('devolverComMotivoDraft', createEmptyDevolverComMotivoDraft());
            this.publish('devolverComMotivoStatus', 'success');
        }
        catch (error) {
            this.failRequest('devolverComMotivo', this.unexpectedError(error));
        }
    }
    /** navigate — opens the person's task list (minhas_tarefas); carries nothing */
    abrirMinhasTarefas() {
        auraNavigate('/tarefas/minhas_tarefas', { basePath: '/tarefas' });
    }
    /** navigate — opens the daily notices page (meus_avisos), carrying today's notice id as avisoVencimentoId when the notice exists */
    abrirMeusAvisos() {
        const avisoId = this.avisoDoDia ? this.avisoDoDia.id : '';
        if (avisoId) {
            auraNavigate(`/tarefas/meus_avisos?avisoVencimentoId=${encodeURIComponent(avisoId)}`, { basePath: '/tarefas' });
            return;
        }
        auraNavigate('/tarefas/meus_avisos', { basePath: '/tarefas' });
    }
    /** navigate — opens minhas_tarefas with the picked task selected (tarefaId); argument: tarefaId = id of the task row the person opens; null is refused with client.preconditionMissing in carregarInicioError */
    abrirTarefaParaAjustar(tarefaId) {
        if (tarefaId === null || tarefaId === '') {
            this.publish('carregarInicioError', { code: 'client.preconditionMissing', message: '', details: { params: ['tarefaId'] } });
            return;
        }
        auraNavigate(`/tarefas/minhas_tarefas?tarefaId=${encodeURIComponent(tarefaId)}`, { basePath: '/tarefas' });
    }
}
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "resumo", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "avisoDoDia", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "esperaPorMim", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "devolverComMotivoDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "carregarInicioStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "carregarInicioError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "iniciarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "iniciarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "enviarParaRevisaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "enviarParaRevisaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "aceitarEntregaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "aceitarEntregaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "devolverComMotivoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "devolverComMotivoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/shared/inicio_membro.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
function emptyDevolverComMotivoDraft() {
    return { id: null, version: null, details: { motivoDevolucao: null } };
}
const STATE_MEMBER_BY_KEY = {
    'ui.tarefas.inicio_membro.resumo': 'resumo',
    'ui.tarefas.inicio_membro.avisoDoDia': 'avisoDoDia',
    'ui.tarefas.inicio_membro.esperaPorMim': 'esperaPorMim',
    'ui.tarefas.inicio_membro.devolverComMotivoDraft': 'devolverComMotivoDraft',
    'ui.tarefas.inicio_membro.pageStatus': 'pageStatus',
    'ui.tarefas.inicio_membro.carregarInicioStatus': 'carregarInicioStatus',
    'ui.tarefas.inicio_membro.carregarInicioError': 'carregarInicioError',
    'ui.tarefas.inicio_membro.iniciarTarefaStatus': 'iniciarTarefaStatus',
    'ui.tarefas.inicio_membro.iniciarTarefaError': 'iniciarTarefaError',
    'ui.tarefas.inicio_membro.enviarParaRevisaoStatus': 'enviarParaRevisaoStatus',
    'ui.tarefas.inicio_membro.enviarParaRevisaoError': 'enviarParaRevisaoError',
    'ui.tarefas.inicio_membro.aceitarEntregaStatus': 'aceitarEntregaStatus',
    'ui.tarefas.inicio_membro.aceitarEntregaError': 'aceitarEntregaError',
    'ui.tarefas.inicio_membro.devolverComMotivoStatus': 'devolverComMotivoStatus',
    'ui.tarefas.inicio_membro.devolverComMotivoError': 'devolverComMotivoError',
    'ui.tarefas.inicio_membro.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class TarefasInicio_membroShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state resumo — workload of the person: totals of open, due-today and overdue tasks and the most urgent open tasks; source carregarInicio.resumo; organism resumoMinhasTarefas */
        this.resumo = null;
        /** state avisoDoDia — today's daily due-date notice with delivery status and included tasks (null when not generated yet); source carregarInicio.avisoDoDia; organism avisoDoDia */
        this.avisoDoDia = null;
        /** state esperaPorMim — tasks waiting for the person, grouped by expected action: paraIniciar, paraEnviarRevisao, paraRevisar, devolvidas; source carregarInicio.esperaPorMim; organism esperaPorMim */
        this.esperaPorMim = null;
        /** state devolverComMotivoDraft — draft of the return-with-reason form (the typed reason lives in details.motivoDevolucao); source devolverComMotivo.input; organism esperaPorMim */
        this.devolverComMotivoDraft = emptyDevolverComMotivoDraft();
        /** state pageStatus — overall status of the page: idle, loading, empty (nothing loaded in any list), success or error; source carregarInicio */
        this.pageStatus = 'idle';
        /** state carregarInicioStatus — status of the initial load request; source carregarInicio */
        this.carregarInicioStatus = 'idle';
        /** state carregarInicioError — error of the initial load request (also used by navigations refused on a missing value); source carregarInicio */
        this.carregarInicioError = null;
        /** state iniciarTarefaStatus — status of the start-task command; source iniciarTarefa */
        this.iniciarTarefaStatus = 'idle';
        /** state iniciarTarefaError — error of the start-task command; source iniciarTarefa */
        this.iniciarTarefaError = null;
        /** state enviarParaRevisaoStatus — status of the send-to-review command; source enviarParaRevisao */
        this.enviarParaRevisaoStatus = 'idle';
        /** state enviarParaRevisaoError — error of the send-to-review command; source enviarParaRevisao */
        this.enviarParaRevisaoError = null;
        /** state aceitarEntregaStatus — status of the accept-delivery command; source aceitarEntrega */
        this.aceitarEntregaStatus = 'idle';
        /** state aceitarEntregaError — error of the accept-delivery command; source aceitarEntrega */
        this.aceitarEntregaError = null;
        /** state devolverComMotivoStatus — status of the return-with-reason command; source devolverComMotivo */
        this.devolverComMotivoStatus = 'idle';
        /** state devolverComMotivoError — error of the return-with-reason command; source devolverComMotivo */
        this.devolverComMotivoError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.tarefas.inicio_membro.${member}`, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        const resumo = getState('ui.tarefas.inicio_membro.resumo');
        if (resumo !== undefined)
            this.assignState('ui.tarefas.inicio_membro.resumo', resumo);
        const aviso = getState('ui.tarefas.inicio_membro.avisoDoDia');
        if (aviso !== undefined)
            this.assignState('ui.tarefas.inicio_membro.avisoDoDia', aviso);
        const espera = getState('ui.tarefas.inicio_membro.esperaPorMim');
        if (espera !== undefined)
            this.assignState('ui.tarefas.inicio_membro.esperaPorMim', espera);
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        void this.carregarInicio();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('scenary', '');
        this.publish('carregarInicioStatus', 'idle');
        this.publish('carregarInicioError', null);
        this.publish('devolverComMotivoDraft', emptyDevolverComMotivoDraft());
        this.resetCommandResults();
    }
    resetCommandResults() {
        this.publish('iniciarTarefaStatus', 'idle');
        this.publish('iniciarTarefaError', null);
        this.publish('enviarParaRevisaoStatus', 'idle');
        this.publish('enviarParaRevisaoError', null);
        this.publish('aceitarEntregaStatus', 'idle');
        this.publish('aceitarEntregaError', null);
        this.publish('devolverComMotivoStatus', 'idle');
        this.publish('devolverComMotivoError', null);
    }
    unexpected(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    /** Finds the version of a pending task by id across the four pending lists (picks an element, computes nothing). */
    findVersion(id) {
        const espera = this.esperaPorMim;
        if (!espera)
            return null;
        const groups = [espera.paraIniciar, espera.paraEnviarRevisao, espera.paraRevisar, espera.devolvidas];
        for (const group of groups) {
            const found = group.find((item) => item.id === id);
            if (found)
                return found.version;
        }
        return null;
    }
    isEverythingEmpty(resumo, espera) {
        return (resumo.tarefas.length === 0 &&
            espera.paraIniciar.length === 0 &&
            espera.paraEnviarRevisao.length === 0 &&
            espera.paraRevisar.length === 0 &&
            espera.devolvidas.length === 0);
    }
    applyCommandOutput(output) {
        this.publish('resumo', output.resumo);
        this.publish('esperaPorMim', output.esperaPorMim);
    }
    /** setScenario — publishes the visible scene of the page; clears the results of every command. */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the draft of the return-with-reason form (set details.motivoDevolucao with the typed reason); clears the results of every command. */
    setDevolverComMotivoDraft(value) {
        this.resetCommandResults();
        this.publish('devolverComMotivoDraft', value);
    }
    /** request carregarInicio — loads the workload summary, today's daily notice and the tasks waiting for the person (the person is the session's); redraws resumo, avisoDoDia and esperaPorMim by replace; no arguments, also the method to reload the page */
    async carregarInicio() {
        if (this.carregarInicioStatus === 'loading')
            return;
        this.publish('carregarInicioStatus', 'loading');
        this.publish('carregarInicioError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = {};
            const response = await execBff('tarefas.inicio_membro.carregarInicio', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('carregarInicioError', response.error);
                this.publish('carregarInicioStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const data = response.data;
            this.publish('resumo', data.resumo);
            this.publish('avisoDoDia', data.avisoDoDia ?? null);
            this.publish('esperaPorMim', data.esperaPorMim);
            this.publish('carregarInicioStatus', 'success');
            this.publish('pageStatus', this.isEverythingEmpty(data.resumo, data.esperaPorMim) ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('carregarInicioError', this.unexpected(error));
            this.publish('carregarInicioStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** request iniciarTarefa — starts a task assigned to the person (aFazer to emAndamento); redraws resumo and esperaPorMim by replace with the recalculated values; id: the pending task to start (its version is read from esperaPorMim) */
    async iniciarTarefa(id) {
        if (this.iniciarTarefaStatus === 'loading')
            return;
        const version = this.findVersion(id);
        if (version === null) {
            this.publish('iniciarTarefaError', { code: 'client.selectionInvalid', message: '', details: { id } });
            this.publish('iniciarTarefaStatus', 'error');
            return;
        }
        this.publish('iniciarTarefaStatus', 'loading');
        this.publish('iniciarTarefaError', null);
        try {
            const input = { id, version };
            const response = await runBlockingUiAction((signal) => execBff('tarefas.inicio_membro.iniciarTarefa', input, { mode: 'blocking', signal }));
            if (!response) {
                this.publish('iniciarTarefaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('iniciarTarefaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('iniciarTarefaError', response.error);
                this.publish('iniciarTarefaStatus', 'error');
                return;
            }
            this.applyCommandOutput(response.data);
            this.publish('iniciarTarefaStatus', 'success');
        }
        catch (error) {
            this.publish('iniciarTarefaError', this.unexpected(error));
            this.publish('iniciarTarefaStatus', 'error');
        }
    }
    /** request enviarParaRevisao — sends an in-progress task of the person (also a returned one) to the creator's review; redraws resumo and esperaPorMim by replace with the recalculated values; id: the pending task to send (its version is read from esperaPorMim) */
    async enviarParaRevisao(id) {
        if (this.enviarParaRevisaoStatus === 'loading')
            return;
        const version = this.findVersion(id);
        if (version === null) {
            this.publish('enviarParaRevisaoError', { code: 'client.selectionInvalid', message: '', details: { id } });
            this.publish('enviarParaRevisaoStatus', 'error');
            return;
        }
        this.publish('enviarParaRevisaoStatus', 'loading');
        this.publish('enviarParaRevisaoError', null);
        try {
            const input = { id, version };
            const response = await runBlockingUiAction((signal) => execBff('tarefas.inicio_membro.enviarParaRevisao', input, { mode: 'blocking', signal }));
            if (!response) {
                this.publish('enviarParaRevisaoError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('enviarParaRevisaoStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('enviarParaRevisaoError', response.error);
                this.publish('enviarParaRevisaoStatus', 'error');
                return;
            }
            this.applyCommandOutput(response.data);
            this.publish('enviarParaRevisaoStatus', 'success');
        }
        catch (error) {
            this.publish('enviarParaRevisaoError', this.unexpected(error));
            this.publish('enviarParaRevisaoStatus', 'error');
        }
    }
    /** request aceitarEntrega — accepts the delivery of a task the person created, concluding it; redraws resumo and esperaPorMim by replace (the task leaves paraRevisar); id: the task in review (its version is read from esperaPorMim) */
    async aceitarEntrega(id) {
        if (this.aceitarEntregaStatus === 'loading')
            return;
        const version = this.findVersion(id);
        if (version === null) {
            this.publish('aceitarEntregaError', { code: 'client.selectionInvalid', message: '', details: { id } });
            this.publish('aceitarEntregaStatus', 'error');
            return;
        }
        this.publish('aceitarEntregaStatus', 'loading');
        this.publish('aceitarEntregaError', null);
        try {
            const input = { id, version };
            const response = await runBlockingUiAction((signal) => execBff('tarefas.inicio_membro.aceitarEntrega', input, { mode: 'blocking', signal }));
            if (!response) {
                this.publish('aceitarEntregaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('aceitarEntregaStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('aceitarEntregaError', response.error);
                this.publish('aceitarEntregaStatus', 'error');
                return;
            }
            this.applyCommandOutput(response.data);
            this.publish('aceitarEntregaStatus', 'success');
        }
        catch (error) {
            this.publish('aceitarEntregaError', this.unexpected(error));
            this.publish('aceitarEntregaStatus', 'error');
        }
    }
    /** request devolverComMotivo — returns a task in review that the person created back for adjustment, with the reason typed in devolverComMotivoDraft.details.motivoDevolucao; redraws resumo and esperaPorMim by replace and clears the draft; id: the task in review (its version is read from esperaPorMim) */
    async devolverComMotivo(id) {
        if (this.devolverComMotivoStatus === 'loading')
            return;
        const version = this.findVersion(id);
        if (version === null) {
            this.publish('devolverComMotivoError', { code: 'client.selectionInvalid', message: '', details: { id } });
            this.publish('devolverComMotivoStatus', 'error');
            return;
        }
        const motivo = this.devolverComMotivoDraft.details.motivoDevolucao;
        if (motivo === null || motivo.trim() === '') {
            this.publish('devolverComMotivoError', {
                code: 'client.requiredMissing',
                message: '',
                details: { stateKeys: ['ui.tarefas.inicio_membro.devolverComMotivoDraft'] },
            });
            this.publish('devolverComMotivoStatus', 'error');
            return;
        }
        this.publish('devolverComMotivoStatus', 'loading');
        this.publish('devolverComMotivoError', null);
        try {
            const input = { id, version, details: { motivoDevolucao: motivo } };
            const response = await runBlockingUiAction((signal) => execBff('tarefas.inicio_membro.devolverComMotivo', input, { mode: 'blocking', signal }));
            if (!response) {
                this.publish('devolverComMotivoError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish('devolverComMotivoStatus', 'error');
                return;
            }
            if (!response.ok || !response.data) {
                this.publish('devolverComMotivoError', response.error);
                this.publish('devolverComMotivoStatus', 'error');
                return;
            }
            this.applyCommandOutput(response.data);
            this.publish('devolverComMotivoDraft', emptyDevolverComMotivoDraft());
            this.publish('devolverComMotivoStatus', 'success');
        }
        catch (error) {
            this.publish('devolverComMotivoError', this.unexpected(error));
            this.publish('devolverComMotivoStatus', 'error');
        }
    }
    /** navigate — opens the page minhas_tarefas (carries nothing) from the workload summary */
    abrirMinhasTarefas() {
        auraNavigate('/tarefas/minhas_tarefas', { basePath: '/tarefas' });
    }
    /** navigate — opens the page meus_avisos, carrying today's notice id (avisoVencimentoId) when the notice exists */
    abrirMeusAvisos() {
        const aviso = this.avisoDoDia;
        if (aviso && aviso.id) {
            auraNavigate(`/tarefas/meus_avisos?avisoVencimentoId=${encodeURIComponent(aviso.id)}`, { basePath: '/tarefas' });
            return;
        }
        auraNavigate('/tarefas/meus_avisos', { basePath: '/tarefas' });
    }
    /** navigate — opens minhas_tarefas with the given task selected (tarefaId) so the person adjusts a returned task; tarefaId: id of the task picked */
    abrirTarefaParaAjustar(tarefaId) {
        if (tarefaId === null || tarefaId === '') {
            this.publish('carregarInicioError', { code: 'client.preconditionMissing', message: '', details: { params: ['tarefaId'] } });
            return;
        }
        auraNavigate(`/tarefas/minhas_tarefas?tarefaId=${encodeURIComponent(tarefaId)}`, { basePath: '/tarefas' });
    }
}
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "resumo", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "avisoDoDia", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "esperaPorMim", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "devolverComMotivoDraft", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "carregarInicioStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "carregarInicioError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "iniciarTarefaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "iniciarTarefaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "enviarParaRevisaoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "enviarParaRevisaoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "aceitarEntregaStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "aceitarEntregaError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "devolverComMotivoStatus", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "devolverComMotivoError", void 0);
__decorate([
    property({ attribute: false })
], TarefasInicio_membroShared.prototype, "scenary", void 0);

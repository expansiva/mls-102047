var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/tarefas_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasTarefas_equipeShared } from '/_102047_/l2/tarefas/web/shared/tarefas_equipe.js';
import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown.js';
import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card.js';
import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102040_/l2/molecules/groupviewtable/ml-advanced-data-table.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Tarefas da equipe',
    pageSubtitle: 'Acompanhe o andamento de todas as tarefas, filtre onde precisar e abra uma tarefa para agir sobre ela.',
    filtrosAria: 'Filtros do quadro',
    filtroLista: 'Lista',
    filtroListaTodas: 'Todas as listas',
    filtroResponsavel: 'Responsável',
    filtroResponsavelTodos: 'Todos os responsáveis',
    filtroPrioridade: 'Prioridade',
    filtroPrioridadeTodas: 'Todas as prioridades',
    filtroSituacao: 'Situação',
    filtroSituacaoTodas: 'Todas as situações',
    filtroPrazo: 'Prazo',
    prazoDe: 'De',
    prazoAte: 'Até',
    venceHoje: 'Vencem hoje',
    atrasadas: 'Atrasadas',
    limparFiltros: 'Limpar filtros',
    prioridadeLow: 'Baixa',
    prioridadeMedium: 'Média',
    prioridadeHigh: 'Alta',
    statusAFazer: 'A fazer',
    statusEmAndamento: 'Em andamento',
    statusEmRevisao: 'Em revisão',
    statusConcluida: 'Concluída',
    statusCancelada: 'Cancelada',
    colTarefa: 'Tarefa',
    colResponsavel: 'Responsável',
    colPrioridade: 'Prioridade',
    colSituacao: 'Situação',
    colChecklist: 'Checklist',
    colPrazo: 'Prazo',
    selVenceHoje: 'Vence hoje',
    selAtrasada: 'Atrasada',
    quadroVazio: 'Nenhuma tarefa encontrada com estes filtros.',
    quadroVazioDica: 'Ajuste ou limpe os filtros para ver mais tarefas.',
    quadroCarregando: 'Carregando tarefas…',
    carregarMais: 'Carregar mais tarefas',
    erroQuadro: 'Não foi possível carregar as tarefas da equipe.',
    tentarNovamente: 'Tentar novamente',
    precondTitulo: 'Faltam informações para abrir o quadro',
    precondTexto: 'Esta tela foi aberta sem o contexto de que precisa. Volte para a tela anterior e abra o quadro de tarefas da equipe novamente.',
    voltar: 'Voltar',
    cenaDetalhe: 'Detalhe da tarefa',
    cenaConfirmar: 'Confirmar cancelamento',
    semSelecao: 'Escolha uma tarefa no quadro para ver o detalhe, a checklist e o histórico, e para trocar o responsável ou cancelar.',
    detalheCarregando: 'Abrindo a tarefa…',
    detalheErro: 'Não foi possível abrir esta tarefa.',
    semDescricao: 'Sem descrição.',
    criadaPor: 'Criada por',
    criadaEm: 'Criada em',
    responsavel: 'Responsável',
    prazo: 'Prazo',
    situacao: 'Situação',
    subtarefas: 'Subtarefas',
    progresso: 'Progresso da checklist',
    checklistTitulo: 'Checklist',
    checklistColItem: 'Item',
    checklistColSituacao: 'Situação',
    itemFeito: 'Feito',
    itemPendente: 'Pendente',
    semChecklist: 'Esta tarefa não tem itens na checklist.',
    acoesTitulo: 'Ações do gestor',
    novoResponsavel: 'Novo responsável',
    novoResponsavelDica: 'Só pessoas ativas da equipe podem receber a tarefa. A pessoa escolhida é avisada.',
    buscarMembro: 'Buscar pela equipe',
    semMembro: 'Nenhuma pessoa encontrada.',
    membroIndisponivel: 'indisponível',
    trocarResponsavel: 'Trocar responsável',
    cancelarTarefa: 'Cancelar tarefa',
    tarefaEncerrada: 'Esta tarefa já está encerrada e não muda mais de situação.',
    reatribuirOk: 'Responsável trocado. A pessoa escolhida foi avisada.',
    reatribuirErro: 'Não foi possível trocar o responsável. Confira a escolha e tente de novo.',
    confirmarTexto: 'Você vai cancelar a tarefa',
    confirmarEfeito: 'Ela passa para cancelada e não muda mais de situação.',
    confirmarSim: 'Sim, encerrar esta tarefa',
    confirmarNao: 'Manter a tarefa',
    cancelarOk: 'Tarefa cancelada.',
    cancelarErro: 'Não foi possível cancelar a tarefa. Tente de novo.',
    voltarTarefa: 'Voltar à tarefa',
    historicoTitulo: 'Histórico',
    histColQuando: 'Quando',
    histColEvento: 'Evento',
    histCriada: 'Tarefa criada',
    histPor: 'por',
    histDevolvida: 'Devolvida para ajuste',
    histMotivo: 'Motivo',
    histConcluida: 'Concluída',
    histCancelada: 'Cancelada'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
const ALL = '__todos__';
function orNull(v) {
    return v === null || v === ALL ? null : v;
}
function lang() {
    return document.documentElement.lang || undefined;
}
function fmtDate(iso) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
    const d = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : new Date(iso);
    if (Number.isNaN(d.getTime()))
        return iso;
    return new Intl.DateTimeFormat(lang(), { dateStyle: 'medium' }).format(d);
}
function fmtDateTime(iso) {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime()))
        return iso;
    return new Intl.DateTimeFormat(lang(), { dateStyle: 'medium', timeStyle: 'short' }).format(d);
}
function statusClass(s) {
    switch (s) {
        case 'emAndamento':
            return 'bg-[var(--status-info-bg,transparent)] text-[var(--status-info-text,currentColor)]';
        case 'emRevisao':
            return 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]';
        case 'concluida':
            return 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]';
        default:
            return 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]';
    }
}
let TarefasDesktopPage11Tarefas_equipePage = class TarefasDesktopPage11Tarefas_equipePage extends TarefasTarefas_equipeShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    statusLabel(s) {
        switch (s) {
            case 'aFazer': return this.msg['statusAFazer'];
            case 'emAndamento': return this.msg['statusEmAndamento'];
            case 'emRevisao': return this.msg['statusEmRevisao'];
            case 'concluida': return this.msg['statusConcluida'];
            default: return this.msg['statusCancelada'];
        }
    }
    prioridadeLabel(p) {
        switch (p) {
            case 'low': return this.msg['prioridadeLow'];
            case 'medium': return this.msg['prioridadeMedium'];
            default: return this.msg['prioridadeHigh'];
        }
    }
    chip(s) {
        return html `<span class="inline-block rounded-full px-2 py-0.5 text-xs font-medium ${statusClass(s)}">${this.statusLabel(s)}</span>`;
    }
    filtro(label, value, itens, onChange) {
        return html `
<groupselectone--ml-select-dropdown
class="min-w-[11rem] flex-1"
.value=${value}
@change=${(e) => onChange(e.detail.value)}>
<Label>${label}</Label>
${itens}
</groupselectone--ml-select-dropdown>`;
    }
    renderFiltros() {
        return html `
<div role="search" aria-label=${this.msg['filtrosAria']}
class="flex flex-wrap items-end gap-3 rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] p-3">
${this.filtro(this.msg['filtroLista'], this.listaId ?? ALL, html `
<Item value=${ALL}>${this.msg['filtroListaTodas']}</Item>
${this.listas.map((l) => html `<Item value=${l.id}>${l.nome}</Item>`)}`, (v) => { this.listarTarefasEquipe({ listaId: orNull(v) }, 1); })}
${this.filtro(this.msg['filtroResponsavel'], this.responsavelId ?? ALL, html `
<Item value=${ALL}>${this.msg['filtroResponsavelTodos']}</Item>
${this.membros.map((m) => html `<Item value=${m.id}>${m.details.identification.name}</Item>`)}`, (v) => { this.listarTarefasEquipe({ responsavelId: orNull(v) }, 1); })}
${this.filtro(this.msg['filtroPrioridade'], this.prioridade ?? ALL, html `
<Item value=${ALL}>${this.msg['filtroPrioridadeTodas']}</Item>
<Item value="high">${this.msg['prioridadeHigh']}</Item>
<Item value="medium">${this.msg['prioridadeMedium']}</Item>
<Item value="low">${this.msg['prioridadeLow']}</Item>`, (v) => {
            const o = orNull(v);
            this.listarTarefasEquipe({ prioridade: o === null ? null : o }, 1);
        })}
${this.filtro(this.msg['filtroSituacao'], this.status ?? ALL, html `
<Item value=${ALL}>${this.msg['filtroSituacaoTodas']}</Item>
<Item value="aFazer">${this.msg['statusAFazer']}</Item>
<Item value="emAndamento">${this.msg['statusEmAndamento']}</Item>
<Item value="emRevisao">${this.msg['statusEmRevisao']}</Item>
<Item value="concluida">${this.msg['statusConcluida']}</Item>
<Item value="cancelada">${this.msg['statusCancelada']}</Item>`, (v) => {
            const o = orNull(v);
            this.listarTarefasEquipe({ status: o === null ? null : o }, 1);
        })}
<groupenterdateinterval--ml-date-interval-presets
class="min-w-[18rem]"
locale="pt-BR"
.startDate=${this.prazoDe}
.endDate=${this.prazoAte}
@change=${(e) => {
            this.listarTarefasEquipe({ prazoDe: e.detail.startDate, prazoAte: e.detail.endDate }, 1);
        }}>
<Label>${this.msg['filtroPrazo']}</Label>
<LabelStart>${this.msg['prazoDe']}</LabelStart>
<LabelEnd>${this.msg['prazoAte']}</LabelEnd>
</groupenterdateinterval--ml-date-interval-presets>
<div class="flex items-center gap-4 pb-2">
<label class="flex min-h-[44px] cursor-pointer items-center gap-2 text-sm">
<input type="checkbox" class="h-4 w-4 focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]"
.checked=${this.venceHoje === true}
@change=${(e) => { this.listarTarefasEquipe({ venceHoje: e.target.checked ? true : null }, 1); }} />
${this.msg['venceHoje']}
</label>
<label class="flex min-h-[44px] cursor-pointer items-center gap-2 text-sm">
<input type="checkbox" class="h-4 w-4 focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]"
.checked=${this.atrasada === true}
@change=${(e) => { this.listarTarefasEquipe({ atrasada: e.target.checked ? true : null }, 1); }} />
${this.msg['atrasadas']}
</label>
<grouptriggeraction--ml-button-standard data-variant="secondary" size="sm"
@action=${() => {
            this.listarTarefasEquipe({
                listaId: null, responsavelId: null, prioridade: null, status: null,
                prazoDe: null, prazoAte: null, venceHoje: null, atrasada: null
            }, 1);
        }}>
<Label>${this.msg['limparFiltros']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</div>`;
    }
    renderLinha(item) {
        const atrasada = item.details.atrasada;
        return html `
<TableRow key=${item.id}>
<TableCell>
<div class="font-medium text-[var(--text-strong,currentColor)]">${item.titulo}</div>
<div class="text-xs text-[var(--text-muted,currentColor)]">${item.lista.nome}</div>
</TableCell>
<TableCell>${item.responsavel.details.identification.name}</TableCell>
<TableCell><span class=${item.prioridade === 'high' ? 'font-semibold' : ''}>${this.prioridadeLabel(item.prioridade)}</span></TableCell>
<TableCell>${this.chip(item.status)}</TableCell>
<TableCell>${item.details.progressoChecklist}</TableCell>
<TableCell>
<div class="flex flex-col items-end gap-1 text-right">
<span class=${atrasada ? 'font-semibold text-[var(--status-error-text,currentColor)]' : ''}>${fmtDate(item.prazo)}</span>
${atrasada ? html `<span class="text-xs text-[var(--status-error-text,currentColor)]">${this.msg['selAtrasada']}</span>` : nothing}
${item.details.venceHoje
            ? html `<span class="rounded-full px-2 py-0.5 text-xs bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]">${this.msg['selVenceHoje']}</span>`
            : nothing}
</div>
</TableCell>
</TableRow>`;
    }
    renderQuadro() {
        const items = this.tarefas?.items ?? [];
        const idx = items.findIndex((i) => i.id === this.selectedTarefa);
        const loading = this.pageStatus === 'loading' || this.listarTarefasEquipeStatus === 'loading';
        const hasError = this.listarTarefasEquipeStatus === 'error' || this.carregarOpcoesEquipeStatus === 'error';
        return html `
${hasError ? html `
<div class="flex items-center justify-between gap-3 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--status-error-bg,transparent)] p-3 text-[var(--status-error-text,currentColor)]" aria-live="polite">
<span>${this.msg['erroQuadro']}</span>
<grouptriggeraction--ml-button-standard data-variant="secondary" size="sm"
@action=${() => { this.carregarOpcoesEquipe(); this.listarTarefasEquipe({}, 1); }}>
<Label>${this.msg['tentarNovamente']}</Label>
</grouptriggeraction--ml-button-standard>
</div>` : nothing}
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)]" aria-busy=${loading ? 'true' : 'false'}>
<groupviewtable--ml-advanced-data-table
.value=${idx >= 0 ? String(idx) : ''}
.loading=${loading}
@rowClick=${(e) => {
            const item = items[e.detail.index];
            if (item) {
                this.setScenario('detalhe');
                this.obterTarefa(item.id);
            }
        }}>
<TableHeader>
<TableRow>
<TableHead key="titulo">${this.msg['colTarefa']}</TableHead>
<TableHead key="responsavel">${this.msg['colResponsavel']}</TableHead>
<TableHead key="prioridade">${this.msg['colPrioridade']}</TableHead>
<TableHead key="status">${this.msg['colSituacao']}</TableHead>
<TableHead key="checklist">${this.msg['colChecklist']}</TableHead>
<TableHead key="prazo">${this.msg['colPrazo']}</TableHead>
</TableRow>
</TableHeader>
<TableBody>${items.map((i) => this.renderLinha(i))}</TableBody>
<Empty>
<div class="py-10 text-center">
<p class="font-medium text-[var(--text-strong,currentColor)]">${this.msg['quadroVazio']}</p>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['quadroVazioDica']}</p>
</div>
</Empty>
<Loading><div class="py-10 text-center text-[var(--text-muted,currentColor)]">${this.msg['quadroCarregando']}</div></Loading>
</groupviewtable--ml-advanced-data-table>
</div>
${this.tarefas?.hasMore ? html `
<div class="flex justify-center">
<grouptriggeraction--ml-button-standard data-variant="secondary"
.loading=${this.listarTarefasEquipeStatus === 'loading'}
@action=${() => { this.listarTarefasEquipe({}, undefined, true); }}>
<Label>${this.msg['carregarMais']}</Label>
</grouptriggeraction--ml-button-standard>
</div>` : nothing}`;
    }
    renderResumo(t) {
        const dd = (label, value) => html `
<div class="flex flex-col">
<dt class="text-xs text-[var(--text-muted,currentColor)]">${label}</dt>
<dd class="text-sm text-[var(--text-strong,currentColor)]">${value}</dd>
</div>`;
        return html `
<groupviewcard--ml-vertical-card>
<CardHeader>
<CardTitle>${t.titulo}</CardTitle>
<CardDescription>${t.details.descricao ?? this.msg['semDescricao']}</CardDescription>
</CardHeader>
<CardContent>
<dl class="grid grid-cols-2 gap-x-4 gap-y-3">
${dd(this.msg['criadaPor'], t.criador.details.identification.name)}
${dd(this.msg['responsavel'], t.responsavel.details.identification.name)}
${dd(this.msg['prazo'], fmtDate(t.prazo))}
${dd(this.msg['situacao'], this.chip(t.status))}
${dd(this.msg['subtarefas'], t.details.quantidadeSubtarefas)}
${dd(this.msg['progresso'], t.details.progressoChecklist)}
${dd(this.msg['criadaEm'], fmtDateTime(t.criadaEm))}
</dl>
</CardContent>
</groupviewcard--ml-vertical-card>
<section class="mt-4">
<h3 class="mb-1 text-sm font-semibold text-[var(--text-strong,currentColor)]">${this.msg['checklistTitulo']}</h3>
<groupviewdata--ml-vertical-record-list>
<Columns>
<Column field="situacao" header=${this.msg['checklistColSituacao']} width="90px" />
<Column field="item" header=${this.msg['checklistColItem']} />
</Columns>
<Rows>
${t.itensChecklist.map((i) => html `
<Row>
<Cell>
<span class="text-xs ${i.feito ? 'text-[var(--status-success-text,currentColor)]' : 'text-[var(--text-muted,currentColor)]'}">
${i.feito ? this.msg['itemFeito'] : this.msg['itemPendente']}
</span>
</Cell>
<Cell><span class=${i.feito ? 'line-through text-[var(--text-muted,currentColor)]' : ''}>${i.details.descricao}</span></Cell>
</Row>`)}
</Rows>
<Empty><div class="py-4 text-center text-sm text-[var(--text-muted,currentColor)]">${this.msg['semChecklist']}</div></Empty>
</groupviewdata--ml-vertical-record-list>
</section>`;
    }
    renderAcoes(t) {
        const salvando = this.reatribuirTarefaStatus === 'loading';
        return html `
<h3 class="mb-2 text-sm font-semibold text-[var(--text-strong,currentColor)]">${this.msg['acoesTitulo']}</h3>
<div class="flex flex-col gap-3 rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-alt-bg,transparent)] p-3">
<groupselectone--ml-select-one-autocomplete
.value=${this.reatribuirTarefaDraft.responsavelId}
.disabled=${salvando}
placeholder=${this.msg['buscarMembro']}
@change=${(e) => this.setReatribuirTarefaDraft({ responsavelId: e.detail.value })}>
<Label>${this.msg['novoResponsavel']}</Label>
<Helper>${this.msg['novoResponsavelDica']}</Helper>
${this.membros.map((m) => html `
<Item value=${m.id} ?disabled=${m.details.identification.status !== 'Active'}>
${m.details.identification.name}${m.details.identification.status !== 'Active' ? ` · ${this.msg['membroIndisponivel']}` : ''}
</Item>`)}
<Empty>${this.msg['semMembro']}</Empty>
</groupselectone--ml-select-one-autocomplete>
<div aria-live="polite">
<groupnotifyuser--ml-contextual-feedback type="error" .visible=${this.reatribuirTarefaStatus === 'error'} .dismissible=${false}>
<Message>${this.msg['reatribuirErro']}</Message>
</groupnotifyuser--ml-contextual-feedback>
<groupnotifyuser--ml-contextual-feedback type="success" .visible=${this.reatribuirTarefaStatus === 'success'} .dismissible=${false}>
<Message>${this.msg['reatribuirOk']}</Message>
</groupnotifyuser--ml-contextual-feedback>
</div>
<div class="flex flex-wrap items-center gap-2">
<grouptriggeraction--ml-button-standard data-variant="primary"
.loading=${salvando}
.disabled=${!this.reatribuirTarefaDraft.responsavelId}
@action=${() => { this.reatribuirTarefa(); }}>
<Label>${this.msg['trocarResponsavel']}</Label>
</grouptriggeraction--ml-button-standard>
<grouptriggeraction--ml-button-standard data-variant="secondary"
.disabled=${!t.details.aberta}
@action=${() => this.setScenario('confirmar')}>
<Label>${this.msg['cancelarTarefa']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
${!t.details.aberta ? html `<p class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['tarefaEncerrada']}</p>` : nothing}
</div>`;
    }
    renderHistorico(t) {
        const evento = (quando, titulo, extra) => html `
<Row>
<Cell><span class="text-xs text-[var(--text-muted,currentColor)]">${fmtDateTime(quando)}</span></Cell>
<Cell>
<div class="text-sm font-medium text-[var(--text-strong,currentColor)]">${titulo}</div>
${extra ? html `<div class="text-xs text-[var(--text-default,currentColor)]">${extra}</div>` : nothing}
</Cell>
</Row>`;
        return html `
<h3 class="mb-1 text-sm font-semibold text-[var(--text-strong,currentColor)]">${this.msg['historicoTitulo']}</h3>
<groupviewdata--ml-timeline-view>
<Columns>
<Column field="quando" header=${this.msg['histColQuando']} />
<Column field="evento" header=${this.msg['histColEvento']} />
</Columns>
<Rows>
${evento(t.criadaEm, this.msg['histCriada'], `${this.msg['histPor']} ${t.criador.details.identification.name}`)}
${t.details.devolvidaEm
            ? evento(t.details.devolvidaEm, this.msg['histDevolvida'], t.details.motivoDevolucao ? `${this.msg['histMotivo']}: ${t.details.motivoDevolucao}` : undefined)
            : nothing}
${t.details.concluidaEm ? evento(t.details.concluidaEm, this.msg['histConcluida']) : nothing}
${t.details.canceladaEm ? evento(t.details.canceladaEm, this.msg['histCancelada']) : nothing}
</Rows>
</groupviewdata--ml-timeline-view>`;
    }
    renderDetalhe() {
        const t = this.tarefa;
        const carregando = this.obterTarefaStatus === 'loading';
        const erro = this.obterTarefaStatus === 'error';
        return html `
<div class="flex max-h-[calc(100vh-13rem)] flex-col gap-5 overflow-y-auto pr-1">
<div data-organism-id="detalheTarefa" aria-busy=${carregando ? 'true' : 'false'}>
${carregando
            ? html `<p class="py-6 text-center text-sm text-[var(--text-muted,currentColor)]">${this.msg['detalheCarregando']}</p>`
            : erro
                ? html `<p class="py-6 text-center text-sm text-[var(--status-error-text,currentColor)]" aria-live="polite">${this.msg['detalheErro']}</p>`
                : t
                    ? this.renderResumo(t)
                    : html `<p class="py-10 text-center text-sm text-[var(--text-muted,currentColor)]">${this.msg['semSelecao']}</p>`}
</div>
<div data-organism-id="acoesGestor">${t && !carregando ? this.renderAcoes(t) : nothing}</div>
<div data-organism-id="historicoTarefa">${t && !carregando ? this.renderHistorico(t) : nothing}</div>
</div>`;
    }
    renderConfirmar() {
        const t = this.tarefa;
        if (!t) {
            return html `<p class="py-6 text-sm text-[var(--text-muted,currentColor)]">${this.msg['semSelecao']}</p>`;
        }
        const cancelando = this.cancelarTarefaStatus === 'loading';
        const ok = this.cancelarTarefaStatus === 'success';
        return html `
<div class="flex flex-col gap-4 py-2">
<p class="text-sm text-[var(--text-default,currentColor)]">
${this.msg['confirmarTexto']} <strong class="text-[var(--text-strong,currentColor)]">${t.titulo}</strong>.
${this.msg['confirmarEfeito']}
</p>
<div aria-live="polite">
<groupnotifyuser--ml-contextual-feedback type="error" .visible=${this.cancelarTarefaStatus === 'error'} .dismissible=${false}>
<Message>${this.msg['cancelarErro']}</Message>
</groupnotifyuser--ml-contextual-feedback>
<groupnotifyuser--ml-contextual-feedback type="success" .visible=${ok} .dismissible=${false}>
<Message>${this.msg['cancelarOk']}</Message>
</groupnotifyuser--ml-contextual-feedback>
</div>
<div class="flex flex-wrap items-center gap-2">
${ok ? nothing : html `
<grouptriggeraction--ml-button-standard data-variant="danger" .loading=${cancelando}
@action=${() => { this.cancelarTarefa(); }}>
<Label>${this.msg['confirmarSim']}</Label>
</grouptriggeraction--ml-button-standard>`}
<grouptriggeraction--ml-button-standard data-variant="secondary" .disabled=${cancelando}
@action=${() => this.setScenario('detalhe')}>
<Label>${ok ? this.msg['voltarTarefa'] : this.msg['confirmarNao']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</div>`;
    }
    renderPrecondicao() {
        return html `
<div data-organism-id="tarefasEquipe" class="mx-auto mt-10 flex max-w-lg flex-col items-start gap-3 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-6" aria-live="polite">
<h2 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${this.msg['precondTitulo']}</h2>
<p class="text-sm">${this.msg['precondTexto']}</p>
<grouptriggeraction--ml-button-standard data-variant="primary" @action=${() => history.back()}>
<Label>${this.msg['voltar']}</Label>
</grouptriggeraction--ml-button-standard>
</div>`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        const err = this.carregarOpcoesEquipeError ?? this.listarTarefasEquipeError;
        const semContexto = err?.code === 'client.preconditionMissing';
        return html `
<div class="flex min-h-screen flex-col gap-4 bg-[var(--page-bg,transparent)] p-6 text-[var(--text-default,currentColor)]">
<header>
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['pageTitle']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['pageSubtitle']}</p>
</header>
${semContexto
            ? this.renderPrecondicao()
            : html `
<div class="flex items-start gap-4">
<div data-organism-id="tarefasEquipe" class="flex min-w-0 flex-1 flex-col gap-3">
${this.renderFiltros()}
${this.renderQuadro()}
</div>
<aside class="w-[27rem] shrink-0 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4">
<molecules--ml-scenary-102020 mode="scenary"
.value=${this.scenary || 'detalhe'}
backLabel=${this.msg['voltar']}
@change=${(e) => { if (e.target === e.currentTarget)
                this.setScenario(e.detail.value); }}>
<Scene value="detalhe" title=${this.msg['cenaDetalhe']}>${this.renderDetalhe()}</Scene>
<Scene value="confirmar" title=${this.msg['cenaConfirmar']} nav="back">${this.renderConfirmar()}</Scene>
</molecules--ml-scenary-102020>
</aside>
</div>`}
</div>`;
    }
};
TarefasDesktopPage11Tarefas_equipePage = __decorate([
    customElement('tarefas--web--desktop--page11--tarefas_equipe-102047')
], TarefasDesktopPage11Tarefas_equipePage);
export { TarefasDesktopPage11Tarefas_equipePage };

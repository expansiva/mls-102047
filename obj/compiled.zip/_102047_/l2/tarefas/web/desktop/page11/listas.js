var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/listas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasListasShared, } from '/_102047_/l2/tarefas/web/shared/listas.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/groupentertext/ml-multiline-text.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    tituloPagina: 'Listas de tarefas',
    subtituloPagina: 'As listas agrupam as tarefas da equipe por projeto ou área.',
    novaLista: 'Nova lista',
    buscaRotulo: 'Buscar pelo nome',
    buscaPlaceholder: 'Digite parte do nome da lista',
    colNome: 'Nome',
    colTipo: 'Tipo',
    colSituacao: 'Situação',
    colTarefas: 'Tarefas abertas',
    tipoProjeto: 'Projeto',
    tipoArea: 'Área',
    ativa: 'Ativa',
    inativa: 'Inativa',
    nenhumaLista: 'Nenhuma lista cadastrada ainda. Use “Nova lista” para começar.',
    nadaEncontrado: 'Nenhuma lista tem esse nome. Tente outro trecho.',
    erroCarregar: 'Não foi possível carregar as listas.',
    erroSelecao: 'A lista indicada no endereço não foi encontrada entre as listas cadastradas.',
    erroBusca: 'Não foi possível buscar as listas agora. Tente de novo.',
    tentarNovamente: 'Tentar novamente',
    painelRepousoTitulo: 'Manutenção das listas',
    painelRepousoTexto: 'Escolha uma lista na tabela para alterar seus dados ou cadastre uma nova.',
    criarTitulo: 'Dados da nova lista',
    editarFallback: 'Lista selecionada',
    listaNaoEncontrada: 'Esta lista não está entre as listas carregadas. Escolha outra na tabela.',
    campoNome: 'Nome da lista',
    campoNomeAjuda: 'Não pode haver duas listas com o mesmo nome.',
    campoTipo: 'Tipo',
    tipoEscolha: 'Escolha o tipo',
    campoDescricao: 'Descrição',
    campoDescricaoAjuda: 'Explique o objetivo da lista (opcional).',
    campoAtiva: 'Lista ativa',
    campoAtivaAjuda: 'Listas inativas deixam de aparecer na escolha ao criar tarefa.',
    tarefasAbertasNota: 'Tarefas abertas nesta lista',
    cadastrar: 'Cadastrar lista',
    salvar: 'Salvar alterações',
    fecharPainel: 'Fechar painel',
    confirmarDescartar: 'Há alterações que ainda não foram salvas. Descartar e continuar?',
    sucessoCriar: 'Lista cadastrada. Você já pode cadastrar outra.',
    sucessoSalvar: 'Alterações salvas.',
    erroObrigatorios: 'Informe o nome e o tipo da lista para continuar.',
    erroNomeObrigatorio: 'Informe o nome da lista.',
    erroNomeRepetido: 'Já existe uma lista com esse nome. Escolha outro nome.',
    erroSelecionar: 'Escolha uma lista na tabela antes de salvar.',
    erroGenerico: 'Não foi possível salvar. Confira os dados e tente de novo; se persistir, recarregue as listas.',
    voltarLista: 'Fechar',
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
function formatNumber(n) {
    return new Intl.NumberFormat(document.documentElement.lang || undefined).format(n);
}
function norm(v) {
    return (v ?? '').trim();
}
function criarSujo(d) {
    return norm(d.nome) !== '' || norm(d.details.descricao) !== '' || d.details.tipo !== null;
}
function editarSujo(d, l) {
    if (!l)
        return false;
    return (norm(d.nome) !== norm(l.nome) ||
        (d.details.tipo ?? '') !== l.details.tipo ||
        norm(d.details.descricao) !== norm(l.details.descricao) ||
        (d.ativa ?? l.ativa) !== l.ativa);
}
function erroTexto(msg, code) {
    if (!code)
        return '';
    if (code === 'client.requiredMissing')
        return msg.erroObrigatorios;
    if (code === 'listaNomeUnico')
        return msg.erroNomeRepetido;
    return msg.erroGenerico;
}
let TarefasDesktopPage11ListasPage = class TarefasDesktopPage11ListasPage extends TarefasListasShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-full bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)] p-6">
<header class="flex items-start justify-between gap-4 mb-5">
<div>
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['tituloPagina']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)] mt-1">${this.msg['subtituloPagina']}</p>
</div>
<grouptriggeraction--ml-button-standard
data-variant="primary"
size="md"
@action=${() => this.abrirCriar()}
>
<Label>${this.msg['novaLista']}</Label>
</grouptriggeraction--ml-button-standard>
</header>
<div class="grid gap-6 items-start grid-cols-[minmax(0,1fr)_400px]">
${this.renderListas()} ${this.renderPainel()}
</div>
</div>
`;
    }
    abrirCriar() {
        if (!this.podeSair())
            return;
        this.selectLista(null);
        this.setScenario('criar');
    }
    podeSair() {
        const sujo = criarSujo(this.criarListaDraft) ||
            editarSujo(this.salvarListaDraft, this.formularioLista);
        return !sujo || window.confirm(this.msg['confirmarDescartar']);
    }
    renderListas() {
        const loading = this.pageStatus === 'loading' || this.buscarListasStatus === 'loading';
        const selIdx = this.selectedLista ? this.listas.findIndex((l) => l.id === this.selectedLista) : -1;
        const erroCarga = this.pageStatus === 'error' && this.listarListasError?.code !== 'client.selectionInvalid';
        return html `
<section data-organism-id="listasCadastradas" class="flex flex-col gap-3 min-w-0">
<groupsearchcontent--ml-search-bar
.value=${this.busca}
placeholder=${this.msg['buscaPlaceholder']}
debounce="350"
?loading=${this.buscarListasStatus === 'loading'}
@search=${(e) => this.buscarListas(e.detail.query)}
@change=${(e) => this.buscarListas(e.detail.value ?? '')}
@clear=${() => this.buscarListas('')}
>
<Label>${this.msg['buscaRotulo']}</Label>
</groupsearchcontent--ml-search-bar>
${this.listarListasError?.code === 'client.selectionInvalid'
            ? html `<p aria-live="polite" class="text-sm text-[var(--text-default,currentColor)]">${this.msg['erroSelecao']}</p>`
            : nothing}
${this.buscarListasError
            ? html `<p aria-live="polite" class="text-sm text-[var(--text-default,currentColor)]">${this.msg['erroBusca']}</p>`
            : nothing}
${erroCarga
            ? html `
<div
aria-live="polite"
class="flex items-center justify-between gap-3 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4"
>
<span>${this.msg['erroCarregar']}</span>
<grouptriggeraction--ml-button-standard
data-variant="secondary"
size="sm"
@action=${() => this.listarListas()}
>
<Label>${this.msg['tentarNovamente']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`
            : html `
<div class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)]">
<groupviewtable--ml-data-table
.value=${selIdx >= 0 ? String(selIdx) : ''}
?loading=${loading}
@rowClick=${(e) => {
                const l = this.listas[e.detail.index];
                if (!l || l.id === this.selectedLista) {
                    if (l)
                        this.setScenario('editar');
                    return;
                }
                if (!this.podeSair())
                    return;
                this.selectLista(l.id);
                this.setScenario('editar');
            }}
>
<TableHeader>
<TableRow>
<TableHead key="nome">${this.msg['colNome']}</TableHead>
<TableHead key="tipo">${this.msg['colTipo']}</TableHead>
<TableHead key="situacao">${this.msg['colSituacao']}</TableHead>
<TableHead key="tarefas">${this.msg['colTarefas']}</TableHead>
</TableRow>
</TableHeader>
<TableBody>${this.listas.map((l) => this.renderLinha(l))}</TableBody>
<Empty>${this.busca ? this.msg['nadaEncontrado'] : this.msg['nenhumaLista']}</Empty>
</groupviewtable--ml-data-table>
</div>
`}
</section>
`;
    }
    renderLinha(l) {
        const muted = l.ativa ? 'text-[var(--text-strong,currentColor)]' : 'text-[var(--text-muted,currentColor)]';
        const badge = l.ativa
            ? 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]'
            : 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]';
        return html `
<TableRow key=${l.id}>
<TableCell><span class="font-medium ${muted}">${l.nome}</span></TableCell>
<TableCell>
<span class=${l.ativa ? '' : 'text-[var(--text-muted,currentColor)]'}>
${l.details.tipo === 'project' ? this.msg['tipoProjeto'] : this.msg['tipoArea']}
</span>
</TableCell>
<TableCell>
<span class="inline-block rounded-full px-2 py-0.5 text-xs ${badge}">
${l.ativa ? this.msg['ativa'] : this.msg['inativa']}
</span>
</TableCell>
<TableCell sort-value=${String(l.details.quantidadeTarefasAbertas)}>
<span class=${l.ativa ? '' : 'text-[var(--text-muted,currentColor)]'}>
${formatNumber(l.details.quantidadeTarefasAbertas)}
</span>
</TableCell>
</TableRow>
`;
    }
    renderPainel() {
        const lista = this.formularioLista;
        return html `
<aside
data-organism-id="formularioLista"
class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4 sticky top-4"
>
<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'fechado'}
backLabel=${this.msg['voltarLista']}
@change=${(e) => {
            if (e.target === e.currentTarget)
                this.setScenario(e.detail.value);
        }}
>
<Scene value="fechado" title=${this.msg['painelRepousoTitulo']}>
<p class="text-sm text-[var(--text-muted,currentColor)] py-2">${this.msg['painelRepousoTexto']}</p>
</Scene>
<Scene value="criar" title=${this.msg['criarTitulo']}>${this.renderCriar()}</Scene>
<Scene value="editar" title=${lista ? lista.nome : this.msg['editarFallback']}>
${this.renderEditar(lista)}
</Scene>
</molecules--ml-scenary-102020>
</aside>
`;
    }
    renderCriar() {
        const d = this.criarListaDraft;
        const loading = this.criarListaStatus === 'loading';
        const pronto = norm(d.nome) !== '' && d.details.tipo !== null;
        const code = this.criarListaError?.code;
        return html `
<form class="flex flex-col gap-4 pt-2" @submit=${(e) => e.preventDefault()}>
${this.renderCampos(d, (v) => this.setCriarListaDraft(v), 'criar', code)}
${this.renderFeedback(code, this.criarListaStatus === 'success', this.msg['sucessoCriar'])}
<div class="flex items-center gap-2">
<grouptriggeraction--ml-button-standard
data-variant="primary"
size="md"
?disabled=${!pronto}
?loading=${loading}
@action=${() => this.criarLista()}
>
<Label>${this.msg['cadastrar']}</Label>
</grouptriggeraction--ml-button-standard>
${this.renderFechar()}
</div>
</form>
`;
    }
    renderEditar(lista) {
        if (!lista) {
            return html `<p aria-live="polite" class="text-sm text-[var(--text-muted,currentColor)] py-2">${this.msg['listaNaoEncontrada']}</p>`;
        }
        const d = this.salvarListaDraft;
        const loading = this.salvarListaStatus === 'loading';
        const pronto = norm(d.nome) !== '' && d.details.tipo !== null && editarSujo(d, lista);
        const code = this.salvarListaError?.code;
        return html `
<form class="flex flex-col gap-4 pt-2" @submit=${(e) => e.preventDefault()}>
<p class="text-sm text-[var(--text-muted,currentColor)]">
${this.msg['tarefasAbertasNota']}:
<span class="font-medium text-[var(--text-strong,currentColor)]">${formatNumber(lista.details.quantidadeTarefasAbertas)}</span>
</p>
${this.renderCampos(d, (v) => this.setSalvarListaDraft({ ...d, ...v }), 'editar', code)}
${this.renderFeedback(code, this.salvarListaStatus === 'success', this.msg['sucessoSalvar'])}
<div class="flex items-center gap-2">
<grouptriggeraction--ml-button-standard
data-variant="primary"
size="md"
?disabled=${!pronto}
?loading=${loading}
@action=${() => this.salvarLista()}
>
<Label>${this.msg['salvar']}</Label>
</grouptriggeraction--ml-button-standard>
${this.renderFechar()}
</div>
</form>
`;
    }
    renderFechar() {
        return html `
<grouptriggeraction--ml-button-standard
data-variant="secondary"
size="md"
@action=${() => {
            if (!this.podeSair())
                return;
            this.selectLista(null);
            this.setScenario('fechado');
        }}
>
<Label>${this.msg['fecharPainel']}</Label>
</grouptriggeraction--ml-button-standard>
`;
    }
    renderFeedback(code, sucesso, textoSucesso) {
        if (code) {
            return html `
<groupnotifyuser--ml-contextual-feedback type="error" visible dismissible="false">
<Message>${erroTexto(this.msg, code)}</Message>
</groupnotifyuser--ml-contextual-feedback>
`;
        }
        if (sucesso) {
            return html `
<groupnotifyuser--ml-contextual-feedback type="success" visible dismissible="false">
<Message>${textoSucesso}</Message>
</groupnotifyuser--ml-contextual-feedback>
`;
        }
        return nothing;
    }
    renderCampos(d, onChange, prefix, code) {
        const nomeErro = code === 'client.requiredMissing' && norm(d.nome) === '' ? this.msg['erroNomeObrigatorio'] : '';
        const selectId = `${prefix}-tipo`;
        return html `
<groupentertext--ml-enter-text
.value=${d.nome ?? ''}
.error=${nomeErro}
maxLength="120"
required
@input=${(e) => onChange({ ...d, nome: e.detail.value })}
>
<Label>${this.msg['campoNome']}</Label>
<Helper>${this.msg['campoNomeAjuda']}</Helper>
</groupentertext--ml-enter-text>
<div class="flex flex-col gap-1">
<label for=${selectId} class="text-sm font-medium text-[var(--text-strong,currentColor)]">${this.msg['campoTipo']}</label>
<select
id=${selectId}
class="h-10 rounded-md border border-[var(--border-default,currentColor)] bg-[var(--input-bg,transparent)] text-[var(--text-default,currentColor)] px-2 focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)] outline-none"
@change=${(e) => {
            const v = e.target.value;
            const tipo = v === 'project' || v === 'area' ? v : null;
            onChange({ ...d, details: { ...d.details, tipo } });
        }}
>
<option value="" ?selected=${d.details.tipo === null}>${this.msg['tipoEscolha']}</option>
<option value="project" ?selected=${d.details.tipo === 'project'}>${this.msg['tipoProjeto']}</option>
<option value="area" ?selected=${d.details.tipo === 'area'}>${this.msg['tipoArea']}</option>
</select>
</div>
<groupentertext--ml-multiline-text
.value=${d.details.descricao ?? ''}
rows="4"
maxLength="500"
@input=${(e) => onChange({ ...d, details: { ...d.details, descricao: e.detail.value } })}
>
<Label>${this.msg['campoDescricao']}</Label>
<Helper>${this.msg['campoDescricaoAjuda']}</Helper>
</groupentertext--ml-multiline-text>
<label class="flex items-start gap-3 min-h-[44px] cursor-pointer">
<input
type="checkbox"
class="mt-1 h-4 w-4 focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]"
.checked=${d.ativa ?? true}
@change=${(e) => onChange({ ...d, ativa: e.target.checked })}
/>
<span class="flex flex-col">
<span class="text-sm font-medium text-[var(--text-strong,currentColor)]">${this.msg['campoAtiva']}</span>
<span class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['campoAtivaAjuda']}</span>
</span>
</label>
`;
    }
};
TarefasDesktopPage11ListasPage = __decorate([
    customElement('tarefas--web--desktop--page11--listas-102047')
], TarefasDesktopPage11ListasPage);
export { TarefasDesktopPage11ListasPage };

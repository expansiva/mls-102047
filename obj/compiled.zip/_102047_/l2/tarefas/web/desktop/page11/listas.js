var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/listas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasListasShared } from '/_102047_/l2/tarefas/web/shared/listas.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/groupentertext/ml-multiline-text.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.js';
import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Listas',
    pageSubtitle: 'As listas que agrupam as tarefas da equipe, com o que ainda está aberto em cada uma.',
    novaLista: 'Nova lista',
    buscaLabel: 'Buscar lista',
    buscaPlaceholder: 'Digite parte do nome da lista',
    colNome: 'Nome',
    colTipo: 'Tipo',
    colSituacao: 'Situação',
    colAbertas: 'Tarefas abertas',
    tipoProject: 'Projeto',
    tipoArea: 'Área',
    situacaoAtiva: 'Ativa',
    situacaoInativa: 'Inativa',
    vazioGeral: 'Nenhuma lista cadastrada ainda. Use "Nova lista" para começar.',
    vazioBusca: 'Nenhuma lista tem esse nome.',
    carregando: 'Carregando as listas…',
    erroCarga: 'Não foi possível carregar as listas.',
    tentarNovamente: 'Tentar de novo',
    faltaContexto: 'Esta página foi aberta sem o que ela precisa para carregar as listas. Volte à tela anterior e abra as listas de novo.',
    voltar: 'Voltar',
    selecaoInvalida: 'A lista escolhida não foi encontrada. Escolha outra na tabela.',
    painelDica: 'Escolha uma lista na tabela para alterar seus dados, ou cadastre uma nova.',
    tituloNovaLista: 'Dados da nova lista',
    fechar: 'Fechar painel',
    campoNome: 'Nome da lista',
    campoNomeAjuda: 'Não pode haver duas listas com o mesmo nome.',
    campoNomePlaceholder: 'Ex.: Site novo, Financeiro',
    campoTipo: 'Tipo',
    tipoEscolha: 'Escolha o tipo',
    campoDescricao: 'Descrição',
    campoDescricaoAjuda: 'Explique o objetivo da lista.',
    campoAtiva: 'Lista ativa',
    campoAtivaAjuda: 'Listas inativas deixam de aparecer na escolha ao criar tarefa.',
    abertasInfo: 'Tarefas abertas nesta lista',
    cadastrar: 'Cadastrar lista',
    salvar: 'Salvar alterações',
    erroCriar: 'A lista não foi cadastrada.',
    erroSalvar: 'As alterações não foram salvas.',
    toastCriada: 'Lista cadastrada.',
    toastSalva: 'Alterações da lista salvas.',
    confirmarDescarte: 'Há alterações que ainda não foram salvas. Descartar essas alterações?',
    semNome: 'Lista sem nome'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
const emptyCriar = { nome: null, details: { tipo: null, descricao: null }, ativa: null };
function textOf(e) {
    const d = e.detail;
    if (d && typeof d === 'object' && typeof d.value === 'string')
        return d.value;
    return null;
}
function criarSujo(d) {
    return !!(d.nome && d.nome.trim()) || !!(d.details.descricao && d.details.descricao.trim()) || !!d.details.tipo;
}
function criarPronto(d) {
    return !!(d.nome && d.nome.trim()) && !!d.details.tipo;
}
function salvarMudou(d, row) {
    if (!row)
        return false;
    return ((d.nome ?? '') !== row.nome ||
        (d.details.descricao ?? '') !== (row.details.descricao ?? '') ||
        d.details.tipo !== row.details.tipo ||
        d.ativa !== row.ativa);
}
function salvarPronto(d) {
    return !!(d.nome && d.nome.trim()) && !!d.details.tipo;
}
function indexOfSelected(listas, id) {
    if (!id)
        return -1;
    return listas.findIndex((l) => l.id === id);
}
let TarefasDesktopPage11ListasPage = class TarefasDesktopPage11ListasPage extends TarefasListasShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    numberLocale() {
        return document.documentElement.lang || undefined;
    }
    painelSujo() {
        return criarSujo(this.criarListaDraft) || salvarMudou(this.salvarListaDraft, this.formularioLista);
    }
    confirmarDescarte() {
        if (!this.painelSujo())
            return true;
        return window.confirm(this.msg['confirmarDescarte']);
    }
    fechar() {
        if (!this.confirmarDescarte())
            return;
        this.selectFormularioLista(null);
        this.setCriarListaDraft(emptyCriar);
        this.setScenario('fechado');
    }
    abrirNova() {
        if (!this.confirmarDescarte())
            return;
        this.selectFormularioLista(null);
        this.setCriarListaDraft({ ...this.criarListaDraft, ativa: this.criarListaDraft.ativa ?? true });
        this.setScenario('criar');
    }
    abrirLista(index) {
        const lista = this.listas[index];
        if (!lista)
            return;
        if (lista.id === this.selectedLista)
            return;
        if (!this.confirmarDescarte())
            return;
        this.setCriarListaDraft(emptyCriar);
        this.selectFormularioLista(lista.id);
        this.setScenario('editar');
    }
    tipoLabel(tipo) {
        return tipo === 'project' ? this.msg['tipoProject'] : this.msg['tipoArea'];
    }
    renderToolbar() {
        return html `
<div class="flex items-end gap-3">
<div class="flex-1 max-w-md">
<groupsearchcontent--ml-search-bar
.value=${this.busca}
placeholder=${this.msg['buscaPlaceholder']}
?loading=${this.buscarListasStatus === 'loading'}
@search=${(e) => this.buscarListas(e.detail.query ?? '')}
@clear=${() => this.buscarListas('')}
>
<Label>${this.msg['buscaLabel']}</Label>
</groupsearchcontent--ml-search-bar>
</div>
<grouptriggeraction--ml-button-standard size="md" @action=${() => this.abrirNova()}>
<Label>${this.msg['novaLista']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    renderLoadError() {
        const err = this.listarListasError;
        const faltaContexto = err?.code === 'client.preconditionMissing';
        const selecao = err?.code === 'client.selectionInvalid';
        if (selecao) {
            return html `<p class="text-sm text-[var(--text-default,currentColor)]" aria-live="polite">${this.msg['selecaoInvalida']}</p>`;
        }
        return html `
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-6 flex flex-col items-start gap-3" aria-live="polite">
<p class="text-sm text-[var(--text-default,currentColor)]">${faltaContexto ? this.msg['faltaContexto'] : this.msg['erroCarga']}</p>
${faltaContexto
            ? html `<grouptriggeraction--ml-button-standard data-variant="secondary" size="md" @action=${() => window.history.back()}>
<Label>${this.msg['voltar']}</Label>
</grouptriggeraction--ml-button-standard>`
            : html `<grouptriggeraction--ml-button-standard data-variant="secondary" size="md" @action=${() => this.listarListas()}>
<Label>${this.msg['tentarNovamente']}</Label>
</grouptriggeraction--ml-button-standard>`}
</div>
`;
    }
    renderTabela() {
        const nf = new Intl.NumberFormat(this.numberLocale());
        const loading = this.pageStatus === 'loading' || this.listarListasStatus === 'loading';
        const idx = indexOfSelected(this.listas, this.selectedLista);
        return html `
${this.pageStatus === 'error' ? this.renderLoadError() : nothing}
<div class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] text-[var(--text-default,currentColor)]" aria-busy=${loading ? 'true' : 'false'}>
<groupviewtable--ml-data-table
.value=${idx >= 0 ? String(idx) : ''}
?loading=${loading}
@rowClick=${(e) => this.abrirLista(e.detail.index)}
>
<TableHeader>
<TableRow>
<TableHead key="nome">${this.msg['colNome']}</TableHead>
<TableHead key="tipo">${this.msg['colTipo']}</TableHead>
<TableHead key="situacao">${this.msg['colSituacao']}</TableHead>
<TableHead key="abertas">${this.msg['colAbertas']}</TableHead>
</TableRow>
</TableHeader>
<TableBody>
${this.listas.map((l) => html `
<TableRow key=${l.id}>
<TableCell>
<span class=${l.ativa ? 'font-medium text-[var(--text-strong,currentColor)]' : 'font-medium text-[var(--text-muted,currentColor)]'}>${l.nome}</span>
</TableCell>
<TableCell>
<span class=${l.ativa ? 'text-[var(--text-default,currentColor)]' : 'text-[var(--text-muted,currentColor)]'}>${this.tipoLabel(l.details.tipo)}</span>
</TableCell>
<TableCell>
<span
class=${l.ativa
            ? 'inline-block rounded-full px-2 py-0.5 text-xs bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]'
            : 'inline-block rounded-full px-2 py-0.5 text-xs bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]'}
>${l.ativa ? this.msg['situacaoAtiva'] : this.msg['situacaoInativa']}</span
>
</TableCell>
<TableCell>
<span class=${l.ativa ? 'tabular-nums' : 'tabular-nums text-[var(--text-muted,currentColor)]'}>${nf.format(l.details.quantidadeTarefasAbertas)}</span>
</TableCell>
</TableRow>
`)}
</TableBody>
<Loading>${this.msg['carregando']}</Loading>
<Empty>${this.busca ? this.msg['vazioBusca'] : this.msg['vazioGeral']}</Empty>
</groupviewtable--ml-data-table>
</div>
`;
    }
    renderCamposTipoAtiva(tipo, ativa, onTipo, onAtiva, idPrefix) {
        return html `
<div class="flex flex-col gap-1">
<label for="${idPrefix}-tipo" class="text-sm font-medium text-[var(--text-strong,currentColor)]">${this.msg['campoTipo']}</label>
<select
id="${idPrefix}-tipo"
required
class="h-10 rounded-md border border-[var(--border-default,currentColor)] bg-[var(--input-bg,transparent)] px-3 text-sm text-[var(--text-default,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]"
@change=${(e) => {
            const v = e.target.value;
            onTipo(v === 'project' || v === 'area' ? v : null);
        }}
>
<option value="" ?selected=${!tipo}>${this.msg['tipoEscolha']}</option>
<option value="project" ?selected=${tipo === 'project'}>${this.msg['tipoProject']}</option>
<option value="area" ?selected=${tipo === 'area'}>${this.msg['tipoArea']}</option>
</select>
</div>
<label class="flex items-start gap-3 cursor-pointer min-h-10">
<input
type="checkbox"
class="mt-1 h-4 w-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]"
.checked=${ativa === true}
@change=${(e) => onAtiva(e.target.checked)}
/>
<span class="flex flex-col">
<span class="text-sm font-medium text-[var(--text-strong,currentColor)]">${this.msg['campoAtiva']}</span>
<span class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['campoAtivaAjuda']}</span>
</span>
</label>
`;
    }
    renderErro(err, titulo) {
        return html `
<div aria-live="polite">
<groupnotifyuser--ml-contextual-feedback type="error" .visible=${!!err} .dismissible=${false}>
<Title>${titulo}</Title>
<Message>${err ? err.message : ''}</Message>
</groupnotifyuser--ml-contextual-feedback>
</div>
`;
    }
    renderFechar() {
        return html `
<div class="flex justify-end">
<grouptriggeraction--ml-button-standard data-variant="ghost" size="sm" @action=${() => this.fechar()}>
<Label>${this.msg['fechar']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    renderFormCriar() {
        const d = this.criarListaDraft;
        const loading = this.criarListaStatus === 'loading';
        return html `
<div class="flex flex-col gap-4 p-4">
${this.renderFechar()}
<groupentertext--ml-enter-text
.value=${d.nome ?? ''}
placeholder=${this.msg['campoNomePlaceholder']}
maxLength="120"
required
@input=${(e) => {
            const v = textOf(e);
            if (v !== null)
                this.setCriarListaDraft({ ...this.criarListaDraft, nome: v });
        }}
>
<Label>${this.msg['campoNome']}</Label>
<Helper>${this.msg['campoNomeAjuda']}</Helper>
</groupentertext--ml-enter-text>
${this.renderCamposTipoAtiva(d.details.tipo, d.ativa, (t) => this.setCriarListaDraft({ ...this.criarListaDraft, details: { ...this.criarListaDraft.details, tipo: t } }), (a) => this.setCriarListaDraft({ ...this.criarListaDraft, ativa: a }), 'criar')}
<groupentertext--ml-multiline-text
.value=${d.details.descricao ?? ''}
rows="4"
maxLength="500"
@input=${(e) => {
            const v = textOf(e);
            if (v !== null)
                this.setCriarListaDraft({ ...this.criarListaDraft, details: { ...this.criarListaDraft.details, descricao: v } });
        }}
>
<Label>${this.msg['campoDescricao']}</Label>
<Helper>${this.msg['campoDescricaoAjuda']}</Helper>
</groupentertext--ml-multiline-text>
${this.renderErro(this.criarListaError, this.msg['erroCriar'])}
<grouptriggeraction--ml-button-standard
size="md"
?disabled=${!criarPronto(d)}
?loading=${loading}
@action=${() => this.criarLista().then(() => {
            if (this.criarListaStatus === 'success')
                this.setScenario('fechado');
        })}
>
<Label>${this.msg['cadastrar']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    renderFormEditar() {
        const row = this.formularioLista;
        if (!row)
            return html `<p class="p-4 text-sm text-[var(--text-muted,currentColor)]">${this.msg['painelDica']}</p>`;
        const d = this.salvarListaDraft;
        const loading = this.salvarListaStatus === 'loading';
        const nf = new Intl.NumberFormat(this.numberLocale());
        return html `
<div class="flex flex-col gap-4 p-4">
${this.renderFechar()}
<dl class="flex items-baseline justify-between rounded-md bg-[var(--surface-alt-bg,transparent)] px-3 py-2">
<dt class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['abertasInfo']}</dt>
<dd class="text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${nf.format(row.details.quantidadeTarefasAbertas)}</dd>
</dl>
<groupentertext--ml-enter-text
.value=${d.nome ?? ''}
maxLength="120"
required
@input=${(e) => {
            const v = textOf(e);
            if (v !== null)
                this.setSalvarListaDraft({ ...this.salvarListaDraft, nome: v });
        }}
>
<Label>${this.msg['campoNome']}</Label>
<Helper>${this.msg['campoNomeAjuda']}</Helper>
</groupentertext--ml-enter-text>
${this.renderCamposTipoAtiva(d.details.tipo, d.ativa, (t) => this.setSalvarListaDraft({ ...this.salvarListaDraft, details: { ...this.salvarListaDraft.details, tipo: t } }), (a) => this.setSalvarListaDraft({ ...this.salvarListaDraft, ativa: a }), 'editar')}
<groupentertext--ml-multiline-text
.value=${d.details.descricao ?? ''}
rows="4"
maxLength="500"
@input=${(e) => {
            const v = textOf(e);
            if (v !== null)
                this.setSalvarListaDraft({ ...this.salvarListaDraft, details: { ...this.salvarListaDraft.details, descricao: v } });
        }}
>
<Label>${this.msg['campoDescricao']}</Label>
<Helper>${this.msg['campoDescricaoAjuda']}</Helper>
</groupentertext--ml-multiline-text>
${this.renderErro(this.salvarListaError, this.msg['erroSalvar'])}
<grouptriggeraction--ml-button-standard
size="md"
?disabled=${!salvarPronto(d) || !salvarMudou(d, row)}
?loading=${loading}
@action=${() => this.salvarLista().then(() => {
            if (this.salvarListaStatus === 'success') {
                this.selectFormularioLista(null);
                this.setScenario('fechado');
            }
        })}
>
<Label>${this.msg['salvar']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    renderPainel() {
        const row = this.formularioLista;
        return html `
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] text-[var(--text-default,currentColor)]">
<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'fechado'}
@change=${(e) => {
            if (e.target === e.currentTarget)
                this.setScenario(e.detail.value);
        }}
>
<Scene value="fechado" title="">
<p class="p-4 text-sm text-[var(--text-muted,currentColor)]">${this.msg['painelDica']}</p>
</Scene>
<Scene value="criar" title=${this.msg['tituloNovaLista']}>${this.renderFormCriar()}</Scene>
<Scene value="editar" title=${row ? row.nome : this.msg['semNome']}>${this.renderFormEditar()}</Scene>
</molecules--ml-scenary-102020>
</div>
`;
    }
    renderToast() {
        const criada = this.criarListaStatus === 'success';
        const salva = this.salvarListaStatus === 'success';
        return html `
<groupnotifyuser--ml-toast-notification type="success" position="top-right" .visible=${criada || salva} .duration=${3500}>
<Message>${criada ? this.msg['toastCriada'] : this.msg['toastSalva']}</Message>
</groupnotifyuser--ml-toast-notification>
`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-screen bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)] p-6">
<header class="mb-5">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['pageTitle']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['pageSubtitle']}</p>
</header>
<div class="grid gap-6 items-start" style="grid-template-columns: minmax(0, 1fr) 24rem;">
<section data-organism-id="listasCadastradas" class="flex flex-col gap-4 min-w-0">
${this.renderToolbar()} ${this.renderTabela()}
</section>
<section data-organism-id="formularioLista" class="min-w-0">${this.renderPainel()}</section>
</div>
${this.renderToast()}
</div>
`;
    }
};
TarefasDesktopPage11ListasPage = __decorate([
    customElement('tarefas--web--desktop--page11--listas-102047')
], TarefasDesktopPage11ListasPage);
export { TarefasDesktopPage11ListasPage };

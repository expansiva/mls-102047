var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/meus_avisos.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasMeus_avisosShared } from '/_102047_/l2/tarefas/web/shared/meus_avisos.js';
import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar.js';
import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card.js';
import '/_102040_/l2/molecules/groupviewtable/ml-view-table.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Meus avisos',
    pageSubtitle: 'Seus avisos diários das 8h: escolha um dia e veja o que vencia ou já estava atrasado.',
    filtroPeriodo: 'Período de referência',
    filtroDe: 'De',
    filtroAte: 'Até',
    listaVazia: 'Nenhum aviso encontrado neste período.',
    semAvisos: 'Você ainda não recebeu nenhum aviso diário.',
    carregando: 'Carregando seus avisos…',
    carregarMais: 'Mostrar avisos mais antigos',
    carregandoMais: 'Carregando…',
    tentarNovamente: 'Tentar novamente',
    erroAbertura: 'Não foi possível carregar seus avisos.',
    erroLista: 'Não foi possível atualizar a lista de avisos.',
    erroAviso: 'Não foi possível abrir este aviso.',
    precondicaoTitulo: 'Faltam informações para abrir seus avisos',
    precondicaoTexto: 'Esta página foi aberta sem a sessão ou o contexto necessários. Volte para a página anterior e abra os avisos a partir dela.',
    voltar: 'Voltar',
    listaRegiao: 'Avisos por data',
    colData: 'Data de referência',
    colTotais: 'Totais',
    colEnvio: 'Envio',
    tarefas: 'Tarefas',
    atrasadas: 'Atrasadas',
    envioPendente: 'Aguardando envio',
    envioConcluido: 'Enviado',
    envioFalhou: 'Falhou',
    tabTarefas: 'Tarefas do aviso',
    tabEnvio: 'Registro de envio',
    painelVazio: 'Escolha um aviso na lista para ver as tarefas que ele trouxe.',
    avisoDe: 'Aviso de',
    metricTarefas: 'Tarefas no aviso',
    metricAtrasadas: 'Já atrasadas',
    colTarefa: 'Tarefa',
    colPrazo: 'Prazo',
    colVencimento: 'Vencimento',
    colSituacao: 'Situação',
    venceHoje: 'Vence hoje',
    atrasada: 'Atrasada',
    tarefasVazio: 'Este aviso não trouxe tarefas.',
    sitAFazer: 'A fazer',
    sitEmAndamento: 'Em andamento',
    sitEmRevisao: 'Em revisão',
    sitConcluida: 'Concluída',
    sitCancelada: 'Cancelada',
    envioQuando: 'Quando',
    envioEvento: 'Evento',
    envioGerado: 'Gerado',
    envioFinalizado: 'Finalizado',
    envioMotivo: 'Motivo da falha',
    envioVazio: 'Ainda não há registro de envio.',
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
function lang() {
    return document.documentElement.lang || undefined;
}
function parseDay(value) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
    return m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : null;
}
function fmtDay(value, long) {
    const d = parseDay(value);
    if (!d)
        return value;
    return new Intl.DateTimeFormat(lang(), long
        ? { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }
        : { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }).format(d);
}
function fmtDateTime(value) {
    const d = new Date(value);
    if (Number.isNaN(d.getTime()))
        return value;
    return new Intl.DateTimeFormat(lang(), { dateStyle: 'short', timeStyle: 'short' }).format(d);
}
function fmtNumber(n) {
    return new Intl.NumberFormat(lang()).format(n);
}
function tone(kind) {
    switch (kind) {
        case 'success':
            return 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]';
        case 'error':
            return 'bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]';
        case 'warning':
            return 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]';
        case 'info':
            return 'bg-[var(--status-info-bg,transparent)] text-[var(--status-info-text,currentColor)]';
        default:
            return 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]';
    }
}
let TarefasDesktopPage11Meus_avisosPage = class TarefasDesktopPage11Meus_avisosPage extends TarefasMeus_avisosShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    chip(kind, text) {
        return html `<span class="inline-block rounded-full px-2 py-0.5 text-xs font-medium whitespace-nowrap ${tone(kind)}">${text}</span>`;
    }
    avisoStatusChip(status) {
        if (status === 'completed')
            return this.chip('success', this.msg['envioConcluido']);
        if (status === 'failed')
            return this.chip('error', this.msg['envioFalhou']);
        return this.chip('neutral', this.msg['envioPendente']);
    }
    tarefaStatusLabel(status) {
        switch (status) {
            case 'aFazer':
                return this.msg['sitAFazer'];
            case 'emAndamento':
                return this.msg['sitEmAndamento'];
            case 'emRevisao':
                return this.msg['sitEmRevisao'];
            case 'concluida':
                return this.msg['sitConcluida'];
            default:
                return this.msg['sitCancelada'];
        }
    }
    renderHeader() {
        return html `
<header class="mb-4">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['pageTitle']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['pageSubtitle']}</p>
</header>
`;
    }
    renderBlockingState() {
        const err = this.qryPaginaMeusAvisosError;
        const missing = err?.code === 'client.preconditionMissing';
        return html `
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-8 max-w-xl" aria-live="polite">
<h2 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">
${missing ? this.msg['precondicaoTitulo'] : this.msg['erroAbertura']}
</h2>
${missing ? html `<p class="mt-2 text-sm text-[var(--text-default,currentColor)]">${this.msg['precondicaoTexto']}</p>` : nothing}
<div class="mt-4 flex gap-2">
${missing
            ? html `<button type="button" class="min-h-[40px] rounded-md px-4 text-sm font-medium bg-[var(--button-primary-bg,transparent)] text-[var(--button-primary-text,currentColor)] focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]" @click=${() => history.back()}>${this.msg['voltar']}</button>`
            : html `<button type="button" class="min-h-[40px] rounded-md px-4 text-sm font-medium bg-[var(--button-primary-bg,transparent)] text-[var(--button-primary-text,currentColor)] focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]" @click=${() => this.qryPaginaMeusAvisos()}>${this.msg['tentarNovamente']}</button>`}
</div>
</div>
`;
    }
    renderList() {
        const items = this.avisos?.items ?? [];
        const selected = this.selectedAvisoVencimento ?? this.avisoAtual?.id ?? null;
        const loadingOpen = this.pageStatus === 'loading' || this.qryPaginaMeusAvisosStatus === 'loading';
        const loadingList = this.qryListarMeusAvisosStatus === 'loading';
        const hasMore = !!this.avisos?.hasMore;
        const nextPage = (this.avisos?.page ?? 1) + 1;
        return html `
<section data-organism-id="listaAvisos" class="flex flex-col gap-3" aria-label=${this.msg['listaRegiao']}>
<div class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] p-3">
<groupenterdateinterval--ml-date-range-dual-calendar
.startDate=${this.filtroDataInicio}
.endDate=${this.filtroDataFim}
.loading=${loadingList}
locale="pt-BR"
@change=${(e) => this.qryListarMeusAvisos(e.detail.startDate, e.detail.endDate, 1, false)}
>
<Label>${this.msg['filtroPeriodo']}</Label>
<LabelStart>${this.msg['filtroDe']}</LabelStart>
<LabelEnd>${this.msg['filtroAte']}</LabelEnd>
</groupenterdateinterval--ml-date-range-dual-calendar>
</div>
${this.qryListarMeusAvisosError
            ? html `<div class="text-sm text-[var(--text-default,currentColor)]" aria-live="polite">
${this.msg['erroLista']}
<button type="button" class="underline text-[var(--link-text,currentColor)] focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]" @click=${() => this.qryListarMeusAvisos()}>${this.msg['tentarNovamente']}</button>
</div>`
            : nothing}
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] max-h-[65vh] overflow-auto">
<groupviewdata--ml-vertical-record-list
.hoverable=${true}
.loading=${loadingOpen || loadingList}
@row-click=${(e) => {
            const item = items[e.detail.index];
            if (item)
                this.selectAvisoVencimento(item.id);
        }}
>
<Columns>
<Column field="data" header=${this.msg['colData']} />
<Column field="totais" header=${this.msg['colTotais']} width="150px" />
<Column field="envio" header=${this.msg['colEnvio']} width="130px" align="right" />
</Columns>
<Rows>
${items.map((aviso) => html `
<Row ?selected=${aviso.id === selected}>
<Cell>
<div class="font-medium text-[var(--text-strong,currentColor)]">${fmtDay(aviso.dataReferencia, false)}</div>
</Cell>
<Cell>
<div class="text-xs text-[var(--text-muted,currentColor)]">
${this.msg['tarefas']} <strong class="text-[var(--text-default,currentColor)]">${fmtNumber(aviso.details.quantidadeTarefas)}</strong>
· ${this.msg['atrasadas']} <strong class="text-[var(--text-default,currentColor)]">${fmtNumber(aviso.details.quantidadeAtrasadas)}</strong>
</div>
</Cell>
<Cell>${this.avisoStatusChip(aviso.status)}</Cell>
</Row>
`)}
</Rows>
<Empty>
<div class="text-center py-8 text-sm text-[var(--text-muted,currentColor)]">
${this.pageStatus === 'empty' ? this.msg['semAvisos'] : this.msg['listaVazia']}
</div>
</Empty>
<Loading>
<div class="text-center py-8 text-sm text-[var(--text-muted,currentColor)]">${this.msg['carregando']}</div>
</Loading>
</groupviewdata--ml-vertical-record-list>
</div>
${hasMore
            ? html `<button type="button"
class="self-start min-h-[36px] rounded-md px-3 text-sm border border-[var(--button-secondary-border,currentColor)] bg-[var(--button-secondary-bg,transparent)] text-[var(--button-secondary-text,currentColor)] focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)] disabled:opacity-50"
?disabled=${loadingList}
aria-busy=${loadingList ? 'true' : 'false'}
@click=${() => this.qryListarMeusAvisos(undefined, undefined, nextPage, true)}>
${loadingList ? this.msg['carregandoMais'] : this.msg['carregarMais']}
</button>`
            : nothing}
</section>
`;
    }
    renderAviso() {
        const aviso = this.avisoAtual;
        const loading = this.qryAvisoPorIdStatus === 'loading';
        if (this.qryAvisoPorIdError) {
            return html `<div data-organism-id="avisoDoDia" class="p-4 text-sm text-[var(--text-default,currentColor)]" aria-live="polite">
${this.msg['erroAviso']}
${this.selectedAvisoVencimento
                ? html `<button type="button" class="underline text-[var(--link-text,currentColor)] focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]" @click=${() => this.qryAvisoPorId(this.selectedAvisoVencimento)}>${this.msg['tentarNovamente']}</button>`
                : nothing}
</div>`;
        }
        if (!aviso) {
            return html `<div data-organism-id="avisoDoDia" class="p-8 text-sm text-center text-[var(--text-muted,currentColor)]" aria-live="polite">
${this.pageStatus === 'loading' ? this.msg['carregando'] : this.pageStatus === 'empty' ? this.msg['semAvisos'] : this.msg['painelVazio']}
</div>`;
        }
        const linhas = aviso.details.tarefas ?? [];
        return html `
<div data-organism-id="avisoDoDia" class="flex flex-col gap-5" aria-busy=${loading ? 'true' : 'false'}>
<div class="flex items-center gap-3 flex-wrap">
<h2 class="text-xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['avisoDe']} ${fmtDay(aviso.dataReferencia, true)}</h2>
${this.avisoStatusChip(aviso.status)}
</div>
<div class="grid grid-cols-2 gap-4 max-w-xl">
<groupviewmetric--ml-metric-card .loading=${loading}>
<Label>${this.msg['metricTarefas']}</Label>
<Value>${fmtNumber(aviso.details.quantidadeTarefas)}</Value>
</groupviewmetric--ml-metric-card>
<groupviewmetric--ml-metric-card .loading=${loading}>
<Label>${this.msg['metricAtrasadas']}</Label>
<Value>${fmtNumber(aviso.details.quantidadeAtrasadas)}</Value>
</groupviewmetric--ml-metric-card>
</div>
<groupviewtable--ml-view-table .loading=${loading}>
<TableHeader>
<TableRow>
<TableHead key="titulo">${this.msg['colTarefa']}</TableHead>
<TableHead key="prazo">${this.msg['colPrazo']}</TableHead>
<TableHead key="vencimento">${this.msg['colVencimento']}</TableHead>
<TableHead key="situacao">${this.msg['colSituacao']}</TableHead>
</TableRow>
</TableHeader>
<TableBody>
${linhas.map((linha) => html `
<TableRow key=${linha.tarefaId}>
<TableCell>${linha.tarefa.titulo}</TableCell>
<TableCell sort-value=${linha.prazo}>${fmtDay(linha.prazo, false)}</TableCell>
<TableCell>
${linha.situacaoPrazo === 'overdue'
            ? this.chip('warning', this.msg['atrasada'])
            : this.chip('info', this.msg['venceHoje'])}
</TableCell>
<TableCell>${this.tarefaStatusLabel(linha.tarefa.status)}</TableCell>
</TableRow>
`)}
</TableBody>
<Empty>${this.msg['tarefasVazio']}</Empty>
<Loading>${this.msg['carregando']}</Loading>
</groupviewtable--ml-view-table>
</div>
`;
    }
    renderHistorico() {
        const items = this.avisos?.items ?? [];
        const loading = this.pageStatus === 'loading' || this.qryPaginaMeusAvisosStatus === 'loading';
        return html `
<div data-organism-id="historicoAvisos">
<groupviewdata--ml-timeline-view .loading=${loading}>
<Columns>
<Column field="quando" header=${this.msg['envioQuando']} width="150px" />
<Column field="evento" header=${this.msg['envioEvento']} />
</Columns>
<Rows>
${items.map((aviso) => html `
<Row>
<Cell><span class="text-xs text-[var(--text-muted,currentColor)]">${fmtDateTime(aviso.details.geradoEm)}</span></Cell>
<Cell>
<div class="font-medium text-[var(--text-strong,currentColor)]">${this.msg['avisoDe']} ${fmtDay(aviso.dataReferencia, false)}</div>
<div class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['envioGerado']}</div>
</Cell>
</Row>
${aviso.details.finalizadoEm || aviso.status === 'failed'
            ? html `<Row>
<Cell><span class="text-xs text-[var(--text-muted,currentColor)]">${aviso.details.finalizadoEm ? fmtDateTime(aviso.details.finalizadoEm) : ''}</span></Cell>
<Cell>
<div class="flex items-center gap-2">
<span class="font-medium text-[var(--text-strong,currentColor)]">${this.msg['envioFinalizado']}</span>
${this.avisoStatusChip(aviso.status)}
</div>
${aviso.status === 'failed' && aviso.details.motivoFalha
                ? html `<div class="text-xs text-[var(--text-default,currentColor)]">${this.msg['envioMotivo']}: ${aviso.details.motivoFalha}</div>`
                : nothing}
</Cell>
</Row>`
            : nothing}
`)}
</Rows>
<Empty><div class="text-center py-8 text-sm text-[var(--text-muted,currentColor)]">${this.msg['envioVazio']}</div></Empty>
<Loading><div class="text-center py-8 text-sm text-[var(--text-muted,currentColor)]">${this.msg['carregando']}</div></Loading>
</groupviewdata--ml-timeline-view>
</div>
`;
    }
    renderPanel() {
        return html `
<section class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4 min-w-0">
<molecules--ml-scenary-102020
mode="tabs"
.value=${this.scenary || 'aviso'}
backLabel=${this.msg['voltar']}
@change=${(e) => {
            if (e.target === e.currentTarget)
                this.setScenario(e.detail.value);
        }}
>
<Scene value="aviso" title=${this.msg['tabTarefas']}>${this.renderAviso()}</Scene>
<Scene value="envio" title=${this.msg['tabEnvio']}>${this.renderHistorico()}</Scene>
</molecules--ml-scenary-102020>
</section>
`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        const blocked = this.pageStatus === 'error' || this.qryPaginaMeusAvisosStatus === 'error';
        return html `
<div class="block p-6 bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)]">
${this.renderHeader()}
${blocked
            ? this.renderBlockingState()
            : html `<div class="grid grid-cols-[minmax(340px,420px)_minmax(0,1fr)] gap-6 items-start">
${this.renderList()} ${this.renderPanel()}
</div>`}
</div>
`;
    }
};
TarefasDesktopPage11Meus_avisosPage = __decorate([
    customElement('tarefas--web--desktop--page11--meus_avisos-102047')
], TarefasDesktopPage11Meus_avisosPage);
export { TarefasDesktopPage11Meus_avisosPage };

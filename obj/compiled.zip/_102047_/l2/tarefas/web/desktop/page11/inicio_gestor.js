var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/inicio_gestor.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasInicio_gestorShared } from '/_102047_/l2/tarefas/web/shared/inicio_gestor.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Visão da equipe',
    headlinePrefix: 'Precisam de você:',
    overdueOne: 'atrasada',
    overdueMany: 'atrasadas',
    dueTodayOne: 'vence hoje',
    dueTodayMany: 'vencem hoje',
    and: 'e',
    goodNews: 'Nada precisa de atenção agora.',
    goodNewsHint: 'Nenhuma tarefa da equipe está atrasada ou vence hoje.',
    queueHint: 'Da mais atrasada para a que vence hoje. Toque numa tarefa para tratá-la em Tarefas da equipe.',
    colTarefa: 'Tarefa',
    colPrioridade: 'Prioridade',
    colSituacao: 'Situação',
    colChecklist: 'Checklist',
    colPrazo: 'Prazo',
    colAbrir: 'Abrir',
    checklistLabel: 'Checklist',
    responsavel: 'Responsável',
    overdueFact: 'Atrasada',
    dueTodayFact: 'Vence hoje',
    prioLow: 'Prioridade baixa',
    prioMedium: 'Prioridade média',
    prioHigh: 'Prioridade alta',
    stAFazer: 'A fazer',
    stEmAndamento: 'Em andamento',
    stEmRevisao: 'Em revisão',
    stConcluida: 'Concluída',
    stCancelada: 'Cancelada',
    loadMore: 'Mostrar mais tarefas',
    queueLoading: 'Carregando as tarefas da equipe…',
    queueEmpty: 'Nenhuma tarefa na fila.',
    queueErrorTitle: 'Não foi possível carregar as tarefas que pedem sua decisão.',
    panoramaErrorTitle: 'Não foi possível carregar o panorama da equipe.',
    retry: 'Tentar de novo',
    preconditionMissing: 'Escolha uma tarefa da fila para abri-la em Tarefas da equipe.',
    selectionInvalid: 'Essa tarefa não está mais na fila. Atualize a lista e escolha de novo.',
    reloadQueue: 'Atualizar fila',
    stripLabel: 'Panorama da equipe',
    stripOpen: 'Tarefas abertas',
    stripChecklist: 'Checklists das tarefas abertas',
    stripLists: 'Abertas por lista',
    stripLoading: 'Carregando panorama…',
    stripNoLists: 'Nenhuma lista com tarefas abertas.'
};
const pageMessages = {
    'pt-br': pageMessage_pt_br
};
/// **collab_i18n_end**
function formatDate(value) {
    const d = value.length === 10 ? new Date(value + 'T00:00:00') : new Date(value);
    if (Number.isNaN(d.getTime()))
        return value;
    return new Intl.DateTimeFormat(document.documentElement.lang || undefined, { day: '2-digit', month: 'short' }).format(d);
}
function formatNumber(n) {
    return new Intl.NumberFormat(document.documentElement.lang || undefined).format(n);
}
let TarefasDesktopPage11Inicio_gestorPage = class TarefasDesktopPage11Inicio_gestorPage extends TarefasInicio_gestorShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-full bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)]">
<div class="mx-auto max-w-5xl px-8 py-8 flex flex-col gap-8">
<header>
<h1 class="text-sm font-medium text-[var(--text-muted,currentColor)]">${this.msg['pageTitle']}</h1>
</header>
${this.renderTarefasParaAcao()}
${this.renderDestaquesEquipe()}
</div>
</div>
`;
    }
    plural(n, one, many) {
        return n === 1 ? one : many;
    }
    renderHeadline() {
        const items = this.tarefas?.items;
        const loaded = this.listarTarefasParaAcaoStatus === 'success' && items;
        if (this.listarTarefasParaAcaoStatus === 'loading' && !items) {
            return html `<div class="h-9 w-2/3 rounded animate-pulse bg-[var(--surface-alt-bg,transparent)]" aria-hidden="true"></div>`;
        }
        if (loaded && items.length === 0) {
            return html `
<div aria-live="polite">
<p class="text-3xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['goodNews']}</p>
<p class="mt-1 text-sm text-[var(--text-muted,currentColor)]">${this.msg['goodNewsHint']}</p>
</div>`;
        }
        if (this.obterPanoramaEquipeStatus !== 'success')
            return nothing;
        return html `
<p class="text-3xl font-semibold text-[var(--text-strong,currentColor)]" aria-live="polite">
${this.msg['headlinePrefix']}
<span class="text-[var(--status-error-text,currentColor)]">${formatNumber(this.totalAtrasadas)} ${this.plural(this.totalAtrasadas, this.msg['overdueOne'], this.msg['overdueMany'])}</span>
${this.msg['and']}
<span>${formatNumber(this.totalVenceHoje)} ${this.plural(this.totalVenceHoje, this.msg['dueTodayOne'], this.msg['dueTodayMany'])}</span>
</p>`;
    }
    prioLabel(p) {
        if (p === 'high')
            return this.msg['prioHigh'];
        if (p === 'medium')
            return this.msg['prioMedium'];
        return this.msg['prioLow'];
    }
    statusLabel(s) {
        switch (s) {
            case 'aFazer': return this.msg['stAFazer'];
            case 'emAndamento': return this.msg['stEmAndamento'];
            case 'emRevisao': return this.msg['stEmRevisao'];
            case 'concluida': return this.msg['stConcluida'];
            default: return this.msg['stCancelada'];
        }
    }
    renderDecisiveFact(t) {
        if (t.details.atrasada) {
            return html `<div class="text-right tabular-nums font-semibold text-[var(--status-error-text,currentColor)]">
<div>${this.msg['overdueFact']}</div>
<div class="text-sm">${formatDate(t.prazo)}</div>
</div>`;
        }
        if (t.details.venceHoje) {
            return html `<div class="text-right tabular-nums font-semibold text-[var(--status-warning-text,currentColor)]">
<div>${this.msg['dueTodayFact']}</div>
<div class="text-sm">${formatDate(t.prazo)}</div>
</div>`;
        }
        return html `<div class="text-right tabular-nums text-[var(--text-muted,currentColor)]">${formatDate(t.prazo)}</div>`;
    }
    renderErrorNote() {
        const err = this.listarTarefasParaAcaoError;
        if (!err)
            return nothing;
        const text = err.code === 'client.preconditionMissing'
            ? this.msg['preconditionMissing']
            : err.code === 'client.selectionInvalid'
                ? this.msg['selectionInvalid']
                : this.msg['queueErrorTitle'];
        return html `
<div role="alert" aria-live="polite" class="flex items-center justify-between gap-4 rounded-md border border-[var(--border-default,currentColor)] bg-[var(--status-error-bg,transparent)] px-4 py-3 text-sm text-[var(--status-error-text,currentColor)]">
<span>${text}</span>
<molecules--grouptriggeraction--ml-button-standard-102040 size="sm" data-variant="secondary" @action=${() => this.listarTarefasParaAcao()}>
<Label>${this.msg['reloadQueue']}</Label>
</molecules--grouptriggeraction--ml-button-standard-102040>
</div>`;
    }
    renderTarefasParaAcao() {
        const items = this.tarefas?.items ?? [];
        const loading = this.listarTarefasParaAcaoStatus === 'loading' && items.length === 0;
        const failedNoData = this.listarTarefasParaAcaoStatus === 'error' && items.length === 0;
        const hasMore = !!this.tarefas?.hasMore;
        const page = this.tarefas?.page ?? 1;
        const showList = items.length > 0 || loading;
        return html `
<section data-organism-id="tarefasParaAcao" class="flex flex-col gap-4" aria-busy=${loading ? 'true' : 'false'}>
${this.renderHeadline()}
${showList ? html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['queueHint']}</p>` : nothing}
${this.renderErrorNote()}
${failedNoData && !this.listarTarefasParaAcaoError ? nothing : nothing}
${showList ? html `
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] overflow-hidden">
<molecules--groupviewdata--ml-vertical-record-list-102040
.hoverable=${true}
.loading=${loading}
@row-click=${(e) => {
            const t = items[e.detail.index];
            if (t)
                this.abrirTarefasEquipe(t.id);
        }}>
<Columns>
<Column field="titulo" header=${this.msg['colTarefa']} />
<Column field="prioridade" header=${this.msg['colPrioridade']} width="150px" />
<Column field="status" header=${this.msg['colSituacao']} width="130px" />
<Column field="checklist" header=${this.msg['colChecklist']} width="90px" align="center" />
<Column field="prazo" header=${this.msg['colPrazo']} width="130px" align="right" />
<Column field="abrir" header=${this.msg['colAbrir']} width="32px" align="right" />
</Columns>
<Rows>
${items.map(t => html `
<Row ?selected=${t.id === this.selectedTarefa}>
<Cell>
<div class="min-h-11 flex flex-col justify-center">
<div class="font-medium text-[var(--text-strong,currentColor)]">${t.titulo}</div>
<div class="text-sm text-[var(--text-muted,currentColor)]">${t.lista.nome} · ${t.membroEquipe.details.identification.name}</div>
</div>
</Cell>
<Cell><span class="text-sm text-[var(--text-muted,currentColor)]">${this.prioLabel(t.prioridade)}</span></Cell>
<Cell><span class="text-sm text-[var(--text-muted,currentColor)]">${this.statusLabel(t.status)}</span></Cell>
<Cell><span class="text-sm tabular-nums text-[var(--text-muted,currentColor)]" title=${this.msg['checklistLabel']}>${t.details.progressoChecklist}</span></Cell>
<Cell>${this.renderDecisiveFact(t)}</Cell>
<Cell>
<svg class="w-4 h-4 text-[var(--text-muted,currentColor)]" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M7 4l6 6-6 6" stroke-linecap="round" stroke-linejoin="round"/></svg>
</Cell>
</Row>`)}
</Rows>
<Loading>
<div class="py-10 text-center text-[var(--text-muted,currentColor)]">${this.msg['queueLoading']}</div>
</Loading>
<Empty>
<div class="py-8 text-center text-[var(--text-muted,currentColor)]">${this.msg['queueEmpty']}</div>
</Empty>
</molecules--groupviewdata--ml-vertical-record-list-102040>
</div>
${hasMore ? html `
<div class="flex justify-center">
<molecules--grouptriggeraction--ml-button-standard-102040
size="md"
data-variant="secondary"
?loading=${this.listarTarefasParaAcaoStatus === 'loading'}
@action=${() => this.listarTarefasParaAcao(page + 1, true)}>
<Label>${this.msg['loadMore']}</Label>
</molecules--grouptriggeraction--ml-button-standard-102040>
</div>` : nothing}
` : nothing}
</section>
`;
    }
    renderListaChip(l) {
        return html `
<li class="inline-flex items-baseline gap-1.5">
<span class="tabular-nums font-medium text-[var(--text-strong,currentColor)]">${formatNumber(l.details.quantidadeTarefasAbertas)}</span>
<span>${l.nome}</span>
</li>`;
    }
    renderDestaquesEquipe() {
        const status = this.obterPanoramaEquipeStatus;
        let body;
        if (status === 'error') {
            body = html `
<div role="alert" aria-live="polite" class="flex items-center justify-between gap-4 text-sm text-[var(--status-error-text,currentColor)]">
<span>${this.msg['panoramaErrorTitle']}</span>
<molecules--grouptriggeraction--ml-button-standard-102040 size="sm" data-variant="secondary" @action=${() => this.obterPanoramaEquipe()}>
<Label>${this.msg['retry']}</Label>
</molecules--grouptriggeraction--ml-button-standard-102040>
</div>`;
        }
        else if (status !== 'success') {
            body = html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['stripLoading']}</p>`;
        }
        else {
            body = html `
<div class="flex flex-col gap-3 text-sm text-[var(--text-muted,currentColor)]">
<dl class="flex flex-wrap gap-x-8 gap-y-2">
<div class="flex items-baseline gap-1.5">
<dd class="order-1 tabular-nums font-medium text-[var(--text-strong,currentColor)]">${formatNumber(this.totalAbertas)}</dd>
<dt class="order-2">${this.msg['stripOpen']}</dt>
</div>
<div class="flex items-baseline gap-1.5">
<dd class="order-1 tabular-nums font-medium text-[var(--text-strong,currentColor)]">${this.progressoChecklist}</dd>
<dt class="order-2">${this.msg['stripChecklist']}</dt>
</div>
</dl>
<div class="flex flex-wrap items-baseline gap-x-4 gap-y-1">
<span>${this.msg['stripLists']}:</span>
${this.listas.length > 0
                ? html `<ul class="flex flex-wrap gap-x-6 gap-y-1">${this.listas.map(l => this.renderListaChip(l))}</ul>`
                : html `<span>${this.msg['stripNoLists']}</span>`}
</div>
</div>`;
        }
        return html `
<section data-organism-id="destaquesEquipe" aria-label=${this.msg['stripLabel']}
class="border-t border-[var(--border-subtle,currentColor)] pt-4" aria-busy=${status === 'loading' ? 'true' : 'false'}>
${body}
</section>`;
    }
};
TarefasDesktopPage11Inicio_gestorPage = __decorate([
    customElement('tarefas--web--desktop--page11--inicio_gestor-102047')
], TarefasDesktopPage11Inicio_gestorPage);
export { TarefasDesktopPage11Inicio_gestorPage };

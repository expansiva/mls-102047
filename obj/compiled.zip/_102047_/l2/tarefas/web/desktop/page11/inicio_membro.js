var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/inicio_membro.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasInicio_membroShared } from '/_102047_/l2/tarefas/web/shared/inicio_membro.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Início',
    refresh: 'Atualizar',
    loading: 'Carregando seu início',
    headlineAttention: 'O que precisa de você agora',
    headlineClear: 'Nada precisa de você agora',
    clearHint: 'Nenhuma tarefa espera por uma ação sua. Veja abaixo como está sua carga de trabalho.',
    laneDevolvidas: 'Devolvidas para ajuste',
    laneDevolvidasHint: 'O criador pediu ajustes. Leia o motivo e reenvie.',
    laneRevisar: 'Entregas aguardando sua revisão',
    laneRevisarHint: 'Tarefas que você criou e que já foram entregues para conferência.',
    laneEnviar: 'Em andamento, prontas para entregar',
    laneEnviarHint: 'Quando terminar, envie para o criador revisar.',
    laneIniciar: 'Esperando para começar',
    laneIniciarHint: 'Tarefas atribuídas a você que ainda não foram iniciadas.',
    actIniciar: 'Iniciar',
    actEnviar: 'Enviar para revisão',
    actReenviar: 'Reenviar para revisão',
    actAbrir: 'Abrir tarefa',
    actAceitar: 'Aceitar entrega',
    actDevolver: 'Devolver para ajuste',
    actConfirmarDevolucao: 'Confirmar devolução',
    actCancelar: 'Cancelar',
    motivoLabel: 'Motivo da devolução',
    motivoPlaceholder: 'Explique o que precisa ser ajustado',
    motivoHint: 'O responsável lê este motivo ao retomar a tarefa.',
    motivoInformado: 'Motivo informado',
    prazo: 'Prazo',
    responsavel: 'Responsável',
    criadaPor: 'Criada por',
    checklist: 'Checklist',
    prioridade: 'Prioridade',
    devolvidaEm: 'Devolvida em',
    prioLow: 'baixa',
    prioMedium: 'média',
    prioHigh: 'alta',
    stAFazer: 'A fazer',
    stEmAndamento: 'Em andamento',
    stEmRevisao: 'Em revisão',
    stConcluida: 'Concluída',
    stCancelada: 'Cancelada',
    stripAria: 'Carga de trabalho',
    stripAbertas: 'Abertas',
    stripHoje: 'Vencem hoje',
    stripAtrasadas: 'Atrasadas',
    destaquesTitle: 'Minhas tarefas em destaque',
    destaquesVazio: 'Nenhuma tarefa aberta no momento.',
    verTodas: 'Ver todas as minhas tarefas',
    listaLabel: 'Lista',
    avisoTitle: 'Aviso das 8h',
    avisoVazio: 'O aviso de hoje ainda não foi gerado.',
    avisoTarefas: 'Tarefas no aviso',
    avisoAtrasadas: 'Atrasadas',
    avisoReferente: 'Referente a',
    avisoAbrir: 'Ver tarefas do aviso',
    avisoPending: 'Aguardando envio',
    avisoCompleted: 'Enviado',
    avisoFailed: 'Falha no envio',
    loadErrorTitle: 'Não foi possível carregar seu início',
    retry: 'Tentar novamente',
    preconditionTitle: 'Falta indicar qual tarefa abrir',
    preconditionBody: 'A tarefa escolhida não foi identificada. Abra a lista de tarefas e escolha uma por lá.',
    goToTasks: 'Ir para minhas tarefas',
    okIniciar: 'Tarefa iniciada.',
    okEnviar: 'Tarefa enviada para revisão.',
    okAceitar: 'Entrega aceita. A tarefa foi concluída.',
    okDevolver: 'Tarefa devolvida com o motivo informado.'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
const statusKey = {
    aFazer: 'stAFazer',
    emAndamento: 'stEmAndamento',
    emRevisao: 'stEmRevisao',
    concluida: 'stConcluida',
    cancelada: 'stCancelada'
};
const prioKey = { low: 'prioLow', medium: 'prioMedium', high: 'prioHigh' };
const avisoKey = { pending: 'avisoPending', completed: 'avisoCompleted', failed: 'avisoFailed' };
function fmtDate(v) {
    if (!v)
        return '';
    const d = new Date(v.length === 10 ? v + 'T00:00:00' : v);
    if (Number.isNaN(d.getTime()))
        return v;
    return new Intl.DateTimeFormat(document.documentElement.lang || undefined, { day: '2-digit', month: 'short' }).format(d);
}
function fmtNumber(n) {
    return new Intl.NumberFormat(document.documentElement.lang || undefined).format(n);
}
const focusRing = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]';
let TarefasDesktopPage11Inicio_membroPage = class TarefasDesktopPage11Inicio_membroPage extends TarefasInicio_membroShared {
    busy() {
        return this.iniciarTarefaStatus === 'loading'
            || this.enviarParaRevisaoStatus === 'loading'
            || this.aceitarEntregaStatus === 'loading'
            || this.devolverComMotivoStatus === 'loading';
    }
    act(label, variant, handler, disabled = false) {
        return html `<grouptriggeraction--ml-button-standard-102040 size="sm" data-variant=${variant}
?disabled=${disabled || this.busy()} @action=${handler}><Label>${label}</Label></grouptriggeraction--ml-button-standard-102040>`;
    }
    renderFeedback() {
        const errors = [
            this.iniciarTarefaError, this.enviarParaRevisaoError, this.aceitarEntregaError, this.devolverComMotivoError
        ];
        const oks = [];
        if (this.iniciarTarefaStatus === 'success')
            oks.push(this.msg.okIniciar);
        if (this.enviarParaRevisaoStatus === 'success')
            oks.push(this.msg.okEnviar);
        if (this.aceitarEntregaStatus === 'success')
            oks.push(this.msg.okAceitar);
        if (this.devolverComMotivoStatus === 'success')
            oks.push(this.msg.okDevolver);
        const loadErr = this.pageStatus === 'error' ? null : this.carregarInicioError;
        return html `<div aria-live="polite" class="flex flex-col gap-2 empty:hidden">
${errors.map(e => e ? html `<p role="alert" class="rounded-md px-3 py-2 text-sm bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]">${e.message}</p>` : nothing)}
${oks.map(o => html `<p class="rounded-md px-3 py-2 text-sm bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]">${o}</p>`)}
${loadErr ? this.renderLoadError() : nothing}
</div>`;
    }
    renderLoadError() {
        const err = this.carregarInicioError;
        if (!err)
            return nothing;
        const precondition = err.code === 'client.preconditionMissing';
        return html `<div role="alert" class="rounded-md border border-[var(--border-default,currentColor)] bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)] p-4 flex flex-col gap-2">
<p class="font-semibold">${precondition ? this.msg.preconditionTitle : this.msg.loadErrorTitle}</p>
<p class="text-sm">${precondition ? this.msg.preconditionBody : err.message}</p>
<div>
${precondition
            ? this.act(this.msg.goToTasks, 'secondary', () => this.abrirMinhasTarefas())
            : this.act(this.msg.retry, 'secondary', () => { void this.carregarInicio(); })}
</div>
</div>`;
    }
    renderSkeleton() {
        return html `<div class="flex flex-col gap-3" aria-busy="true" aria-label=${this.msg.loading}>
${[0, 1, 2].map(() => html `<div class="h-16 rounded-md animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>`)}
</div>`;
    }
    renderRow(t, who, actions, extra = nothing) {
        const person = who === 'responsavel'
            ? `${this.msg.responsavel}: ${t.responsavel?.details?.identification?.name ?? ''}`
            : `${this.msg.criadaPor}: ${t.criador?.details?.identification?.name ?? ''}`;
        return html `<li class="grid grid-cols-[minmax(0,1fr)_7rem_auto] items-center gap-x-6 gap-y-2 px-4 py-3 border-b border-[var(--border-subtle,currentColor)] last:border-b-0">
<div class="min-w-0">
<button type="button" @click=${() => this.abrirTarefaParaAjustar(t.id)}
class="text-left font-medium text-[var(--link-text,currentColor)] hover:underline rounded ${focusRing}">${t.titulo}</button>
<p class="mt-0.5 text-xs text-[var(--text-muted,currentColor)]">
${person} · ${this.msg.prioridade}: ${this.msg[prioKey[t.prioridade]]} · ${this.msg.checklist}: ${t.details?.progressoChecklist ?? ''}
</p>
</div>
<div class="text-right tabular-nums">
<span class="block text-xs text-[var(--text-muted,currentColor)]">${this.msg.prazo}</span>
<span class="font-semibold text-[var(--text-strong,currentColor)]">${fmtDate(t.prazo)}</span>
</div>
<div class="flex flex-wrap justify-end gap-2">${actions}</div>
${extra}
</li>`;
    }
    renderLane(title, hint, items, row) {
        if (!items || items.length === 0)
            return nothing;
        return html `<section class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)]">
<header class="px-4 pt-3 pb-2">
<h3 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${title}</h3>
<p class="text-xs text-[var(--text-muted,currentColor)]">${hint}</p>
</header>
<ul class="border-t border-[var(--border-subtle,currentColor)]">${items.map(row)}</ul>
</section>`;
    }
    renderDevolverForm(t) {
        const d = this.devolverComMotivoDraft;
        const motivo = d.details.motivoDevolucao ?? '';
        return html `<div class="col-span-3 flex flex-col gap-2 rounded-md bg-[var(--surface-alt-bg,transparent)] p-3">
<label class="text-sm font-medium text-[var(--text-strong,currentColor)]" for=${'motivo-' + t.id}>${this.msg.motivoLabel}</label>
<textarea id=${'motivo-' + t.id} rows="3" .value=${motivo} placeholder=${this.msg.motivoPlaceholder}
@input=${(e) => this.setDevolverComMotivoDraft({
            id: t.id, version: t.version,
            details: { motivoDevolucao: e.target.value }
        })}
class="w-full rounded-md border border-[var(--border-default,currentColor)] bg-[var(--input-bg,transparent)] p-2 text-sm text-[var(--text-default,currentColor)] ${focusRing}"></textarea>
<p class="text-xs text-[var(--text-muted,currentColor)]">${this.msg.motivoHint}</p>
<div class="flex gap-2 justify-end">
${this.act(this.msg.actCancelar, 'ghost', () => this.setDevolverComMotivoDraft({ id: null, version: null, details: { motivoDevolucao: null } }))}
${this.act(this.msg.actConfirmarDevolucao, 'primary', () => { void this.devolverComMotivo(t.id, t.version); }, motivo.trim() === '')}
</div>
</div>`;
    }
    renderLanes() {
        const e = this.esperaPorMim;
        return html `
${this.renderLane(this.msg.laneDevolvidas, this.msg.laneDevolvidasHint, e?.devolvidas, t => this.renderRow(t, 'criador', html `${this.act(this.msg.actAbrir, 'secondary', () => this.abrirTarefaParaAjustar(t.id))}
${this.act(this.msg.actReenviar, 'primary', () => { void this.enviarParaRevisao(t.id, t.version); })}`, t.details?.motivoDevolucao
            ? html `<p class="col-span-3 text-sm text-[var(--text-default,currentColor)]">
<span class="text-[var(--text-muted,currentColor)]">${this.msg.motivoInformado}${t.details.devolvidaEm ? ` (${this.msg.devolvidaEm} ${fmtDate(t.details.devolvidaEm)})` : ''}:</span>
${t.details.motivoDevolucao}</p>`
            : nothing))}
${this.renderLane(this.msg.laneRevisar, this.msg.laneRevisarHint, e?.paraRevisar, t => {
            const open = this.devolverComMotivoDraft.id === t.id;
            return this.renderRow(t, 'responsavel', open ? nothing : html `${this.act(this.msg.actDevolver, 'secondary', () => this.setDevolverComMotivoDraft({ id: t.id, version: t.version, details: { motivoDevolucao: '' } }))}
${this.act(this.msg.actAceitar, 'primary', () => { void this.aceitarEntrega(t.id, t.version); })}`, open ? this.renderDevolverForm(t) : nothing);
        })}
${this.renderLane(this.msg.laneEnviar, this.msg.laneEnviarHint, e?.paraEnviarRevisao, t => this.renderRow(t, 'criador', this.act(this.msg.actEnviar, 'primary', () => { void this.enviarParaRevisao(t.id, t.version); })))}
${this.renderLane(this.msg.laneIniciar, this.msg.laneIniciarHint, e?.paraIniciar, t => this.renderRow(t, 'criador', this.act(this.msg.actIniciar, 'primary', () => { void this.iniciarTarefa(t.id, t.version); })))}
`;
    }
    renderTriage() {
        if (this.pageStatus === 'idle' || this.pageStatus === 'loading')
            return this.renderSkeleton();
        if (this.pageStatus === 'error')
            return this.carregarInicioError ? this.renderLoadError() : nothing;
        if (this.pageStatus === 'empty') {
            return html `<p class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)] px-4 py-5">${this.msg.clearHint}</p>`;
        }
        return this.renderLanes();
    }
    renderResumoTarefa(t) {
        return html `<li class="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-6 px-4 py-2 border-b border-[var(--border-subtle,currentColor)] last:border-b-0">
<div class="min-w-0">
<button type="button" @click=${() => this.abrirTarefaParaAjustar(t.id)}
class="text-left font-medium text-[var(--link-text,currentColor)] hover:underline rounded ${focusRing}">${t.titulo}</button>
<p class="text-xs text-[var(--text-muted,currentColor)]">
${this.msg.listaLabel}: ${t.lista?.nome ?? ''} · ${this.msg[statusKey[t.status]]} · ${this.msg.checklist}: ${t.details?.progressoChecklist ?? ''}
</p>
</div>
<span class="tabular-nums text-sm font-semibold ${t.details?.atrasada ? 'text-[var(--status-error-text,currentColor)]' : 'text-[var(--text-strong,currentColor)]'}">${fmtDate(t.prazo)}</span>
</li>`;
    }
    renderResumo() {
        const r = this.resumo;
        if (!r)
            return this.pageStatus === 'loading' ? html `<div class="h-8 rounded animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>` : nothing;
        return html `
<dl aria-label=${this.msg.stripAria} class="flex flex-wrap items-baseline gap-x-8 gap-y-2 border-t border-[var(--border-subtle,currentColor)] pt-4">
<div class="flex items-baseline gap-2"><dd class="order-1 text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${fmtNumber(r.quantidadeAbertas)}</dd><dt class="order-2 text-sm text-[var(--text-muted,currentColor)]">${this.msg.stripAbertas}</dt></div>
<div class="flex items-baseline gap-2"><dd class="order-1 text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${fmtNumber(r.quantidadeVencemHoje)}</dd><dt class="order-2 text-sm text-[var(--text-muted,currentColor)]">${this.msg.stripHoje}</dt></div>
<div class="flex items-baseline gap-2"><dd class="order-1 text-lg font-semibold tabular-nums text-[var(--status-error-text,currentColor)]">${fmtNumber(r.quantidadeAtrasadas)}</dd><dt class="order-2 text-sm text-[var(--text-muted,currentColor)]">${this.msg.stripAtrasadas}</dt></div>
</dl>
<details class="rounded-lg border border-[var(--border-subtle,currentColor)]">
<summary class="cursor-pointer px-4 py-3 text-sm font-medium text-[var(--text-default,currentColor)] ${focusRing}">${this.msg.destaquesTitle}</summary>
${r.tarefas && r.tarefas.length > 0
            ? html `<ul class="border-t border-[var(--border-subtle,currentColor)]">${r.tarefas.map(t => this.renderResumoTarefa(t))}</ul>`
            : html `<p class="px-4 py-3 text-sm text-[var(--text-muted,currentColor)]">${this.msg.destaquesVazio}</p>`}
<div class="px-4 py-3 border-t border-[var(--border-subtle,currentColor)]">
<grouptriggeraction--ml-button-standard-102040 size="sm" data-variant="link" @action=${() => this.abrirMinhasTarefas()}><Label>${this.msg.verTodas}</Label></grouptriggeraction--ml-button-standard-102040>
</div>
</details>`;
    }
    renderAviso() {
        const a = this.avisoDoDia;
        return html `<aside class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4 flex flex-col gap-3">
<h2 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${this.msg.avisoTitle}</h2>
${a ? html `
<span class="self-start rounded-full px-2 py-0.5 text-xs bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]">${this.msg[avisoKey[a.status]]}</span>
<p class="text-xs text-[var(--text-muted,currentColor)]">${this.msg.avisoReferente} ${fmtDate(a.dataReferencia)}</p>
<dl class="flex gap-6">
<div><dd class="text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${fmtNumber(a.details.quantidadeTarefas)}</dd><dt class="text-xs text-[var(--text-muted,currentColor)]">${this.msg.avisoTarefas}</dt></div>
<div><dd class="text-lg font-semibold tabular-nums text-[var(--status-error-text,currentColor)]">${fmtNumber(a.details.quantidadeAtrasadas)}</dd><dt class="text-xs text-[var(--text-muted,currentColor)]">${this.msg.avisoAtrasadas}</dt></div>
</dl>
<div>${this.act(this.msg.avisoAbrir, 'secondary', () => this.abrirMeusAvisos())}</div>`
            : html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg.avisoVazio}</p>`}
</aside>`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        const loading = this.carregarInicioStatus === 'loading';
        return html `<div class="min-h-full p-8 bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)]">
<div class="mx-auto max-w-6xl flex flex-col gap-6">
<header class="flex items-center justify-between gap-4">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg.pageTitle}</h1>
<grouptriggeraction--ml-button-standard-102040 size="sm" data-variant="ghost" ?loading=${loading} ?disabled=${loading}
@action=${() => { void this.carregarInicio(); }}><Label>${this.msg.refresh}</Label></grouptriggeraction--ml-button-standard-102040>
</header>
${this.renderFeedback()}
<div class="grid grid-cols-[minmax(0,1fr)_20rem] gap-8 items-start">
<div class="flex flex-col gap-4" aria-busy=${loading ? 'true' : 'false'}>
<div data-organism-id="esperaPorMim" class="flex flex-col gap-4">
<h2 class="text-xl font-semibold text-[var(--text-strong,currentColor)]">${this.pageStatus === 'empty' ? this.msg.headlineClear : this.msg.headlineAttention}</h2>
${this.renderTriage()}
</div>
<div data-organism-id="resumoMinhasTarefas" class="flex flex-col gap-4 mt-2">
${this.renderResumo()}
</div>
</div>
<div data-organism-id="avisoDoDia">${this.renderAviso()}</div>
</div>
</div>
</div>`;
    }
};
TarefasDesktopPage11Inicio_membroPage = __decorate([
    customElement('tarefas--web--desktop--page11--inicio_membro-102047')
], TarefasDesktopPage11Inicio_membroPage);
export { TarefasDesktopPage11Inicio_membroPage };

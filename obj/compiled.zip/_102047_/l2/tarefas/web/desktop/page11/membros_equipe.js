var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/desktop/page11/membros_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasMembros_equipeShared } from '/_102047_/l2/tarefas/web/shared/membros_equipe.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Equipe',
    pageSubtitle: 'Pessoas que podem criar tarefas e ser responsáveis por elas.',
    searchLabel: 'Buscar pessoa pelo nome',
    searchPlaceholder: 'Buscar pelo nome',
    newPerson: 'Nova pessoa',
    colName: 'Nome',
    colCountry: 'País',
    colStatus: 'Situação no cadastro',
    colContacts: 'Contatos',
    statusActive: 'Ativo',
    statusInactive: 'Inativo',
    statusMerged: 'Unificado',
    statusBlocked: 'Bloqueado',
    emptyList: 'Nenhuma pessoa encontrada.',
    emptyListSearch: 'Nenhuma pessoa encontrada. Tente outro nome.',
    loadMore: 'Mostrar mais pessoas',
    retry: 'Tentar de novo',
    listError: 'Não foi possível carregar a equipe.',
    missingTitle: 'Falta indicar o que abrir',
    missingBody: 'Esta tela foi aberta sem as informações de que precisa. Volte à tela anterior e abra a equipe de novo.',
    back: 'Voltar',
    closePanel: 'Fechar painel',
    idleTitle: 'Cadastro de pessoas',
    idleHint: 'Escolha uma pessoa na lista para corrigir o nome e o país, ou cadastre uma nova pessoa.',
    newTitle: 'Dados da pessoa',
    editTitleFallback: 'Pessoa selecionada',
    fieldName: 'Nome',
    fieldNameHelper: 'É o nome que aparece como responsável e criador nas tarefas.',
    fieldCountry: 'País',
    fieldCountryHelper: 'Código do país, por exemplo BR. Define as regras de privacidade aplicáveis.',
    countryPlaceholder: 'BR',
    registerPerson: 'Cadastrar pessoa',
    saveChanges: 'Salvar alterações',
    registered: 'Pessoa cadastrada:',
    saved: 'Alterações salvas.',
    registerFailed: 'Não foi possível cadastrar a pessoa.',
    saveFailed: 'Não foi possível salvar as alterações.',
    readOnlyStatus: 'Situação no cadastro',
    readOnlyRoles: 'Papéis',
    readOnlyContacts: 'Contatos',
    activeHint: 'Ativo pode receber tarefas.',
    discardConfirm: 'Há alterações não salvas nesta pessoa. Descartar e abrir outra?',
    noValue: '—',
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
function isDirty(rec, draft) {
    if (!rec)
        return false;
    const a = rec.details.identification;
    const b = draft.details.identification;
    return (b.name ?? '') !== a.name || (b.countryCode ?? '') !== a.countryCode;
}
let TarefasDesktopPage11Membros_equipePage = class TarefasDesktopPage11Membros_equipePage extends TarefasMembros_equipeShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    setScenario(value) {
        if (value === 'inicio')
            this.selectMembroEquipe(null);
        super.setScenario(value);
    }
    statusLabel(s) {
        switch (s) {
            case 'Active': return this.msg.statusActive;
            case 'Inactive': return this.msg.statusInactive;
            case 'Merged': return this.msg.statusMerged;
            default: return this.msg.statusBlocked;
        }
    }
    selectRow(index) {
        const item = this.pessoas?.items[index];
        if (!item)
            return;
        if (item.id === this.selectedMembroEquipe)
            return;
        if (isDirty(this.cadastroPessoa, this.cmdSalvarAlteracoesDraft)) {
            if (!window.confirm(this.msg.discardConfirm))
                return;
        }
        this.selectMembroEquipe(item.id);
        this.setScenario('editar');
    }
    renderFeedback(type, visible, text) {
        return html `<groupnotifyuser--ml-contextual-feedback type=${type} ?visible=${visible} .dismissible=${false}>
<Message>${text}</Message>
</groupnotifyuser--ml-contextual-feedback>`;
    }
    renderTable() {
        const items = this.pessoas?.items ?? [];
        const selIdx = items.findIndex((p) => p.id === this.selectedMembroEquipe);
        const loading = this.pageStatus === 'loading' || this.qryPessoasEquipeStatus === 'loading';
        return html `
<groupviewtable--ml-data-table
.value=${selIdx >= 0 ? String(selIdx) : ''}
?loading=${loading && items.length === 0}
@rowClick=${(e) => this.selectRow(e.detail.index)}
>
<TableHeader>
<TableRow>
<TableHead key="name" sortable>${this.msg.colName}</TableHead>
<TableHead key="country">${this.msg.colCountry}</TableHead>
<TableHead key="status">${this.msg.colStatus}</TableHead>
<TableHead key="contacts">${this.msg.colContacts}</TableHead>
</TableRow>
</TableHeader>
<TableBody>
${items.map((p) => {
            const id = p.details.identification;
            const muted = id.status !== 'Active';
            const tone = muted
                ? 'text-[var(--text-muted,currentColor)]'
                : 'text-[var(--text-strong,currentColor)]';
            return html `<TableRow key=${p.id}>
<TableCell><span class="font-medium ${tone}">${id.name}</span></TableCell>
<TableCell><span class=${muted ? 'text-[var(--text-muted,currentColor)]' : 'text-[var(--text-default,currentColor)]'}>${id.countryCode}</span></TableCell>
<TableCell>
<span class="inline-block rounded-full px-2 py-0.5 text-xs ${muted
                ? 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]'
                : 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]'}">${this.statusLabel(id.status)}</span>
</TableCell>
<TableCell><span class="text-sm text-[var(--text-muted,currentColor)]">${p.details.base.contacts || this.msg.noValue}</span></TableCell>
</TableRow>`;
        })}
</TableBody>
<Empty>${this.busca ? this.msg.emptyListSearch : this.msg.emptyList}</Empty>
</groupviewtable--ml-data-table>
${this.pessoas?.hasMore
            ? html `<div class="mt-3 flex justify-center">
<grouptriggeraction--ml-button-standard
data-variant="secondary"
size="sm"
?loading=${this.qryPessoasEquipeStatus === 'loading'}
@action=${() => this.qryPessoasEquipe(undefined, (this.pessoas?.page ?? 1) + 1, true)}
><Label>${this.msg.loadMore}</Label></grouptriggeraction--ml-button-standard>
</div>`
            : nothing}
`;
    }
    renderListError() {
        const err = this.qryPessoasEquipeError;
        if (!err)
            return nothing;
        if (err.code === 'client.preconditionMissing') {
            return html `<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-alt-bg,transparent)] p-6" aria-live="polite">
<p class="font-medium text-[var(--text-strong,currentColor)]">${this.msg.missingTitle}</p>
<p class="mt-1 text-sm text-[var(--text-default,currentColor)]">${this.msg.missingBody}</p>
<div class="mt-4">
<grouptriggeraction--ml-button-standard data-variant="secondary" @action=${() => history.back()}>
<Label>${this.msg.back}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</div>`;
        }
        return html `<div class="mb-3 flex items-center justify-between gap-3 rounded-lg bg-[var(--status-error-bg,transparent)] px-3 py-2 text-sm text-[var(--status-error-text,currentColor)]" aria-live="polite">
<span>${this.msg.listError} ${err.message}</span>
<grouptriggeraction--ml-button-standard data-variant="secondary" size="sm" @action=${() => this.qryPessoasEquipe()}>
<Label>${this.msg.retry}</Label>
</grouptriggeraction--ml-button-standard>
</div>`;
    }
    renderNovo() {
        const d = this.cmdCadastrarPessoaDraft;
        const id = d.details.identification;
        const loading = this.cmdCadastrarPessoaStatus === 'loading';
        const canSave = !!(id.name && id.name.trim()) && !!(id.countryCode && id.countryCode.trim());
        const justDone = this.cmdCadastrarPessoaStatus === 'success';
        const doneName = this.cmdCadastrarPessoaPessoa?.details.identification.name ?? '';
        return html `<form class="flex flex-col gap-4" @submit=${(e) => e.preventDefault()}>
<groupentertext--ml-enter-text
.value=${id.name ?? ''}
required
@input=${(e) => this.setCmdCadastrarPessoaDraft({ details: { identification: { ...id, name: e.detail.value } } })}
>
<Label>${this.msg.fieldName}</Label>
<Helper>${this.msg.fieldNameHelper}</Helper>
</groupentertext--ml-enter-text>
<groupentertext--ml-enter-text
.value=${id.countryCode ?? ''}
placeholder=${this.msg.countryPlaceholder}
required
@input=${(e) => this.setCmdCadastrarPessoaDraft({ details: { identification: { ...id, countryCode: e.detail.value } } })}
>
<Label>${this.msg.fieldCountry}</Label>
<Helper>${this.msg.fieldCountryHelper}</Helper>
</groupentertext--ml-enter-text>
<div aria-live="polite" class="flex flex-col gap-2">
${this.renderFeedback('error', this.cmdCadastrarPessoaStatus === 'error', `${this.msg.registerFailed} ${this.cmdCadastrarPessoaError?.message ?? ''}`)}
${this.renderFeedback('success', justDone, `${this.msg.registered} ${doneName}`)}
</div>
<grouptriggeraction--ml-button-standard
data-class="w-full"
?disabled=${!canSave}
?loading=${loading}
@action=${() => this.cmdCadastrarPessoa()}
><Label>${this.msg.registerPerson}</Label></grouptriggeraction--ml-button-standard>
</form>`;
    }
    renderEditar() {
        const rec = this.cadastroPessoa;
        const d = this.cmdSalvarAlteracoesDraft;
        const id = d.details.identification;
        const loading = this.cmdSalvarAlteracoesStatus === 'loading';
        const filled = !!(id.name && id.name.trim()) && !!(id.countryCode && id.countryCode.trim());
        const canSave = filled && isDirty(rec, d);
        const ident = rec?.details.identification;
        return html `<form class="flex flex-col gap-4" @submit=${(e) => e.preventDefault()}>
<groupentertext--ml-enter-text
.value=${id.name ?? ''}
required
@input=${(e) => this.setCmdSalvarAlteracoesDraft({ ...d, details: { identification: { ...id, name: e.detail.value } } })}
>
<Label>${this.msg.fieldName}</Label>
<Helper>${this.msg.fieldNameHelper}</Helper>
</groupentertext--ml-enter-text>
<groupentertext--ml-enter-text
.value=${id.countryCode ?? ''}
placeholder=${this.msg.countryPlaceholder}
required
@input=${(e) => this.setCmdSalvarAlteracoesDraft({ ...d, details: { identification: { ...id, countryCode: e.detail.value } } })}
>
<Label>${this.msg.fieldCountry}</Label>
<Helper>${this.msg.fieldCountryHelper}</Helper>
</groupentertext--ml-enter-text>
${ident && rec
            ? html `<dl class="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 border-t border-[var(--border-subtle,currentColor)] pt-3 text-sm">
<dt class="text-[var(--text-muted,currentColor)]">${this.msg.readOnlyStatus}</dt>
<dd class="text-[var(--text-default,currentColor)]">${this.statusLabel(ident.status)}${ident.status === 'Active' ? html ` · <span class="text-[var(--text-muted,currentColor)]">${this.msg.activeHint}</span>` : nothing}</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg.readOnlyRoles}</dt>
<dd class="text-[var(--text-default,currentColor)]">${ident.tags || this.msg.noValue}</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg.readOnlyContacts}</dt>
<dd class="text-[var(--text-default,currentColor)]">${rec.details.base.contacts || this.msg.noValue}</dd>
</dl>`
            : nothing}
<div aria-live="polite" class="flex flex-col gap-2">
${this.renderFeedback('error', this.cmdSalvarAlteracoesStatus === 'error', `${this.msg.saveFailed} ${this.cmdSalvarAlteracoesError?.message ?? ''}`)}
${this.renderFeedback('success', this.cmdSalvarAlteracoesStatus === 'success', this.msg.saved)}
</div>
<grouptriggeraction--ml-button-standard
data-class="w-full"
?disabled=${!canSave}
?loading=${loading}
@action=${() => this.cmdSalvarAlteracoes()}
><Label>${this.msg.saveChanges}</Label></grouptriggeraction--ml-button-standard>
</form>`;
    }
    renderPanel() {
        const rec = this.cadastroPessoa;
        const editTitle = rec ? rec.details.identification.name : this.msg.editTitleFallback;
        return html `<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'inicio'}
backLabel=${this.msg.closePanel}
@change=${(e) => { if (e.target === e.currentTarget)
            this.setScenario(e.detail.value); }}
>
<Scene value="inicio" title=${this.msg.idleTitle}>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg.idleHint}</p>
</Scene>
<Scene value="novo" title=${this.msg.newTitle} nav="back" backTo="inicio">
${this.renderNovo()}
</Scene>
<Scene value="editar" title=${editTitle} nav="back" backTo="inicio">
${this.renderEditar()}
</Scene>
</molecules--ml-scenary-102020>`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        const missing = this.qryPessoasEquipeError?.code === 'client.preconditionMissing';
        return html `
<div class="min-h-full bg-[var(--page-bg,transparent)] p-6 text-[var(--text-default,currentColor)]">
<header class="mb-5">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg.pageTitle}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg.pageSubtitle}</p>
</header>
${missing
            ? this.renderListError()
            : html `<div class="grid grid-cols-[minmax(0,1fr)_22rem] items-start gap-6">
<section data-organism-id="pessoasEquipe" class="min-w-0">
<div class="mb-3 flex items-end justify-between gap-4">
<div class="max-w-sm flex-1">
<groupsearchcontent--ml-search-bar
.value=${this.busca}
placeholder=${this.msg.searchPlaceholder}
debounce="300"
?loading=${this.qryPessoasEquipeStatus === 'loading'}
@search=${(e) => this.qryPessoasEquipe(e.detail.query)}
@clear=${() => this.qryPessoasEquipe(null)}
>
<Label data-class="sr-only">${this.msg.searchLabel}</Label>
</groupsearchcontent--ml-search-bar>
</div>
<grouptriggeraction--ml-button-standard
@action=${() => {
                this.selectMembroEquipe(null);
                this.setScenario('novo');
            }}
><Label>${this.msg.newPerson}</Label></grouptriggeraction--ml-button-standard>
</div>
${this.renderListError()}
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-2" aria-busy=${this.qryPessoasEquipeStatus === 'loading' ? 'true' : 'false'}>
${this.renderTable()}
</div>
</section>
<aside data-organism-id="cadastroPessoa" class="sticky top-6 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4">
${this.renderPanel()}
</aside>
</div>`}
</div>
`;
    }
};
TarefasDesktopPage11Membros_equipePage = __decorate([
    customElement('tarefas--web--desktop--page11--membros_equipe-102047')
], TarefasDesktopPage11Membros_equipePage);
export { TarefasDesktopPage11Membros_equipePage };

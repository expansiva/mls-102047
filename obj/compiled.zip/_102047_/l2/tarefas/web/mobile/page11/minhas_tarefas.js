var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/mobile/page11/minhas_tarefas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { keyed } from 'lit/directives/keyed.js';
import { TarefasMinhas_tarefasShared } from '/_102047_/l2/tarefas/web/shared/minhas_tarefas.js';
import '/_102020_/l2/molecules/ml-scenary.js';
import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference.js';
import '/_102040_/l2/molecules/groupenterdate/ml-date-picker.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/groupentertext/ml-multiline-text.js';
import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner.js';
import '/_102040_/l2/molecules/groupselectone/ml-combobox.js';
import '/_102040_/l2/molecules/groupselectone/ml-segmented-control.js';
import '/_102040_/l2/molecules/groupselectone/ml-select.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-kebab-action-trigger.js';
import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card.js';
import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view.js';
import '/_102040_/l2/molecules/groupviewtable/ml-responsive-table.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    sceneLista: 'Minhas tarefas',
    sceneDetalhe: 'Tarefa',
    sceneCriar: 'Nova tarefa',
    sceneEditar: 'Editar tarefa',
    sceneChecklist: 'Checklist da tarefa',
    sceneDevolver: 'Devolução da tarefa',
    sceneCancelar: 'Confirmar cancelamento',
    voltar: 'Voltar',
    filtrosAria: 'Filtros rápidos',
    fTodas: 'Todas',
    fCriadas: 'Criadas por mim',
    fAtribuidas: 'Atribuídas a mim',
    fRevisao: 'Em revisão',
    fDevolvidas: 'Devolvidas',
    hTarefa: 'Tarefa',
    hPrazo: 'Prazo',
    hSituacao: 'Situação',
    hResponsavel: 'Responsável',
    hChecklist: 'Checklist',
    carregando: 'Carregando suas tarefas…',
    erroLista: 'Não foi possível carregar suas tarefas.',
    tentarNovamente: 'Tentar de novo',
    semContexto: 'Esta tela foi aberta sem o contexto do módulo de tarefas, então não sei de quem são as tarefas. Volte e abra de novo pelo módulo.',
    voltarInicio: 'Voltar',
    listaVazia: 'Nenhuma tarefa por aqui. Crie uma tarefa ou troque o filtro.',
    carregarMais: 'Carregar mais tarefas',
    novaTarefa: 'Nova tarefa',
    atrasada: 'Atrasada',
    venceHoje: 'Vence hoje',
    subtarefas: 'subtarefas',
    pBaixa: 'Baixa',
    pMedia: 'Média',
    pAlta: 'Alta',
    stAFazer: 'A fazer',
    stEmAndamento: 'Em andamento',
    stEmRevisao: 'Em revisão',
    stConcluida: 'Concluída',
    stCancelada: 'Cancelada',
    lDescricao: 'Descrição',
    lLista: 'Lista',
    lCriador: 'Criada por',
    lResponsavel: 'Responsável',
    lPrazo: 'Prazo',
    lPrioridade: 'Prioridade',
    lSituacao: 'Situação',
    lCriadaEm: 'Criada em',
    motivoTitulo: 'Motivo da devolução',
    checklist: 'Checklist',
    checklistVazia: 'Esta tarefa não tem itens na checklist.',
    itemFeito: 'Feito',
    itemPendente: 'Pendente',
    editarDados: 'Editar dados',
    marcarItens: 'Marcar itens',
    detalheVazio: 'Nenhuma tarefa aberta. Volte e escolha uma tarefa da lista.',
    detalheCarregando: 'Abrindo a tarefa…',
    detalheErro: 'Não foi possível abrir a tarefa.',
    aIniciar: 'Iniciar tarefa',
    aEnviar: 'Enviar para revisão',
    aReenviar: 'Reenviar para revisão',
    aAceitar: 'Aceitar entrega',
    aDevolver: 'Devolver para ajuste',
    aCancelar: 'Cancelar tarefa',
    maisAcoes: 'Mais ações',
    okIniciada: 'Tarefa iniciada.',
    okEnviada: 'Tarefa enviada para revisão.',
    okAceita: 'Entrega aceita. Tarefa concluída.',
    historico: 'Histórico',
    hQuando: 'Quando',
    hEvento: 'Evento',
    evCriada: 'Tarefa criada',
    evDevolvida: 'Devolvida para ajuste',
    evConcluida: 'Entrega aceita, tarefa concluída',
    evCancelada: 'Tarefa cancelada',
    fLista: 'Lista',
    fListaPlaceholder: 'Escolha a lista',
    fListaVazia: 'Nenhuma lista ativa disponível.',
    fTitulo: 'Título',
    fDescricao: 'Descrição',
    fPrioridade: 'Prioridade',
    fPrazo: 'Prazo',
    fPrazoPh: 'Escolha a data',
    fResponsavel: 'Responsável',
    fResponsavelPh: 'Digite o nome para buscar',
    fResponsavelAjuda: 'Busque pelo nome da pessoa da equipe.',
    fResponsavelVazio: 'Ninguém encontrado.',
    checklistInicial: 'Checklist inicial',
    addItem: 'Adicionar item',
    removerItem: 'Remover item',
    subir: 'Mover item para cima',
    descer: 'Mover item para baixo',
    itemDescricao: 'Descrição do item',
    itemMarcar: 'Marcar item como feito',
    registrar: 'Registrar tarefa',
    salvarEdicao: 'Salvar alterações',
    salvarChecklist: 'Salvar checklist',
    faltaCampos: 'Preencha lista, título, prioridade, prazo e responsável para continuar.',
    edicaoNaoMuda: 'Editar não muda a situação da tarefa.',
    checklistNaoMuda: 'Marcar ou ajustar itens não muda a situação da tarefa.',
    motivo: 'Motivo',
    motivoAjuda: 'Explique o que precisa ser ajustado. A tarefa volta para o responsável.',
    devolverTarefa: 'Devolver tarefa',
    cancelarTexto: 'A tarefa a seguir será cancelada e não poderá mais mudar de situação:',
    manter: 'Manter tarefa',
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
const STATUS_CLS = {
    aFazer: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]',
    emAndamento: 'bg-[var(--status-info-bg,transparent)] text-[var(--status-info-text,currentColor)]',
    emRevisao: 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]',
    concluida: 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]',
    cancelada: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]',
};
let buscaTimer;
function agendar(fn, ms) {
    if (buscaTimer)
        clearTimeout(buscaTimer);
    buscaTimer = setTimeout(fn, ms);
}
function lang() {
    return document.documentElement.lang || undefined;
}
function fmtData(v) {
    if (!v)
        return '';
    const d = new Date(v.length === 10 ? v + 'T12:00:00' : v);
    if (Number.isNaN(d.getTime()))
        return v;
    return new Intl.DateTimeFormat(lang(), { day: '2-digit', month: 'short', year: 'numeric' }).format(d);
}
function fmtDataHora(v) {
    if (!v)
        return '';
    const d = new Date(v);
    if (Number.isNaN(d.getTime()))
        return v;
    return new Intl.DateTimeFormat(lang(), { dateStyle: 'medium', timeStyle: 'short' }).format(d);
}
function texto(e) {
    const d = e.detail;
    if (d && typeof d === 'object' && 'value' in d) {
        const v = d.value;
        return typeof v === 'string' ? v : null;
    }
    return null;
}
function camposOk(d) {
    return !!(d.listaId && d.titulo && d.titulo.trim() && d.prioridade && d.prazo && d.responsavelId);
}
function renumerar(itens) {
    return itens.map((it, i) => ({ ...it, ordem: i + 1 }));
}
function mover(itens, i, d) {
    const j = i + d;
    if (j < 0 || j >= itens.length)
        return itens;
    const c = [...itens];
    [c[i], c[j]] = [c[j], c[i]];
    return renumerar(c);
}
function novoItem(n) {
    return { id: null, version: null, details: { descricao: '' }, ordem: n + 1, feito: false };
}
function abrirMenu(e) {
    const host = e.currentTarget;
    const menu = host.parentElement?.querySelector('[popover]');
    menu?.togglePopover?.();
}
function fecharMenu(e) {
    const menu = e.currentTarget.closest('[popover]');
    menu?.hidePopover?.();
}
let TarefasMobilePage11Minhas_tarefasPage = class TarefasMobilePage11Minhas_tarefasPage extends TarefasMinhas_tarefasShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    statusLabel(s) {
        const m = {
            aFazer: this.msg['stAFazer'],
            emAndamento: this.msg['stEmAndamento'],
            emRevisao: this.msg['stEmRevisao'],
            concluida: this.msg['stConcluida'],
            cancelada: this.msg['stCancelada'],
        };
        return m[s];
    }
    prioLabel(p) {
        const m = {
            low: this.msg['pBaixa'],
            medium: this.msg['pMedia'],
            high: this.msg['pAlta'],
        };
        return m[p];
    }
    chip(s) {
        return html `<span class="inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${STATUS_CLS[s]}">${this.statusLabel(s)}</span>`;
    }
    aviso(tipo, txt) {
        return html `<groupnotifyuser--ml-contextual-feedback type=${tipo} .visible=${true} .dismissible=${false}>
<Message>${txt}</Message>
</groupnotifyuser--ml-contextual-feedback>`;
    }
    btn(label, run, opts = {}) {
        return html `<grouptriggeraction--ml-button-standard
data-variant=${opts.variant ?? 'primary'}
size=${opts.size ?? 'lg'}
data-class=${opts.full ? 'w-full' : ''}
.loading=${!!opts.loading}
.disabled=${!!opts.disabled}
@action=${run}
><Label>${label}</Label></grouptriggeraction--ml-button-standard>`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="mx-auto min-h-screen w-full max-w-[430px] bg-[var(--page-bg,transparent)] px-4 pb-6 pt-3 text-[var(--text-default,currentColor)]">
<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'lista'}
backLabel=${this.msg['voltar']}
@change=${(e) => {
            if (e.target === e.currentTarget)
                this.setScenario(e.detail.value);
        }}
>
<Scene value="lista" title=${this.msg['sceneLista']}>${this.renderLista()}</Scene>
<Scene value="detalhe" title=${this.msg['sceneDetalhe']} nav="back">${this.renderDetalhe()}</Scene>
<Scene value="criar" title=${this.msg['sceneCriar']} nav="back">${this.renderCriar()}</Scene>
<Scene value="editar" title=${this.msg['sceneEditar']} nav="back">${this.renderEditar()}</Scene>
<Scene value="checklist" title=${this.msg['sceneChecklist']} nav="back">${this.renderChecklist()}</Scene>
<Scene value="devolver" title=${this.msg['sceneDevolver']} nav="back">${this.renderDevolver()}</Scene>
<Scene value="cancelar" title=${this.msg['sceneCancelar']} nav="back">${this.renderCancelar()}</Scene>
</molecules--ml-scenary-102020>
</div>
`;
    }
    /* ---------------- lista ---------------- */
    renderLista() {
        const t = this.tarefas;
        const items = t?.items ?? [];
        const semContexto = this.qryMinhasTarefasError?.code === 'client.preconditionMissing';
        const erro = this.qryMinhasTarefasStatus === 'error';
        const carregando = this.qryMinhasTarefasStatus === 'loading' || this.pageStatus === 'loading';
        const sel = items.findIndex((i) => i.id === this.selectedTarefa);
        if (semContexto) {
            return html `<div data-organism-id="listaTarefas" class="flex flex-col gap-4 py-6" role="alert">
<p class="text-[var(--text-strong,currentColor)]">${this.msg['semContexto']}</p>
${this.btn(this.msg['voltarInicio'], () => history.back(), { variant: 'secondary', full: true })}
</div>`;
        }
        return html `
<div data-organism-id="listaTarefas" class="flex flex-col gap-3">
<groupnavigatesection--ml-navigate-pills
aria-label=${this.msg['filtrosAria']}
.value=${this.filtro ?? 'todas'}
@change=${(e) => this.qryMinhasTarefas(e.detail.value === 'todas' ? null : e.detail.value)}
>
<Tab value="todas" title=${this.msg['fTodas']}></Tab>
<Tab value="criadasPorMim" title=${this.msg['fCriadas']}></Tab>
<Tab value="atribuidasAMim" title=${this.msg['fAtribuidas']}></Tab>
<Tab value="emRevisao" title=${this.msg['fRevisao']}></Tab>
<Tab value="devolvidas" title=${this.msg['fDevolvidas']}></Tab>
</groupnavigatesection--ml-navigate-pills>
${erro
            ? html `<div role="alert" class="flex flex-col gap-3 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4">
<p class="text-[var(--text-strong,currentColor)]">${this.msg['erroLista']}</p>
${this.btn(this.msg['tentarNovamente'], () => { this.qryMinhasTarefas(); }, { variant: 'secondary', full: true })}
</div>`
            : html `<div aria-busy=${carregando ? 'true' : 'false'}>
<groupviewtable--ml-responsive-table
.value=${sel >= 0 ? String(sel) : ''}
.loading=${carregando}
@rowClick=${(e) => {
                const row = items[e.detail.index];
                if (!row)
                    return;
                this.qryTarefa(row.id);
                this.setScenario('detalhe');
            }}
>
<TableHeader>
<TableRow>
<TableHead key="titulo">${this.msg['hTarefa']}</TableHead>
<TableHead key="prazo">${this.msg['hPrazo']}</TableHead>
<TableHead key="situacao">${this.msg['hSituacao']}</TableHead>
<TableHead key="responsavel">${this.msg['hResponsavel']}</TableHead>
<TableHead key="checklist">${this.msg['hChecklist']}</TableHead>
</TableRow>
</TableHeader>
<TableBody>
${items.map((r) => html `<TableRow key=${r.id}>
<TableCell>
<div class="font-semibold text-[var(--text-strong,currentColor)]">${r.titulo}</div>
<div class="text-sm text-[var(--text-muted,currentColor)]">${r.lista.nome} · ${this.prioLabel(r.prioridade)}</div>
</TableCell>
<TableCell>
<span class="${r.details.atrasada ? 'font-semibold text-[var(--status-error-text,currentColor)]' : r.details.venceHoje ? 'font-semibold text-[var(--status-warning-text,currentColor)]' : ''}">${fmtData(r.prazo)}</span>
${r.details.atrasada
                ? html `<span class="ml-1 text-xs text-[var(--status-error-text,currentColor)]">${this.msg['atrasada']}</span>`
                : r.details.venceHoje
                    ? html `<span class="ml-1 text-xs text-[var(--status-warning-text,currentColor)]">${this.msg['venceHoje']}</span>`
                    : nothing}
</TableCell>
<TableCell>${this.chip(r.status)}</TableCell>
<TableCell>${r.responsavel.details.identification.name}</TableCell>
<TableCell>${r.details.progressoChecklist} · ${r.details.quantidadeSubtarefas} ${this.msg['subtarefas']}</TableCell>
</TableRow>`)}
</TableBody>
<Empty>${this.msg['listaVazia']}</Empty>
<Loading>${this.msg['carregando']}</Loading>
</groupviewtable--ml-responsive-table>
</div>`}
${t?.hasMore
            ? this.btn(this.msg['carregarMais'], () => { this.qryMinhasTarefas(undefined, t.page + 1, true); }, { variant: 'secondary', full: true, loading: carregando })
            : nothing}
<div class="pointer-events-none sticky bottom-4 mt-2 flex justify-end">
<div class="pointer-events-auto shadow-lg">
${this.btn(this.msg['novaTarefa'], () => {
            this.clearCmdCriarTarefaDraft();
            this.qryListasAtivas();
            this.setScenario('criar');
        })}
</div>
</div>
</div>
`;
    }
    /* ---------------- detalhe ---------------- */
    renderDetalhe() {
        const t = this.tarefa;
        if (this.qryTarefaStatus === 'loading') {
            return html `<p data-organism-id="detalheTarefa" aria-busy="true" class="py-6 text-[var(--text-muted,currentColor)]">${this.msg['detalheCarregando']}</p>`;
        }
        if (this.qryTarefaStatus === 'error') {
            return html `<div data-organism-id="detalheTarefa" role="alert" class="flex flex-col gap-3 py-4">
<p class="text-[var(--text-strong,currentColor)]">${this.msg['detalheErro']}</p>
${this.btn(this.msg['tentarNovamente'], () => { this.qryTarefa(this.selectedTarefa); }, { variant: 'secondary', full: true })}
</div>`;
        }
        if (!t) {
            return html `<p data-organism-id="detalheTarefa" class="py-6 text-[var(--text-muted,currentColor)]">${this.msg['detalheVazio']}</p>`;
        }
        const aberta = t.status === 'aFazer' || t.status === 'emAndamento' || t.status === 'emRevisao';
        let prim = null;
        if (t.souResponsavel && t.status === 'aFazer') {
            prim = { label: this.msg['aIniciar'], run: () => { this.cmdIniciar(); }, loading: this.cmdIniciarStatus === 'loading' };
        }
        else if (t.souResponsavel && t.status === 'emAndamento') {
            prim = {
                label: t.details.devolvidaEm ? this.msg['aReenviar'] : this.msg['aEnviar'],
                run: () => { this.cmdEnviarRevisao(); },
                loading: this.cmdEnviarRevisaoStatus === 'loading',
            };
        }
        else if (t.souCriador && t.status === 'emRevisao') {
            prim = { label: this.msg['aAceitar'], run: () => { this.cmdAceitar(); }, loading: this.cmdAceitarStatus === 'loading' };
        }
        const podeDevolver = t.souCriador && t.status === 'emRevisao';
        const podeCancelar = t.souCriador && aberta;
        const erroAcao = this.cmdIniciarError ?? this.cmdEnviarRevisaoError ?? this.cmdAceitarError;
        const okAcao = this.cmdIniciarStatus === 'success'
            ? this.msg['okIniciada']
            : this.cmdEnviarRevisaoStatus === 'success'
                ? this.msg['okEnviada']
                : this.cmdAceitarStatus === 'success'
                    ? this.msg['okAceita']
                    : '';
        return html `
<div class="flex flex-col gap-4">
<div data-organism-id="detalheTarefa" class="flex flex-col gap-4">
${keyed(t.id + ':' + t.version, html `<groupviewcard--ml-vertical-card>
<CardHeader>
<CardTitle>${t.titulo}</CardTitle>
<CardDescription>${t.lista.nome}</CardDescription>
</CardHeader>
<CardContent>
<div class="flex flex-wrap items-center gap-2 pb-3">${this.chip(t.status)}</div>
<dl class="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
${t.details.descricao
            ? html `<dt class="text-[var(--text-muted,currentColor)]">${this.msg['lDescricao']}</dt><dd class="text-[var(--text-strong,currentColor)]">${t.details.descricao}</dd>`
            : nothing}
<dt class="text-[var(--text-muted,currentColor)]">${this.msg['lResponsavel']}</dt>
<dd class="text-[var(--text-strong,currentColor)]">${t.responsavel.details.identification.name}</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg['lCriador']}</dt>
<dd class="text-[var(--text-strong,currentColor)]">${t.criador.details.identification.name}</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg['lPrazo']}</dt>
<dd class="text-[var(--text-strong,currentColor)]">${fmtData(t.prazo)}</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg['lPrioridade']}</dt>
<dd class="text-[var(--text-strong,currentColor)]">${this.prioLabel(t.prioridade)}</dd>
</dl>
</CardContent>
<CardFooter>${this.msg['lCriadaEm']} ${fmtDataHora(t.criadaEm)}</CardFooter>
</groupviewcard--ml-vertical-card>`)}
${t.details.motivoDevolucao
            ? html `<groupnotifyuser--ml-notify-banner type="warning" .visible=${true} .dismissible=${false}>
<Title>${this.msg['motivoTitulo']}</Title>
<Message>${t.details.motivoDevolucao}</Message>
</groupnotifyuser--ml-notify-banner>`
            : nothing}
<section class="flex flex-col gap-2" aria-labelledby="h-check">
<div class="flex items-center justify-between gap-2">
<h2 id="h-check" class="text-base font-semibold text-[var(--text-strong,currentColor)]">${this.msg['checklist']}</h2>
${this.btn(this.msg['marcarItens'], () => this.setScenario('checklist'), { variant: 'secondary', size: 'md' })}
</div>
${t.checklist.length === 0
            ? html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['checklistVazia']}</p>`
            : html `<ul class="flex flex-col gap-2">
${t.checklist.map((it) => html `<li class="flex items-start gap-3 rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] p-3">
<span aria-hidden="true" class="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border border-[var(--border-default,currentColor)] text-xs ${it.feito ? 'bg-[var(--selected-bg,transparent)] text-[var(--selected-text,currentColor)]' : ''}">${it.feito ? '✓' : ''}</span>
<span class="sr-only">${it.feito ? this.msg['itemFeito'] : this.msg['itemPendente']}</span>
<span class="flex-1 text-sm ${it.feito ? 'text-[var(--text-muted,currentColor)] line-through' : 'text-[var(--text-strong,currentColor)]'}">${it.details.descricao}</span>
</li>`)}
</ul>`}
</section>
</div>
<div data-organism-id="acoesTarefa" class="sticky bottom-0 z-10 -mx-4 flex flex-col gap-2 border-t border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] px-4 py-3">
<div aria-live="polite" class="flex flex-col gap-2">
${erroAcao ? this.aviso('error', erroAcao.message) : okAcao ? this.aviso('success', okAcao) : nothing}
</div>
<div class="flex items-center gap-2">
${this.btn(this.msg['editarDados'], () => this.setScenario('editar'), { variant: 'secondary', size: 'lg' })}
${prim
            ? html `<div class="flex-1">${this.btn(prim.label, prim.run, { full: true, loading: prim.loading })}</div>`
            : html `<div class="flex-1"></div>`}
${podeDevolver || podeCancelar
            ? html `<div class="relative">
<grouptriggeraction--ml-kebab-action-trigger size="lg" @action=${abrirMenu}>
<Label>${this.msg['maisAcoes']}</Label>
</grouptriggeraction--ml-kebab-action-trigger>
<div popover class="fixed inset-x-0 bottom-0 top-auto m-0 w-full max-w-none rounded-t-2xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-0 text-[var(--text-default,currentColor)] backdrop:bg-[var(--overlay-backdrop-bg,transparent)]">
<div class="mx-auto flex max-w-[430px] flex-col gap-2 p-4">
${podeDevolver
                ? html `<button type="button" class="min-h-12 rounded-lg px-3 text-left text-[var(--text-strong,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]" @click=${(e) => { fecharMenu(e); this.setScenario('devolver'); }}>${this.msg['aDevolver']}</button>`
                : nothing}
${podeCancelar
                ? html `<button type="button" class="min-h-12 rounded-lg px-3 text-left text-[var(--text-strong,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]" @click=${(e) => { fecharMenu(e); this.setScenario('cancelar'); }}>${this.msg['aCancelar']}</button>`
                : nothing}
</div>
</div>
</div>`
            : nothing}
</div>
</div>
<details data-organism-id="historicoTarefa" class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)]">
<summary class="flex min-h-12 cursor-pointer items-center px-3 font-semibold text-[var(--text-strong,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]">${this.msg['historico']}</summary>
<div class="px-3 pb-3">
${keyed(t.id + ':' + t.version, html `<groupviewdata--ml-timeline-view>
<Columns>
<Column field="quando" header=${this.msg['hQuando']}></Column>
<Column field="evento" header=${this.msg['hEvento']}></Column>
</Columns>
<Rows>
<Row><Cell>${fmtDataHora(t.criadaEm)}</Cell><Cell>${this.msg['evCriada']}</Cell></Row>
${t.details.devolvidaEm
            ? html `<Row><Cell>${fmtDataHora(t.details.devolvidaEm)}</Cell><Cell>${this.msg['evDevolvida']}${t.details.motivoDevolucao ? html `: ${t.details.motivoDevolucao}` : nothing}</Cell></Row>`
            : nothing}
${t.details.concluidaEm
            ? html `<Row><Cell>${fmtDataHora(t.details.concluidaEm)}</Cell><Cell>${this.msg['evConcluida']}</Cell></Row>`
            : nothing}
${t.details.canceladaEm
            ? html `<Row><Cell>${fmtDataHora(t.details.canceladaEm)}</Cell><Cell>${this.msg['evCancelada']}</Cell></Row>`
            : nothing}
</Rows>
</groupviewdata--ml-timeline-view>`)}
</div>
</details>
</div>
`;
    }
    /* ---------------- formulário ---------------- */
    camposTarefa(d, set, atual) {
        return html `
<groupselectone--ml-select
.value=${d.listaId}
.required=${true}
@change=${(e) => set({ listaId: e.detail.value })}
>
<Label>${this.msg['fLista']}</Label>
<Trigger>${this.msg['fListaPlaceholder']}</Trigger>
${this.listas.map((l) => html `<Item value=${l.id}>${l.nome}</Item>`)}
<Empty>${this.msg['fListaVazia']}</Empty>
</groupselectone--ml-select>
<groupentertext--ml-enter-text
.value=${d.titulo ?? ''}
.required=${true}
@input=${(e) => { const v = texto(e); if (v !== null)
            set({ titulo: v }); }}
>
<Label>${this.msg['fTitulo']}</Label>
</groupentertext--ml-enter-text>
<groupentertext--ml-multiline-text
.value=${d.details.descricao ?? ''}
.rows=${4}
@input=${(e) => { const v = texto(e); if (v !== null)
            set({ details: { descricao: v } }); }}
>
<Label>${this.msg['fDescricao']}</Label>
</groupentertext--ml-multiline-text>
<groupselectone--ml-segmented-control
.value=${d.prioridade}
.required=${true}
@change=${(e) => set({ prioridade: e.detail.value })}
>
<Label>${this.msg['fPrioridade']}</Label>
<Item value="low">${this.msg['pBaixa']}</Item>
<Item value="medium">${this.msg['pMedia']}</Item>
<Item value="high">${this.msg['pAlta']}</Item>
</groupselectone--ml-segmented-control>
<groupenterdate--ml-date-picker
.value=${d.prazo}
.required=${true}
.locale=${lang() ?? 'pt-BR'}
.placeholder=${this.msg['fPrazoPh']}
@change=${(e) => set({ prazo: e.detail.value })}
>
<Label>${this.msg['fPrazo']}</Label>
</groupenterdate--ml-date-picker>
<groupselectone--ml-combobox
.value=${d.responsavelId}
.required=${true}
.placeholder=${this.msg['fResponsavelPh']}
@input=${(e) => {
            const v = texto(e);
            if (v !== null)
                agendar(() => { this.qryBuscarMembros(v); }, 300);
        }}
@change=${(e) => set({ responsavelId: e.detail.value })}
>
<Label>${this.msg['fResponsavel']}</Label>
<Helper>${this.msg['fResponsavelAjuda']}</Helper>
${atual ? html `<Item value=${atual.id}>${atual.nome}</Item>` : nothing}
${this.membros
            .filter((m) => m.id !== atual?.id)
            .map((m) => html `<Item value=${m.id}>${m.details.identification.name}</Item>`)}
<Empty>${this.msg['fResponsavelVazio']}</Empty>
</groupselectone--ml-combobox>
`;
    }
    itensChecklist(itens, set, modo) {
        const sep = 'flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] text-[var(--text-strong,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)] disabled:opacity-40';
        return html `
<ul class="flex flex-col gap-3">
${itens.map((it, i) => html `<li class="flex items-start gap-2">
${modo === 'editar'
            ? html `<div class="pt-3">
<groupenterboolean--ml-checkbox-preference
.value=${!!it.feito}
@change=${(e) => set(itens.map((x, k) => (k === i ? { ...x, feito: e.detail.value } : x)))}
><Label><span class="sr-only">${this.msg['itemMarcar']}</span></Label></groupenterboolean--ml-checkbox-preference>
</div>`
            : nothing}
<div class="min-w-0 flex-1">
<groupentertext--ml-enter-text
.value=${it.details.descricao ?? ''}
@input=${(e) => {
            const v = texto(e);
            if (v !== null)
                set(itens.map((x, k) => (k === i ? { ...x, details: { descricao: v } } : x)));
        }}
><Label><span class="sr-only">${this.msg['itemDescricao']}</span></Label></groupentertext--ml-enter-text>
</div>
${modo === 'editar'
            ? html `<div class="flex shrink-0 gap-1">
<button type="button" class=${sep} aria-label=${this.msg['subir']} @click=${() => set(mover(itens, i, -1))}>↑</button>
<button type="button" class=${sep} aria-label=${this.msg['descer']} @click=${() => set(mover(itens, i, 1))}>↓</button>
</div>`
            : html `<button type="button" class=${sep} aria-label=${this.msg['removerItem']} @click=${() => set(renumerar(itens.filter((_, k) => k !== i)))}>×</button>`}
</li>`)}
</ul>
${this.btn(this.msg['addItem'], () => set([...itens, novoItem(itens.length)]), { variant: 'secondary', full: true })}
`;
    }
    renderCriar() {
        const d = this.cmdCriarTarefaDraft;
        const ok = camposOk(d);
        const erro = this.cmdCriarTarefaError;
        return html `
<form data-organism-id="formTarefa" class="flex flex-col gap-4" @submit=${(e) => e.preventDefault()}>
${this.camposTarefa(d, (p) => this.setCmdCriarTarefaDraft({ ...this.cmdCriarTarefaDraft, ...p }), null)}
<section class="flex flex-col gap-3" aria-labelledby="h-chk-ini">
<h2 id="h-chk-ini" class="text-base font-semibold text-[var(--text-strong,currentColor)]">${this.msg['checklistInicial']}</h2>
${this.itensChecklist(d.checklist, (v) => this.setCmdCriarTarefaDraft({ ...this.cmdCriarTarefaDraft, checklist: v }), 'criar')}
</section>
<div aria-live="polite" class="flex flex-col gap-2">
${erro ? this.aviso('error', erro.message) : nothing}
${ok ? nothing : html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['faltaCampos']}</p>`}
</div>
${this.btn(this.msg['registrar'], () => {
            this.cmdCriarTarefa().then(() => {
                if (this.cmdCriarTarefaStatus === 'success')
                    this.setScenario('detalhe');
            });
        }, { full: true, disabled: !ok, loading: this.cmdCriarTarefaStatus === 'loading' })}
</form>
`;
    }
    renderEditar() {
        const d = this.cmdSalvarEdicaoDraft;
        const t = this.tarefa;
        const ok = camposOk(d);
        const erro = this.cmdSalvarEdicaoError;
        return html `
<form data-organism-id="formTarefa" class="flex flex-col gap-4" @submit=${(e) => e.preventDefault()}>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['edicaoNaoMuda']}</p>
${this.camposTarefa(d, (p) => this.setCmdSalvarEdicaoDraft({ ...this.cmdSalvarEdicaoDraft, ...p }), t ? { id: t.responsavelId, nome: t.responsavel.details.identification.name } : null)}
<div aria-live="polite" class="flex flex-col gap-2">
${erro ? this.aviso('error', erro.message) : nothing}
${ok ? nothing : html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['faltaCampos']}</p>`}
</div>
${this.btn(this.msg['salvarEdicao'], () => {
            this.cmdSalvarEdicao().then(() => {
                if (this.cmdSalvarEdicaoStatus === 'success')
                    this.setScenario('detalhe');
            });
        }, { full: true, disabled: !ok, loading: this.cmdSalvarEdicaoStatus === 'loading' })}
</form>
`;
    }
    renderChecklist() {
        const d = this.cmdSalvarChecklistDraft;
        const erro = this.cmdSalvarChecklistError;
        return html `
<form data-organism-id="formTarefa" class="flex flex-col gap-4" @submit=${(e) => e.preventDefault()}>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['checklistNaoMuda']}</p>
${this.itensChecklist(d.itens, (v) => this.setCmdSalvarChecklistDraft({ ...this.cmdSalvarChecklistDraft, itens: v }), 'editar')}
<div aria-live="polite">${erro ? this.aviso('error', erro.message) : nothing}</div>
${this.btn(this.msg['salvarChecklist'], () => {
            this.cmdSalvarChecklist().then(() => {
                if (this.cmdSalvarChecklistStatus === 'success')
                    this.setScenario('detalhe');
            });
        }, { full: true, loading: this.cmdSalvarChecklistStatus === 'loading' })}
</form>
`;
    }
    /* ---------------- devolver / cancelar ---------------- */
    renderDevolver() {
        const motivo = this.cmdDevolverDraft.details.motivoDevolucao ?? '';
        const erro = this.cmdDevolverError;
        return html `
<div data-organism-id="acoesTarefa" class="flex flex-col gap-4">
<p class="font-semibold text-[var(--text-strong,currentColor)]">${this.tarefa?.titulo ?? ''}</p>
<groupentertext--ml-multiline-text
.value=${motivo}
.rows=${5}
.required=${true}
@input=${(e) => {
            const v = texto(e);
            if (v !== null)
                this.setCmdDevolverDraft({ details: { motivoDevolucao: v } });
        }}
>
<Label>${this.msg['motivo']}</Label>
<Helper>${this.msg['motivoAjuda']}</Helper>
</groupentertext--ml-multiline-text>
<div aria-live="polite">${erro ? this.aviso('error', erro.message) : nothing}</div>
${this.btn(this.msg['devolverTarefa'], () => {
            this.cmdDevolver().then(() => {
                if (this.cmdDevolverStatus === 'success')
                    this.setScenario('detalhe');
            });
        }, { full: true, disabled: !motivo.trim(), loading: this.cmdDevolverStatus === 'loading' })}
</div>
`;
    }
    renderCancelar() {
        const erro = this.cmdCancelarError;
        return html `
<div data-organism-id="acoesTarefa" class="flex flex-col gap-4">
<p class="text-[var(--text-default,currentColor)]">${this.msg['cancelarTexto']}</p>
<p class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-3 font-semibold text-[var(--text-strong,currentColor)]">${this.tarefa?.titulo ?? ''}</p>
<div aria-live="polite">${erro ? this.aviso('error', erro.message) : nothing}</div>
${this.btn(this.msg['aCancelar'], () => {
            this.cmdCancelar().then(() => {
                if (this.cmdCancelarStatus === 'success')
                    this.setScenario('detalhe');
            });
        }, { variant: 'danger', full: true, loading: this.cmdCancelarStatus === 'loading' })}
${this.btn(this.msg['manter'], () => this.setScenario('detalhe'), { variant: 'secondary', full: true })}
</div>
`;
    }
};
TarefasMobilePage11Minhas_tarefasPage = __decorate([
    customElement('tarefas--web--mobile--page11--minhas_tarefas-102047')
], TarefasMobilePage11Minhas_tarefasPage);
export { TarefasMobilePage11Minhas_tarefasPage };

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/mobile/page11/tarefas_equipe.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasTarefas_equipeShared } from '/_102047_/l2/tarefas/web/shared/tarefas_equipe.js';
import '/_102020_/l2/molecules/ml-scenary.js';
import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.js';
import '/_102040_/l2/molecules/groupselectone/ml-select.js';
import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card.js';
import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102040_/l2/molecules/groupviewtable/ml-responsive-table.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    tituloQuadro: 'Tarefas da equipe',
    tituloDetalhe: 'Detalhe da tarefa',
    voltar: 'Voltar às tarefas',
    filtros: 'Filtros',
    filtroLista: 'Lista',
    todasListas: 'Todas as listas',
    filtroResponsavel: 'Responsável',
    todosResponsaveis: 'Todos os responsáveis',
    filtroPrioridade: 'Prioridade',
    todasPrioridades: 'Todas as prioridades',
    filtroSituacao: 'Situação',
    todasSituacoes: 'Todas as situações',
    escolher: 'Escolher…',
    prazo: 'Prazo',
    prazoDe: 'De',
    prazoAte: 'Até',
    soAtrasadas: 'Só atrasadas',
    soVenceHoje: 'Vencem hoje',
    limparFiltros: 'Limpar filtros',
    colTarefa: 'Tarefa',
    colResponsavel: 'Responsável',
    colPrazo: 'Prazo',
    colSituacao: 'Situação',
    colPrioridade: 'Prioridade',
    atrasada: 'Atrasada',
    venceHoje: 'Vence hoje',
    prioAlta: 'Alta',
    prioMedia: 'Média',
    prioBaixa: 'Baixa',
    stAFazer: 'A fazer',
    stEmAndamento: 'Em andamento',
    stEmRevisao: 'Em revisão',
    stConcluida: 'Concluída',
    stCancelada: 'Cancelada',
    vazio: 'Nenhuma tarefa encontrada com estes filtros.',
    carregando: 'Carregando tarefas…',
    carregarMais: 'Carregar mais tarefas',
    erroListar: 'Não foi possível carregar as tarefas da equipe.',
    tentarNovamente: 'Tentar novamente',
    precondicao: 'Esta tela foi aberta sem as informações de que precisa para carregar as tarefas da equipe. Volte para a página anterior e abra-a de novo.',
    paginaAnterior: 'Voltar à página anterior',
    detalheCarregando: 'Abrindo a tarefa…',
    erroDetalhe: 'Não foi possível abrir esta tarefa.',
    semSelecao: 'Escolha uma tarefa na lista para ver o detalhe.',
    descricao: 'Descrição',
    criadaPor: 'Criada por',
    responsavel: 'Responsável',
    situacao: 'Situação',
    prioridade: 'Prioridade',
    prazoTarefa: 'Prazo',
    subtarefas: 'Subtarefas',
    progresso: 'Progresso da checklist',
    motivoDevolucao: 'Motivo da devolução',
    checklist: 'Checklist',
    checklistVazia: 'Esta tarefa não tem itens na checklist.',
    colItem: 'Item',
    colFeito: 'Feito',
    sim: 'Sim',
    nao: 'Não',
    acoes: 'Ações do gestor',
    novoResponsavel: 'Novo responsável',
    escolherPessoa: 'Escolha uma pessoa da equipe',
    semMembros: 'Nenhum membro disponível.',
    reatribuir: 'Reatribuir tarefa',
    cancelar: 'Cancelar tarefa',
    erroReatribuir: 'Não foi possível trocar o responsável. Tente de novo.',
    erroCancelar: 'Não foi possível cancelar a tarefa. Tente de novo.',
    encerrada: 'Esta tarefa está encerrada: não pode mais ser reatribuída nem cancelada.',
    confirmaTitulo: 'Confirmar cancelamento',
    confirmaMsg: 'Você vai cancelar a tarefa',
    confirmaAviso: 'Ela deixa de estar aberta e não muda mais de situação.',
    manter: 'Manter tarefa',
    confirmarCancelar: 'Sim, cancelar',
    toastReatribuida: 'Responsável trocado. A pessoa escolhida foi avisada.',
    toastCancelada: 'Tarefa cancelada.',
    historico: 'Histórico',
    colQuando: 'Quando',
    colEvento: 'Evento',
    hCriada: 'Tarefa criada',
    hDevolvida: 'Devolvida para ajuste',
    hConcluida: 'Tarefa concluída',
    hCancelada: 'Tarefa cancelada'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
const ALL = '__todos__';
const STATUS_KEY = {
    aFazer: 'stAFazer',
    emAndamento: 'stEmAndamento',
    emRevisao: 'stEmRevisao',
    concluida: 'stConcluida',
    cancelada: 'stCancelada'
};
const STATUS_CLASS = {
    aFazer: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]',
    emAndamento: 'bg-[var(--status-info-bg,transparent)] text-[var(--status-info-text,currentColor)]',
    emRevisao: 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]',
    concluida: 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]',
    cancelada: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]'
};
const PRIO_KEY = {
    high: 'prioAlta',
    medium: 'prioMedia',
    low: 'prioBaixa'
};
const STATUS_VALUES = ['aFazer', 'emAndamento', 'emRevisao', 'concluida', 'cancelada'];
const PRIO_VALUES = ['high', 'medium', 'low'];
const CARD = 'rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] text-[var(--text-default,currentColor)]';
const FOCUS = 'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]';
function fmtDate(v) {
    if (!v)
        return '';
    const d = new Date(v.length === 10 ? v + 'T00:00:00' : v);
    if (Number.isNaN(d.getTime()))
        return v;
    return new Intl.DateTimeFormat(document.documentElement.lang || undefined, { dateStyle: 'medium' }).format(d);
}
function fmtDateTime(v) {
    if (!v)
        return '';
    const d = new Date(v);
    if (Number.isNaN(d.getTime()))
        return v;
    return new Intl.DateTimeFormat(document.documentElement.lang || undefined, { dateStyle: 'short', timeStyle: 'short' }).format(d);
}
function setModal(e, visible) {
    const target = e.currentTarget;
    const el = target
        ?.closest('[data-organism-id="acoesGestor"]')
        ?.querySelector('[data-modal="cancelar"]');
    if (el)
        el.visible = visible;
}
let TarefasMobilePage11Tarefas_equipePage = class TarefasMobilePage11Tarefas_equipePage extends TarefasTarefas_equipeShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-full bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)] p-3">
<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'quadro'}
backLabel=${this.msg.voltar}
@change=${(e) => {
            if (e.target === e.currentTarget)
                this.setScenario(e.detail.value);
        }}
>
<Scene value="quadro" title=${this.msg.tituloQuadro}>${this.renderQuadro()}</Scene>
<Scene value="tarefa" title=${this.msg.tituloDetalhe} nav="back">${this.renderTarefa()}</Scene>
</molecules--ml-scenary-102020>
</div>
`;
    }
    chip(status) {
        return html `<span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${STATUS_CLASS[status]}">${this.msg[STATUS_KEY[status]]}</span>`;
    }
    /* ---------- quadro ---------- */
    renderQuadro() {
        const m = this.msg;
        const err = this.listarTarefasEquipeError ?? this.carregarOpcoesEquipeError;
        const precondition = err?.code === 'client.preconditionMissing';
        return html `
<section data-organism-id="tarefasEquipe" class="flex flex-col gap-3">
${precondition
            ? html `
<div role="alert" class="${CARD} p-4 flex flex-col gap-3">
<p class="text-sm">${m.precondicao}</p>
<grouptriggeraction--ml-button-standard data-variant="secondary" size="lg" data-class="w-full" @action=${() => history.back()}>
<Label>${m.paginaAnterior}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`
            : html `${this.renderFiltros()} ${this.renderErroLista(err !== null)} ${this.renderLista()}`}
</section>
`;
    }
    renderErroLista(has) {
        if (!has)
            return nothing;
        const m = this.msg;
        return html `
<div role="alert" class="rounded-lg border border-[var(--status-error-text,currentColor)] bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)] p-3 flex flex-col gap-2">
<p class="text-sm">${m.erroListar}</p>
<grouptriggeraction--ml-button-standard data-variant="secondary" size="lg" data-class="w-full" @action=${() => { void this.carregarOpcoesEquipe(); void this.listarTarefasEquipe(undefined, 1); }}>
<Label>${m.tentarNovamente}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    pickFilter(label, allLabel, value, options, onPick) {
        return html `
<groupselectone--ml-select
.value=${value}
placeholder=${this.msg.escolher}
@change=${(e) => onPick(e.detail.value === ALL ? null : e.detail.value)}
>
<Label>${label}</Label>
<Item value=${ALL}>${allLabel}</Item>
${options.map((o) => html `<Item value=${o.value}>${o.label}</Item>`)}
</groupselectone--ml-select>
`;
    }
    toggleChip(label, on, onClick) {
        const cls = on
            ? 'bg-[var(--selected-bg,transparent)] text-[var(--selected-text,currentColor)] border-[var(--selected-border,currentColor)]'
            : 'bg-[var(--surface-bg,transparent)] text-[var(--text-default,currentColor)] border-[var(--border-default,currentColor)]';
        return html `
<button type="button" aria-pressed=${on ? 'true' : 'false'} class="min-h-[44px] rounded-full border px-4 text-sm font-medium ${cls} ${FOCUS}" @click=${onClick}>${label}</button>
`;
    }
    renderFiltros() {
        const m = this.msg;
        return html `
<details class="${CARD}">
<summary class="flex min-h-[44px] cursor-pointer items-center justify-between px-3 text-sm font-semibold ${FOCUS}">
<span>${m.filtros}</span>
<span aria-hidden="true">▾</span>
</summary>
<div class="flex flex-col gap-3 border-t border-[var(--border-subtle,currentColor)] p-3">
${this.pickFilter(m.filtroLista, m.todasListas, this.listaId, this.listas.map((l) => ({ value: l.id, label: l.nome })), (v) => { void this.listarTarefasEquipe({ listaId: v }, 1); })}
${this.pickFilter(m.filtroResponsavel, m.todosResponsaveis, this.responsavelId, this.membros.map((mb) => ({ value: mb.id, label: mb.details.identification.name })), (v) => { void this.listarTarefasEquipe({ responsavelId: v }, 1); })}
${this.pickFilter(m.filtroPrioridade, m.todasPrioridades, this.prioridade, PRIO_VALUES.map((p) => ({ value: p, label: m[PRIO_KEY[p]] })), (v) => { void this.listarTarefasEquipe({ prioridade: v }, 1); })}
${this.pickFilter(m.filtroSituacao, m.todasSituacoes, this.status, STATUS_VALUES.map((s) => ({ value: s, label: m[STATUS_KEY[s]] })), (v) => { void this.listarTarefasEquipe({ status: v }, 1); })}
<groupenterdateinterval--ml-date-interval-presets
.startDate=${this.prazoDe}
.endDate=${this.prazoAte}
locale=${document.documentElement.lang || 'pt-BR'}
@change=${(e) => {
            void this.listarTarefasEquipe({ prazoDe: e.detail.startDate, prazoAte: e.detail.endDate }, 1);
        }}
>
<Label>${m.prazo}</Label>
<LabelStart>${m.prazoDe}</LabelStart>
<LabelEnd>${m.prazoAte}</LabelEnd>
</groupenterdateinterval--ml-date-interval-presets>
<div class="flex flex-wrap gap-2">
${this.toggleChip(m.soAtrasadas, this.atrasada, () => { void this.listarTarefasEquipe({ atrasada: this.atrasada ? null : true }, 1); })}
${this.toggleChip(m.soVenceHoje, this.venceHoje, () => { void this.listarTarefasEquipe({ venceHoje: this.venceHoje ? null : true }, 1); })}
</div>
<grouptriggeraction--ml-button-standard
data-variant="secondary"
size="lg"
data-class="w-full"
@action=${() => {
            void this.listarTarefasEquipe({ listaId: null, responsavelId: null, prioridade: null, status: null, prazoDe: null, prazoAte: null, venceHoje: null, atrasada: null }, 1);
        }}
>
<Label>${m.limparFiltros}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</details>
`;
    }
    renderLinha(item) {
        const m = this.msg;
        return html `
<TableRow key=${item.id}>
<TableCell>
<div class="font-semibold text-[var(--text-strong,currentColor)]">${item.titulo}</div>
<div class="text-xs text-[var(--text-muted,currentColor)]">${item.lista.nome}</div>
</TableCell>
<TableCell>${item.responsavel.details.identification.name}</TableCell>
<TableCell>
<span class="${item.details.atrasada ? 'font-semibold text-[var(--status-error-text,currentColor)]' : ''}">${fmtDate(item.prazo)}</span>
${item.details.atrasada ? html `<span class="ml-1 text-xs text-[var(--status-error-text,currentColor)]">${m.atrasada}</span>` : nothing}
${item.details.venceHoje
            ? html `<span class="ml-1 inline-flex rounded-full px-2 py-0.5 text-xs bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]">${m.venceHoje}</span>`
            : nothing}
</TableCell>
<TableCell>${this.chip(item.status)}</TableCell>
<TableCell>${m[PRIO_KEY[item.prioridade]]}</TableCell>
</TableRow>
`;
    }
    renderLista() {
        const m = this.msg;
        const items = this.tarefas?.items ?? [];
        const idx = items.findIndex((i) => i.id === this.selectedTarefa);
        const busy = this.listarTarefasEquipeStatus === 'loading';
        return html `
<div class="flex flex-col gap-3 ${busy && items.length > 0 ? 'opacity-60' : ''}" aria-busy=${busy ? 'true' : 'false'}>
<groupviewtable--ml-responsive-table
.value=${idx >= 0 ? String(idx) : ''}
?loading=${busy && items.length === 0}
@rowClick=${(e) => {
            const it = items[e.detail.index];
            if (!it)
                return;
            this.setScenario('tarefa');
            void this.obterTarefa(it.id);
        }}
>
<TableHeader>
<TableRow>
<TableHead key="titulo">${m.colTarefa}</TableHead>
<TableHead key="responsavel">${m.colResponsavel}</TableHead>
<TableHead key="prazo">${m.colPrazo}</TableHead>
<TableHead key="status">${m.colSituacao}</TableHead>
<TableHead key="prioridade">${m.colPrioridade}</TableHead>
</TableRow>
</TableHeader>
<TableBody>${items.map((i) => this.renderLinha(i))}</TableBody>
<Empty><div class="py-8 text-center text-sm text-[var(--text-muted,currentColor)]">${m.vazio}</div></Empty>
<Loading><div class="py-8 text-center text-sm text-[var(--text-muted,currentColor)]">${m.carregando}</div></Loading>
</groupviewtable--ml-responsive-table>
${this.tarefas?.hasMore
            ? html `
<grouptriggeraction--ml-button-standard data-variant="secondary" size="lg" data-class="w-full" ?loading=${busy} @action=${() => { void this.listarTarefasEquipe(undefined, undefined, true); }}>
<Label>${m.carregarMais}</Label>
</grouptriggeraction--ml-button-standard>
`
            : nothing}
</div>
`;
    }
    /* ---------- tarefa ---------- */
    renderTarefa() {
        const m = this.msg;
        const t = this.tarefa;
        let body;
        if (this.obterTarefaStatus === 'loading') {
            body = html `
<div class="${CARD} p-4 flex flex-col gap-3" aria-busy="true">
<div class="h-5 w-2/3 animate-pulse rounded bg-[var(--surface-alt-bg,transparent)]"></div>
<div class="h-4 w-full animate-pulse rounded bg-[var(--surface-alt-bg,transparent)]"></div>
<div class="h-4 w-5/6 animate-pulse rounded bg-[var(--surface-alt-bg,transparent)]"></div>
<p class="text-sm text-[var(--text-muted,currentColor)]">${m.detalheCarregando}</p>
</div>
`;
        }
        else if (this.obterTarefaError) {
            body = html `
<div role="alert" class="rounded-lg border border-[var(--status-error-text,currentColor)] bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)] p-3 flex flex-col gap-2">
<p class="text-sm">${m.erroDetalhe}</p>
<grouptriggeraction--ml-button-standard data-variant="secondary" size="lg" data-class="w-full" @action=${() => { void this.obterTarefa(this.selectedTarefa); }}>
<Label>${m.tentarNovamente}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
        }
        else if (!t) {
            body = html `<p class="${CARD} p-4 text-sm text-[var(--text-muted,currentColor)]">${m.semSelecao}</p>`;
        }
        else {
            body = html `${this.renderDetalhe(t)} ${this.renderAcoes(t)} ${this.renderHistorico(t)}`;
        }
        return html `<div class="flex flex-col gap-4">${body}</div>`;
    }
    row(label, value) {
        return html `
<div class="flex items-start justify-between gap-4 border-b border-[var(--border-subtle,currentColor)] py-2 last:border-b-0">
<dt class="text-sm text-[var(--text-muted,currentColor)]">${label}</dt>
<dd class="text-right text-sm text-[var(--text-strong,currentColor)]">${value}</dd>
</div>
`;
    }
    renderDetalhe(t) {
        const m = this.msg;
        return html `
<section data-organism-id="detalheTarefa" class="flex flex-col gap-3">
<groupviewcard--ml-vertical-card>
<CardHeader>
<CardTitle>${t.titulo}</CardTitle>
</CardHeader>
<CardContent>
<div class="mb-2 flex flex-wrap items-center gap-2">
${this.chip(t.status)}
<span class="text-xs text-[var(--text-muted,currentColor)]">${m[PRIO_KEY[t.prioridade]]}</span>
</div>
<dl>
${t.details.descricao ? this.row(m.descricao, t.details.descricao) : nothing}
${this.row(m.criadaPor, t.criador.details.identification.name)}
${this.row(m.responsavel, t.responsavel.details.identification.name)}
${this.row(m.prazoTarefa, fmtDate(t.prazo))}
${this.row(m.subtarefas, t.details.quantidadeSubtarefas)}
${this.row(m.progresso, t.details.progressoChecklist)}
${t.details.motivoDevolucao ? this.row(m.motivoDevolucao, t.details.motivoDevolucao) : nothing}
</dl>
</CardContent>
</groupviewcard--ml-vertical-card>
<div class="${CARD} p-3 flex flex-col gap-2">
<h3 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${m.checklist}</h3>
<groupviewdata--ml-vertical-record-list>
<Columns>
<Column field="descricao" header=${m.colItem}></Column>
<Column field="feito" header=${m.colFeito} width="72px" align="right"></Column>
</Columns>
<Rows>
${t.itensChecklist.map((it) => html `
<Row>
<Cell>${it.details.descricao}</Cell>
<Cell>${it.feito ? m.sim : m.nao}</Cell>
</Row>
`)}
</Rows>
<Empty><div class="py-4 text-center text-sm text-[var(--text-muted,currentColor)]">${m.checklistVazia}</div></Empty>
</groupviewdata--ml-vertical-record-list>
</div>
</section>
`;
    }
    renderAcoes(t) {
        const m = this.msg;
        const reLoading = this.reatribuirTarefaStatus === 'loading';
        const caLoading = this.cancelarTarefaStatus === 'loading';
        return html `
<section data-organism-id="acoesGestor" class="${CARD} p-3 flex flex-col gap-3">
<h3 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${m.acoes}</h3>
${t.details.aberta
            ? html `
<groupselectone--ml-select-one-autocomplete
.value=${this.reatribuirTarefaDraft.responsavelId}
placeholder=${m.escolherPessoa}
?disabled=${reLoading}
@change=${(e) => this.setReatribuirTarefaDraft({ responsavelId: e.detail.value })}
>
<Label>${m.novoResponsavel}</Label>
${this.membros.map((mb) => html `<Item value=${mb.id} ?disabled=${mb.details.identification.status !== 'Active'}>${mb.details.identification.name}</Item>`)}
<Empty>${m.semMembros}</Empty>
</groupselectone--ml-select-one-autocomplete>
${this.reatribuirTarefaError
                ? html `<p role="alert" aria-live="polite" class="text-sm text-[var(--text-default,currentColor)]">${m.erroReatribuir}</p>`
                : nothing}
<grouptriggeraction--ml-button-standard
data-variant="primary"
size="lg"
data-class="w-full"
?loading=${reLoading}
?disabled=${this.reatribuirTarefaDraft.responsavelId === null}
@action=${() => { void this.reatribuirTarefa(); }}
>
<Label>${m.reatribuir}</Label>
</grouptriggeraction--ml-button-standard>
<hr class="border-[var(--border-subtle,currentColor)]" />
${this.cancelarTarefaError
                ? html `<p role="alert" aria-live="polite" class="text-sm text-[var(--text-default,currentColor)]">${m.erroCancelar}</p>`
                : nothing}
<grouptriggeraction--ml-button-standard
data-variant="danger"
size="lg"
data-class="w-full"
?loading=${caLoading}
@action=${(e) => setModal(e, true)}
>
<Label>${m.cancelar}</Label>
</grouptriggeraction--ml-button-standard>
<groupnotifyuser--ml-alert-modal data-modal="cancelar" type="warning" .dismissible=${false}>
<Title>${m.confirmaTitulo}</Title>
<Message>${m.confirmaMsg} <strong>${t.titulo}</strong>. ${m.confirmaAviso}</Message>
<Action>
<div class="flex w-full gap-2">
<grouptriggeraction--ml-button-standard data-variant="secondary" size="lg" data-class="flex-1" @action=${(e) => setModal(e, false)}>
<Label>${m.manter}</Label>
</grouptriggeraction--ml-button-standard>
<grouptriggeraction--ml-button-standard
data-variant="danger"
size="lg"
data-class="flex-1"
@action=${(e) => { setModal(e, false); void this.cancelarTarefa(); }}
>
<Label>${m.confirmarCancelar}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</Action>
</groupnotifyuser--ml-alert-modal>
`
            : html `<p class="text-sm text-[var(--text-muted,currentColor)]">${m.encerrada}</p>`}
<groupnotifyuser--ml-toast-notification type="success" position="bottom-right" .duration=${4000} .visible=${this.reatribuirTarefaStatus === 'success'}>
<Message>${m.toastReatribuida}</Message>
</groupnotifyuser--ml-toast-notification>
<groupnotifyuser--ml-toast-notification type="success" position="bottom-right" .duration=${4000} .visible=${this.cancelarTarefaStatus === 'success'}>
<Message>${m.toastCancelada}</Message>
</groupnotifyuser--ml-toast-notification>
</section>
`;
    }
    renderHistorico(t) {
        const m = this.msg;
        return html `
<section data-organism-id="historicoTarefa" class="${CARD} p-3 flex flex-col gap-2">
<h3 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${m.historico}</h3>
<groupviewdata--ml-timeline-view>
<Columns>
<Column field="quando" header=${m.colQuando} width="110px"></Column>
<Column field="evento" header=${m.colEvento}></Column>
</Columns>
<Rows>
<Row>
<Cell>${fmtDateTime(t.criadaEm)}</Cell>
<Cell>${m.hCriada}</Cell>
</Row>
${t.details.devolvidaEm
            ? html `
<Row>
<Cell>${fmtDateTime(t.details.devolvidaEm)}</Cell>
<Cell>
<div>${m.hDevolvida}</div>
${t.details.motivoDevolucao ? html `<div class="text-xs text-[var(--text-muted,currentColor)]">${t.details.motivoDevolucao}</div>` : nothing}
</Cell>
</Row>
`
            : nothing}
${t.details.concluidaEm
            ? html `
<Row>
<Cell>${fmtDateTime(t.details.concluidaEm)}</Cell>
<Cell>${m.hConcluida}</Cell>
</Row>
`
            : nothing}
${t.details.canceladaEm
            ? html `
<Row>
<Cell>${fmtDateTime(t.details.canceladaEm)}</Cell>
<Cell>${m.hCancelada}</Cell>
</Row>
`
            : nothing}
</Rows>
</groupviewdata--ml-timeline-view>
</section>
`;
    }
};
TarefasMobilePage11Tarefas_equipePage = __decorate([
    customElement('tarefas--web--mobile--page11--tarefas_equipe-102047')
], TarefasMobilePage11Tarefas_equipePage);
export { TarefasMobilePage11Tarefas_equipePage };

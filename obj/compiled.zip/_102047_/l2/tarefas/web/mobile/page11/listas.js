var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/mobile/page11/listas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasListasShared } from '/_102047_/l2/tarefas/web/shared/listas.js';
import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input.js';
import '/_102040_/l2/molecules/groupentertext/ml-multiline-text.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.js';
import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102020_/l2/molecules/ml-scenary.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Listas de tarefas',
    back: 'Voltar',
    searchLabel: 'Buscar lista',
    searchPlaceholder: 'Digite parte do nome da lista',
    newList: 'Nova lista',
    colLista: 'Lista',
    colSituacao: 'Situação',
    colAbertas: 'Abertas',
    openTasks: 'Tarefas abertas',
    tipoProject: 'Projeto',
    tipoArea: 'Área',
    ativa: 'Ativa',
    inativa: 'Inativa',
    loading: 'Carregando as listas…',
    emptyAll: 'Nenhuma lista cadastrada ainda. Toque em “Nova lista” para começar.',
    emptySearch: 'Nenhuma lista com esse nome.',
    retry: 'Tentar de novo',
    errPrecondition: 'Esta tela foi aberta sem o que ela precisa para carregar as listas. Volte ao início do módulo e abra as listas de novo.',
    errSelection: 'A lista pedida não existe mais. Escolha outra na relação.',
    errGeneric: 'Não foi possível carregar as listas.',
    savedToast: 'Lista salva com sucesso.',
    createdToast: 'Lista cadastrada com sucesso.',
    createTitle: 'Cadastro de lista',
    editTitleFallback: 'Alterar lista',
    fieldNome: 'Nome da lista',
    nomeHelper: 'O nome não pode repetir o de outra lista.',
    fieldTipo: 'Tipo',
    tipoHelper: 'Se a lista agrupa as tarefas de um projeto ou de uma área.',
    fieldDescricao: 'Descrição',
    descricaoPlaceholder: 'Explique o objetivo da lista (opcional)',
    fieldAtiva: 'Situação',
    ativaHelper: 'Lista inativa não aparece na escolha ao criar tarefa.',
    createAction: 'Cadastrar lista',
    saveAction: 'Salvar alterações',
    errCreate: 'Não foi possível cadastrar a lista. Confira os dados e tente de novo.',
    errSave: 'Não foi possível salvar as alterações. Confira os dados e tente de novo.'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
const formatInt = (n) => new Intl.NumberFormat(document.documentElement.lang || undefined).format(n);
let TarefasMobilePage11ListasPage = class TarefasMobilePage11ListasPage extends TarefasListasShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    tipoLabel(tipo) {
        if (tipo === 'project')
            return this.msg['tipoProject'];
        if (tipo === 'area')
            return this.msg['tipoArea'];
        return '';
    }
    errorText(error) {
        if (!error)
            return '';
        if (error.code === 'client.preconditionMissing')
            return this.msg['errPrecondition'];
        if (error.code === 'client.selectionInvalid')
            return this.msg['errSelection'];
        return error.message || this.msg['errGeneric'];
    }
    segmented(label, helper, options, current, onPick) {
        return html `
<div role="group" aria-label=${label} class="flex flex-col gap-1.5">
<span class="text-sm font-medium text-[var(--text-strong,currentColor)]">${label}</span>
<div class="grid grid-cols-2 gap-2">
${options.map((o) => html `
<button
type="button"
aria-pressed=${current === o.value ? 'true' : 'false'}
@click=${() => onPick(o.value)}
class="min-h-[44px] rounded-lg border px-3 text-base focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)] ${current === o.value
            ? 'bg-[var(--selected-bg,transparent)] text-[var(--selected-text,currentColor)] border-[var(--selected-border,currentColor)] font-semibold'
            : 'bg-[var(--surface-bg,transparent)] text-[var(--text-default,currentColor)] border-[var(--border-default,currentColor)]'}"
>
${o.label}
</button>
`)}
</div>
<span class="text-xs text-[var(--text-muted,currentColor)]">${helper}</span>
</div>
`;
    }
    renderFields(draft, update) {
        return html `
<groupentertext--ml-floating-text-input
data-class="w-full"
required
.value=${draft.nome ?? ''}
@input=${(e) => update({ ...draft, nome: e.detail.value })}
@change=${(e) => update({ ...draft, nome: e.detail.value })}
>
<Label>${this.msg['fieldNome']}</Label>
<Helper>${this.msg['nomeHelper']}</Helper>
</groupentertext--ml-floating-text-input>
${this.segmented(this.msg['fieldTipo'], this.msg['tipoHelper'], [
            { value: 'project', label: this.msg['tipoProject'] },
            { value: 'area', label: this.msg['tipoArea'] }
        ], draft.details.tipo, (v) => update({ ...draft, details: { ...draft.details, tipo: v } }))}
<groupentertext--ml-multiline-text
data-class="w-full"
rows="4"
maxLength="500"
placeholder=${this.msg['descricaoPlaceholder']}
.value=${draft.details.descricao ?? ''}
@input=${(e) => update({ ...draft, details: { ...draft.details, descricao: e.detail.value } })}
@change=${(e) => update({ ...draft, details: { ...draft.details, descricao: e.detail.value } })}
>
<Label>${this.msg['fieldDescricao']}</Label>
</groupentertext--ml-multiline-text>
${this.segmented(this.msg['fieldAtiva'], this.msg['ativaHelper'], [
            { value: true, label: this.msg['ativa'] },
            { value: false, label: this.msg['inativa'] }
        ], draft.ativa, (v) => update({ ...draft, ativa: v }))}
`;
    }
    renderCreateForm() {
        const d = this.criarListaDraft;
        const incomplete = !(d.nome ?? '').trim() || d.details.tipo === null || d.ativa === null;
        return html `
<div data-organism-id="formularioLista" class="flex flex-col gap-5 px-4 pb-8 pt-2">
${this.renderFields(d, (next) => this.setCriarListaDraft(next))}
<div aria-live="polite">
${this.criarListaError
            ? html `<groupnotifyuser--ml-contextual-feedback type="error" .visible=${true} .dismissible=${false}>
<Message>${this.criarListaError.message || this.msg['errCreate']}</Message>
</groupnotifyuser--ml-contextual-feedback>`
            : nothing}
</div>
<grouptriggeraction--ml-button-standard
size="lg"
data-class="w-full"
?disabled=${incomplete}
.loading=${this.criarListaStatus === 'loading'}
@action=${() => {
            this.criarLista().then(() => {
                if (this.criarListaStatus === 'success')
                    this.setScenario('lista');
            });
        }}
>
<Label>${this.msg['createAction']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    renderEditForm() {
        const d = this.salvarListaDraft;
        const incomplete = !(d.nome ?? '').trim() || d.details.tipo === null || d.ativa === null || d.id === null;
        return html `
<div data-organism-id="formularioLista" class="flex flex-col gap-5 px-4 pb-8 pt-2">
${this.formularioLista === null
            ? nothing
            : html `
<p class="text-sm text-[var(--text-muted,currentColor)]">
${this.msg['openTasks']}: ${formatInt(this.formularioLista.details.quantidadeTarefasAbertas)}
</p>
`}
${this.renderFields(d, (next) => this.setSalvarListaDraft(next))}
<div aria-live="polite">
${this.salvarListaError
            ? html `<groupnotifyuser--ml-contextual-feedback type="error" .visible=${true} .dismissible=${false}>
<Message>${this.salvarListaError.message || this.msg['errSave']}</Message>
</groupnotifyuser--ml-contextual-feedback>`
            : nothing}
</div>
<grouptriggeraction--ml-button-standard
size="lg"
data-class="w-full"
?disabled=${incomplete}
.loading=${this.salvarListaStatus === 'loading'}
@action=${() => {
            this.salvarLista().then(() => {
                if (this.salvarListaStatus === 'success') {
                    this.setScenario('lista');
                    this.selectLista(null);
                }
            });
        }}
>
<Label>${this.msg['saveAction']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
`;
    }
    renderList() {
        const loadError = this.listarListasError || this.buscarListasError;
        const loading = this.pageStatus === 'loading' || this.buscarListasStatus === 'loading';
        return html `
<div data-organism-id="listasCadastradas" class="flex flex-col gap-4 px-4 pb-8 pt-2">
<groupsearchcontent--ml-search-bar
placeholder=${this.msg['searchPlaceholder']}
.loading=${this.buscarListasStatus === 'loading'}
@search=${(e) => this.buscarListas(e.detail.query)}
@change=${(e) => this.buscarListas(e.detail.value ?? '')}
@clear=${() => this.buscarListas('')}
>
<Label>${this.msg['searchLabel']}</Label>
</groupsearchcontent--ml-search-bar>
<grouptriggeraction--ml-button-standard
size="lg"
data-class="w-full"
@action=${() => {
            this.selectLista(null);
            this.setScenario('nova');
        }}
>
<Label>${this.msg['newList']}</Label>
</grouptriggeraction--ml-button-standard>
<div aria-live="polite">
${loadError
            ? html `<div class="flex flex-col gap-3">
<groupnotifyuser--ml-contextual-feedback type="error" .visible=${true} .dismissible=${false}>
<Message>${this.errorText(loadError)}</Message>
</groupnotifyuser--ml-contextual-feedback>
<grouptriggeraction--ml-button-standard
data-variant="secondary"
size="lg"
data-class="w-full"
@action=${() => this.listarListas()}
>
<Label>${this.msg['retry']}</Label>
</grouptriggeraction--ml-button-standard>
</div>`
            : nothing}
</div>
<groupviewdata--ml-vertical-record-list
.loading=${loading}
@row-click=${(e) => {
            const lista = this.listas[e.detail.index];
            if (!lista)
                return;
            this.selectLista(lista.id);
            this.setScenario('editar');
        }}
>
<Columns>
<Column field="nome" header=${this.msg['colLista']} />
<Column field="situacao" header=${this.msg['colSituacao']} width="96px" align="center" />
<Column field="abertas" header=${this.msg['colAbertas']} width="64px" align="right" />
</Columns>
<Rows>
${this.listas.map((lista) => html `
<Row ?selected=${lista.id === this.selectedLista}>
<Cell>
<div class="flex min-h-[44px] flex-col justify-center py-1">
<span class="text-base font-semibold break-words ${lista.ativa
            ? 'text-[var(--text-strong,currentColor)]'
            : 'text-[var(--text-muted,currentColor)]'}">${lista.nome}</span>
<span class="text-xs text-[var(--text-muted,currentColor)]">${this.tipoLabel(lista.details.tipo)}</span>
</div>
</Cell>
<Cell>
<span class="inline-block rounded-full px-2 py-0.5 text-xs ${lista.ativa
            ? 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]'
            : 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]'}">
${lista.ativa ? this.msg['ativa'] : this.msg['inativa']}
</span>
</Cell>
<Cell>
<span class="text-lg font-semibold ${lista.ativa
            ? 'text-[var(--text-strong,currentColor)]'
            : 'text-[var(--text-muted,currentColor)]'}">${formatInt(lista.details.quantidadeTarefasAbertas)}</span>
</Cell>
</Row>
`)}
</Rows>
<Loading>
<div class="py-10 text-center text-[var(--text-muted,currentColor)]">${this.msg['loading']}</div>
</Loading>
<Empty>
<div class="px-4 py-10 text-center text-[var(--text-muted,currentColor)]">
${this.busca ? this.msg['emptySearch'] : this.msg['emptyAll']}
</div>
</Empty>
</groupviewdata--ml-vertical-record-list>
<groupnotifyuser--ml-toast-notification
type="success"
position="bottom"
.duration=${3500}
.visible=${this.salvarListaStatus === 'success' || this.criarListaStatus === 'success'}
>
<Message>${this.salvarListaStatus === 'success' ? this.msg['savedToast'] : this.msg['createdToast']}</Message>
</groupnotifyuser--ml-toast-notification>
</div>
`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-full w-full bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)]">
<molecules--ml-scenary-102020
mode="scenary"
backLabel=${this.msg['back']}
.value=${this.scenary || (this.selectedLista !== null ? 'editar' : 'lista')}
@change=${(e) => {
            if (e.target === e.currentTarget) {
                this.setScenario(e.detail.value);
                if (e.detail.value === 'lista')
                    this.selectLista(null);
            }
        }}
>
<Scene value="lista" title=${this.msg['pageTitle']}>${this.renderList()}</Scene>
<Scene value="editar" nav="back" backTo="lista" title=${this.formularioLista?.nome || this.msg['editTitleFallback']}>
${this.renderEditForm()}
</Scene>
<Scene value="nova" nav="back" backTo="lista" title=${this.msg['createTitle']}>
${this.renderCreateForm()}
</Scene>
</molecules--ml-scenary-102020>
</div>
`;
    }
};
TarefasMobilePage11ListasPage = __decorate([
    customElement('tarefas--web--mobile--page11--listas-102047')
], TarefasMobilePage11ListasPage);
export { TarefasMobilePage11ListasPage };

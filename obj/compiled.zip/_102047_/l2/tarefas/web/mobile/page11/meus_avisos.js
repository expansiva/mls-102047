var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/mobile/page11/meus_avisos.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasMeus_avisosShared } from '/_102047_/l2/tarefas/web/shared/meus_avisos.js';
import '/_102020_/l2/molecules/ml-scenary.js';
import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets.js';
import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number.js';
import '/_102040_/l2/molecules/groupviewtable/ml-responsive-table.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    sceneLista: 'Meus avisos',
    sceneAviso: 'Aviso diário',
    back: 'Voltar aos avisos',
    openNoticeLabel: 'Aviso aberto',
    seeTasks: 'Ver tarefas do aviso',
    filterSummary: 'Filtrar por período',
    filterLabel: 'Data de referência',
    filterFrom: 'De',
    filterTo: 'Até',
    filterHelper: 'Mostra só os avisos do período escolhido.',
    clearFilter: 'Mostrar todos os avisos',
    colDate: 'Data de referência',
    colSend: 'Situação do envio',
    tasksLabel: 'Tarefas',
    overdueLabel: 'Atrasadas',
    listEmpty: 'Nenhum aviso neste período.',
    listLoading: 'Carregando seus avisos…',
    pageEmpty: 'Você ainda não recebeu nenhum aviso diário. Ele chega todo dia às 8h com as tarefas que vencem hoje ou estão atrasadas.',
    pageError: 'Não foi possível carregar seus avisos.',
    preconditionMissing: 'Esta tela foi aberta sem a informação necessária para mostrar seus avisos. Volte à tela anterior e abra os avisos de novo.',
    goBack: 'Voltar à tela anterior',
    retryLoad: 'Tentar carregar de novo',
    listError: 'Não foi possível filtrar os avisos.',
    noticeError: 'Não foi possível abrir este aviso.',
    retryNotice: 'Tentar abrir de novo',
    noticeLoading: 'Abrindo o aviso…',
    noNotice: 'Escolha um aviso na lista para ver as tarefas.',
    referenceOn: 'Referência',
    tasksTableCaption: 'Tarefas que vencem hoje ou estão atrasadas',
    colTask: 'Tarefa',
    colDeadline: 'Prazo',
    colDeadlineState: 'Situação do prazo',
    colProgress: 'Andamento',
    tasksEmpty: 'Nenhuma tarefa neste aviso.',
    dueToday: 'Vence hoje',
    overdue: 'Atrasada',
    taskTodo: 'A fazer',
    taskDoing: 'Em andamento',
    taskReview: 'Em revisão',
    taskDone: 'Concluída',
    taskCanceled: 'Cancelada',
    sendPending: 'Aguardando envio',
    sendCompleted: 'Enviado',
    sendFailed: 'Falhou',
    logHeading: 'Registro de envio',
    logNotice: 'Aviso',
    logWhen: 'Geração e finalização',
    generatedAt: 'Gerado em',
    finishedAt: 'Finalizado em',
    failureReason: 'Motivo da falha',
    logEmpty: 'Nenhum registro de envio.'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
const lang = () => document.documentElement.lang || undefined;
function formatDate(value) {
    if (!value)
        return '';
    const parts = value.slice(0, 10).split('-').map(Number);
    if (parts.length !== 3 || parts.some((n) => Number.isNaN(n)))
        return value;
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    return new Intl.DateTimeFormat(lang(), { day: '2-digit', month: 'short', year: 'numeric' }).format(d);
}
function formatDateTime(value) {
    if (!value)
        return '';
    const d = new Date(value);
    if (Number.isNaN(d.getTime()))
        return value;
    return new Intl.DateTimeFormat(lang(), { dateStyle: 'short', timeStyle: 'short' }).format(d);
}
function formatNumber(n) {
    return new Intl.NumberFormat(lang()).format(n);
}
const badgeBase = 'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap';
const badgeSuccess = `${badgeBase} bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]`;
const badgeError = `${badgeBase} bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]`;
const badgeWarning = `${badgeBase} bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]`;
const badgeInfo = `${badgeBase} bg-[var(--status-info-bg,transparent)] text-[var(--status-info-text,currentColor)]`;
const badgeNeutral = `${badgeBase} bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]`;
const btnPrimary = 'min-h-[44px] px-4 rounded-lg font-medium bg-[var(--button-primary-bg,transparent)] text-[var(--button-primary-text,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]';
const btnSecondary = 'min-h-[44px] px-4 rounded-lg font-medium border border-[var(--button-secondary-border,currentColor)] bg-[var(--button-secondary-bg,transparent)] text-[var(--button-secondary-text,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]';
let TarefasMobilePage11Meus_avisosPage = class TarefasMobilePage11Meus_avisosPage extends TarefasMeus_avisosShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-full w-full max-w-[430px] mx-auto bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)]">
<molecules--ml-scenary-102020
mode="scenary"
.value=${this.scenary || 'lista'}
backLabel=${this.msg.back}
@change=${(e) => {
            if (e.target === e.currentTarget)
                this.setScenario(e.detail.value);
        }}
>
<Scene value="lista" title=${this.msg.sceneLista}>${this.renderLista()}</Scene>
<Scene value="aviso" title=${this.msg.sceneAviso} nav="back">
<div class="flex flex-col gap-6">
${this.renderAviso()} ${this.renderHistorico()}
</div>
</Scene>
</molecules--ml-scenary-102020>
</div>
`;
    }
    sendBadge(status) {
        if (status === 'completed')
            return html `<span class=${badgeSuccess}>${this.msg.sendCompleted}</span>`;
        if (status === 'failed')
            return html `<span class=${badgeError}>${this.msg.sendFailed}</span>`;
        return html `<span class=${badgeWarning}>${this.msg.sendPending}</span>`;
    }
    taskStatusLabel(status) {
        switch (status) {
            case 'aFazer':
                return this.msg.taskTodo;
            case 'emAndamento':
                return this.msg.taskDoing;
            case 'emRevisao':
                return this.msg.taskReview;
            case 'concluida':
                return this.msg.taskDone;
            default:
                return this.msg.taskCanceled;
        }
    }
    renderLista() {
        const m = this.msg;
        const loadingPage = this.pageStatus === 'loading' || this.pageStatus === 'idle';
        if (loadingPage) {
            return html `<div data-organism-id="listaAvisos" class="p-4 text-[var(--text-muted,currentColor)]" aria-busy="true" aria-live="polite">${m.listLoading}</div>`;
        }
        if (this.pageStatus === 'error') {
            const missing = this.qryPaginaMeusAvisosError?.code === 'client.preconditionMissing';
            return html `
<div data-organism-id="listaAvisos" class="p-4 flex flex-col gap-3" aria-live="polite">
<p class="text-[var(--text-strong,currentColor)]">${missing ? m.preconditionMissing : m.pageError}</p>
<div class="flex flex-col gap-2">
${missing
                ? html `<button type="button" class=${btnPrimary} @click=${() => window.history.back()}>${m.goBack}</button>`
                : html `<button type="button" class=${btnPrimary} @click=${() => this.qryPaginaMeusAvisos()}>${m.retryLoad}</button>`}
</div>
</div>
`;
        }
        if (this.pageStatus === 'empty') {
            return html `<div data-organism-id="listaAvisos" class="p-6 text-center text-[var(--text-muted,currentColor)]">${m.pageEmpty}</div>`;
        }
        const hasFilter = this.filtroDataInicio !== null || this.filtroDataFim !== null;
        const listLoading = this.qryListarMeusAvisosStatus === 'loading';
        const aberto = this.avisoAtual;
        return html `
<div data-organism-id="listaAvisos" class="flex flex-col gap-4">
${aberto
            ? html `
<div class="rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4 flex flex-col gap-3">
<div class="flex items-start justify-between gap-3">
<div class="min-w-0">
<p class="text-xs text-[var(--text-muted,currentColor)]">${m.openNoticeLabel}</p>
<p class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${formatDate(aberto.dataReferencia)}</p>
</div>
${this.sendBadge(aberto.status)}
</div>
<p class="text-sm text-[var(--text-default,currentColor)]">
${m.tasksLabel}: <strong>${formatNumber(aberto.details.quantidadeTarefas)}</strong>
· ${m.overdueLabel}: <strong>${formatNumber(aberto.details.quantidadeAtrasadas)}</strong>
</p>
<button type="button" class=${btnPrimary} @click=${() => this.setScenario('aviso')}>${m.seeTasks}</button>
</div>
`
            : nothing}
<details class="rounded-lg border border-[var(--border-subtle,currentColor)] px-3" ?open=${hasFilter}>
<summary class="min-h-[44px] flex items-center cursor-pointer text-sm font-medium text-[var(--text-default,currentColor)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)]">
${m.filterSummary}
</summary>
<div class="pb-3 flex flex-col gap-3">
<groupenterdateinterval--ml-date-interval-presets
.startDate=${this.filtroDataInicio}
.endDate=${this.filtroDataFim}
.loading=${listLoading}
locale=${document.documentElement.lang || 'pt-BR'}
@change=${(e) => this.qryListarMeusAvisos(e.detail.startDate, e.detail.endDate, 1, false)}
>
<Label>${m.filterLabel}</Label>
<LabelStart>${m.filterFrom}</LabelStart>
<LabelEnd>${m.filterTo}</LabelEnd>
<Helper>${m.filterHelper}</Helper>
</groupenterdateinterval--ml-date-interval-presets>
${hasFilter
            ? html `<button type="button" class=${btnSecondary} @click=${() => this.qryListarMeusAvisos(null, null, 1, false)}>${m.clearFilter}</button>`
            : nothing}
</div>
</details>
${this.qryListarMeusAvisosError
            ? html `<p class="text-[var(--text-strong,currentColor)]" aria-live="polite">${m.listError}</p>`
            : nothing}
<groupviewdata--ml-vertical-record-list
.loading=${listLoading}
.hoverable=${true}
@row-click=${(e) => {
            const item = this.avisos.items[e.detail.index];
            if (!item)
                return;
            this.selectAvisoVencimento(item.id);
            this.setScenario('aviso');
        }}
>
<Columns>
<Column field="data" header=${m.colDate}></Column>
<Column field="envio" header=${m.colSend} align="right"></Column>
</Columns>
<Rows>
${this.avisos.items.map((aviso) => html `
<Row ?selected=${aviso.id === this.selectedAvisoVencimento}>
<Cell>
<div class="min-h-[44px] flex flex-col justify-center">
<div class="font-semibold text-[var(--text-strong,currentColor)]">${formatDate(aviso.dataReferencia)}</div>
<div class="text-sm text-[var(--text-muted,currentColor)]">
${m.tasksLabel}: ${formatNumber(aviso.details.quantidadeTarefas)} · ${m.overdueLabel}: ${formatNumber(aviso.details.quantidadeAtrasadas)}
</div>
</div>
</Cell>
<Cell>${this.sendBadge(aviso.status)}</Cell>
</Row>
`)}
</Rows>
<Loading><div class="text-center py-8 text-[var(--text-muted,currentColor)]">${m.listLoading}</div></Loading>
<Empty><div class="text-center py-8 text-[var(--text-muted,currentColor)]">${m.listEmpty}</div></Empty>
</groupviewdata--ml-vertical-record-list>
</div>
`;
    }
    renderAviso() {
        const m = this.msg;
        const aviso = this.avisoAtual;
        if (this.qryAvisoPorIdStatus === 'loading') {
            return html `<div data-organism-id="avisoDoDia" class="p-4 text-[var(--text-muted,currentColor)]" aria-busy="true" aria-live="polite">${m.noticeLoading}</div>`;
        }
        if (this.qryAvisoPorIdError) {
            return html `
<div data-organism-id="avisoDoDia" class="p-4 flex flex-col gap-3" aria-live="polite">
<p class="text-[var(--text-strong,currentColor)]">${m.noticeError}</p>
<button
type="button"
class=${btnPrimary}
@click=${() => {
                if (this.selectedAvisoVencimento)
                    this.qryAvisoPorId(this.selectedAvisoVencimento);
            }}
>
${m.retryNotice}
</button>
</div>
`;
        }
        if (!aviso) {
            return html `<div data-organism-id="avisoDoDia" class="p-6 text-center text-[var(--text-muted,currentColor)]">${m.noNotice}</div>`;
        }
        return html `
<div data-organism-id="avisoDoDia" class="flex flex-col gap-4">
<div class="flex items-center justify-between gap-3">
<p class="text-[var(--text-default,currentColor)]">
${m.referenceOn}: <strong class="text-[var(--text-strong,currentColor)]">${formatDate(aviso.dataReferencia)}</strong>
</p>
${this.sendBadge(aviso.status)}
</div>
<div class="grid grid-cols-2 gap-3">
<div class="rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-3">
<groupviewmetric--ml-metric-big-number>
<Label>${m.tasksLabel}</Label>
<Value>${formatNumber(aviso.details.quantidadeTarefas)}</Value>
</groupviewmetric--ml-metric-big-number>
</div>
<div class="rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-3">
<groupviewmetric--ml-metric-big-number>
<Label>${m.overdueLabel}</Label>
<Value>${formatNumber(aviso.details.quantidadeAtrasadas)}</Value>
</groupviewmetric--ml-metric-big-number>
</div>
</div>
<groupviewtable--ml-responsive-table>
<TableCaption>${m.tasksTableCaption}</TableCaption>
<TableHeader>
<TableRow>
<TableHead key="titulo">${m.colTask}</TableHead>
<TableHead key="prazo">${m.colDeadline}</TableHead>
<TableHead key="situacaoPrazo">${m.colDeadlineState}</TableHead>
<TableHead key="andamento">${m.colProgress}</TableHead>
</TableRow>
</TableHeader>
<TableBody>
${aviso.details.tarefas.map((linha) => html `
<TableRow key=${linha.tarefaId}>
<TableCell><span class="font-medium text-[var(--text-strong,currentColor)]">${linha.tarefa.titulo}</span></TableCell>
<TableCell>${formatDate(linha.prazo)}</TableCell>
<TableCell>
${linha.situacaoPrazo === 'overdue'
            ? html `<span class=${badgeError}>${m.overdue}</span>`
            : html `<span class=${badgeInfo}>${m.dueToday}</span>`}
</TableCell>
<TableCell><span class=${badgeNeutral}>${this.taskStatusLabel(linha.tarefa.status)}</span></TableCell>
</TableRow>
`)}
</TableBody>
<Empty>${m.tasksEmpty}</Empty>
</groupviewtable--ml-responsive-table>
</div>
`;
    }
    renderHistorico() {
        const m = this.msg;
        return html `
<section data-organism-id="historicoAvisos" class="flex flex-col gap-2 border-t border-[var(--border-subtle,currentColor)] pt-4">
<h3 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${m.logHeading}</h3>
<groupviewdata--ml-timeline-view>
<Columns>
<Column field="aviso" header=${m.logNotice}></Column>
<Column field="quando" header=${m.logWhen}></Column>
</Columns>
<Rows>
${this.avisos.items.map((aviso) => html `
<Row ?selected=${aviso.id === this.selectedAvisoVencimento}>
<Cell>
<div class="flex flex-wrap items-center gap-2">
<span class="font-medium text-[var(--text-strong,currentColor)]">${formatDate(aviso.dataReferencia)}</span>
${this.sendBadge(aviso.status)}
</div>
</Cell>
<Cell>
<div class="text-sm text-[var(--text-default,currentColor)]">
<div>${m.generatedAt}: ${formatDateTime(aviso.details.geradoEm)}</div>
${aviso.details.finalizadoEm
            ? html `<div>${m.finishedAt}: ${formatDateTime(aviso.details.finalizadoEm)}</div>`
            : nothing}
${aviso.details.motivoFalha
            ? html `<div class="text-[var(--text-muted,currentColor)]">${m.failureReason}: ${aviso.details.motivoFalha}</div>`
            : nothing}
</div>
</Cell>
</Row>
`)}
</Rows>
<Empty><div class="text-center py-6 text-[var(--text-muted,currentColor)]">${m.logEmpty}</div></Empty>
</groupviewdata--ml-timeline-view>
</section>
`;
    }
};
TarefasMobilePage11Meus_avisosPage = __decorate([
    customElement('tarefas--web--mobile--page11--meus_avisos-102047')
], TarefasMobilePage11Meus_avisosPage);
export { TarefasMobilePage11Meus_avisosPage };

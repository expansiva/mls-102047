var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/tarefas/web/mobile/page11/inicio_gestor.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TarefasInicio_gestorShared } from '/_102047_/l2/tarefas/web/shared/inicio_gestor.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Início do gestor',
    headlinePrefix: 'Precisam de você:',
    headlineLate: 'atrasadas',
    headlineToday: 'vencem hoje',
    headlineAnd: 'e',
    goodNews: 'Nada precisa de atenção agora',
    goodNewsHint: 'Nenhuma tarefa da equipe está atrasada ou vence hoje.',
    laneTitle: 'Para decidir: trocar responsável ou cancelar',
    laneEmpty: 'Nenhuma tarefa para decidir.',
    laneColTask: 'Tarefa',
    laneColDue: 'Prazo',
    factLate: 'Atrasada',
    factToday: 'Vence hoje',
    statusAFazer: 'A fazer',
    statusEmAndamento: 'Em andamento',
    statusEmRevisao: 'Em revisão',
    statusConcluida: 'Concluída',
    statusCancelada: 'Cancelada',
    checklist: 'checklist',
    loadMore: 'Carregar mais tarefas',
    retry: 'Tentar de novo',
    laneError: 'Não foi possível carregar as tarefas que pedem sua decisão.',
    stripError: 'Não foi possível carregar o panorama da equipe.',
    preconditionMissing: 'Escolha uma tarefa da fila para abrir em Tarefas da equipe.',
    loading: 'Carregando…',
    stripTitle: 'Panorama da equipe',
    stripOpen: 'Abertas',
    stripToday: 'Vencem hoje',
    stripLate: 'Atrasadas',
    stripChecklist: 'Checklists feitas',
    byList: 'Tarefas abertas por lista',
    byListSeries: 'Tarefas abertas',
    byListEmpty: 'Nenhuma lista com tarefas abertas.',
};
const pageMessages = {
    'pt-br': pageMessage_pt_br,
};
/// **collab_i18n_end**
function formatDate(value) {
    const parts = (value || '').slice(0, 10).split('-').map(Number);
    if (parts.length < 3 || parts.some(n => Number.isNaN(n)))
        return value || '';
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    return new Intl.DateTimeFormat(document.documentElement.lang || undefined, { day: '2-digit', month: 'short' }).format(d);
}
function formatNumber(n) {
    return new Intl.NumberFormat(document.documentElement.lang || undefined).format(n);
}
let TarefasMobilePage11Inicio_gestorPage = class TarefasMobilePage11Inicio_gestorPage extends TarefasInicio_gestorShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<main class="min-h-screen w-full max-w-[430px] mx-auto bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)] px-4 pb-10 pt-4 flex flex-col gap-6">
<header>
<h1 class="text-sm font-medium text-[var(--text-muted,currentColor)]">${this.msg['pageTitle']}</h1>
</header>
${this.renderHeadline()}
${this.renderLane()}
${this.renderStrip()}
</main>
`;
    }
    statusLabel(status) {
        switch (status) {
            case 'aFazer': return this.msg['statusAFazer'];
            case 'emAndamento': return this.msg['statusEmAndamento'];
            case 'emRevisao': return this.msg['statusEmRevisao'];
            case 'concluida': return this.msg['statusConcluida'];
            default: return this.msg['statusCancelada'];
        }
    }
    renderHeadline() {
        if (this.pageStatus === 'empty') {
            return html `
<section aria-live="polite" class="flex flex-col gap-1">
<p class="text-xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['goodNews']}</p>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['goodNewsHint']}</p>
</section>`;
        }
        if (this.obterPanoramaEquipeStatus !== 'success') {
            return html `
<section aria-live="polite" aria-busy=${this.obterPanoramaEquipeStatus === 'loading' ? 'true' : 'false'}>
<div class="h-7 w-3/4 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
</section>`;
        }
        return html `
<section aria-live="polite">
<p class="text-xl font-semibold leading-snug text-[var(--text-strong,currentColor)]">
${this.msg['headlinePrefix']}
${formatNumber(this.totalAtrasadas)} ${this.msg['headlineLate']}
${this.msg['headlineAnd']}
${formatNumber(this.totalVenceHoje)} ${this.msg['headlineToday']}
</p>
</section>`;
    }
    renderLane() {
        if (this.pageStatus === 'empty')
            return nothing;
        const err = this.listarTarefasParaAcaoError;
        const items = this.tarefas?.items ?? [];
        const loadingFirst = this.listarTarefasParaAcaoStatus === 'loading' && !this.tarefas;
        return html `
<section data-organism-id="tarefasParaAcao" class="flex flex-col gap-3">
<h2 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${this.msg['laneTitle']}</h2>
${err && err.code === 'client.preconditionMissing' ? html `
<p role="status" aria-live="polite" class="rounded-lg px-3 py-3 text-sm bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]">${this.msg['preconditionMissing']}</p>` : nothing}
${err && err.code !== 'client.preconditionMissing' && this.listarTarefasParaAcaoStatus === 'error' ? html `
<div role="alert" class="rounded-lg px-3 py-3 flex flex-col gap-2 bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]">
<p class="text-sm">${this.msg['laneError']}</p>
<grouptriggeraction--ml-button-standard-102040 data-variant="secondary" size="md" @action=${() => { void this.listarTarefasParaAcao(); }}>
<Label>${this.msg['retry']}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>` : html `
<div class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] overflow-hidden">
<groupviewdata--ml-vertical-record-list-102040
.loading=${loadingFirst}
.hoverable=${true}
@row-click=${(e) => {
            const row = items[e.detail.index];
            if (row)
                this.abrirTarefasEquipe(row.id);
        }}>
<Columns>
<Column field="titulo" header=${this.msg['laneColTask']}></Column>
<Column field="prazo" header=${this.msg['laneColDue']} width="112px" align="right"></Column>
</Columns>
<Rows>
${items.map(t => this.renderRow(t))}
</Rows>
<Empty>
<div class="py-6 text-center text-sm text-[var(--text-muted,currentColor)]">${this.msg['laneEmpty']}</div>
</Empty>
<Loading>
<div class="flex flex-col gap-3 p-4" aria-live="polite">
<div class="h-11 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
<div class="h-11 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
<div class="h-11 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
</div>
</Loading>
</groupviewdata--ml-vertical-record-list-102040>
</div>
${this.tarefas?.hasMore ? html `
<grouptriggeraction--ml-button-standard-102040
data-variant="secondary" size="lg" data-class="w-full"
?loading=${this.listarTarefasParaAcaoStatus === 'loading'}
@action=${() => { void this.listarTarefasParaAcao((this.tarefas?.page ?? 1) + 1, true); }}>
<Label>${this.msg['loadMore']}</Label>
</grouptriggeraction--ml-button-standard-102040>` : nothing}
`}
</section>`;
    }
    renderRow(t) {
        const factClass = t.details.atrasada
            ? 'bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]'
            : 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]';
        const fact = t.details.atrasada ? this.msg['factLate'] : t.details.venceHoje ? this.msg['factToday'] : '';
        return html `
<Row ?selected=${t.id === this.selectedTarefa}>
<Cell>
<div class="min-h-[44px] flex flex-col justify-center gap-0.5 py-1">
<span class="font-medium text-[var(--text-strong,currentColor)] break-words">${t.titulo}</span>
<span class="text-xs text-[var(--text-muted,currentColor)] break-words">
${t.membroEquipe.details.identification.name} · ${t.lista.nome}
</span>
<span class="text-xs text-[var(--text-muted,currentColor)]">
${this.statusLabel(t.status)} · ${this.msg['checklist']} ${t.details.progressoChecklist}
</span>
</div>
</Cell>
<Cell>
<div class="min-h-[44px] flex flex-col items-end justify-center gap-1 py-1 tabular-nums">
${fact ? html `<span class="rounded-full px-2 py-0.5 text-xs font-semibold whitespace-nowrap ${factClass}">${fact}</span>` : nothing}
<span class="text-sm font-medium whitespace-nowrap text-[var(--text-strong,currentColor)]">${formatDate(t.prazo)}</span>
</div>
</Cell>
</Row>`;
    }
    renderStrip() {
        const err = this.obterPanoramaEquipeError;
        return html `
<section data-organism-id="destaquesEquipe" class="flex flex-col gap-3 border-t border-[var(--border-subtle,currentColor)] pt-5">
<h2 class="text-sm font-semibold text-[var(--text-muted,currentColor)]">${this.msg['stripTitle']}</h2>
${this.obterPanoramaEquipeStatus === 'error' && err ? html `
<div role="alert" class="rounded-lg px-3 py-3 flex flex-col gap-2 bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]">
<p class="text-sm">${this.msg['stripError']}</p>
<grouptriggeraction--ml-button-standard-102040 data-variant="secondary" size="md" @action=${() => { void this.obterPanoramaEquipe(); }}>
<Label>${this.msg['retry']}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>` : this.obterPanoramaEquipeStatus === 'success' ? html `
<dl class="flex flex-wrap gap-x-6 gap-y-3 m-0">
<div class="flex flex-col">
<dd class="m-0 text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${formatNumber(this.totalAbertas)}</dd>
<dt class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['stripOpen']}</dt>
</div>
<div class="flex flex-col">
<dd class="m-0 text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${formatNumber(this.totalVenceHoje)}</dd>
<dt class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['stripToday']}</dt>
</div>
<div class="flex flex-col">
<dd class="m-0 text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${formatNumber(this.totalAtrasadas)}</dd>
<dt class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['stripLate']}</dt>
</div>
<div class="flex flex-col">
<dd class="m-0 text-lg font-semibold tabular-nums text-[var(--text-strong,currentColor)]">${this.progressoChecklist}</dd>
<dt class="text-xs text-[var(--text-muted,currentColor)]">${this.msg['stripChecklist']}</dt>
</div>
</dl>
<details class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)]">
<summary class="min-h-[44px] flex items-center px-3 cursor-pointer text-sm font-medium text-[var(--text-default,currentColor)] focus-visible:ring-2 focus-visible:ring-[var(--focus-ring,currentColor)] rounded-lg">${this.msg['byList']}</summary>
<div class="px-3 pb-3">
<groupviewchart--ml-bar-chart-102040 .showValues=${true} .showLegend=${false}>
<Series name=${this.msg['byListSeries']}>
${this.listas.map(l => html `<Point label=${l.nome} value=${String(l.details.quantidadeTarefasAbertas)}></Point>`)}
</Series>
<Empty>${this.msg['byListEmpty']}</Empty>
</groupviewchart--ml-bar-chart-102040>
</div>
</details>` : html `
<div class="flex flex-wrap gap-4" aria-busy="true" aria-live="polite">
<div class="h-10 w-16 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
<div class="h-10 w-16 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
<div class="h-10 w-16 rounded bg-[var(--surface-alt-bg,transparent)] animate-pulse"></div>
<span class="sr-only">${this.msg['loading']}</span>
</div>`}
</section>`;
    }
};
TarefasMobilePage11Inicio_gestorPage = __decorate([
    customElement('tarefas--web--mobile--page11--inicio_gestor-102047')
], TarefasMobilePage11Inicio_gestorPage);
export { TarefasMobilePage11Inicio_gestorPage };

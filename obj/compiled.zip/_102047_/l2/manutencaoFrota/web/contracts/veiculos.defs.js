/// <mls fileReference="_102047_/l2/manutencaoFrota/web/contracts/veiculos.defs.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102047_/l2/manutencaoFrota/web/contracts/abastecimentos.defs.ts" enhancement="_blank"/>
export {};

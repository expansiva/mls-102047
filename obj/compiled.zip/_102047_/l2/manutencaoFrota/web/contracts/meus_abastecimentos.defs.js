export const createFuelingRoute = "manutencaoFrota.meus_abastecimentos.cmdCreateFueling";
export const listFuelingRoute = "manutencaoFrota.meus_abastecimentos.qryListFueling";
export const listVehicleRoute = "manutencaoFrota.meus_abastecimentos.qryListVehicle";

/// <mls fileReference="_102047_/l2/manutencaoFrota/web/contracts/meus_abastecimentos.defs.ts" enhancement="_blank"/>
export {};

export const createMaintenanceOrderRoute = "manutencaoFrota.planos_preventivos.cmdCreateMaintenanceOrder";
export const createMaintenancePlanRoute = "manutencaoFrota.planos_preventivos.cmdCreateMaintenancePlan";
export const listMaintenanceOrderRoute = "manutencaoFrota.planos_preventivos.qryListMaintenanceOrder";
export const listMaintenancePlanRoute = "manutencaoFrota.planos_preventivos.qryListMaintenancePlan";
export const listVehicleRoute = "manutencaoFrota.planos_preventivos.qryListVehicle";

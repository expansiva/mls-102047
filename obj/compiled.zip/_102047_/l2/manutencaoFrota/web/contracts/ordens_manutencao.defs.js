export const createMaintenanceOrderRoute = "manutencaoFrota.ordens_manutencao.cmdCreateMaintenanceOrder";
export const updateMaintenanceOrderRoute = "manutencaoFrota.ordens_manutencao.cmdUpdateMaintenanceOrder";
export const listMaintenanceOrderRoute = "manutencaoFrota.ordens_manutencao.qryListMaintenanceOrder";
export const listMaintenancePlanRoute = "manutencaoFrota.ordens_manutencao.qryListMaintenancePlan";
export const listVehicleRoute = "manutencaoFrota.ordens_manutencao.qryListVehicle";

export const createMaintenanceOrderRoute = "manutencaoFrota.veiculos_frota.cmdCreateMaintenanceOrder";
export const createMaintenancePlanRoute = "manutencaoFrota.veiculos_frota.cmdCreateMaintenancePlan";
export const listMaintenanceOrderRoute = "manutencaoFrota.veiculos_frota.qryListMaintenanceOrder";
export const listMaintenancePlanRoute = "manutencaoFrota.veiculos_frota.qryListMaintenancePlan";
export const listVehicleRoute = "manutencaoFrota.veiculos_frota.qryListVehicle";

/// <mls fileReference="_102047_/l2/manutencaoFrota/web/contracts/painel_frota.defs.ts" enhancement="_blank"/>
export {};

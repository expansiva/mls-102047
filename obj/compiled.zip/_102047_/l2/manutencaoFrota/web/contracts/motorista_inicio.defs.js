export const listVehicleRoute = "manutencaoFrota.motorista_inicio.qryListVehicle";

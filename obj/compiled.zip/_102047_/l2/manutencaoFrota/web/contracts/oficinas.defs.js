/// <mls fileReference="_102047_/l2/manutencaoFrota/web/contracts/oficinas.defs.ts" enhancement="_blank"/>
export {};

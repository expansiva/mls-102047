export const listMaintenanceOrderRoute = "manutencaoFrota.gestor_inicio.qryListMaintenanceOrder";
export const listMaintenancePlanRoute = "manutencaoFrota.gestor_inicio.qryListMaintenancePlan";
export const listVehicleRoute = "manutencaoFrota.gestor_inicio.qryListVehicle";

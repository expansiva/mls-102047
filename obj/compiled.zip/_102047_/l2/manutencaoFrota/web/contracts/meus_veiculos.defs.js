export const createFuelingRoute = "manutencaoFrota.meus_veiculos.cmdCreateFueling";
export const listFuelingRoute = "manutencaoFrota.meus_veiculos.qryListFueling";
export const listVehicleRoute = "manutencaoFrota.meus_veiculos.qryListVehicle";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/inicio/web/desktop/page11/meu_cadastro.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { InicioMeu_cadastroShared } from '/_102047_/l2/inicio/web/shared/meu_cadastro.js';
import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewcard/ml-profile-card.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Meu cadastro',
    pageIntro: 'Confira seus dados na organização e complete só o que ainda falta.',
    accessComplete: 'Acesso completo',
    accessPending: 'Acesso pendente',
    statusActive: 'Ativo na plataforma',
    statusInactive: 'Inativo na plataforma',
    statusMerged: 'Cadastro unificado',
    statusBlocked: 'Bloqueado na plataforma',
    noName: 'Nome ainda não informado',
    noValue: '—',
    companyLabel: 'Empresa',
    countryLabel: 'País',
    contactsLabel: 'Contatos',
    missingLabel: 'Dados que faltam',
    warningTitle: 'Aguardando liberação do responsável',
    warningMessage: 'Já existe outro cadastro com o mesmo e-mail de contato. O responsável precisa liberar o seu acesso; este aviso fica aqui até a liberação.',
    formTitle: 'Dados mínimos',
    formHint: 'Os campos marcados são obrigatórios. Seu e-mail é o da conta e não pode ser editado.',
    nameLabel: 'Nome',
    namePlaceholder: 'Como você quer ser chamado',
    countryFieldLabel: 'País',
    countryHelper: 'Código de 2 letras, como BR ou PT.',
    countryPlaceholder: 'BR',
    consentLabel: 'Concordo com o uso dos meus dados pessoais',
    consentHelper: 'Exigido pela lei do seu país.',
    saveLabel: 'Salvar meus dados',
    retryLabel: 'Tentar salvar novamente',
    saveNote: 'O pedido de liberação fica com o responsável. Depois de completar os dados mínimos, você segue para os módulos liberados.',
    savedOk: 'Dados salvos.',
    completeNote: 'Seus dados mínimos estão completos. Os módulos liberados pelo responsável já podem ser usados.',
    timelineTitle: 'Andamento do pedido de liberação',
    step1Title: 'Encaminhado ao responsável',
    step1Desc: 'O pedido foi enviado para quem responde pela empresa.',
    step2Title: 'Acesso liberado',
    step2Desc: 'O responsável libera o seu acesso.',
    step3Title: 'Login ligado',
    step3Desc: 'A plataforma liga o seu login ao cadastro.',
    loadingLabel: 'Carregando seu cadastro',
    emptyTitle: 'Não encontramos o seu cadastro',
    emptyText: 'Ainda não há um cadastro ligado à sua conta nesta organização.',
    errorTitle: 'Não foi possível carregar seu cadastro',
    errorText: 'Tente carregar novamente em instantes.',
    missingTitle: 'Esta página precisa de um cadastro selecionado',
    missingText: 'A página foi aberta sem o cadastro que ela mostra. Volte para a página anterior e abra Meu cadastro de lá.',
    selectionInvalidText: 'O cadastro selecionado não é o seu. Volte e abra Meu cadastro novamente.',
    backLabel: 'Voltar à página anterior',
    reloadLabel: 'Carregar novamente'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
function withIdent(d, patch) {
    return {
        details: {
            identification: { ...d.details.identification, ...patch },
            person: { ...d.details.person }
        }
    };
}
function withConsent(d, consent) {
    return {
        details: {
            identification: { ...d.details.identification },
            person: { ...d.details.person, privacyConsent: consent }
        }
    };
}
function statusTone(status) {
    if (status === 'Active')
        return 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]';
    if (status === 'Inactive')
        return 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]';
    if (status === 'Blocked')
        return 'bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]';
    return 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]';
}
let InicioDesktopPage11Meu_cadastroPage = class InicioDesktopPage11Meu_cadastroPage extends InicioMeu_cadastroShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        const data = this.meuCadastro;
        return html `
<div class="min-h-full bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)]">
<div class="mx-auto max-w-6xl px-8 py-8 flex flex-col gap-6">
${this.renderHeader(data)}
${data ? this.renderContent(data) : this.renderNoData()}
</div>
</div>
`;
    }
    renderHeader(data) {
        return html `
<header class="flex items-start justify-between gap-4">
<div class="flex flex-col gap-1">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg['pageTitle']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['pageIntro']}</p>
</div>
${data
            ? html `<span
class="inline-flex items-center rounded-full px-3 py-1 text-sm font-medium ${data.details.inicio.acessoCompleto
                ? 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]'
                : 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]'}"
>${data.details.inicio.acessoCompleto ? this.msg['accessComplete'] : this.msg['accessPending']}</span
>`
            : nothing}
</header>
`;
    }
    renderNoData() {
        const status = this.pageStatus;
        const err = this.qryMeuCadastroError;
        if (status === 'loading' || (status === 'idle' && !err)) {
            return html `
<div class="grid grid-cols-12 gap-6" aria-busy="true" aria-live="polite">
<span class="sr-only">${this.msg['loadingLabel']}</span>
<div class="col-span-5 flex flex-col gap-4">
<div class="h-48 animate-pulse rounded-lg bg-[var(--surface-alt-bg,transparent)]"></div>
<div class="h-40 animate-pulse rounded-lg bg-[var(--surface-alt-bg,transparent)]"></div>
</div>
<div class="col-span-7 h-96 animate-pulse rounded-lg bg-[var(--surface-alt-bg,transparent)]"></div>
</div>
`;
        }
        if (err) {
            const precondition = err.code === 'client.preconditionMissing';
            const selection = err.code === 'client.selectionInvalid';
            const title = precondition ? this.msg['missingTitle'] : this.msg['errorTitle'];
            const text = precondition ? this.msg['missingText'] : selection ? this.msg['selectionInvalidText'] : this.msg['errorText'];
            return html `
<section
class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-8 flex flex-col gap-3 max-w-xl"
aria-live="polite"
>
<h2 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${title}</h2>
<p>${text}</p>
${!precondition && !selection && err.message ? html `<p class="text-sm text-[var(--text-muted,currentColor)]">${err.message}</p>` : nothing}
<div class="flex gap-3 pt-2">
${precondition || selection
                ? html `<grouptriggeraction--ml-button-standard data-variant="primary" @action=${() => history.back()}>
<Label>${this.msg['backLabel']}</Label>
</grouptriggeraction--ml-button-standard>`
                : html `<grouptriggeraction--ml-button-standard data-variant="primary" @action=${() => this.qryMeuCadastro()}>
<Label>${this.msg['reloadLabel']}</Label>
</grouptriggeraction--ml-button-standard>`}
</div>
</section>
`;
        }
        return html `
<section class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-bg,transparent)] p-8 flex flex-col gap-2 max-w-xl">
<h2 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${this.msg['emptyTitle']}</h2>
<p class="text-[var(--text-muted,currentColor)]">${this.msg['emptyText']}</p>
</section>
`;
    }
    renderContent(data) {
        return html `
<div data-organism-id="avisoLiberacao">${this.renderAviso(data)}</div>
<div class="grid grid-cols-12 gap-6 items-start">
<div class="col-span-5 flex flex-col gap-6">
<div data-organism-id="meuCadastroResumo">${this.renderResumo()}</div>
<div data-organism-id="andamentoLiberacao">${this.renderAndamento(data)}</div>
</div>
<section class="col-span-7 rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-6 flex flex-col gap-6">
<div data-organism-id="dadosMinimosForm">${this.renderForm(data)}</div>
<div data-organism-id="acoesMeuCadastro">${this.renderAcoes(data)}</div>
</section>
</div>
`;
    }
    renderAviso(data) {
        return html `
<groupnotifyuser--ml-notify-banner type="warning" .visible=${data.aguardaLiberacao} .dismissible=${false}>
<Title>${this.msg['warningTitle']}</Title>
<Message>${this.msg['warningMessage']}</Message>
</groupnotifyuser--ml-notify-banner>
`;
    }
    renderResumo() {
        const r = this.meuCadastroResumo;
        if (!r) {
            return html `<p class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4" aria-live="polite">
${this.msg['selectionInvalidText']}
</p>`;
        }
        const id = r.details.identification;
        const statusLabels = {
            Active: this.msg['statusActive'],
            Inactive: this.msg['statusInactive'],
            Merged: this.msg['statusMerged'],
            Blocked: this.msg['statusBlocked']
        };
        const row = (label, value) => html `
<div class="flex flex-col">
<dt class="text-xs text-[var(--text-muted,currentColor)]">${label}</dt>
<dd class="text-sm text-[var(--text-default,currentColor)]">${value}</dd>
</div>
`;
        return html `
<groupviewcard--ml-profile-card>
<CardHeader>
<CardTitle>${id.name || this.msg['noName']}</CardTitle>
<CardDescription>
<span class="inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${statusTone(id.status)}">${statusLabels[id.status] ?? id.status}</span>
</CardDescription>
</CardHeader>
<CardContent>
<dl class="mt-3 flex flex-col gap-3">
${row(this.msg['companyLabel'], r.empresa?.details.identification.name || this.msg['noValue'])}
${row(this.msg['countryLabel'], id.countryCode || this.msg['noValue'])}
${row(this.msg['contactsLabel'], r.details.base.contacts || this.msg['noValue'])}
${r.details.inicio.dadosFaltantes ? row(this.msg['missingLabel'], r.details.inicio.dadosFaltantes) : nothing}
</dl>
</CardContent>
</groupviewcard--ml-profile-card>
`;
    }
    renderAndamento(data) {
        const pending = data.aguardaLiberacao;
        return html `
<div class="rounded-lg border border-[var(--border-subtle,currentColor)] bg-[var(--surface-alt-bg,transparent)] p-4">
<groupnavigatesteps--ml-vertical-stepper .value=${pending ? 1 : 2}>
<Label>${this.msg['timelineTitle']}</Label>
<Step title=${this.msg['step1Title']} description=${this.msg['step1Desc']} completed></Step>
<Step title=${this.msg['step2Title']} description=${this.msg['step2Desc']} ?completed=${!pending}></Step>
<Step title=${this.msg['step3Title']} description=${this.msg['step3Desc']} ?completed=${!pending}></Step>
</groupnavigatesteps--ml-vertical-stepper>
</div>
`;
    }
    renderForm(data) {
        if (data.details.inicio.acessoCompleto) {
            return html `
<p class="text-[var(--status-success-text,currentColor)]" aria-live="polite">${this.msg['completeNote']}</p>
`;
        }
        const draft = this.salvarMeusDadosDraft;
        const ident = draft.details.identification;
        const nameValue = ident.name ?? data.details.identification.name ?? '';
        const countryValue = ident.countryCode ?? data.details.identification.countryCode ?? '';
        const consentOn = draft.details.person.privacyConsent === 'true';
        return html `
<form class="flex flex-col gap-5" @submit=${(e) => e.preventDefault()}>
<div class="flex flex-col gap-1">
<h2 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${this.msg['formTitle']}</h2>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['formHint']}</p>
</div>
<groupentertext--ml-enter-text
name="name"
required
autocomplete="name"
placeholder=${this.msg['namePlaceholder']}
.value=${nameValue}
@change=${(e) => this.setSalvarMeusDadosDraft(withIdent(draft, { name: e.detail.value }))}
>
<Label>${this.msg['nameLabel']}</Label>
</groupentertext--ml-enter-text>
<groupentertext--ml-enter-text
name="countryCode"
required
.maxLength=${2}
.minLength=${2}
placeholder=${this.msg['countryPlaceholder']}
.value=${countryValue}
@change=${(e) => this.setSalvarMeusDadosDraft(withIdent(draft, { countryCode: (e.detail.value || '').toUpperCase() }))}
>
<Label>${this.msg['countryFieldLabel']}</Label>
<Helper>${this.msg['countryHelper']}</Helper>
</groupentertext--ml-enter-text>
${data.details.inicio.consentimentoExigido
            ? html `
<groupenterboolean--ml-checkbox-preference
name="privacyConsent"
.value=${consentOn}
@change=${(e) => this.setSalvarMeusDadosDraft(withConsent(draft, e.detail.value ? 'true' : null))}
>
<Label>${this.msg['consentLabel']}</Label>
<Helper>${this.msg['consentHelper']}</Helper>
</groupenterboolean--ml-checkbox-preference>
`
            : nothing}
</form>
`;
    }
    renderAcoes(data) {
        const status = this.salvarMeusDadosStatus;
        const err = this.salvarMeusDadosError;
        if (data.details.inicio.acessoCompleto) {
            return html `<div aria-live="polite">
${status === 'success' ? html `<p class="text-sm text-[var(--status-success-text,currentColor)]">${this.msg['savedOk']}</p>` : nothing}
</div>`;
        }
        const d = this.salvarMeusDadosDraft;
        const name = d.details.identification.name ?? data.details.identification.name ?? '';
        const country = d.details.identification.countryCode ?? data.details.identification.countryCode ?? '';
        const consentOk = !data.details.inicio.consentimentoExigido || d.details.person.privacyConsent === 'true';
        const ready = name.trim() !== '' && country.trim() !== '' && consentOk;
        return html `
<div class="flex flex-col gap-3 border-t border-[var(--border-subtle,currentColor)] pt-4">
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['saveNote']}</p>
<div aria-live="polite" class="flex flex-col gap-1">
${status === 'error' && err ? html `<p class="text-sm text-[var(--text-default,currentColor)]">${err.message}</p>` : nothing}
${status === 'success' ? html `<p class="text-sm text-[var(--status-success-text,currentColor)]">${this.msg['savedOk']}</p>` : nothing}
</div>
<div>
<grouptriggeraction--ml-button-standard
data-variant="primary"
?disabled=${!ready}
?loading=${status === 'loading'}
@action=${() => this.salvarMeusDados()}
>
<Label>${status === 'error' ? this.msg['retryLabel'] : this.msg['saveLabel']}</Label>
</grouptriggeraction--ml-button-standard>
</div>
</div>
`;
    }
};
InicioDesktopPage11Meu_cadastroPage = __decorate([
    customElement('inicio--web--desktop--page11--meu_cadastro-102047')
], InicioDesktopPage11Meu_cadastroPage);
export { InicioDesktopPage11Meu_cadastroPage };

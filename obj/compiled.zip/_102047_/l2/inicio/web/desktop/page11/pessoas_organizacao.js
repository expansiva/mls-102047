var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/inicio/web/desktop/page11/pessoas_organizacao.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { InicioPessoas_organizacaoShared } from '/_102047_/l2/inicio/web/shared/pessoas_organizacao.js';
import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner.js';
import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
import '/_102040_/l2/molecules/groupselectone/ml-segmented-control.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewcard/ml-profile-card.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    pageTitle: 'Pessoas da organização',
    pageLead: 'Veja quem já completou o acesso e quem ainda precisa de atenção.',
    searchLabel: 'Procurar pelo nome',
    searchPlaceholder: 'Nome da pessoa',
    searchEmpty: 'A lista ao lado mostra os resultados.',
    situacaoLabel: 'Situação do acesso',
    filtroTodas: 'Todas',
    filtroIncompleto: 'Acesso incompleto',
    filtroAguardando: 'Aguardando liberação',
    colNome: 'Nome',
    colPais: 'País',
    colSituacao: 'Situação na plataforma',
    colAcesso: 'Acesso',
    acessoCompleto: 'Acesso completo',
    acessoIncompleto: 'Acesso incompleto',
    faltaPrefixo: 'Falta:',
    statusActive: 'Ativa',
    statusInactive: 'Inativa',
    statusMerged: 'Unificada',
    statusBlocked: 'Bloqueada',
    tableEmpty: 'Nenhuma pessoa encontrada com esses filtros.',
    loadMore: 'Mostrar mais pessoas',
    listError: 'Não foi possível atualizar a lista de pessoas.',
    selectHint: 'Selecione uma pessoa na lista para ver o que falta para ela, se o consentimento é exigido e em que ponto está a liberação.',
    loadingPerson: 'Carregando a pessoa…',
    personError: 'Não foi possível carregar esta pessoa.',
    retry: 'Tentar de novo',
    fieldCountry: 'País',
    fieldContacts: 'Contatos',
    fieldSituacao: 'Situação na plataforma',
    fieldConsent: 'Consentimento de privacidade',
    consentRequired: 'Exigido pela lei do país',
    consentNotRequired: 'Não exigido no país',
    noContacts: 'Nenhum contato informado',
    missingTitle: 'O que ainda falta',
    missingNone: 'Nenhum dado mínimo falta; o acesso depende da liberação pela plataforma.',
    completeMessage: 'Esta pessoa já informou todos os dados mínimos.',
    stepperLabel: 'Andamento da liberação',
    stepPedido: 'Pedido encaminhado',
    stepLiberado: 'Acesso liberado',
    stepLogin: 'Login ligado',
    stepCompleto: 'Acesso completado',
    orientTitle: 'Como liberar o acesso',
    orientMessage: 'Quem aguarda liberação passa a ter acesso quando o responsável faz a liberação na plataforma. Aqui você só acompanha em que ponto a pessoa está.',
    empresaPendente: 'Dados da empresa que ainda faltam:',
    goEmpresa: 'Completar dados da empresa',
    goInicio: 'Voltar ao início',
    navError: 'Não foi possível seguir por este caminho.',
    loadingPage: 'Carregando as pessoas da organização…',
    errorTitle: 'Não foi possível abrir as pessoas da organização',
    errorBody: 'Tente de novo em instantes.',
    precondTitle: 'Falta saber de onde abrir as pessoas',
    precondBody: 'Esta página foi aberta sem a empresa ou a pessoa de origem. Volte para a tela anterior e abra as pessoas a partir dela.',
    back: 'Voltar para a tela anterior'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
const TONES = {
    success: 'bg-[var(--status-success-bg,transparent)] text-[var(--status-success-text,currentColor)]',
    warning: 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]',
    error: 'bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]',
    neutral: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]'
};
const STATUS_TONE = {
    Active: 'success',
    Inactive: 'warning',
    Merged: 'neutral',
    Blocked: 'error'
};
const ETAPA_INDEX = {
    pedidoEncaminhado: 0,
    acessoLiberado: 1,
    loginLigado: 2,
    acessoCompletado: 3
};
function chip(label, tone) {
    return html `<span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap ${TONES[tone]}">${label}</span>`;
}
function statusLabel(msg, s) {
    const map = {
        Active: msg.statusActive,
        Inactive: msg.statusInactive,
        Merged: msg.statusMerged,
        Blocked: msg.statusBlocked
    };
    return map[s];
}
function listText(items) {
    return items.join(', ');
}
function rowsOf(p) {
    if (Array.isArray(p))
        return p;
    const rec = p;
    if (!rec)
        return [];
    for (const key of ['items', 'rows', 'data', 'pessoas']) {
        const v = rec[key];
        if (Array.isArray(v))
            return v;
    }
    return [];
}
function hasMoreOf(p) {
    if (!p || Array.isArray(p))
        return false;
    return p['hasMore'] === true;
}
let InicioDesktopPage11Pessoas_organizacaoPage = class InicioDesktopPage11Pessoas_organizacaoPage extends InicioPessoas_organizacaoShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        return html `
<div class="min-h-full bg-[var(--page-bg,transparent)] text-[var(--text-default,currentColor)] px-8 py-6 flex flex-col gap-6">
<header class="flex flex-col gap-1">
<h1 class="text-2xl font-semibold text-[var(--text-strong,currentColor)]">${this.msg.pageTitle}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg.pageLead}</p>
</header>
${this.renderBody()}
</div>
`;
    }
    renderBody() {
        if (this.pageStatus === 'error')
            return this.renderFailure();
        if (this.pageStatus === 'loading' || this.pageStatus === 'idle')
            return this.renderLoading();
        return this.renderDirectory();
    }
    renderLoading() {
        return html `
<div class="grid grid-cols-[minmax(0,1.5fr)_minmax(360px,1fr)] gap-6" aria-busy="true" aria-live="polite">
<span class="sr-only">${this.msg.loadingPage}</span>
<div class="flex flex-col gap-3">
<div class="h-12 rounded-md animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>
${[0, 1, 2, 3, 4, 5].map(() => html `<div class="h-12 rounded-md animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>`)}
</div>
<div class="h-72 rounded-lg animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>
</div>
`;
    }
    renderFailure() {
        const missing = this.abrirPessoasOrganizacaoError?.code === 'client.preconditionMissing';
        return html `
<div class="max-w-xl rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-6 flex flex-col gap-4" aria-live="polite">
<h2 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${missing ? this.msg.precondTitle : this.msg.errorTitle}</h2>
<p class="text-sm text-[var(--text-default,currentColor)]">${missing ? this.msg.precondBody : this.msg.errorBody}</p>
<div>
${missing
            ? html `<grouptriggeraction--ml-button-standard-102040 size="md" data-variant="secondary" @action=${() => history.back()}><Label>${this.msg.back}</Label></grouptriggeraction--ml-button-standard-102040>`
            : html `<grouptriggeraction--ml-button-standard-102040 size="md" data-variant="primary" @action=${() => this.abrirPessoasOrganizacao()}><Label>${this.msg.retry}</Label></grouptriggeraction--ml-button-standard-102040>`}
</div>
</div>
`;
    }
    renderDirectory() {
        return html `
<div class="grid grid-cols-[minmax(0,1.5fr)_minmax(360px,1fr)] gap-6 items-start">
<section data-organism-id="listaPessoas" class="flex flex-col gap-4 min-w-0">
${this.renderList()}
</section>
<aside class="sticky top-4 flex flex-col gap-4 min-w-0">
${this.renderPanel()}
${this.renderActions()}
</aside>
</div>
`;
    }
    renderList() {
        const rows = rowsOf(this.pessoas);
        const idx = rows.findIndex((r) => r.id === this.selectedPessoaOrganizacao);
        const busy = this.buscarPessoasStatus === 'loading';
        return html `
<div class="flex flex-wrap items-end gap-4">
<div class="flex-1 min-w-[240px]">
<groupsearchcontent--ml-search-bar-102040
.value=${this.filtroBusca}
.loading=${busy}
placeholder=${this.msg.searchPlaceholder}
debounce="350"
@search=${(e) => this.buscarPessoas({ busca: e.detail.query })}
@change=${(e) => this.buscarPessoas({ busca: e.detail.value ?? '' })}
@clear=${() => this.buscarPessoas({ busca: '' })}
>
<Label>${this.msg.searchLabel}</Label>
<Empty>${this.msg.searchEmpty}</Empty>
</groupsearchcontent--ml-search-bar-102040>
</div>
<groupselectone--ml-segmented-control-102040
.value=${this.filtroSituacao}
@change=${(e) => {
            if (e.detail.value)
                this.buscarPessoas({ situacao: e.detail.value });
        }}
>
<Label>${this.msg.situacaoLabel}</Label>
<Item value="todas">${this.msg.filtroTodas}</Item>
<Item value="acessoIncompleto">${this.msg.filtroIncompleto}</Item>
<Item value="aguardandoLiberacao">${this.msg.filtroAguardando}</Item>
</groupselectone--ml-segmented-control-102040>
</div>
${this.buscarPessoasError
            ? html `<div aria-live="polite" class="text-sm text-[var(--text-default,currentColor)] rounded-md border border-[var(--status-error-text,currentColor)] bg-[var(--status-error-bg,transparent)] px-3 py-2">${this.msg.listError}</div>`
            : nothing}
<groupviewtable--ml-data-table-102040
.value=${idx >= 0 ? String(idx) : ''}
.loading=${busy}
@rowClick=${(e) => {
            const row = rows[e.detail.index];
            if (row)
                this.selectPessoaOrganizacao(row.id);
        }}
>
<TableHeader>
<TableRow>
<TableHead key="nome">${this.msg.colNome}</TableHead>
<TableHead key="pais">${this.msg.colPais}</TableHead>
<TableHead key="situacao">${this.msg.colSituacao}</TableHead>
<TableHead key="acesso">${this.msg.colAcesso}</TableHead>
</TableRow>
</TableHeader>
<TableBody>
${rows.map((p) => this.renderRow(p))}
</TableBody>
<Empty>${this.msg.tableEmpty}</Empty>
</groupviewtable--ml-data-table-102040>
${hasMoreOf(this.pessoas)
            ? html `<div>
<grouptriggeraction--ml-button-standard-102040 size="md" data-variant="secondary" .loading=${busy} @action=${() => this.buscarPessoas({ append: true })}>
<Label>${this.msg.loadMore}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>`
            : nothing}
`;
    }
    renderRow(p) {
        const id = p.details.identification;
        const ini = p.details.inicio;
        return html `
<TableRow key=${p.id}>
<TableCell>
<span class="${ini.acessoCompleto ? '' : 'font-semibold text-[var(--text-strong,currentColor)]'}">${id.name}</span>
</TableCell>
<TableCell>${id.countryCode}</TableCell>
<TableCell>${chip(statusLabel(this.msg, id.status), STATUS_TONE[id.status])}</TableCell>
<TableCell>
<span class="inline-flex flex-col gap-0.5">
${ini.acessoCompleto
            ? chip(this.msg.acessoCompleto, 'success')
            : chip(this.msg.acessoIncompleto, 'warning')}
${!ini.acessoCompleto && ini.dadosFaltantes.length > 0
            ? html `<span class="text-xs text-[var(--text-muted,currentColor)]">${this.msg.faltaPrefixo} ${listText(ini.dadosFaltantes)}</span>`
            : nothing}
</span>
</TableCell>
</TableRow>
`;
    }
    renderPanel() {
        const sel = this.selectedPessoaOrganizacao;
        const p = this.pessoa;
        let detail;
        if (!sel) {
            detail = html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg.selectHint}</p>`;
        }
        else if (this.obterPessoaStatus === 'error') {
            detail = html `
<div class="flex flex-col gap-3" aria-live="polite">
<p class="text-sm text-[var(--text-default,currentColor)]">${this.msg.personError}</p>
<div>
<grouptriggeraction--ml-button-standard-102040 size="sm" data-variant="secondary" @action=${() => this.obterPessoa(sel)}>
<Label>${this.msg.retry}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>
</div>`;
        }
        else if (this.obterPessoaStatus === 'loading' || !p) {
            detail = html `
<div aria-busy="true" aria-live="polite" class="flex flex-col gap-3">
<span class="sr-only">${this.msg.loadingPerson}</span>
<div class="h-6 w-2/3 rounded animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>
<div class="h-20 rounded animate-pulse bg-[var(--surface-alt-bg,transparent)]"></div>
</div>`;
        }
        else {
            detail = this.renderPessoa(p);
        }
        return html `
<div class="rounded-lg border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-5 flex flex-col gap-5">
<div data-organism-id="detalhePessoa">${detail}</div>
<div data-organism-id="andamentoLiberacao">${sel && p && this.obterPessoaStatus !== 'error' ? this.renderAndamento(p) : nothing}</div>
</div>
`;
    }
    renderPessoa(p) {
        const id = p.details.identification;
        const ini = p.details.inicio;
        const contatos = p.contacts.map((c) => c.details.base.contacts);
        return html `
<div class="flex flex-col gap-4">
<groupviewcard--ml-profile-card-102040>
<CardHeader>
<CardTitle>${id.name}</CardTitle>
<CardDescription>${chip(statusLabel(this.msg, id.status), STATUS_TONE[id.status])}</CardDescription>
</CardHeader>
<CardContent>
<dl class="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
<dt class="text-[var(--text-muted,currentColor)]">${this.msg.fieldCountry}</dt>
<dd class="text-[var(--text-strong,currentColor)]">${id.countryCode}</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg.fieldContacts}</dt>
<dd class="text-[var(--text-strong,currentColor)]">
${contatos.length > 0
            ? html `<ul class="flex flex-col gap-0.5">${contatos.map((c) => html `<li>${c}</li>`)}</ul>`
            : html `<span class="text-[var(--text-muted,currentColor)]">${this.msg.noContacts}</span>`}
</dd>
<dt class="text-[var(--text-muted,currentColor)]">${this.msg.fieldConsent}</dt>
<dd class="text-[var(--text-strong,currentColor)]">${ini.consentimentoExigido ? this.msg.consentRequired : this.msg.consentNotRequired}</dd>
</dl>
</CardContent>
</groupviewcard--ml-profile-card-102040>
${ini.acessoCompleto
            ? html `<groupnotifyuser--ml-contextual-feedback-102040 type="success" .visible=${true} .dismissible=${false}>
<Message>${this.msg.completeMessage}</Message>
</groupnotifyuser--ml-contextual-feedback-102040>`
            : html `<groupnotifyuser--ml-contextual-feedback-102040 type="warning" .visible=${true} .dismissible=${false}>
<Title>${this.msg.missingTitle}</Title>
<Message>${ini.dadosFaltantes.length > 0 ? listText(ini.dadosFaltantes) : this.msg.missingNone}</Message>
</groupnotifyuser--ml-contextual-feedback-102040>`}
</div>
`;
    }
    renderAndamento(p) {
        const idx = ETAPA_INDEX[p.etapaLiberacao];
        return html `
<div class="pointer-events-none">
<groupnavigatesteps--ml-horizontal-stepper-102040
.value=${idx}
.linear=${true}
@change=${(e) => {
            e.currentTarget.value = idx;
        }}
>
<Label>${this.msg.stepperLabel}</Label>
<Step title=${this.msg.stepPedido}></Step>
<Step title=${this.msg.stepLiberado}></Step>
<Step title=${this.msg.stepLogin}></Step>
<Step title=${this.msg.stepCompleto}></Step>
</groupnavigatesteps--ml-horizontal-stepper-102040>
</div>
`;
    }
    renderActions() {
        const emp = this.empresa;
        const pendente = emp ? !emp.details.inicio.preparada : false;
        const faltantes = emp ? emp.details.inicio.dadosFaltantes : [];
        return html `
<section data-organism-id="acoesLiberacao" class="flex flex-col gap-3">
<groupnotifyuser--ml-notify-banner-102040 type="info" .visible=${true} .dismissible=${false}>
<Title>${this.msg.orientTitle}</Title>
<Message>${this.msg.orientMessage}</Message>
</groupnotifyuser--ml-notify-banner-102040>
${pendente && faltantes.length > 0
            ? html `<p class="text-sm text-[var(--text-default,currentColor)]">${this.msg.empresaPendente} <span class="text-[var(--text-strong,currentColor)]">${listText(faltantes)}</span></p>`
            : nothing}
${this.abrirPessoasOrganizacaoError
            ? html `<div aria-live="polite" class="text-sm text-[var(--text-default,currentColor)] rounded-md border border-[var(--status-error-text,currentColor)] bg-[var(--status-error-bg,transparent)] px-3 py-2">${this.msg.navError}</div>`
            : nothing}
<div class="flex flex-wrap gap-3">
<grouptriggeraction--ml-button-standard-102040 size="md" data-variant=${pendente ? 'primary' : 'secondary'} @action=${() => this.irPrepararEmpresa()}>
<Label>${this.msg.goEmpresa}</Label>
</grouptriggeraction--ml-button-standard-102040>
<grouptriggeraction--ml-button-standard-102040 size="md" data-variant="secondary" @action=${() => this.irInicio()}>
<Label>${this.msg.goInicio}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>
</section>
`;
    }
};
InicioDesktopPage11Pessoas_organizacaoPage = __decorate([
    customElement('inicio--web--desktop--page11--pessoas_organizacao-102047')
], InicioDesktopPage11Pessoas_organizacaoPage);
export { InicioDesktopPage11Pessoas_organizacaoPage };

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/inicio/web/mobile/page11/inicio_pessoa.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { InicioInicio_pessoaShared } from '/_102047_/l2/inicio/web/shared/inicio_pessoa.js';
import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.js';
import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal.js';
/// **collab_i18n_start**
const pageMessage_pt_br = {
    headlineOk: 'Nada precisa de atenção agora',
    headlineAttention: 'Seu acesso precisa de atenção',
    subOk: 'Seus dados mínimos estão completos e você pode seguir para os módulos liberados para você.',
    subAttention: 'Veja abaixo o que falta e siga para o seu cadastro.',
    progressLabel: 'Dados mínimos completos',
    missingTitle: 'Dados que ainda faltam',
    consentNotice: 'O país informado exige o consentimento de privacidade (LGPD ou GDPR).',
    statusActive: 'Cadastro ativo',
    statusInactive: 'Cadastro inativo',
    statusMerged: 'Cadastro unificado',
    statusBlocked: 'Cadastro bloqueado',
    openRegistration: 'Abrir meu cadastro',
    pendingTitle: 'O que espera por você',
    pendingNone: 'Você não tem pendências.',
    releaseTitle: 'Seu acesso aguarda liberação',
    releaseDescription: 'Já existe outro cadastro com o seu e-mail de contato.',
    releaseDescriptionWithEmail: 'Já existe outro cadastro com o e-mail',
    releaseNotice: 'O responsável precisa liberar o seu acesso. Você não precisa preencher nada até lá.',
    releaseAction: 'Encaminhar pedido ao responsável',
    completeTitle: 'Complete seus dados mínimos',
    completeDescription: 'Informe só o que ainda falta no seu cadastro.',
    completeMissing: 'Falta:',
    completeAction: 'Completar meus dados',
    companyTitle: 'Sua empresa',
    companyNone: 'Nenhuma empresa vinculada ao seu cadastro.',
    loading: 'Carregando a situação do seu acesso',
    emptyTitle: 'Não encontramos o seu cadastro',
    emptyText: 'Ainda não há um cadastro ligado à sua sessão. Tente atualizar em instantes.',
    errorTitle: 'Não foi possível carregar a sua situação',
    errorText: 'Tente de novo. Se continuar, volte mais tarde.',
    preconditionTitle: 'Falta algo para abrir esta página',
    preconditionText: 'Esta página precisa ser aberta a partir do seu acesso na plataforma. Volte e entre de novo por lá.',
    back: 'Voltar',
    retry: 'Tentar de novo',
    refresh: 'Atualizar situação',
    summaryRegion: 'Situação do seu acesso',
    companyIcon: '🏢',
    pendingIconRelease: '⏳',
    pendingIconComplete: '📝'
};
const pageMessages = { 'pt-br': pageMessage_pt_br };
/// **collab_i18n_end**
const statusClass = {
    Active: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]',
    Merged: 'bg-[var(--status-neutral-bg,transparent)] text-[var(--status-neutral-text,currentColor)]',
    Inactive: 'bg-[var(--status-warning-bg,transparent)] text-[var(--status-warning-text,currentColor)]',
    Blocked: 'bg-[var(--status-error-bg,transparent)] text-[var(--status-error-text,currentColor)]'
};
function listText(items) {
    if (items.length <= 1)
        return items.join('');
    return `${items.slice(0, -1).join(', ')} e ${items[items.length - 1]}`;
}
let InicioMobilePage11Inicio_pessoaPage = class InicioMobilePage11Inicio_pessoaPage extends InicioInicio_pessoaShared {
    constructor() {
        super(...arguments);
        this.msg = pageMessage_pt_br;
    }
    statusLabel(status) {
        if (status === 'Active')
            return this.msg.statusActive;
        if (status === 'Inactive')
            return this.msg.statusInactive;
        if (status === 'Merged')
            return this.msg.statusMerged;
        return this.msg.statusBlocked;
    }
    renderLoading() {
        return html `
<div class="flex flex-col gap-4" aria-busy="true" aria-live="polite">
<span class="sr-only">${this.msg['loading']}</span>
<div class="h-40 animate-pulse rounded-xl bg-[var(--surface-alt-bg,transparent)]"></div>
<div class="h-32 animate-pulse rounded-xl bg-[var(--surface-alt-bg,transparent)]"></div>
<div class="h-16 animate-pulse rounded-xl bg-[var(--surface-alt-bg,transparent)]"></div>
</div>
`;
    }
    renderFailure(title, text, canGoBack) {
        return html `
<section class="flex flex-col gap-3 rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4" role="alert">
<h1 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${title}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${text}</p>
<div class="flex flex-col gap-2">
${canGoBack
            ? html `<grouptriggeraction--ml-button-standard-102040 size="lg" data-variant="secondary" data-class="w-full" @action=${() => window.history.back()}><Label>${this.msg['back']}</Label></grouptriggeraction--ml-button-standard-102040>`
            : nothing}
<grouptriggeraction--ml-button-standard-102040 size="lg" data-variant="primary" data-class="w-full" @action=${() => this.qryInicioPessoa()}><Label>${this.msg['retry']}</Label></grouptriggeraction--ml-button-standard-102040>
</div>
</section>
`;
    }
    renderResumo(acesso) {
        const ini = acesso.details.inicio;
        const ident = acesso.details.identification;
        const complete = ini.acessoCompleto;
        const missing = ini.dadosFaltantes;
        return html `
<section data-organism-id="resumoMeuAcesso" aria-label=${this.msg['summaryRegion']} class="flex flex-col gap-3 rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4">
<div class="flex flex-col gap-1" aria-live="polite">
<h1 class="text-xl font-semibold leading-snug text-[var(--text-strong,currentColor)]">${complete ? this.msg['headlineOk'] : this.msg['headlineAttention']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${complete ? this.msg['subOk'] : this.msg['subAttention']}</p>
</div>
<div class="flex flex-wrap items-center gap-2">
${ident.name ? html `<span class="text-sm font-medium text-[var(--text-default,currentColor)]">${ident.name}</span>` : nothing}
<span class="inline-flex min-h-[28px] items-center rounded-full px-3 text-xs font-medium ${statusClass[ident.status] || ''}">${this.statusLabel(ident.status)}</span>
</div>
${complete
            ? html `<groupshowprogress--ml-linear-progress-102040 .value=${100} size="sm" label=${this.msg['progressLabel']}></groupshowprogress--ml-linear-progress-102040>`
            : nothing}
${!complete && missing.length
            ? html `
<div class="flex flex-col gap-2">
<p class="text-xs font-medium text-[var(--text-muted,currentColor)]">${this.msg['missingTitle']}</p>
<ul class="flex flex-wrap gap-2">
${missing.map((m) => html `<li class="inline-flex min-h-[28px] items-center rounded-full border border-[var(--border-default,currentColor)] px-3 text-xs text-[var(--text-default,currentColor)]">${m}</li>`)}
</ul>
</div>
`
            : nothing}
${ini.consentimentoExigido
            ? html `<groupnotifyuser--ml-contextual-feedback-102040 type="info" .visible=${true} .dismissible=${false}>
<Message>${this.msg['consentNotice']}</Message>
</groupnotifyuser--ml-contextual-feedback-102040>`
            : nothing}
<grouptriggeraction--ml-button-standard-102040 size="lg" data-variant="secondary" data-class="w-full" @action=${() => this.abrirMeuCadastroResumo()}>
<Label>${this.msg['openRegistration']}</Label>
</grouptriggeraction--ml-button-standard-102040>
</section>
`;
    }
    renderPendencia(p) {
        if (p.tipo === 'pedirLiberacao') {
            return html `
<li>
<groupviewcard--ml-view-card-horizontal-102040>
<CardContent><span aria-hidden="true" class="text-2xl">${this.msg['pendingIconRelease']}</span></CardContent>
<CardHeader>
<CardTitle>${this.msg['releaseTitle']}</CardTitle>
<CardDescription>${p.emailConta ? `${this.msg['releaseDescriptionWithEmail']} ${p.emailConta}.` : this.msg['releaseDescription']}</CardDescription>
</CardHeader>
<CardFooter>
<div class="flex flex-col gap-3 pt-2">
<groupnotifyuser--ml-contextual-feedback-102040 type="warning" .visible=${true} .dismissible=${false}>
<Message>${this.msg['releaseNotice']}</Message>
</groupnotifyuser--ml-contextual-feedback-102040>
<grouptriggeraction--ml-button-standard-102040 size="lg" data-variant="primary" data-class="w-full" @action=${() => this.encaminharPedidoLiberacao()}>
<Label>${this.msg['releaseAction']}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>
</CardFooter>
</groupviewcard--ml-view-card-horizontal-102040>
</li>
`;
        }
        const missing = p.details.inicio.dadosFaltantes ?? [];
        return html `
<li>
<groupviewcard--ml-view-card-horizontal-102040>
<CardContent><span aria-hidden="true" class="text-2xl">${this.msg['pendingIconComplete']}</span></CardContent>
<CardHeader>
<CardTitle>${this.msg['completeTitle']}</CardTitle>
<CardDescription>${missing.length ? `${this.msg['completeMissing']} ${listText(missing)}.` : this.msg['completeDescription']}</CardDescription>
</CardHeader>
<CardFooter>
<div class="pt-2">
<grouptriggeraction--ml-button-standard-102040 size="lg" data-variant="primary" data-class="w-full" @action=${() => this.completarDadosMinimos()}>
<Label>${this.msg['completeAction']}</Label>
</grouptriggeraction--ml-button-standard-102040>
</div>
</CardFooter>
</groupviewcard--ml-view-card-horizontal-102040>
</li>
`;
    }
    renderPendencias(list) {
        return html `
<section data-organism-id="pendenciasMeuAcesso" class="flex flex-col gap-3">
<h2 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${this.msg['pendingTitle']}</h2>
${list.length
            ? html `<ul class="flex flex-col gap-3">${list.map((p) => this.renderPendencia(p))}</ul>`
            : html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['pendingNone']}</p>`}
</section>
`;
    }
    renderEmpresa(emp) {
        return html `
<section data-organism-id="destaqueEmpresa" class="flex flex-col gap-3">
<h2 class="text-base font-semibold text-[var(--text-strong,currentColor)]">${this.msg['companyTitle']}</h2>
${emp
            ? html `
<groupviewcard--ml-view-card-horizontal-102040>
<CardContent><span aria-hidden="true" class="text-2xl">${this.msg['companyIcon']}</span></CardContent>
<CardHeader>
<CardTitle>${emp.details.identification.name}</CardTitle>
${emp.details.company.tradeName ? html `<CardDescription>${emp.details.company.tradeName}</CardDescription>` : nothing}
</CardHeader>
</groupviewcard--ml-view-card-horizontal-102040>
`
            : html `<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['companyNone']}</p>`}
</section>
`;
    }
    render() {
        this.msg = pageMessages[this.getMessageKey(pageMessages)];
        let body;
        if (this.pageStatus === 'idle' || this.pageStatus === 'loading') {
            body = this.renderLoading();
        }
        else if (this.pageStatus === 'error') {
            const pre = this.qryInicioPessoaError?.code === 'client.preconditionMissing';
            body = pre
                ? this.renderFailure(this.msg['preconditionTitle'], this.msg['preconditionText'], true)
                : this.renderFailure(this.msg['errorTitle'], this.qryInicioPessoaError?.message || this.msg['errorText'], false);
        }
        else if (this.pageStatus === 'empty' || !this.meuAcesso) {
            body = html `
<section class="flex flex-col gap-3 rounded-xl border border-[var(--border-default,currentColor)] bg-[var(--surface-bg,transparent)] p-4" aria-live="polite">
<h1 class="text-lg font-semibold text-[var(--text-strong,currentColor)]">${this.msg['emptyTitle']}</h1>
<p class="text-sm text-[var(--text-muted,currentColor)]">${this.msg['emptyText']}</p>
<grouptriggeraction--ml-button-standard-102040 size="lg" data-variant="primary" data-class="w-full" @action=${() => this.qryInicioPessoa()}><Label>${this.msg['retry']}</Label></grouptriggeraction--ml-button-standard-102040>
</section>
`;
        }
        else {
            body = html `
${this.renderResumo(this.meuAcesso)}
${this.renderPendencias(this.pendencias)}
${this.renderEmpresa(this.empresa)}
<div class="flex justify-center">
<grouptriggeraction--ml-button-standard-102040 size="md" data-variant="ghost" @action=${() => this.qryInicioPessoa()}><Label>${this.msg['refresh']}</Label></grouptriggeraction--ml-button-standard-102040>
</div>
`;
        }
        return html `
<main class="mx-auto flex w-full max-w-[430px] flex-col gap-5 bg-[var(--page-bg,transparent)] px-4 py-4 text-[var(--text-default,currentColor)]" aria-busy=${this.pageStatus === 'loading' ? 'true' : 'false'}>
${body}
</main>
`;
    }
};
InicioMobilePage11Inicio_pessoaPage = __decorate([
    customElement('inicio--web--mobile--page11--inicio_pessoa-102047')
], InicioMobilePage11Inicio_pessoaPage);
export { InicioMobilePage11Inicio_pessoaPage };

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/inicio/web/shared/inicio_pessoa.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { auraNavigate } from '/_102033_/l2/shared/layout/auraNavigate.js';
const STATE_MEMBER_BY_KEY = {
    'ui.inicio.inicio_pessoa.meuAcesso': 'meuAcesso',
    'ui.inicio.inicio_pessoa.pendencias': 'pendencias',
    'ui.inicio.inicio_pessoa.empresa': 'empresa',
    'ui.inicio.inicio_pessoa.pageStatus': 'pageStatus',
    'ui.inicio.inicio_pessoa.qryInicioPessoaStatus': 'qryInicioPessoaStatus',
    'ui.inicio.inicio_pessoa.qryInicioPessoaError': 'qryInicioPessoaError',
    'ui.inicio.inicio_pessoa.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class InicioInicio_pessoaShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state meuAcesso — person record linked to the session, with the status of the minimum data (complete access, missing data, consent required); source qryInicioPessoa.meuAcesso; organisms pendenciasMeuAcesso, resumoMeuAcesso */
        this.meuAcesso = null;
        /** state pendencias — short non-paged list of things waiting for the person: ask the responsible to release access, or complete the minimum data; empty when access is complete and linked; source qryInicioPessoa.pendencias; organism pendenciasMeuAcesso */
        this.pendencias = [];
        /** state empresa — company the person belongs to, with the fields the person may see (name and trade name); null when none; source qryInicioPessoa.empresa; organism destaqueEmpresa */
        this.empresa = null;
        /** state pageStatus — overall status of the page load: idle, loading, empty, success or error; derived from qryInicioPessoa */
        this.pageStatus = 'idle';
        /** state qryInicioPessoaStatus — status of the request qryInicioPessoa: idle, loading, success or error */
        this.qryInicioPessoaStatus = 'idle';
        /** state qryInicioPessoaError — error of the request qryInicioPessoa (code, message, details), or null */
        this.qryInicioPessoaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.inicio.inicio_pessoa.${member}`, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    connectedCallback() {
        super.connectedCallback();
        this.hydrateData();
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        void this.qryInicioPessoa();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    hydrateData() {
        const meuAcesso = getState('ui.inicio.inicio_pessoa.meuAcesso');
        if (meuAcesso !== undefined)
            this.assignState('ui.inicio.inicio_pessoa.meuAcesso', meuAcesso);
        const pendencias = getState('ui.inicio.inicio_pessoa.pendencias');
        if (pendencias !== undefined)
            this.assignState('ui.inicio.inicio_pessoa.pendencias', pendencias);
        const empresa = getState('ui.inicio.inicio_pessoa.empresa');
        if (empresa !== undefined)
            this.assignState('ui.inicio.inicio_pessoa.empresa', empresa);
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('qryInicioPessoaStatus', 'idle');
        this.publish('qryInicioPessoaError', null);
        this.publish('scenary', '');
    }
    /** setScenario — publishes the visible scene of the page (state scenary); not persisted, never in the URL */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** request qryInicioPessoa — loads at once the person's access status, the pending items waiting for the person and the person's company; replaces meuAcesso, pendencias and empresa; no arguments (the person is the one in the session); also the method to reload the page */
    async qryInicioPessoa() {
        if (this.qryInicioPessoaStatus === 'loading')
            return;
        this.publish('qryInicioPessoaStatus', 'loading');
        this.publish('qryInicioPessoaError', null);
        this.publish('pageStatus', 'loading');
        try {
            const input = {};
            const response = await execBff('inicio.inicio_pessoa.qryInicioPessoa', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('qryInicioPessoaError', response.error);
                this.publish('qryInicioPessoaStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const output = response.data;
            this.publish('meuAcesso', output.meuAcesso);
            this.publish('pendencias', output.pendencias);
            this.publish('empresa', output.empresa ?? null);
            this.publish('qryInicioPessoaStatus', 'success');
            this.publish('pageStatus', 'success');
        }
        catch (error) {
            const name = error instanceof Error ? error.name : 'unknown';
            this.publish('qryInicioPessoaError', { code: 'client.unexpected', message: '', details: { name } });
            this.publish('qryInicioPessoaStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** Opens meu_cadastro carrying the id of the person's record (entry param pessoaOrganizacaoId); refuses with client.preconditionMissing when the record is not loaded */
    openMeuCadastro() {
        const id = this.meuAcesso ? this.meuAcesso.id : null;
        if (id === null || id === '') {
            this.publish('qryInicioPessoaError', {
                code: 'client.preconditionMissing',
                message: '',
                details: { params: ['pessoaOrganizacaoId'] },
            });
            return;
        }
        auraNavigate(`/inicio/meu_cadastro?pessoaOrganizacaoId=${encodeURIComponent(id)}`, { basePath: '/inicio' });
    }
    /** navigate (organism resumoMeuAcesso) — opens the person's own registration page (meu_cadastro) with the id of the loaded person record; takes no argument */
    abrirMeuCadastroResumo() {
        this.openMeuCadastro();
    }
    /** navigate (organism pendenciasMeuAcesso) — opens meu_cadastro so the person completes the missing minimum data (pending item completarDadosMinimos); takes no argument */
    completarDadosMinimos() {
        this.openMeuCadastro();
    }
    /** navigate (organism pendenciasMeuAcesso) — opens meu_cadastro to forward the access release request to the responsible (pending item pedirLiberacao); takes no argument */
    encaminharPedidoLiberacao() {
        this.openMeuCadastro();
    }
}
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "meuAcesso", void 0);
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "pendencias", void 0);
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "empresa", void 0);
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "qryInicioPessoaStatus", void 0);
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "qryInicioPessoaError", void 0);
__decorate([
    property({ attribute: false })
], InicioInicio_pessoaShared.prototype, "scenary", void 0);

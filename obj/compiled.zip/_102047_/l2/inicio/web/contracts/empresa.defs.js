/// <mls fileReference="_102047_/l2/inicio/web/contracts/empresa.defs.ts" enhancement="_blank"/>
export {};

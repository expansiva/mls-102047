export const moveToHiredRoute = "hiringPipeline.managed_positions.cmdMoveToHired";
export const listApplicationRoute = "hiringPipeline.managed_positions.qryListApplication";
export const listJobPositionRoute = "hiringPipeline.managed_positions.qryListJobPosition";

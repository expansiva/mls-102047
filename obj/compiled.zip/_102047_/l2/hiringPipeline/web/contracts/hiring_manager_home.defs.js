export const listJobPositionRoute = "hiringPipeline.hiring_manager_home.qryListJobPosition";

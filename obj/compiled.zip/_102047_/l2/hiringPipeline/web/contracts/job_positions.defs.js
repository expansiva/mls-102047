export const createApplicationRoute = "hiringPipeline.job_positions.cmdCreateApplication";
export const createJobPositionRoute = "hiringPipeline.job_positions.cmdCreateJobPosition";
export const rejectApplicationRoute = "hiringPipeline.job_positions.cmdRejectApplication";
export const listApplicationRoute = "hiringPipeline.job_positions.qryListApplication";
export const listCandidateRoute = "hiringPipeline.job_positions.qryListCandidate";
export const listJobPositionRoute = "hiringPipeline.job_positions.qryListJobPosition";

export const moveToHiredRoute = "hiringPipeline.managed_applications.cmdMoveToHired";
export const moveToOfferRoute = "hiringPipeline.managed_applications.cmdMoveToOffer";
export const listApplicationRoute = "hiringPipeline.managed_applications.qryListApplication";
export const listCandidateRoute = "hiringPipeline.managed_applications.qryListCandidate";
export const listJobPositionRoute = "hiringPipeline.managed_applications.qryListJobPosition";

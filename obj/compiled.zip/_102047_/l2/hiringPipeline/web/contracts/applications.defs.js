export const createApplicationRoute = "hiringPipeline.applications.cmdCreateApplication";
export const moveToInterviewRoute = "hiringPipeline.applications.cmdMoveToInterview";
export const rejectApplicationRoute = "hiringPipeline.applications.cmdRejectApplication";
export const listApplicationRoute = "hiringPipeline.applications.qryListApplication";
export const listCandidateRoute = "hiringPipeline.applications.qryListCandidate";
export const listJobPositionRoute = "hiringPipeline.applications.qryListJobPosition";

export const listJobPositionRoute = "hiringPipeline.recruiter_home.qryListJobPosition";

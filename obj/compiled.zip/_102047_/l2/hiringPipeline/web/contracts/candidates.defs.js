export const createApplicationRoute = "hiringPipeline.candidates.cmdCreateApplication";
export const createCandidateRoute = "hiringPipeline.candidates.cmdCreateCandidate";
export const moveToInterviewRoute = "hiringPipeline.candidates.cmdMoveToInterview";
export const listApplicationRoute = "hiringPipeline.candidates.qryListApplication";
export const listCandidateRoute = "hiringPipeline.candidates.qryListCandidate";
export const listJobPositionRoute = "hiringPipeline.candidates.qryListJobPosition";

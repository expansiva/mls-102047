/// <mls fileReference="_102047_/l2/hiringPipeline/web/contracts/candidates.defs.ts" enhancement="_blank"/>
export {};

/// <mls fileReference="_102047_/l2/hiringPipeline/web/mobile/page11/my_applications.defs.ts" enhancement="_blank"/>
export const definition = {
    "template": {
        "category": "_102020_/l4/collabux/templates/approvalWorkflow/page21.md",
        "experience": "readAndDecide"
    },
    "intent": "On a narrow screen, find an application on my positions and decide it. The review comes first and the decision stays close below it, in a single fluid column of about 390px that also works at 360px and 430px.",
    "sections": [
        {
            "id": "findSection",
            "priority": "main",
            "purpose": "Search and filter my applications by stage. Each one appears as a compact entry showing the candidate, position, stage and days in stage.",
            "organisms": [
                "applicationList"
            ]
        },
        {
            "id": "reviewSection",
            "priority": "primary",
            "purpose": "Read the candidate and the application in short stacked blocks. The remaining openings stay visible before deciding.",
            "organisms": [
                "applicationReview"
            ]
        },
        {
            "id": "decisionSection",
            "priority": "primary",
            "purpose": "Extend the offer, hire, or send the application back with a reason, using full-width actions under the review.",
            "organisms": [
                "applicationDecision"
            ]
        },
        {
            "id": "historySection",
            "priority": "secondary",
            "purpose": "Check the stage history and who made each decision when needed.",
            "organisms": [
                "stageHistory"
            ]
        }
    ],
    "organisms": {
        "applicationList": {
            "kind": "list",
            "text": "Applications to the positions I manage. Each shows its number, candidate, position, stage and days in the current stage, and can be searched or filtered by stage.",
            "intents": []
        },
        "applicationReview": {
            "kind": "detail",
            "text": "The candidate and the application: name, contact, resume link and source, when they applied, when they moved to interview, the offer and its notes, and the position's remaining openings, so I can decide with the headcount in view.",
            "intents": [
                {
                    "id": "openMyPositions",
                    "kind": "navigate",
                    "to": "my_positions"
                }
            ]
        },
        "applicationDecision": {
            "kind": "actions",
            "text": "Only the decisions allowed at the current stage: extend an offer with offer notes, hire the candidate when an opening remains, or send the application back to the recruiter with a rejection reason.",
            "intents": [
                {
                    "id": "extendOffer",
                    "kind": "submit"
                },
                {
                    "id": "hireCandidate",
                    "kind": "submit"
                },
                {
                    "id": "sendBackToReject",
                    "kind": "submit"
                }
            ]
        },
        "stageHistory": {
            "kind": "timeline",
            "text": "The application's stage history: when it was applied, moved to interview and by whom, when the offer was extended and the hire was decided and by whom, and when and at which stage it was rejected.",
            "intents": []
        }
    },
    "molecules": {
        "applicationList": [
            {
                "role": "Search by application number, candidate or position",
                "preferred": "groupsearchcontent--ml-search-bar"
            },
            {
                "role": "Filter by stage",
                "preferred": "groupselectone--ml-select",
                "alternative": "groupselectone--ml-segmented-control"
            },
            {
                "role": "Applications with stage and days in stage",
                "preferred": "groupviewdata--ml-vertical-record-list",
                "alternative": "groupviewtable--ml-responsive-data-table"
            }
        ],
        "applicationReview": [
            {
                "role": "Candidate summary with resume link and source",
                "preferred": "groupviewcard--ml-profile-card",
                "alternative": "groupviewcard--ml-vertical-card"
            },
            {
                "role": "Remaining openings of the position",
                "preferred": "groupviewmetric--ml-metric-big-number",
                "alternative": "groupviewmetric--ml-metric-card"
            },
            {
                "role": "Interview and offer details",
                "preferred": "groupexpandcontent--ml-accordion",
                "alternative": "groupexpandcontent--ml-collapsible-panel"
            }
        ],
        "applicationDecision": [
            {
                "role": "Decision buttons for offer, hire or send back",
                "preferred": "grouptriggeraction--ml-button-standard",
                "alternative": "grouptriggeraction--ml-button-group"
            },
            {
                "role": "Offer notes or rejection reason",
                "preferred": "groupentertext--ml-multiline-text"
            },
            {
                "role": "Confirm the decision before it is recorded",
                "preferred": "groupnotifyuser--ml-alert-modal"
            },
            {
                "role": "Result of the decision",
                "preferred": "groupnotifyuser--ml-toast-notification"
            }
        ],
        "stageHistory": [
            {
                "role": "Stage changes over time",
                "preferred": "groupviewdata--ml-timeline-view",
                "alternative": "groupviewdata--ml-vertical-record-list"
            }
        ]
    }
};

/// <mls fileReference="_102047_/l2/financeiro/web/contracts/recebimentos.defs.ts" enhancement="_blank"/>
export {};

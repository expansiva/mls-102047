/// <mls fileReference="_102047_/l2/financeiro/web/contracts/painel_recebiveis.defs.ts" enhancement="_blank"/>
export {};

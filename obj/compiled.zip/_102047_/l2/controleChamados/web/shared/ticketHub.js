/// <mls fileReference="_102047_/l2/controleChamados/web/shared/ticketHub.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { qryListTicketRoute, qryListTicketCommentRoute, } from '/_102047_/l2/controleChamados/web/contracts/ticketHub.js';
const SUBSCRIBED_STATE_KEYS = [
    'ui.ticketHub.status',
    'ui.ticketHub.scenary',
    'ui.ticketHub.action.qryListTicket.status',
    'ui.ticketHub.input.qryListTicket.search',
    'ui.ticketHub.input.qryListTicket.sortBy',
    'ui.ticketHub.input.qryListTicket.sortOrder',
    'ui.ticketHub.data.qryListTicket',
    'ui.ticketHub.action.qryListTicketComment.status',
    'ui.ticketHub.data.qryListTicketComment',
];
export class ControleChamadosTicketHubBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state ui.ticketHub.scenary — uiScenary, values: base */
        this.uiScenary = 'base';
        /** state qryListTicketState — actionStatus, values: idle|loading|success|error */
        this.qryListTicketState = 'idle';
        /** state qryListTicketSearch — input */
        this.qryListTicketSearch = '';
        /** state qryListTicketSortBy — input, values: open|closed */
        this.qryListTicketSortBy = '';
        /** state qryListTicketSortOrder — input, values: asc|desc */
        this.qryListTicketSortOrder = '';
        /** state qryListTicketData — queryResult, outputShape: array */
        this.qryListTicketData = [];
        /** state qryListTicketCommentState — actionStatus, values: idle|loading|success|error */
        this.qryListTicketCommentState = 'idle';
        /** state qryListTicketCommentData — queryResult, outputShape: array */
        this.qryListTicketCommentData = [];
    }
    /** lifecycle — initialize shared state, subscriptions and initial query loads */
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.ticketHub.status', '');
        this.initStateValue('ui.ticketHub.scenary', 'base');
        this.initStateValue('ui.ticketHub.action.qryListTicket.status', 'idle');
        this.initStateValue('ui.ticketHub.input.qryListTicket.search', '');
        this.initStateValue('ui.ticketHub.input.qryListTicket.sortBy', '');
        this.initStateValue('ui.ticketHub.input.qryListTicket.sortOrder', '');
        this.initStateValue('ui.ticketHub.data.qryListTicket', []);
        this.initStateValue('ui.ticketHub.action.qryListTicketComment.status', 'idle');
        this.initStateValue('ui.ticketHub.data.qryListTicketComment', []);
        this.applyUrlScenary();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListTicket();
        void this.loadQryListTicketComment();
    }
    /** lifecycle — remove shared-state subscriptions */
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.ticketHub.status':
                this.status = value ?? '';
                break;
            case 'ui.ticketHub.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.ticketHub.action.qryListTicket.status':
                this.qryListTicketState = value ?? 'idle';
                break;
            case 'ui.ticketHub.input.qryListTicket.search':
                this.qryListTicketSearch = value ?? '';
                break;
            case 'ui.ticketHub.input.qryListTicket.sortBy':
                this.qryListTicketSortBy = value ?? '';
                break;
            case 'ui.ticketHub.input.qryListTicket.sortOrder':
                this.qryListTicketSortOrder = value ?? '';
                break;
            case 'ui.ticketHub.data.qryListTicket':
                this.qryListTicketData = value ?? [];
                break;
            case 'ui.ticketHub.action.qryListTicketComment.status':
                this.qryListTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketHub.data.qryListTicketComment':
                this.qryListTicketCommentData = value ?? [];
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.ticketHub.status':
                this.status = value ?? '';
                break;
            case 'ui.ticketHub.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.ticketHub.action.qryListTicket.status':
                this.qryListTicketState = value ?? 'idle';
                break;
            case 'ui.ticketHub.input.qryListTicket.search':
                this.qryListTicketSearch = value ?? '';
                break;
            case 'ui.ticketHub.input.qryListTicket.sortBy':
                this.qryListTicketSortBy = value ?? '';
                break;
            case 'ui.ticketHub.input.qryListTicket.sortOrder':
                this.qryListTicketSortOrder = value ?? '';
                break;
            case 'ui.ticketHub.data.qryListTicket':
                this.qryListTicketData = value ?? [];
                break;
            case 'ui.ticketHub.action.qryListTicketComment.status':
                this.qryListTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketHub.data.qryListTicketComment':
                this.qryListTicketCommentData = value ?? [];
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    /** setter for state ui.ticketHub.scenary */
    setUiScenary(value) {
        const allowed = ['base'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        this.uiScenary = next;
        setState('ui.ticketHub.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
    /** action qryListTicket (query) — route controleChamados.ticketHub.qryListTicket; inputs: search, sortBy, sortOrder; writes ui.ticketHub.data.qryListTicket; status ui.ticketHub.action.qryListTicket.status */
    async loadQryListTicket() {
        this.qryListTicketState = 'loading';
        setState('ui.ticketHub.action.qryListTicket.status', 'loading');
        const params = {};
        if (this.qryListTicketSearch)
            params.search = this.qryListTicketSearch;
        if (this.qryListTicketSortBy)
            params.sortBy = this.qryListTicketSortBy;
        if (this.qryListTicketSortOrder)
            params.sortOrder = this.qryListTicketSortOrder;
        const options = { mode: 'silent' };
        const response = await execBff(qryListTicketRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListTicketData = data;
            setState('ui.ticketHub.data.qryListTicket', data);
            this.qryListTicketState = 'success';
            setState('ui.ticketHub.action.qryListTicket.status', 'success');
        }
        else {
            this.qryListTicketState = 'error';
            setState('ui.ticketHub.action.qryListTicket.status', 'error');
            if (response.error)
                console.error('qryListTicket failed', response.error);
        }
        this.requestUpdate();
    }
    /** handler for action qryListTicket — bind UI events here */
    handleQryListTicketClick(event) {
        if (event)
            event.preventDefault();
        void this.loadQryListTicket();
    }
    /** action qryListTicketComment (query) — route controleChamados.ticketHub.qryListTicketComment; inputs: none; writes ui.ticketHub.data.qryListTicketComment; status ui.ticketHub.action.qryListTicketComment.status */
    async loadQryListTicketComment() {
        this.qryListTicketCommentState = 'loading';
        setState('ui.ticketHub.action.qryListTicketComment.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryListTicketCommentRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListTicketCommentData = data;
            setState('ui.ticketHub.data.qryListTicketComment', data);
            this.qryListTicketCommentState = 'success';
            setState('ui.ticketHub.action.qryListTicketComment.status', 'success');
        }
        else {
            this.qryListTicketCommentState = 'error';
            setState('ui.ticketHub.action.qryListTicketComment.status', 'error');
            if (response.error)
                console.error('qryListTicketComment failed', response.error);
        }
        this.requestUpdate();
    }
    /** handler for action qryListTicketComment — bind UI events here */
    handleQryListTicketCommentClick(event) {
        if (event)
            event.preventDefault();
        void this.loadQryListTicketComment();
    }
    /** setter for state ui.ticketHub.input.qryListTicket.search */
    setQryListTicketSearch(value) {
        this.qryListTicketSearch = value;
        setState('ui.ticketHub.input.qryListTicket.search', value);
        this.requestUpdate();
    }
    /** handler for action set.qryListTicketSearch — bind UI events here */
    handleQryListTicketSearchChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryListTicketSearch(value);
    }
    /** setter for state ui.ticketHub.input.qryListTicket.sortBy */
    setQryListTicketSortBy(value) {
        this.qryListTicketSortBy = value;
        setState('ui.ticketHub.input.qryListTicket.sortBy', value);
        this.requestUpdate();
    }
    /** handler for action set.qryListTicketSortBy — bind UI events here */
    handleQryListTicketSortByChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryListTicketSortBy(value);
    }
    /** setter for state ui.ticketHub.input.qryListTicket.sortOrder */
    setQryListTicketSortOrder(value) {
        this.qryListTicketSortOrder = value;
        setState('ui.ticketHub.input.qryListTicket.sortOrder', value);
        this.requestUpdate();
    }
    /** handler for action set.qryListTicketSortOrder — bind UI events here */
    handleQryListTicketSortOrderChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryListTicketSortOrder(value);
    }
}
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "status", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "uiScenary", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketSearch", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketSortBy", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketSortOrder", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketData", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketCommentState", void 0);
__decorate([
    property()
], ControleChamadosTicketHubBase.prototype, "qryListTicketCommentData", void 0);

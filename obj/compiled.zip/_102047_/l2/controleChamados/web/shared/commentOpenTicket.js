/// <mls fileReference="_102047_/l2/controleChamados/web/shared/commentOpenTicket.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryLocateTicketRoute, cmdRecordCommentRoute, } from '/_102047_/l2/controleChamados/web/contracts/commentOpenTicket.js';
const SUBSCRIBED_STATE_KEYS = [
    'ui.commentOpenTicket.status',
    'ui.commentOpenTicket.scenary',
    'ui.commentOpenTicket.action.qryLocateTicket.status',
    'ui.commentOpenTicket.data.qryLocateTicket',
    'ui.commentOpenTicket.action.cmdRecordComment.status',
    'ui.commentOpenTicket.input.cmdRecordComment.ticketId',
    'ui.commentOpenTicket.input.cmdRecordComment.commentText',
    'ui.commentOpenTicket.output.cmdRecordComment',
    'ui.commentOpenTicket.action.cmdRecordComment.error',
];
export class ControleChamadosCommentOpenTicketBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state ui.commentOpenTicket.scenary — uiScenary, values: base|recordComment */
        this.uiScenary = 'base';
        /** state qryLocateTicketState — actionStatus, values: idle|loading|success|error */
        this.qryLocateTicketState = 'idle';
        /** state qryLocateTicketData — queryResult, outputShape: array */
        this.qryLocateTicketData = [];
        /** state cmdRecordCommentState — actionStatus, values: idle|loading|success|error */
        this.cmdRecordCommentState = 'idle';
        /** state cmdRecordCommentTicketId — input */
        this.cmdRecordCommentTicketId = '';
        /** state cmdRecordCommentCommentText — input */
        this.cmdRecordCommentCommentText = '';
        /** state cmdRecordCommentOutput — commandOutput */
        this.cmdRecordCommentOutput = null;
        /** state cmdRecordCommentError — actionError */
        this.cmdRecordCommentError = '';
    }
    /** Lifecycle connection for state initialization and initial data loading. */
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.commentOpenTicket.status', '');
        this.initStateValue('ui.commentOpenTicket.scenary', 'base');
        this.initStateValue('ui.commentOpenTicket.action.qryLocateTicket.status', 'idle');
        this.initStateValue('ui.commentOpenTicket.data.qryLocateTicket', []);
        this.initStateValue('ui.commentOpenTicket.action.cmdRecordComment.status', 'idle');
        this.initStateValue('ui.commentOpenTicket.input.cmdRecordComment.ticketId', '');
        this.initStateValue('ui.commentOpenTicket.input.cmdRecordComment.commentText', '');
        this.initStateValue('ui.commentOpenTicket.output.cmdRecordComment', null);
        this.initStateValue('ui.commentOpenTicket.action.cmdRecordComment.error', '');
        this.syncRouteParams();
        this.applyUrlScenary();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryLocateTicket();
    }
    /** Lifecycle disconnection for removing shared-state subscriptions. */
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.commentOpenTicket.status':
                this.status = value ?? '';
                break;
            case 'ui.commentOpenTicket.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.commentOpenTicket.action.qryLocateTicket.status':
                this.qryLocateTicketState = value ?? 'idle';
                break;
            case 'ui.commentOpenTicket.data.qryLocateTicket':
                this.qryLocateTicketData = value ?? [];
                break;
            case 'ui.commentOpenTicket.action.cmdRecordComment.status':
                this.cmdRecordCommentState = value ?? 'idle';
                break;
            case 'ui.commentOpenTicket.input.cmdRecordComment.ticketId':
                this.cmdRecordCommentTicketId = value ?? '';
                break;
            case 'ui.commentOpenTicket.input.cmdRecordComment.commentText':
                this.cmdRecordCommentCommentText = value ?? '';
                break;
            case 'ui.commentOpenTicket.output.cmdRecordComment':
                this.cmdRecordCommentOutput = value ?? null;
                break;
            case 'ui.commentOpenTicket.action.cmdRecordComment.error':
                this.cmdRecordCommentError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.commentOpenTicket.status':
                this.status = value ?? '';
                break;
            case 'ui.commentOpenTicket.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.commentOpenTicket.action.qryLocateTicket.status':
                this.qryLocateTicketState = value ?? 'idle';
                break;
            case 'ui.commentOpenTicket.data.qryLocateTicket':
                this.qryLocateTicketData = value ?? [];
                break;
            case 'ui.commentOpenTicket.action.cmdRecordComment.status':
                this.cmdRecordCommentState = value ?? 'idle';
                break;
            case 'ui.commentOpenTicket.input.cmdRecordComment.ticketId':
                this.cmdRecordCommentTicketId = value ?? '';
                break;
            case 'ui.commentOpenTicket.input.cmdRecordComment.commentText':
                this.cmdRecordCommentCommentText = value ?? '';
                break;
            case 'ui.commentOpenTicket.output.cmdRecordComment':
                this.cmdRecordCommentOutput = value ?? null;
                break;
            case 'ui.commentOpenTicket.action.cmdRecordComment.error':
                this.cmdRecordCommentError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/controleChamados\/commentOpenTicket(?:\/([^/]+))?\/?$/);
        const rawTicketId = match && match[1] ? match[1] : '';
        let ticketId = '';
        if (rawTicketId) {
            try {
                ticketId = decodeURIComponent(rawTicketId);
            }
            catch {
                ticketId = rawTicketId;
            }
        }
        if (ticketId) {
            if (!this.cmdRecordCommentTicketId) {
                this.cmdRecordCommentTicketId = ticketId;
                setState('ui.commentOpenTicket.input.cmdRecordComment.ticketId', ticketId);
            }
        }
    }
    /** setter for state ui.commentOpenTicket.scenary */
    setUiScenary(value) {
        const allowed = ['base', 'recordComment'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        if (value === 'recordComment' && (!this.cmdRecordCommentTicketId))
            next = 'base';
        this.uiScenary = next;
        setState('ui.commentOpenTicket.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const rawTicketId = params.get('ticketId') || '';
        if (rawTicketId) {
            if (!this.cmdRecordCommentTicketId) {
                this.cmdRecordCommentTicketId = rawTicketId;
                setState('ui.commentOpenTicket.input.cmdRecordComment.ticketId', rawTicketId);
            }
        }
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryLocateTicket (query) — route controleChamados.commentOpenTicket.qryLocateTicket; inputs none; writes ui.commentOpenTicket.data.qryLocateTicket; status ui.commentOpenTicket.action.qryLocateTicket.status */
    async loadQryLocateTicket() {
        this.syncRouteParams();
        this.qryLocateTicketState = 'loading';
        setState('ui.commentOpenTicket.action.qryLocateTicket.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryLocateTicketRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryLocateTicketData = data;
            setState('ui.commentOpenTicket.data.qryLocateTicket', data);
            this.qryLocateTicketState = 'success';
            setState('ui.commentOpenTicket.action.qryLocateTicket.status', 'success');
        }
        else {
            this.qryLocateTicketState = 'error';
            setState('ui.commentOpenTicket.action.qryLocateTicket.status', 'error');
            if (response.error) {
                console.error('qryLocateTicket failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryLocateTicket — bind UI events here */
    handleQryLocateTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryLocateTicket();
    }
    /** action cmdRecordComment (command) — route controleChamados.commentOpenTicket.cmdRecordComment; inputs ticketId, commentText; writes ui.commentOpenTicket.output.cmdRecordComment; status ui.commentOpenTicket.action.cmdRecordComment.status; feedback keys action.cmdRecordComment.success / action.cmdRecordComment.error */
    async cmdRecordComment() {
        this.syncRouteParams();
        if (!this.cmdRecordCommentTicketId) {
            this.cmdRecordCommentState = 'idle';
            setState('ui.commentOpenTicket.action.cmdRecordComment.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdRecordCommentState = 'loading';
        setState('ui.commentOpenTicket.action.cmdRecordComment.status', 'loading');
        this.cmdRecordCommentError = '';
        setState('ui.commentOpenTicket.action.cmdRecordComment.error', '');
        const params = {
            ticketId: this.cmdRecordCommentTicketId,
            commentText: this.cmdRecordCommentCommentText,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdRecordCommentRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdRecordComment.error');
            this.cmdRecordCommentError = errMsg;
            setState('ui.commentOpenTicket.action.cmdRecordComment.error', errMsg);
            this.cmdRecordCommentState = 'error';
            setState('ui.commentOpenTicket.action.cmdRecordComment.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdRecordCommentOutput = data;
        setState('ui.commentOpenTicket.output.cmdRecordComment', data);
        try {
            await this.loadQryLocateTicket();
            if (this.qryLocateTicketState === 'error') {
                this.cmdRecordCommentState = 'error';
                setState('ui.commentOpenTicket.action.cmdRecordComment.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdRecordComment refresh failed', refreshError);
            this.cmdRecordCommentState = 'error';
            setState('ui.commentOpenTicket.action.cmdRecordComment.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdRecordCommentCommentText = '';
        setState('ui.commentOpenTicket.input.cmdRecordComment.commentText', '');
        this.setUiScenary('base');
        this.cmdRecordCommentState = 'success';
        setState('ui.commentOpenTicket.action.cmdRecordComment.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdRecordComment — bind UI events here */
    handleCmdRecordCommentClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdRecordComment();
        });
    }
    /** setter for state ui.commentOpenTicket.input.cmdRecordComment.ticketId */
    setCmdRecordCommentTicketId(value) {
        this.cmdRecordCommentTicketId = value;
        setState('ui.commentOpenTicket.input.cmdRecordComment.ticketId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdRecordCommentTicketId — bind UI events here */
    handleCmdRecordCommentTicketIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdRecordCommentTicketId(value);
    }
    /** setter for state ui.commentOpenTicket.input.cmdRecordComment.commentText */
    setCmdRecordCommentCommentText(value) {
        this.cmdRecordCommentCommentText = value;
        setState('ui.commentOpenTicket.input.cmdRecordComment.commentText', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdRecordCommentCommentText — bind UI events here */
    handleCmdRecordCommentCommentTextChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdRecordCommentCommentText(value);
    }
}
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "status", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "uiScenary", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "qryLocateTicketState", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "qryLocateTicketData", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "cmdRecordCommentState", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "cmdRecordCommentTicketId", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "cmdRecordCommentCommentText", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "cmdRecordCommentOutput", void 0);
__decorate([
    property()
], ControleChamadosCommentOpenTicketBase.prototype, "cmdRecordCommentError", void 0);

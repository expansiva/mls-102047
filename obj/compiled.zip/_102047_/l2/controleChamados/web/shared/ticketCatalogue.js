/// <mls fileReference="_102047_/l2/controleChamados/web/shared/ticketCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListTicketRoute, cmdCreateTicketRoute, cmdUpdateTicketRoute, cmdDeleteTicketRoute, qryGetTicketRoute, qryLocateTicketRoute, cmdDecideClosureRoute, } from '/_102047_/l2/controleChamados/web/contracts/ticketCatalogue.js';
const SUBSCRIBED_STATE_KEYS = [
    'ui.ticketCatalogue.status',
    'ui.ticketCatalogue.scenary',
    'ui.ticketCatalogue.action.qryListTicket.status',
    'ui.ticketCatalogue.input.qryListTicket.search',
    'ui.ticketCatalogue.input.qryListTicket.sortBy',
    'ui.ticketCatalogue.input.qryListTicket.sortOrder',
    'ui.ticketCatalogue.data.qryListTicket',
    'ui.ticketCatalogue.action.cmdCreateTicket.status',
    'ui.ticketCatalogue.input.cmdCreateTicket.title',
    'ui.ticketCatalogue.input.cmdCreateTicket.description',
    'ui.ticketCatalogue.input.cmdCreateTicket.status',
    'ui.ticketCatalogue.output.cmdCreateTicket',
    'ui.ticketCatalogue.action.cmdCreateTicket.error',
    'ui.ticketCatalogue.action.cmdUpdateTicket.status',
    'ui.ticketCatalogue.input.cmdUpdateTicket.ticketId',
    'ui.ticketCatalogue.input.cmdUpdateTicket.title',
    'ui.ticketCatalogue.input.cmdUpdateTicket.description',
    'ui.ticketCatalogue.input.cmdUpdateTicket.status',
    'ui.ticketCatalogue.output.cmdUpdateTicket',
    'ui.ticketCatalogue.action.cmdUpdateTicket.error',
    'ui.ticketCatalogue.action.cmdDeleteTicket.status',
    'ui.ticketCatalogue.input.cmdDeleteTicket.ticketId',
    'ui.ticketCatalogue.output.cmdDeleteTicket',
    'ui.ticketCatalogue.action.cmdDeleteTicket.error',
    'ui.ticketCatalogue.action.qryGetTicket.status',
    'ui.ticketCatalogue.input.qryGetTicket.ticketId',
    'ui.ticketCatalogue.data.qryGetTicket',
    'ui.ticketCatalogue.action.qryLocateTicket.status',
    'ui.ticketCatalogue.data.qryLocateTicket',
    'ui.ticketCatalogue.action.cmdDecideClosure.status',
    'ui.ticketCatalogue.input.cmdDecideClosure.ticketId',
    'ui.ticketCatalogue.input.cmdDecideClosure.status',
    'ui.ticketCatalogue.output.cmdDecideClosure',
    'ui.ticketCatalogue.action.cmdDecideClosure.error',
];
export class ControleChamadosTicketCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */
        this.status = '';
        /** state ui.ticketCatalogue.scenary — values: base|detail|createTicket|updateTicket|decideClosure */
        this.uiScenary = 'base';
        /** state qryListTicketState — actionStatus, values: idle|loading|success|error */
        this.qryListTicketState = 'idle';
        /** state qryListTicketSearch — input */
        this.qryListTicketSearch = '';
        /** state qryListTicketSortBy — input, values: open|closed */
        this.qryListTicketSortBy = '';
        /** state qryListTicketSortOrder — input, values: asc|desc */
        this.qryListTicketSortOrder = '';
        /** state qryListTicketData — queryResult, outputShape: array */
        this.qryListTicketData = [];
        /** state cmdCreateTicketState — actionStatus, values: idle|loading|success|error */
        this.cmdCreateTicketState = 'idle';
        /** state cmdCreateTicketTitle — input */
        this.cmdCreateTicketTitle = '';
        /** state cmdCreateTicketDescription — input */
        this.cmdCreateTicketDescription = '';
        /** state cmdCreateTicketStatus — input, values: open|closed */
        this.cmdCreateTicketStatus = '';
        /** state cmdCreateTicketOutput — commandOutput */
        this.cmdCreateTicketOutput = null;
        /** state cmdCreateTicketError — actionError */
        this.cmdCreateTicketError = '';
        /** state cmdUpdateTicketState — actionStatus, values: idle|loading|success|error */
        this.cmdUpdateTicketState = 'idle';
        /** state cmdUpdateTicketTicketId — input */
        this.cmdUpdateTicketTicketId = '';
        /** state cmdUpdateTicketTitle — input */
        this.cmdUpdateTicketTitle = '';
        /** state cmdUpdateTicketDescription — input */
        this.cmdUpdateTicketDescription = '';
        /** state cmdUpdateTicketStatus — input, values: open|closed */
        this.cmdUpdateTicketStatus = '';
        /** state cmdUpdateTicketOutput — commandOutput */
        this.cmdUpdateTicketOutput = null;
        /** state cmdUpdateTicketError — actionError */
        this.cmdUpdateTicketError = '';
        /** state cmdDeleteTicketState — actionStatus, values: idle|loading|success|error */
        this.cmdDeleteTicketState = 'idle';
        /** state cmdDeleteTicketTicketId — input */
        this.cmdDeleteTicketTicketId = '';
        /** state cmdDeleteTicketOutput — commandOutput */
        this.cmdDeleteTicketOutput = null;
        /** state cmdDeleteTicketError — actionError */
        this.cmdDeleteTicketError = '';
        /** state qryGetTicketState — actionStatus, values: idle|loading|success|error */
        this.qryGetTicketState = 'idle';
        /** state qryGetTicketTicketId — input */
        this.qryGetTicketTicketId = '';
        /** state qryGetTicketData — queryResult, outputShape: object */
        this.qryGetTicketData = null;
        /** state qryLocateTicketState — actionStatus, values: idle|loading|success|error */
        this.qryLocateTicketState = 'idle';
        /** state qryLocateTicketData — queryResult, outputShape: array */
        this.qryLocateTicketData = [];
        /** state cmdDecideClosureState — actionStatus, values: idle|loading|success|error */
        this.cmdDecideClosureState = 'idle';
        /** state cmdDecideClosureTicketId — input */
        this.cmdDecideClosureTicketId = '';
        /** state cmdDecideClosureStatus — input, values: open|closed */
        this.cmdDecideClosureStatus = '';
        /** state cmdDecideClosureOutput — commandOutput */
        this.cmdDecideClosureOutput = null;
        /** state cmdDecideClosureError — actionError */
        this.cmdDecideClosureError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateValue('ui.ticketCatalogue.status', '');
        this.initStateValue('ui.ticketCatalogue.scenary', 'base');
        this.initStateValue('ui.ticketCatalogue.action.qryListTicket.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.input.qryListTicket.search', '');
        this.initStateValue('ui.ticketCatalogue.input.qryListTicket.sortBy', '');
        this.initStateValue('ui.ticketCatalogue.input.qryListTicket.sortOrder', '');
        this.initStateValue('ui.ticketCatalogue.data.qryListTicket', []);
        this.initStateValue('ui.ticketCatalogue.action.cmdCreateTicket.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.input.cmdCreateTicket.title', '');
        this.initStateValue('ui.ticketCatalogue.input.cmdCreateTicket.description', '');
        this.initStateValue('ui.ticketCatalogue.input.cmdCreateTicket.status', '');
        this.initStateValue('ui.ticketCatalogue.output.cmdCreateTicket', null);
        this.initStateValue('ui.ticketCatalogue.action.cmdCreateTicket.error', '');
        this.initStateValue('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.input.cmdUpdateTicket.ticketId', '');
        this.initStateValue('ui.ticketCatalogue.input.cmdUpdateTicket.title', '');
        this.initStateValue('ui.ticketCatalogue.input.cmdUpdateTicket.description', '');
        this.initStateValue('ui.ticketCatalogue.input.cmdUpdateTicket.status', '');
        this.initStateValue('ui.ticketCatalogue.output.cmdUpdateTicket', null);
        this.initStateValue('ui.ticketCatalogue.action.cmdUpdateTicket.error', '');
        this.initStateValue('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.input.cmdDeleteTicket.ticketId', '');
        this.initStateValue('ui.ticketCatalogue.output.cmdDeleteTicket', null);
        this.initStateValue('ui.ticketCatalogue.action.cmdDeleteTicket.error', '');
        this.initStateValue('ui.ticketCatalogue.action.qryGetTicket.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.input.qryGetTicket.ticketId', '');
        this.initStateValue('ui.ticketCatalogue.data.qryGetTicket', null);
        this.initStateValue('ui.ticketCatalogue.action.qryLocateTicket.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.data.qryLocateTicket', []);
        this.initStateValue('ui.ticketCatalogue.action.cmdDecideClosure.status', 'idle');
        this.initStateValue('ui.ticketCatalogue.input.cmdDecideClosure.ticketId', '');
        this.initStateValue('ui.ticketCatalogue.input.cmdDecideClosure.status', '');
        this.initStateValue('ui.ticketCatalogue.output.cmdDecideClosure', null);
        this.initStateValue('ui.ticketCatalogue.action.cmdDecideClosure.error', '');
        this.syncRouteParams();
        this.applyUrlScenary();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListTicket();
        void this.loadQryLocateTicket();
    }
    disconnectedCallback() {
        unsubscribe(SUBSCRIBED_STATE_KEYS, this);
        super.disconnectedCallback();
    }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.ticketCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.ticketCatalogue.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.ticketCatalogue.action.qryListTicket.status':
                this.qryListTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.qryListTicket.search':
                this.qryListTicketSearch = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.qryListTicket.sortBy':
                this.qryListTicketSortBy = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.qryListTicket.sortOrder':
                this.qryListTicketSortOrder = value ?? '';
                break;
            case 'ui.ticketCatalogue.data.qryListTicket':
                this.qryListTicketData = value ?? [];
                break;
            case 'ui.ticketCatalogue.action.cmdCreateTicket.status':
                this.cmdCreateTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdCreateTicket.title':
                this.cmdCreateTicketTitle = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdCreateTicket.description':
                this.cmdCreateTicketDescription = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdCreateTicket.status':
                this.cmdCreateTicketStatus = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdCreateTicket':
                this.cmdCreateTicketOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdCreateTicket.error':
                this.cmdCreateTicketError = value ?? '';
                break;
            case 'ui.ticketCatalogue.action.cmdUpdateTicket.status':
                this.cmdUpdateTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.ticketId':
                this.cmdUpdateTicketTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.title':
                this.cmdUpdateTicketTitle = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.description':
                this.cmdUpdateTicketDescription = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.status':
                this.cmdUpdateTicketStatus = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdUpdateTicket':
                this.cmdUpdateTicketOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdUpdateTicket.error':
                this.cmdUpdateTicketError = value ?? '';
                break;
            case 'ui.ticketCatalogue.action.cmdDeleteTicket.status':
                this.cmdDeleteTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdDeleteTicket.ticketId':
                this.cmdDeleteTicketTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdDeleteTicket':
                this.cmdDeleteTicketOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdDeleteTicket.error':
                this.cmdDeleteTicketError = value ?? '';
                break;
            case 'ui.ticketCatalogue.action.qryGetTicket.status':
                this.qryGetTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.qryGetTicket.ticketId':
                this.qryGetTicketTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.data.qryGetTicket':
                this.qryGetTicketData = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.qryLocateTicket.status':
                this.qryLocateTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.data.qryLocateTicket':
                this.qryLocateTicketData = value ?? [];
                break;
            case 'ui.ticketCatalogue.action.cmdDecideClosure.status':
                this.cmdDecideClosureState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdDecideClosure.ticketId':
                this.cmdDecideClosureTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdDecideClosure.status':
                this.cmdDecideClosureStatus = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdDecideClosure':
                this.cmdDecideClosureOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdDecideClosure.error':
                this.cmdDecideClosureError = value ?? '';
                break;
            default:
                break;
        }
        this.requestUpdate();
    }
    initStateValue(stateKey, defaultValue) {
        const existing = getState(stateKey);
        const value = existing !== undefined ? existing : defaultValue;
        switch (stateKey) {
            case 'ui.ticketCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.ticketCatalogue.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.ticketCatalogue.action.qryListTicket.status':
                this.qryListTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.qryListTicket.search':
                this.qryListTicketSearch = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.qryListTicket.sortBy':
                this.qryListTicketSortBy = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.qryListTicket.sortOrder':
                this.qryListTicketSortOrder = value ?? '';
                break;
            case 'ui.ticketCatalogue.data.qryListTicket':
                this.qryListTicketData = value ?? [];
                break;
            case 'ui.ticketCatalogue.action.cmdCreateTicket.status':
                this.cmdCreateTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdCreateTicket.title':
                this.cmdCreateTicketTitle = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdCreateTicket.description':
                this.cmdCreateTicketDescription = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdCreateTicket.status':
                this.cmdCreateTicketStatus = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdCreateTicket':
                this.cmdCreateTicketOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdCreateTicket.error':
                this.cmdCreateTicketError = value ?? '';
                break;
            case 'ui.ticketCatalogue.action.cmdUpdateTicket.status':
                this.cmdUpdateTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.ticketId':
                this.cmdUpdateTicketTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.title':
                this.cmdUpdateTicketTitle = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.description':
                this.cmdUpdateTicketDescription = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdUpdateTicket.status':
                this.cmdUpdateTicketStatus = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdUpdateTicket':
                this.cmdUpdateTicketOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdUpdateTicket.error':
                this.cmdUpdateTicketError = value ?? '';
                break;
            case 'ui.ticketCatalogue.action.cmdDeleteTicket.status':
                this.cmdDeleteTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdDeleteTicket.ticketId':
                this.cmdDeleteTicketTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdDeleteTicket':
                this.cmdDeleteTicketOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdDeleteTicket.error':
                this.cmdDeleteTicketError = value ?? '';
                break;
            case 'ui.ticketCatalogue.action.qryGetTicket.status':
                this.qryGetTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.qryGetTicket.ticketId':
                this.qryGetTicketTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.data.qryGetTicket':
                this.qryGetTicketData = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.qryLocateTicket.status':
                this.qryLocateTicketState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.data.qryLocateTicket':
                this.qryLocateTicketData = value ?? [];
                break;
            case 'ui.ticketCatalogue.action.cmdDecideClosure.status':
                this.cmdDecideClosureState = value ?? 'idle';
                break;
            case 'ui.ticketCatalogue.input.cmdDecideClosure.ticketId':
                this.cmdDecideClosureTicketId = value ?? '';
                break;
            case 'ui.ticketCatalogue.input.cmdDecideClosure.status':
                this.cmdDecideClosureStatus = value ?? '';
                break;
            case 'ui.ticketCatalogue.output.cmdDecideClosure':
                this.cmdDecideClosureOutput = value ?? null;
                break;
            case 'ui.ticketCatalogue.action.cmdDecideClosure.error':
                this.cmdDecideClosureError = value ?? '';
                break;
            default:
                break;
        }
        if (existing === undefined) {
            setState(stateKey, value);
        }
    }
    syncRouteParams() {
        const pathname = window.location.pathname;
        const match = pathname.match(/^\/controleChamados\/ticketCatalogue(?:\/([^/]+))?\/?$/);
        const rawTicketId = match && match[1] ? match[1] : '';
        let ticketId = '';
        if (rawTicketId) {
            try {
                ticketId = decodeURIComponent(rawTicketId);
            }
            catch {
                ticketId = rawTicketId;
            }
        }
        if (ticketId) {
            if (!this.cmdDecideClosureTicketId) {
                this.cmdDecideClosureTicketId = ticketId;
                setState('ui.ticketCatalogue.input.cmdDecideClosure.ticketId', ticketId);
            }
        }
    }
    /** setter for state ui.ticketCatalogue.scenary */
    setUiScenary(value) {
        const allowed = ['base', 'detail', 'createTicket', 'updateTicket', 'decideClosure'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        if (value === 'detail' && (!this.qryGetTicketTicketId))
            next = 'base';
        if (value === 'updateTicket' && (!this.cmdUpdateTicketTicketId))
            next = 'base';
        if (value === 'decideClosure' && (!this.cmdDecideClosureTicketId))
            next = 'base';
        this.uiScenary = next;
        setState('ui.ticketCatalogue.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const rawTicketId = params.get('ticketId') || '';
        if (rawTicketId) {
            if (!this.qryGetTicketTicketId) {
                this.qryGetTicketTicketId = rawTicketId;
                setState('ui.ticketCatalogue.input.qryGetTicket.ticketId', rawTicketId);
            }
            if (!this.cmdUpdateTicketTicketId) {
                this.cmdUpdateTicketTicketId = rawTicketId;
                setState('ui.ticketCatalogue.input.cmdUpdateTicket.ticketId', rawTicketId);
            }
            if (!this.cmdDecideClosureTicketId) {
                this.cmdDecideClosureTicketId = rawTicketId;
                setState('ui.ticketCatalogue.input.cmdDecideClosure.ticketId', rawTicketId);
            }
        }
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
    readErrorMessage(error, fallback) {
        if (error && typeof error === 'object') {
            const record = error;
            if (typeof record.message === 'string' && record.message) {
                return record.message;
            }
            if (typeof record.error === 'string' && record.error) {
                return record.error;
            }
        }
        return fallback;
    }
    /** action qryListTicket (query) "Listar Chamado" — route controleChamados.ticketCatalogue.qryListTicket; inputs: search, sortBy, sortOrder; writes ui.ticketCatalogue.data.qryListTicket; status ui.ticketCatalogue.action.qryListTicket.status */
    async loadQryListTicket() {
        this.syncRouteParams();
        this.qryListTicketState = 'loading';
        setState('ui.ticketCatalogue.action.qryListTicket.status', 'loading');
        const params = {};
        if (this.qryListTicketSearch) {
            params.search = this.qryListTicketSearch;
        }
        if (this.qryListTicketSortBy) {
            params.sortBy = this.qryListTicketSortBy;
        }
        if (this.qryListTicketSortOrder) {
            params.sortOrder = this.qryListTicketSortOrder;
        }
        const options = { mode: 'silent' };
        const response = await execBff(qryListTicketRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryListTicketData = data;
            setState('ui.ticketCatalogue.data.qryListTicket', data);
            this.qryListTicketState = 'success';
            setState('ui.ticketCatalogue.action.qryListTicket.status', 'success');
        }
        else {
            this.qryListTicketState = 'error';
            setState('ui.ticketCatalogue.action.qryListTicket.status', 'error');
            if (response.error) {
                console.error('qryListTicket failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryListTicket "Listar Chamado" — bind UI events here */
    handleQryListTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryListTicket();
    }
    /** action cmdCreateTicket (command) "Criar Chamado" — route controleChamados.ticketCatalogue.cmdCreateTicket; inputs: title, description, status; writes ui.ticketCatalogue.output.cmdCreateTicket; status ui.ticketCatalogue.action.cmdCreateTicket.status; feedback keys action.cmdCreateTicket.success / action.cmdCreateTicket.error */
    async cmdCreateTicket() {
        this.syncRouteParams();
        this.cmdCreateTicketState = 'loading';
        setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'loading');
        this.cmdCreateTicketError = '';
        setState('ui.ticketCatalogue.action.cmdCreateTicket.error', '');
        const params = {
            title: this.cmdCreateTicketTitle,
            description: this.cmdCreateTicketDescription,
            status: this.cmdCreateTicketStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdCreateTicketRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdCreateTicket.error');
            this.cmdCreateTicketError = errMsg;
            setState('ui.ticketCatalogue.action.cmdCreateTicket.error', errMsg);
            this.cmdCreateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdCreateTicketOutput = data;
        setState('ui.ticketCatalogue.output.cmdCreateTicket', data);
        try {
            await this.loadQryListTicket();
            if (this.qryListTicketState === 'error') {
                this.cmdCreateTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateTicket refresh failed', refreshError);
            this.cmdCreateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryGetTicket();
            if (this.qryGetTicketState === 'error') {
                this.cmdCreateTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateTicket refresh failed', refreshError);
            this.cmdCreateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryLocateTicket();
            if (this.qryLocateTicketState === 'error') {
                this.cmdCreateTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdCreateTicket refresh failed', refreshError);
            this.cmdCreateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdCreateTicketTitle = '';
        setState('ui.ticketCatalogue.input.cmdCreateTicket.title', '');
        this.cmdCreateTicketDescription = '';
        setState('ui.ticketCatalogue.input.cmdCreateTicket.description', '');
        this.cmdCreateTicketStatus = '';
        setState('ui.ticketCatalogue.input.cmdCreateTicket.status', '');
        this.setUiScenary('base');
        this.cmdCreateTicketState = 'success';
        setState('ui.ticketCatalogue.action.cmdCreateTicket.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdCreateTicket "Criar Chamado" — bind UI events here */
    handleCmdCreateTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdCreateTicket();
        });
    }
    /** action cmdUpdateTicket (command) "Atualizar Chamado" — route controleChamados.ticketCatalogue.cmdUpdateTicket; inputs: ticketId, title, description, status; writes ui.ticketCatalogue.output.cmdUpdateTicket; status ui.ticketCatalogue.action.cmdUpdateTicket.status; feedback keys action.cmdUpdateTicket.success / action.cmdUpdateTicket.error */
    async cmdUpdateTicket() {
        this.syncRouteParams();
        if (!this.cmdUpdateTicketTicketId) {
            this.cmdUpdateTicketState = 'idle';
            setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateTicketState = 'loading';
        setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'loading');
        this.cmdUpdateTicketError = '';
        setState('ui.ticketCatalogue.action.cmdUpdateTicket.error', '');
        const params = {
            ticketId: this.cmdUpdateTicketTicketId,
            title: this.cmdUpdateTicketTitle,
            description: this.cmdUpdateTicketDescription,
            status: this.cmdUpdateTicketStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdUpdateTicketRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdUpdateTicket.error');
            this.cmdUpdateTicketError = errMsg;
            setState('ui.ticketCatalogue.action.cmdUpdateTicket.error', errMsg);
            this.cmdUpdateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdUpdateTicketOutput = data;
        setState('ui.ticketCatalogue.output.cmdUpdateTicket', data);
        try {
            await this.loadQryListTicket();
            if (this.qryListTicketState === 'error') {
                this.cmdUpdateTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateTicket refresh failed', refreshError);
            this.cmdUpdateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryGetTicket();
            if (this.qryGetTicketState === 'error') {
                this.cmdUpdateTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateTicket refresh failed', refreshError);
            this.cmdUpdateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryLocateTicket();
            if (this.qryLocateTicketState === 'error') {
                this.cmdUpdateTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdUpdateTicket refresh failed', refreshError);
            this.cmdUpdateTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdUpdateTicketTicketId = '';
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.ticketId', '');
        this.cmdUpdateTicketTitle = '';
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.title', '');
        this.cmdUpdateTicketDescription = '';
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.description', '');
        this.cmdUpdateTicketStatus = '';
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.status', '');
        this.setUiScenary('base');
        this.cmdUpdateTicketState = 'success';
        setState('ui.ticketCatalogue.action.cmdUpdateTicket.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdUpdateTicket "Atualizar Chamado" — bind UI events here */
    handleCmdUpdateTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdUpdateTicket();
        });
    }
    /** action cmdDeleteTicket (command) "Excluir Chamado" — route controleChamados.ticketCatalogue.cmdDeleteTicket; inputs: ticketId; writes ui.ticketCatalogue.output.cmdDeleteTicket; status ui.ticketCatalogue.action.cmdDeleteTicket.status; feedback keys action.cmdDeleteTicket.success / action.cmdDeleteTicket.error */
    async cmdDeleteTicket() {
        this.syncRouteParams();
        if (!this.cmdDeleteTicketTicketId) {
            this.cmdDeleteTicketState = 'idle';
            setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteTicketState = 'loading';
        setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'loading');
        this.cmdDeleteTicketError = '';
        setState('ui.ticketCatalogue.action.cmdDeleteTicket.error', '');
        const params = {
            ticketId: this.cmdDeleteTicketTicketId,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDeleteTicketRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDeleteTicket.error');
            this.cmdDeleteTicketError = errMsg;
            setState('ui.ticketCatalogue.action.cmdDeleteTicket.error', errMsg);
            this.cmdDeleteTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDeleteTicketOutput = data;
        setState('ui.ticketCatalogue.output.cmdDeleteTicket', data);
        try {
            await this.loadQryListTicket();
            if (this.qryListTicketState === 'error') {
                this.cmdDeleteTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteTicket refresh failed', refreshError);
            this.cmdDeleteTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryGetTicket();
            if (this.qryGetTicketState === 'error') {
                this.cmdDeleteTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteTicket refresh failed', refreshError);
            this.cmdDeleteTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryLocateTicket();
            if (this.qryLocateTicketState === 'error') {
                this.cmdDeleteTicketState = 'error';
                setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDeleteTicket refresh failed', refreshError);
            this.cmdDeleteTicketState = 'error';
            setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDeleteTicketTicketId = '';
        setState('ui.ticketCatalogue.input.cmdDeleteTicket.ticketId', '');
        this.setUiScenary('base');
        this.cmdDeleteTicketState = 'success';
        setState('ui.ticketCatalogue.action.cmdDeleteTicket.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDeleteTicket "Excluir Chamado" — bind UI events here */
    handleCmdDeleteTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDeleteTicket();
        });
    }
    /** action qryGetTicket (query) "Obter Chamado" — route controleChamados.ticketCatalogue.qryGetTicket; inputs: ticketId; writes ui.ticketCatalogue.data.qryGetTicket; status ui.ticketCatalogue.action.qryGetTicket.status */
    async loadQryGetTicket() {
        this.syncRouteParams();
        if (!this.qryGetTicketTicketId) {
            this.qryGetTicketState = 'idle';
            setState('ui.ticketCatalogue.action.qryGetTicket.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.qryGetTicketState = 'loading';
        setState('ui.ticketCatalogue.action.qryGetTicket.status', 'loading');
        const params = {
            ticketId: this.qryGetTicketTicketId,
        };
        const options = { mode: 'silent' };
        const response = await execBff(qryGetTicketRoute, params, options);
        if (response.ok) {
            const data = response.data ?? null;
            this.qryGetTicketData = data;
            setState('ui.ticketCatalogue.data.qryGetTicket', data);
            this.qryGetTicketState = 'success';
            setState('ui.ticketCatalogue.action.qryGetTicket.status', 'success');
        }
        else {
            this.qryGetTicketState = 'error';
            setState('ui.ticketCatalogue.action.qryGetTicket.status', 'error');
            if (response.error) {
                console.error('qryGetTicket failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryGetTicket "Obter Chamado" — bind UI events here */
    handleQryGetTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryGetTicket();
    }
    /** action qryLocateTicket (query) "Localizar o chamado aberto" — route controleChamados.ticketCatalogue.qryLocateTicket; inputs: (none); writes ui.ticketCatalogue.data.qryLocateTicket; status ui.ticketCatalogue.action.qryLocateTicket.status */
    async loadQryLocateTicket() {
        this.syncRouteParams();
        this.qryLocateTicketState = 'loading';
        setState('ui.ticketCatalogue.action.qryLocateTicket.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff(qryLocateTicketRoute, params, options);
        if (response.ok) {
            const data = response.data ?? [];
            this.qryLocateTicketData = data;
            setState('ui.ticketCatalogue.data.qryLocateTicket', data);
            this.qryLocateTicketState = 'success';
            setState('ui.ticketCatalogue.action.qryLocateTicket.status', 'success');
        }
        else {
            this.qryLocateTicketState = 'error';
            setState('ui.ticketCatalogue.action.qryLocateTicket.status', 'error');
            if (response.error) {
                console.error('qryLocateTicket failed', response.error);
            }
        }
        this.requestUpdate();
    }
    /** handler for action qryLocateTicket "Localizar o chamado aberto" — bind UI events here */
    handleQryLocateTicketClick(event) {
        if (event) {
            event.preventDefault();
        }
        void this.loadQryLocateTicket();
    }
    /** action cmdDecideClosure (command) "Confirmar o fechamento do chamado" — route controleChamados.ticketCatalogue.cmdDecideClosure; inputs: ticketId, status; writes ui.ticketCatalogue.output.cmdDecideClosure; status ui.ticketCatalogue.action.cmdDecideClosure.status; feedback keys action.cmdDecideClosure.success / action.cmdDecideClosure.error */
    async cmdDecideClosure() {
        this.syncRouteParams();
        if (!this.cmdDecideClosureTicketId) {
            this.cmdDecideClosureState = 'idle';
            setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'idle');
            this.requestUpdate();
            return;
        }
        this.cmdDecideClosureState = 'loading';
        setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'loading');
        this.cmdDecideClosureError = '';
        setState('ui.ticketCatalogue.action.cmdDecideClosure.error', '');
        const params = {
            ticketId: this.cmdDecideClosureTicketId,
            status: this.cmdDecideClosureStatus,
        };
        const options = { mode: 'blocking' };
        const response = await execBff(cmdDecideClosureRoute, params, options);
        if (!response.ok) {
            const errMsg = this.readErrorMessage(response.error, 'action.cmdDecideClosure.error');
            this.cmdDecideClosureError = errMsg;
            setState('ui.ticketCatalogue.action.cmdDecideClosure.error', errMsg);
            this.cmdDecideClosureState = 'error';
            setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
            this.requestUpdate();
            return;
        }
        const data = response.data ?? null;
        this.cmdDecideClosureOutput = data;
        setState('ui.ticketCatalogue.output.cmdDecideClosure', data);
        try {
            await this.loadQryListTicket();
            if (this.qryListTicketState === 'error') {
                this.cmdDecideClosureState = 'error';
                setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDecideClosure refresh failed', refreshError);
            this.cmdDecideClosureState = 'error';
            setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryGetTicket();
            if (this.qryGetTicketState === 'error') {
                this.cmdDecideClosureState = 'error';
                setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDecideClosure refresh failed', refreshError);
            this.cmdDecideClosureState = 'error';
            setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
            this.requestUpdate();
            return;
        }
        try {
            await this.loadQryLocateTicket();
            if (this.qryLocateTicketState === 'error') {
                this.cmdDecideClosureState = 'error';
                setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
                this.requestUpdate();
                return;
            }
        }
        catch (refreshError) {
            console.error('cmdDecideClosure refresh failed', refreshError);
            this.cmdDecideClosureState = 'error';
            setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'error');
            this.requestUpdate();
            return;
        }
        this.cmdDecideClosureStatus = '';
        setState('ui.ticketCatalogue.input.cmdDecideClosure.status', '');
        this.setUiScenary('base');
        this.cmdDecideClosureState = 'success';
        setState('ui.ticketCatalogue.action.cmdDecideClosure.status', 'success');
        this.requestUpdate();
    }
    /** handler for action cmdDecideClosure "Confirmar o fechamento do chamado" — bind UI events here */
    handleCmdDecideClosureClick(event) {
        if (event) {
            event.preventDefault();
        }
        void runBlockingUiAction(async (_signal) => {
            await this.cmdDecideClosure();
        });
    }
    /** setter for state ui.ticketCatalogue.input.qryListTicket.search */
    setQryListTicketSearch(value) {
        this.qryListTicketSearch = value;
        setState('ui.ticketCatalogue.input.qryListTicket.search', value);
        this.requestUpdate();
    }
    /** handler for action set.qryListTicketSearch — bind UI events here */
    handleQryListTicketSearchChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryListTicketSearch(value);
    }
    /** setter for state ui.ticketCatalogue.input.qryListTicket.sortBy */
    setQryListTicketSortBy(value) {
        this.qryListTicketSortBy = value;
        setState('ui.ticketCatalogue.input.qryListTicket.sortBy', value);
        this.requestUpdate();
    }
    /** handler for action set.qryListTicketSortBy — bind UI events here */
    handleQryListTicketSortByChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryListTicketSortBy(value);
    }
    /** setter for state ui.ticketCatalogue.input.qryListTicket.sortOrder */
    setQryListTicketSortOrder(value) {
        this.qryListTicketSortOrder = value;
        setState('ui.ticketCatalogue.input.qryListTicket.sortOrder', value);
        this.requestUpdate();
    }
    /** handler for action set.qryListTicketSortOrder — bind UI events here */
    handleQryListTicketSortOrderChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryListTicketSortOrder(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdCreateTicket.title */
    setCmdCreateTicketTitle(value) {
        this.cmdCreateTicketTitle = value;
        setState('ui.ticketCatalogue.input.cmdCreateTicket.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTicketTitle — bind UI events here */
    handleCmdCreateTicketTitleChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTicketTitle(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdCreateTicket.description */
    setCmdCreateTicketDescription(value) {
        this.cmdCreateTicketDescription = value;
        setState('ui.ticketCatalogue.input.cmdCreateTicket.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTicketDescription — bind UI events here */
    handleCmdCreateTicketDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTicketDescription(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdCreateTicket.status */
    setCmdCreateTicketStatus(value) {
        this.cmdCreateTicketStatus = value;
        setState('ui.ticketCatalogue.input.cmdCreateTicket.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdCreateTicketStatus — bind UI events here */
    handleCmdCreateTicketStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdCreateTicketStatus(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.ticketId */
    setCmdUpdateTicketTicketId(value) {
        this.cmdUpdateTicketTicketId = value;
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.ticketId', value);
        const collection = getState('ui.ticketCatalogue.data.qryListTicket') ?? this.qryListTicketData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.ticketId) === String(value));
            if (item) {
                this.cmdUpdateTicketTitle = item.title;
                setState('ui.ticketCatalogue.input.cmdUpdateTicket.title', item.title);
                this.cmdUpdateTicketDescription = item.description;
                setState('ui.ticketCatalogue.input.cmdUpdateTicket.description', item.description);
                this.cmdUpdateTicketStatus = String(item.status);
                setState('ui.ticketCatalogue.input.cmdUpdateTicket.status', String(item.status));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTicketTicketId — bind UI events here */
    handleCmdUpdateTicketTicketIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTicketTicketId(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.title */
    setCmdUpdateTicketTitle(value) {
        this.cmdUpdateTicketTitle = value;
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.title', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTicketTitle — bind UI events here */
    handleCmdUpdateTicketTitleChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTicketTitle(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.description */
    setCmdUpdateTicketDescription(value) {
        this.cmdUpdateTicketDescription = value;
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.description', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTicketDescription — bind UI events here */
    handleCmdUpdateTicketDescriptionChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTicketDescription(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.status */
    setCmdUpdateTicketStatus(value) {
        this.cmdUpdateTicketStatus = value;
        setState('ui.ticketCatalogue.input.cmdUpdateTicket.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdUpdateTicketStatus — bind UI events here */
    handleCmdUpdateTicketStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdUpdateTicketStatus(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdDeleteTicket.ticketId */
    setCmdDeleteTicketTicketId(value) {
        this.cmdDeleteTicketTicketId = value;
        setState('ui.ticketCatalogue.input.cmdDeleteTicket.ticketId', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDeleteTicketTicketId — bind UI events here */
    handleCmdDeleteTicketTicketIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDeleteTicketTicketId(value);
    }
    /** setter for state ui.ticketCatalogue.input.qryGetTicket.ticketId */
    setQryGetTicketTicketId(value) {
        this.qryGetTicketTicketId = value;
        setState('ui.ticketCatalogue.input.qryGetTicket.ticketId', value);
        if (value)
            this.setUiScenary('detail');
        this.requestUpdate();
    }
    /** handler for action set.qryGetTicketTicketId — bind UI events here */
    handleQryGetTicketTicketIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setQryGetTicketTicketId(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdDecideClosure.ticketId */
    setCmdDecideClosureTicketId(value) {
        this.cmdDecideClosureTicketId = value;
        setState('ui.ticketCatalogue.input.cmdDecideClosure.ticketId', value);
        const collection = getState('ui.ticketCatalogue.data.qryListTicket') ?? this.qryListTicketData;
        if (Array.isArray(collection) && collection.length > 0) {
            const item = collection.find((row) => String(row.ticketId) === String(value));
            if (item) {
                this.cmdDecideClosureStatus = String(item.status);
                setState('ui.ticketCatalogue.input.cmdDecideClosure.status', String(item.status));
            }
        }
        this.requestUpdate();
    }
    /** handler for action set.cmdDecideClosureTicketId — bind UI events here */
    handleCmdDecideClosureTicketIdChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDecideClosureTicketId(value);
    }
    /** setter for state ui.ticketCatalogue.input.cmdDecideClosure.status */
    setCmdDecideClosureStatus(value) {
        this.cmdDecideClosureStatus = value;
        setState('ui.ticketCatalogue.input.cmdDecideClosure.status', value);
        this.requestUpdate();
    }
    /** handler for action set.cmdDecideClosureStatus — bind UI events here */
    handleCmdDecideClosureStatusChange(event) {
        const target = event.target;
        const value = target && 'value' in target ? String(target.value) : '';
        this.setCmdDecideClosureStatus(value);
    }
}
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "uiScenary", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryListTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryListTicketSearch", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryListTicketSortBy", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryListTicketSortOrder", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryListTicketData", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdCreateTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdCreateTicketTitle", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdCreateTicketDescription", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdCreateTicketStatus", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdCreateTicketOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdCreateTicketError", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketTicketId", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketTitle", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketDescription", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketStatus", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdUpdateTicketError", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDeleteTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDeleteTicketTicketId", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDeleteTicketOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDeleteTicketError", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryGetTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryGetTicketTicketId", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryGetTicketData", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryLocateTicketState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "qryLocateTicketData", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDecideClosureState", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDecideClosureTicketId", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDecideClosureStatus", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDecideClosureOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCatalogueBase.prototype, "cmdDecideClosureError", void 0);

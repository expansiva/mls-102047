/// <mls fileReference="_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { qryListTicketCommentRoute, cmdCreateTicketCommentRoute, cmdUpdateTicketCommentRoute, cmdDeleteTicketCommentRoute, qryGetTicketCommentRoute, qryTicketPickerRoute } from '/_102047_/l2/controleChamados/web/contracts/ticketCommentCatalogue.js';
const SUBSCRIBED_STATE_KEYS = [
    'ui.ticketCommentCatalogue.status', 'ui.ticketCommentCatalogue.scenary', 'ui.ticketCommentCatalogue.action.qryListTicketComment.status', 'ui.ticketCommentCatalogue.data.qryListTicketComment', 'ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId', 'ui.ticketCommentCatalogue.input.cmdCreateTicketComment.commentText', 'ui.ticketCommentCatalogue.output.cmdCreateTicketComment', 'ui.ticketCommentCatalogue.action.cmdCreateTicketComment.error', 'ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId', 'ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId', 'ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.commentText', 'ui.ticketCommentCatalogue.output.cmdUpdateTicketComment', 'ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.error', 'ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'ui.ticketCommentCatalogue.input.cmdDeleteTicketComment.ticketCommentId', 'ui.ticketCommentCatalogue.output.cmdDeleteTicketComment', 'ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.error', 'ui.ticketCommentCatalogue.action.qryGetTicketComment.status', 'ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId', 'ui.ticketCommentCatalogue.data.qryGetTicketComment', 'ui.ticketCommentCatalogue.action.qryTicketPicker.status', 'ui.ticketCommentCatalogue.input.qryTicketPicker.search', 'ui.ticketCommentCatalogue.input.qryTicketPicker.sortBy', 'ui.ticketCommentCatalogue.input.qryTicketPicker.sortOrder', 'ui.ticketCommentCatalogue.data.qryTicketPicker'
];
export class ControleChamadosTicketCommentCatalogueBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        /** state status — pageStatus */ this.status = '';
        /** state ui.ticketCommentCatalogue.scenary — uiScenary, values: base|detail|createTicketComment|updateTicketComment */ this.uiScenary = 'base';
        /** state qryListTicketCommentState — actionStatus, values: idle|loading|success|error */ this.qryListTicketCommentState = 'idle';
        /** state qryListTicketCommentData — queryResult, outputShape: array */ this.qryListTicketCommentData = [];
        /** state cmdCreateTicketCommentState — actionStatus, values: idle|loading|success|error */ this.cmdCreateTicketCommentState = 'idle';
        /** state cmdCreateTicketCommentTicketId — input */ this.cmdCreateTicketCommentTicketId = '';
        /** state cmdCreateTicketCommentCommentText — input */ this.cmdCreateTicketCommentCommentText = '';
        /** state cmdCreateTicketCommentOutput — commandOutput */ this.cmdCreateTicketCommentOutput = null;
        /** state cmdCreateTicketCommentError — actionError */ this.cmdCreateTicketCommentError = '';
        /** state cmdUpdateTicketCommentState — actionStatus, values: idle|loading|success|error */ this.cmdUpdateTicketCommentState = 'idle';
        /** state cmdUpdateTicketCommentTicketCommentId — input */ this.cmdUpdateTicketCommentTicketCommentId = '';
        /** state cmdUpdateTicketCommentTicketId — input */ this.cmdUpdateTicketCommentTicketId = '';
        /** state cmdUpdateTicketCommentCommentText — input */ this.cmdUpdateTicketCommentCommentText = '';
        /** state cmdUpdateTicketCommentOutput — commandOutput */ this.cmdUpdateTicketCommentOutput = null;
        /** state cmdUpdateTicketCommentError — actionError */ this.cmdUpdateTicketCommentError = '';
        /** state cmdDeleteTicketCommentState — actionStatus, values: idle|loading|success|error */ this.cmdDeleteTicketCommentState = 'idle';
        /** state cmdDeleteTicketCommentTicketCommentId — input */ this.cmdDeleteTicketCommentTicketCommentId = '';
        /** state cmdDeleteTicketCommentOutput — commandOutput */ this.cmdDeleteTicketCommentOutput = null;
        /** state cmdDeleteTicketCommentError — actionError */ this.cmdDeleteTicketCommentError = '';
        /** state qryGetTicketCommentState — actionStatus, values: idle|loading|success|error */ this.qryGetTicketCommentState = 'idle';
        /** state qryGetTicketCommentTicketCommentId — input */ this.qryGetTicketCommentTicketCommentId = '';
        /** state qryGetTicketCommentData — queryResult, outputShape: object */ this.qryGetTicketCommentData = null;
        /** state qryTicketPickerState — actionStatus, values: idle|loading|success|error */ this.qryTicketPickerState = 'idle';
        /** state qryTicketPickerSearch — input */ this.qryTicketPickerSearch = '';
        /** state qryTicketPickerSortBy — input, values: open|closed */ this.qryTicketPickerSortBy = '';
        /** state qryTicketPickerSortOrder — input, values: asc|desc */ this.qryTicketPickerSortOrder = '';
        /** state qryTicketPickerData — queryResult, outputShape: array */ this.qryTicketPickerData = [];
    }
    connectedCallback() {
        super.connectedCallback();
        const defaults = [['ui.ticketCommentCatalogue.status', ''], ['ui.ticketCommentCatalogue.scenary', 'base'], ['ui.ticketCommentCatalogue.action.qryListTicketComment.status', 'idle'], ['ui.ticketCommentCatalogue.data.qryListTicketComment', []], ['ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'idle'], ['ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId', ''], ['ui.ticketCommentCatalogue.input.cmdCreateTicketComment.commentText', ''], ['ui.ticketCommentCatalogue.output.cmdCreateTicketComment', null], ['ui.ticketCommentCatalogue.action.cmdCreateTicketComment.error', ''], ['ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'idle'], ['ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId', ''], ['ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId', ''], ['ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.commentText', ''], ['ui.ticketCommentCatalogue.output.cmdUpdateTicketComment', null], ['ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.error', ''], ['ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'idle'], ['ui.ticketCommentCatalogue.input.cmdDeleteTicketComment.ticketCommentId', ''], ['ui.ticketCommentCatalogue.output.cmdDeleteTicketComment', null], ['ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.error', ''], ['ui.ticketCommentCatalogue.action.qryGetTicketComment.status', 'idle'], ['ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId', ''], ['ui.ticketCommentCatalogue.data.qryGetTicketComment', null], ['ui.ticketCommentCatalogue.action.qryTicketPicker.status', 'idle'], ['ui.ticketCommentCatalogue.input.qryTicketPicker.search', ''], ['ui.ticketCommentCatalogue.input.qryTicketPicker.sortBy', ''], ['ui.ticketCommentCatalogue.input.qryTicketPicker.sortOrder', ''], ['ui.ticketCommentCatalogue.data.qryTicketPicker', []]];
        defaults.forEach(([key, value]) => this.initStateValue(key, value));
        this.applyUrlScenary();
        subscribe(SUBSCRIBED_STATE_KEYS, this);
        void this.loadQryListTicketComment();
        void this.loadQryTicketPicker();
    }
    disconnectedCallback() { unsubscribe(SUBSCRIBED_STATE_KEYS, this); super.disconnectedCallback(); }
    /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
    handleIcaStateChange(key, value) { this.assignState(key, value); this.requestUpdate(); }
    initStateValue(key, defaultValue) { const value = getState(key) ?? defaultValue; this.assignState(key, value); if (getState(key) === undefined)
        setState(key, value); }
    assignState(key, value) {
        switch (key) {
            case 'ui.ticketCommentCatalogue.status':
                this.status = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.scenary':
                this.uiScenary = value ?? 'base';
                break;
            case 'ui.ticketCommentCatalogue.action.qryListTicketComment.status':
                this.qryListTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketCommentCatalogue.data.qryListTicketComment':
                this.qryListTicketCommentData = value ?? [];
                break;
            case 'ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status':
                this.cmdCreateTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId':
                this.cmdCreateTicketCommentTicketId = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.input.cmdCreateTicketComment.commentText':
                this.cmdCreateTicketCommentCommentText = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.output.cmdCreateTicketComment':
                this.cmdCreateTicketCommentOutput = value ?? null;
                break;
            case 'ui.ticketCommentCatalogue.action.cmdCreateTicketComment.error':
                this.cmdCreateTicketCommentError = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status':
                this.cmdUpdateTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId':
                this.cmdUpdateTicketCommentTicketCommentId = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId':
                this.cmdUpdateTicketCommentTicketId = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.commentText':
                this.cmdUpdateTicketCommentCommentText = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.output.cmdUpdateTicketComment':
                this.cmdUpdateTicketCommentOutput = value ?? null;
                break;
            case 'ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.error':
                this.cmdUpdateTicketCommentError = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status':
                this.cmdDeleteTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketCommentCatalogue.input.cmdDeleteTicketComment.ticketCommentId':
                this.cmdDeleteTicketCommentTicketCommentId = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.output.cmdDeleteTicketComment':
                this.cmdDeleteTicketCommentOutput = value ?? null;
                break;
            case 'ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.error':
                this.cmdDeleteTicketCommentError = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.action.qryGetTicketComment.status':
                this.qryGetTicketCommentState = value ?? 'idle';
                break;
            case 'ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId':
                this.qryGetTicketCommentTicketCommentId = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.data.qryGetTicketComment':
                this.qryGetTicketCommentData = value ?? null;
                break;
            case 'ui.ticketCommentCatalogue.action.qryTicketPicker.status':
                this.qryTicketPickerState = value ?? 'idle';
                break;
            case 'ui.ticketCommentCatalogue.input.qryTicketPicker.search':
                this.qryTicketPickerSearch = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.input.qryTicketPicker.sortBy':
                this.qryTicketPickerSortBy = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.input.qryTicketPicker.sortOrder':
                this.qryTicketPickerSortOrder = value ?? '';
                break;
            case 'ui.ticketCommentCatalogue.data.qryTicketPicker':
                this.qryTicketPickerData = value ?? [];
                break;
        }
    }
    /** setter for state ui.ticketCommentCatalogue.scenary */
    setUiScenary(value) {
        const allowed = ['base', 'detail', 'createTicketComment', 'updateTicketComment'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        if (value === 'detail' && (!this.qryGetTicketCommentTicketCommentId))
            next = 'base';
        if (value === 'createTicketComment' && (!this.cmdCreateTicketCommentTicketId))
            next = 'base';
        if (value === 'updateTicketComment' && (!this.cmdUpdateTicketCommentTicketCommentId || !this.cmdUpdateTicketCommentTicketId))
            next = 'base';
        this.uiScenary = next;
        setState('ui.ticketCommentCatalogue.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const rawTicketCommentId = params.get('ticketCommentId') || '';
        if (rawTicketCommentId) {
            if (!this.qryGetTicketCommentTicketCommentId) {
                this.qryGetTicketCommentTicketCommentId = rawTicketCommentId;
                setState('ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId', rawTicketCommentId);
            }
            if (!this.cmdUpdateTicketCommentTicketCommentId) {
                this.cmdUpdateTicketCommentTicketCommentId = rawTicketCommentId;
                setState('ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId', rawTicketCommentId);
            }
        }
        const rawTicketId = params.get('ticketId') || '';
        if (rawTicketId) {
            if (!this.cmdCreateTicketCommentTicketId) {
                this.cmdCreateTicketCommentTicketId = rawTicketId;
                setState('ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId', rawTicketId);
            }
            if (!this.cmdUpdateTicketCommentTicketId) {
                this.cmdUpdateTicketCommentTicketId = rawTicketId;
                setState('ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId', rawTicketId);
            }
        }
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
    readErrorMessage(error, fallback) { if (error && typeof error === 'object' && 'message' in error) {
        const message = error.message;
        if (typeof message === 'string' && message)
            return message;
    } return fallback; }
    setStatus(key, status) { setState(key, status); this.assignState(key, status); }
    async refresh(action) { if (action === 'qryListTicketComment') {
        await this.loadQryListTicketComment();
        return this.qryListTicketCommentState !== 'error';
    } if (action === 'qryGetTicketComment') {
        await this.loadQryGetTicketComment();
        return this.qryGetTicketCommentState !== 'error';
    } await this.loadQryTicketPicker(); return this.qryTicketPickerState !== 'error'; }
    /** action qryListTicketComment (query) — route controleChamados.ticketCommentCatalogue.qryListTicketComment; inputs none; writes ui.ticketCommentCatalogue.data.qryListTicketComment; status ui.ticketCommentCatalogue.action.qryListTicketComment.status */
    async loadQryListTicketComment() { this.setStatus('ui.ticketCommentCatalogue.action.qryListTicketComment.status', 'loading'); const params = {}; const options = { mode: 'silent' }; const response = await execBff(qryListTicketCommentRoute, params, options); if (response.ok) {
        const data = response.data ?? [];
        this.qryListTicketCommentData = data;
        setState('ui.ticketCommentCatalogue.data.qryListTicketComment', data);
        this.setStatus('ui.ticketCommentCatalogue.action.qryListTicketComment.status', 'success');
    }
    else {
        this.setStatus('ui.ticketCommentCatalogue.action.qryListTicketComment.status', 'error');
        if (response.error)
            console.error('qryListTicketComment failed', response.error);
    } this.requestUpdate(); }
    /** handler for action qryListTicketComment — bind UI events here */
    handleQryListTicketCommentClick(event) { event?.preventDefault(); void this.loadQryListTicketComment(); }
    /** action cmdCreateTicketComment (command) — route controleChamados.ticketCommentCatalogue.cmdCreateTicketComment; inputs ticketId, commentText; writes ui.ticketCommentCatalogue.output.cmdCreateTicketComment; status ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status; feedback keys action.cmdCreateTicketComment.success / action.cmdCreateTicketComment.error */
    async cmdCreateTicketComment() { if (!this.cmdCreateTicketCommentTicketId) {
        this.setStatus('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'idle');
        return;
    } this.setStatus('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'loading'); setState('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.error', ''); const params = { ticketId: this.cmdCreateTicketCommentTicketId, commentText: this.cmdCreateTicketCommentCommentText }; const response = await execBff(cmdCreateTicketCommentRoute, params, { mode: 'blocking' }); if (!response.ok) {
        const message = this.readErrorMessage(response.error, 'action.cmdCreateTicketComment.error');
        this.assignState('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.error', message);
        setState('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.error', message);
        this.setStatus('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'error');
        return;
    } const data = response.data ?? null; this.cmdCreateTicketCommentOutput = data; setState('ui.ticketCommentCatalogue.output.cmdCreateTicketComment', data); for (const action of ['qryListTicketComment', 'qryGetTicketComment', 'qryTicketPicker'])
        if (!(await this.refresh(action))) {
            this.setStatus('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'error');
            return;
        } this.setCmdCreateTicketCommentTicketId(''); this.setCmdCreateTicketCommentCommentText(''); this.setUiScenary('base'); this.setStatus('ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status', 'success'); }
    /** handler for action cmdCreateTicketComment — bind UI events here */
    handleCmdCreateTicketCommentClick(event) { event?.preventDefault(); void runBlockingUiAction(async () => { await this.cmdCreateTicketComment(); }); }
    /** action cmdUpdateTicketComment (command) — route controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment; inputs ticketCommentId, ticketId, commentText; writes ui.ticketCommentCatalogue.output.cmdUpdateTicketComment; status ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status; feedback keys action.cmdUpdateTicketComment.success / action.cmdUpdateTicketComment.error */
    async cmdUpdateTicketComment() { if (!this.cmdUpdateTicketCommentTicketCommentId || !this.cmdUpdateTicketCommentTicketId) {
        this.setStatus('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'idle');
        return;
    } this.setStatus('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'loading'); setState('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.error', ''); const params = { ticketCommentId: this.cmdUpdateTicketCommentTicketCommentId, ticketId: this.cmdUpdateTicketCommentTicketId, commentText: this.cmdUpdateTicketCommentCommentText }; const response = await execBff(cmdUpdateTicketCommentRoute, params, { mode: 'blocking' }); if (!response.ok) {
        const message = this.readErrorMessage(response.error, 'action.cmdUpdateTicketComment.error');
        this.assignState('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.error', message);
        setState('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.error', message);
        this.setStatus('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'error');
        return;
    } const data = response.data ?? null; this.cmdUpdateTicketCommentOutput = data; setState('ui.ticketCommentCatalogue.output.cmdUpdateTicketComment', data); for (const action of ['qryListTicketComment', 'qryGetTicketComment', 'qryTicketPicker'])
        if (!(await this.refresh(action))) {
            this.setStatus('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'error');
            return;
        } this.setCmdUpdateTicketCommentTicketCommentId(''); this.setCmdUpdateTicketCommentTicketId(''); this.setCmdUpdateTicketCommentCommentText(''); this.setUiScenary('base'); this.setStatus('ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status', 'success'); }
    /** handler for action cmdUpdateTicketComment — bind UI events here */
    handleCmdUpdateTicketCommentClick(event) { event?.preventDefault(); void runBlockingUiAction(async () => { await this.cmdUpdateTicketComment(); }); }
    /** action cmdDeleteTicketComment (command) — route controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment; inputs ticketCommentId; writes ui.ticketCommentCatalogue.output.cmdDeleteTicketComment; status ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status; feedback keys action.cmdDeleteTicketComment.success / action.cmdDeleteTicketComment.error */
    async cmdDeleteTicketComment() { if (!this.cmdDeleteTicketCommentTicketCommentId) {
        this.setStatus('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'idle');
        return;
    } this.setStatus('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'loading'); setState('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.error', ''); const params = { ticketCommentId: this.cmdDeleteTicketCommentTicketCommentId }; const response = await execBff(cmdDeleteTicketCommentRoute, params, { mode: 'blocking' }); if (!response.ok) {
        const message = this.readErrorMessage(response.error, 'action.cmdDeleteTicketComment.error');
        this.assignState('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.error', message);
        setState('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.error', message);
        this.setStatus('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'error');
        return;
    } const data = response.data ?? null; this.cmdDeleteTicketCommentOutput = data; setState('ui.ticketCommentCatalogue.output.cmdDeleteTicketComment', data); for (const action of ['qryListTicketComment', 'qryGetTicketComment', 'qryTicketPicker'])
        if (!(await this.refresh(action))) {
            this.setStatus('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'error');
            return;
        } this.setCmdDeleteTicketCommentTicketCommentId(''); this.setUiScenary('base'); this.setStatus('ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status', 'success'); }
    /** handler for action cmdDeleteTicketComment — bind UI events here */
    handleCmdDeleteTicketCommentClick(event) { event?.preventDefault(); void runBlockingUiAction(async () => { await this.cmdDeleteTicketComment(); }); }
    /** action qryGetTicketComment (query) — route controleChamados.ticketCommentCatalogue.qryGetTicketComment; inputs ticketCommentId; writes ui.ticketCommentCatalogue.data.qryGetTicketComment; status ui.ticketCommentCatalogue.action.qryGetTicketComment.status */
    async loadQryGetTicketComment() { if (!this.qryGetTicketCommentTicketCommentId) {
        this.setStatus('ui.ticketCommentCatalogue.action.qryGetTicketComment.status', 'idle');
        return;
    } this.setStatus('ui.ticketCommentCatalogue.action.qryGetTicketComment.status', 'loading'); const params = { ticketCommentId: this.qryGetTicketCommentTicketCommentId }; const response = await execBff(qryGetTicketCommentRoute, params, { mode: 'silent' }); if (response.ok) {
        const data = response.data ?? null;
        this.qryGetTicketCommentData = data;
        setState('ui.ticketCommentCatalogue.data.qryGetTicketComment', data);
        this.setStatus('ui.ticketCommentCatalogue.action.qryGetTicketComment.status', 'success');
    }
    else {
        this.setStatus('ui.ticketCommentCatalogue.action.qryGetTicketComment.status', 'error');
        if (response.error)
            console.error('qryGetTicketComment failed', response.error);
    } this.requestUpdate(); }
    /** handler for action qryGetTicketComment — bind UI events here */
    handleQryGetTicketCommentClick(event) { event?.preventDefault(); void this.loadQryGetTicketComment(); }
    /** action qryTicketPicker (query) — route controleChamados.ticketCommentCatalogue.qryTicketPicker; inputs search, sortBy, sortOrder; writes ui.ticketCommentCatalogue.data.qryTicketPicker; status ui.ticketCommentCatalogue.action.qryTicketPicker.status */
    async loadQryTicketPicker() { this.setStatus('ui.ticketCommentCatalogue.action.qryTicketPicker.status', 'loading'); const params = {}; if (this.qryTicketPickerSearch)
        params.search = this.qryTicketPickerSearch; if (this.qryTicketPickerSortBy)
        params.sortBy = this.qryTicketPickerSortBy; if (this.qryTicketPickerSortOrder)
        params.sortOrder = this.qryTicketPickerSortOrder; const response = await execBff(qryTicketPickerRoute, params, { mode: 'silent' }); if (response.ok) {
        const data = response.data ?? [];
        this.qryTicketPickerData = data;
        setState('ui.ticketCommentCatalogue.data.qryTicketPicker', data);
        this.setStatus('ui.ticketCommentCatalogue.action.qryTicketPicker.status', 'success');
    }
    else {
        this.setStatus('ui.ticketCommentCatalogue.action.qryTicketPicker.status', 'error');
        if (response.error)
            console.error('qryTicketPicker failed', response.error);
    } this.requestUpdate(); }
    /** handler for action qryTicketPicker — bind UI events here */
    handleQryTicketPickerClick(event) { event?.preventDefault(); void this.loadQryTicketPicker(); }
    inputValue(event) { const target = event.target; return target && 'value' in target ? String(target.value) : ''; }
    /** setter for state ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId */
    setCmdCreateTicketCommentTicketId(value) { this.cmdCreateTicketCommentTicketId = value; setState('ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId', value); const item = this.qryListTicketCommentData.find((row) => String(row.ticketId) === String(value)); if (item && item.commentText != null) {
        this.setCmdCreateTicketCommentCommentText(item.commentText);
    } this.requestUpdate(); }
    /** handler for action set.cmdCreateTicketCommentTicketId — bind UI events here */ handleCmdCreateTicketCommentTicketIdChange(event) { this.setCmdCreateTicketCommentTicketId(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.cmdCreateTicketComment.commentText */
    setCmdCreateTicketCommentCommentText(value) { this.cmdCreateTicketCommentCommentText = value; setState('ui.ticketCommentCatalogue.input.cmdCreateTicketComment.commentText', value); this.requestUpdate(); }
    /** handler for action set.cmdCreateTicketCommentCommentText — bind UI events here */ handleCmdCreateTicketCommentCommentTextChange(event) { this.setCmdCreateTicketCommentCommentText(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId */
    setCmdUpdateTicketCommentTicketCommentId(value) { this.cmdUpdateTicketCommentTicketCommentId = value; setState('ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId', value); const item = this.qryListTicketCommentData.find((row) => String(row.ticketCommentId) === String(value)); if (item && item.commentText != null)
        this.setCmdUpdateTicketCommentCommentText(item.commentText); this.requestUpdate(); }
    /** handler for action set.cmdUpdateTicketCommentTicketCommentId — bind UI events here */ handleCmdUpdateTicketCommentTicketCommentIdChange(event) { this.setCmdUpdateTicketCommentTicketCommentId(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId */
    setCmdUpdateTicketCommentTicketId(value) { this.cmdUpdateTicketCommentTicketId = value; setState('ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId', value); const item = this.qryListTicketCommentData.find((row) => String(row.ticketId) === String(value)); if (item && item.commentText != null)
        this.setCmdUpdateTicketCommentCommentText(item.commentText); this.requestUpdate(); }
    /** handler for action set.cmdUpdateTicketCommentTicketId — bind UI events here */ handleCmdUpdateTicketCommentTicketIdChange(event) { this.setCmdUpdateTicketCommentTicketId(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.commentText */
    setCmdUpdateTicketCommentCommentText(value) { this.cmdUpdateTicketCommentCommentText = value; setState('ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.commentText', value); this.requestUpdate(); }
    /** handler for action set.cmdUpdateTicketCommentCommentText — bind UI events here */ handleCmdUpdateTicketCommentCommentTextChange(event) { this.setCmdUpdateTicketCommentCommentText(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.cmdDeleteTicketComment.ticketCommentId */
    setCmdDeleteTicketCommentTicketCommentId(value) { this.cmdDeleteTicketCommentTicketCommentId = value; setState('ui.ticketCommentCatalogue.input.cmdDeleteTicketComment.ticketCommentId', value); this.requestUpdate(); }
    /** handler for action set.cmdDeleteTicketCommentTicketCommentId — bind UI events here */ handleCmdDeleteTicketCommentTicketCommentIdChange(event) { this.setCmdDeleteTicketCommentTicketCommentId(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId */
    setQryGetTicketCommentTicketCommentId(value) { this.qryGetTicketCommentTicketCommentId = value; setState('ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId', value); this.requestUpdate(); }
    /** handler for action set.qryGetTicketCommentTicketCommentId — bind UI events here */ handleQryGetTicketCommentTicketCommentIdChange(event) { this.setQryGetTicketCommentTicketCommentId(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.qryTicketPicker.search */
    setQryTicketPickerSearch(value) { this.qryTicketPickerSearch = value; setState('ui.ticketCommentCatalogue.input.qryTicketPicker.search', value); this.requestUpdate(); }
    /** handler for action set.qryTicketPickerSearch — bind UI events here */ handleQryTicketPickerSearchChange(event) { this.setQryTicketPickerSearch(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.qryTicketPicker.sortBy */
    setQryTicketPickerSortBy(value) { this.qryTicketPickerSortBy = value; setState('ui.ticketCommentCatalogue.input.qryTicketPicker.sortBy', value); this.requestUpdate(); }
    /** handler for action set.qryTicketPickerSortBy — bind UI events here */ handleQryTicketPickerSortByChange(event) { this.setQryTicketPickerSortBy(this.inputValue(event)); }
    /** setter for state ui.ticketCommentCatalogue.input.qryTicketPicker.sortOrder */
    setQryTicketPickerSortOrder(value) { this.qryTicketPickerSortOrder = value; setState('ui.ticketCommentCatalogue.input.qryTicketPicker.sortOrder', value); this.requestUpdate(); }
    /** handler for action set.qryTicketPickerSortOrder — bind UI events here */ handleQryTicketPickerSortOrderChange(event) { this.setQryTicketPickerSortOrder(this.inputValue(event)); }
}
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "status", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "uiScenary", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryListTicketCommentState", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryListTicketCommentData", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdCreateTicketCommentState", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdCreateTicketCommentTicketId", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdCreateTicketCommentCommentText", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdCreateTicketCommentOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdCreateTicketCommentError", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdUpdateTicketCommentState", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdUpdateTicketCommentTicketCommentId", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdUpdateTicketCommentTicketId", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdUpdateTicketCommentCommentText", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdUpdateTicketCommentOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdUpdateTicketCommentError", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdDeleteTicketCommentState", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdDeleteTicketCommentTicketCommentId", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdDeleteTicketCommentOutput", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "cmdDeleteTicketCommentError", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryGetTicketCommentState", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryGetTicketCommentTicketCommentId", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryGetTicketCommentData", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryTicketPickerState", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryTicketPickerSearch", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryTicketPickerSortBy", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryTicketPickerSortOrder", void 0);
__decorate([
    property()
], ControleChamadosTicketCommentCatalogueBase.prototype, "qryTicketPickerData", void 0);

/// <mls fileReference="_102047_/l2/controleChamados/web/contracts/ticketHub.ts" enhancement="_blank"/>
export const qryListTicketRoute = 'controleChamados.ticketHub.qryListTicket';
export const qryListTicketCommentRoute = 'controleChamados.ticketHub.qryListTicketComment';

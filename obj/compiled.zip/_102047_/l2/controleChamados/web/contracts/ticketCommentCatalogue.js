/// <mls fileReference="_102047_/l2/controleChamados/web/contracts/ticketCommentCatalogue.ts" enhancement="_blank"/>
export const qryListTicketCommentRoute = 'controleChamados.ticketCommentCatalogue.qryListTicketComment';
export const cmdCreateTicketCommentRoute = 'controleChamados.ticketCommentCatalogue.cmdCreateTicketComment';
export const cmdUpdateTicketCommentRoute = 'controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment';
export const cmdDeleteTicketCommentRoute = 'controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment';
export const qryGetTicketCommentRoute = 'controleChamados.ticketCommentCatalogue.qryGetTicketComment';
export const qryTicketPickerRoute = 'controleChamados.ticketCommentCatalogue.qryTicketPicker';

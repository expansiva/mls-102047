/// <mls fileReference="_102047_/l2/controleChamados/web/contracts/ticketCatalogue.ts" enhancement="_blank"/>
export const qryListTicketRoute = 'controleChamados.ticketCatalogue.qryListTicket';
export const cmdCreateTicketRoute = 'controleChamados.ticketCatalogue.cmdCreateTicket';
export const cmdUpdateTicketRoute = 'controleChamados.ticketCatalogue.cmdUpdateTicket';
export const cmdDeleteTicketRoute = 'controleChamados.ticketCatalogue.cmdDeleteTicket';
export const qryGetTicketRoute = 'controleChamados.ticketCatalogue.qryGetTicket';
export const qryLocateTicketRoute = 'controleChamados.ticketCatalogue.qryLocateTicket';
export const cmdDecideClosureRoute = 'controleChamados.ticketCatalogue.cmdDecideClosure';

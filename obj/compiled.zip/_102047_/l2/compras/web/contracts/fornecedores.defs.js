/// <mls fileReference="_102047_/l2/compras/web/contracts/fornecedores.defs.ts" enhancement="_blank"/>
export {};

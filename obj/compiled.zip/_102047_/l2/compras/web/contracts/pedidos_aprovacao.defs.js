/// <mls fileReference="_102047_/l2/compras/web/contracts/pedidos_aprovacao.defs.ts" enhancement="_blank"/>
export {};

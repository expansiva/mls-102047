/// <mls fileReference="_102047_/l2/compras/web/contracts/painel_compras.defs.ts" enhancement="_blank"/>
export {};

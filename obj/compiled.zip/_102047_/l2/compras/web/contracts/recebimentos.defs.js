/// <mls fileReference="_102047_/l2/compras/web/contracts/recebimentos.defs.ts" enhancement="_blank"/>
export {};

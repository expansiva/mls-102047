/// <mls fileReference="_102047_/l2/compras/web/contracts/inicio_comprador.defs.ts" enhancement="_blank"/>
export {};

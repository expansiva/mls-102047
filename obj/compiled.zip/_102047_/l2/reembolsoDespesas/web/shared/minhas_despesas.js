var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/reembolsoDespesas/web/shared/minhas_despesas.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const DESPESA_STATUS_VALUES = ['draft', 'awaitingApproval', 'rejected', 'approved', 'paid'];
const PAGE_SIZE = 20;
const STORAGE_PREFIX = 'reembolsoDespesas.minhas_despesas.';
function isDespesaStatus(value) {
    return DESPESA_STATUS_VALUES.includes(value);
}
function emptyDetailsDraft() {
    return { dataDespesa: null, categoria: null, valor: null, descricao: null };
}
function emptyRegistrarDespesaDraft() {
    return { colaboradorId: null, details: emptyDetailsDraft() };
}
function emptySalvarCorrecaoDraft() {
    return { id: null, version: null, details: emptyDetailsDraft() };
}
function isFilled(value) {
    return value !== null && value.trim() !== '';
}
const STATE_MEMBER_BY_KEY = {
    'ui.reembolsoDespesas.minhas_despesas.despesas': 'despesas',
    'ui.reembolsoDespesas.minhas_despesas.despesa': 'despesa',
    'ui.reembolsoDespesas.minhas_despesas.selectedDespesa': 'selectedDespesa',
    'ui.reembolsoDespesas.minhas_despesas.status': 'status',
    'ui.reembolsoDespesas.minhas_despesas.page': 'page',
    'ui.reembolsoDespesas.minhas_despesas.registrarDespesaDraft': 'registrarDespesaDraft',
    'ui.reembolsoDespesas.minhas_despesas.salvarCorrecaoDraft': 'salvarCorrecaoDraft',
    'ui.reembolsoDespesas.minhas_despesas.pageStatus': 'pageStatus',
    'ui.reembolsoDespesas.minhas_despesas.listarMinhasDespesasStatus': 'listarMinhasDespesasStatus',
    'ui.reembolsoDespesas.minhas_despesas.listarMinhasDespesasError': 'listarMinhasDespesasError',
    'ui.reembolsoDespesas.minhas_despesas.obterDespesaStatus': 'obterDespesaStatus',
    'ui.reembolsoDespesas.minhas_despesas.obterDespesaError': 'obterDespesaError',
    'ui.reembolsoDespesas.minhas_despesas.registrarDespesaStatus': 'registrarDespesaStatus',
    'ui.reembolsoDespesas.minhas_despesas.registrarDespesaError': 'registrarDespesaError',
    'ui.reembolsoDespesas.minhas_despesas.salvarCorrecaoStatus': 'salvarCorrecaoStatus',
    'ui.reembolsoDespesas.minhas_despesas.salvarCorrecaoError': 'salvarCorrecaoError',
    'ui.reembolsoDespesas.minhas_despesas.enviarParaAprovacaoStatus': 'enviarParaAprovacaoStatus',
    'ui.reembolsoDespesas.minhas_despesas.enviarParaAprovacaoError': 'enviarParaAprovacaoError',
    'ui.reembolsoDespesas.minhas_despesas.reenviarParaAprovacaoStatus': 'reenviarParaAprovacaoStatus',
    'ui.reembolsoDespesas.minhas_despesas.reenviarParaAprovacaoError': 'reenviarParaAprovacaoError',
    'ui.reembolsoDespesas.minhas_despesas.scenary': 'scenary',
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class ReembolsoDespesasMinhas_despesasShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state despesas — page of the collaborator's own expenses (rows with id, status, date, category, value); source listarMinhasDespesas.despesas; organism listaMinhasDespesas */
        this.despesas = null;
        /** state despesa — the open expense with all its data (id, version, status, details), used by the detail, the correction form and the submit actions; source obterDespesa.despesa; organisms acoesEnvio, detalheDespesa, formularioDespesa */
        this.despesa = null;
        /** state selectedDespesa — id of the selected expense (the record itself is in despesa); source entry.params.despesaId; organisms detalheDespesa, listaMinhasDespesas; persisted */
        this.selectedDespesa = null;
        /** state status — status filter of the expense list, null for all; source entry.params.status; organism listaMinhasDespesas; persisted */
        this.status = null;
        /** state page — page of the list the person went to with a pager (a "load more" never writes it); source entry.params.page; organism listaMinhasDespesas; persisted */
        this.page = null;
        /** state registrarDespesaDraft — form draft of a new expense (date, category, value, description); source registrarDespesa.input; organism formularioDespesa */
        this.registrarDespesaDraft = emptyRegistrarDespesaDraft();
        /** state salvarCorrecaoDraft — form draft correcting a rejected expense, prefilled from the open expense; source salvarCorrecao.input; organism formularioDespesa */
        this.salvarCorrecaoDraft = emptySalvarCorrecaoDraft();
        /** state pageStatus — overall status of the page: loading while the list loads, empty when it has no rows, error when it failed; source page load */
        this.pageStatus = 'idle';
        /** state listarMinhasDespesasStatus — status of the list request; source listarMinhasDespesas */
        this.listarMinhasDespesasStatus = 'idle';
        /** state listarMinhasDespesasError — error of the list request, null when none; source listarMinhasDespesas */
        this.listarMinhasDespesasError = null;
        /** state obterDespesaStatus — status of the request that opens an expense; source obterDespesa */
        this.obterDespesaStatus = 'idle';
        /** state obterDespesaError — error of the request that opens an expense, null when none; source obterDespesa */
        this.obterDespesaError = null;
        /** state registrarDespesaStatus — status of the command that registers a new expense; source registrarDespesa */
        this.registrarDespesaStatus = 'idle';
        /** state registrarDespesaError — error of the register command, null when none; source registrarDespesa */
        this.registrarDespesaError = null;
        /** state salvarCorrecaoStatus — status of the command that saves the correction of a rejected expense; source salvarCorrecao */
        this.salvarCorrecaoStatus = 'idle';
        /** state salvarCorrecaoError — error of the save-correction command, null when none; source salvarCorrecao */
        this.salvarCorrecaoError = null;
        /** state enviarParaAprovacaoStatus — status of the command that submits a draft expense for approval; source enviarParaAprovacao */
        this.enviarParaAprovacaoStatus = 'idle';
        /** state enviarParaAprovacaoError — error of the submit command, null when none; source enviarParaAprovacao */
        this.enviarParaAprovacaoError = null;
        /** state reenviarParaAprovacaoStatus — status of the command that resubmits a corrected rejected expense; source reenviarParaAprovacao */
        this.reenviarParaAprovacaoStatus = 'idle';
        /** state reenviarParaAprovacaoError — error of the resubmit command, null when none; source reenviarParaAprovacao */
        this.reenviarParaAprovacaoError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.reembolsoDespesas.minhas_despesas.${member}`, value);
        if (member === 'status') {
            this.persistParam('status', this.status);
        }
        if (member === 'page') {
            this.persistParam('page', this.page);
        }
        if (member === 'selectedDespesa') {
            this.persistParam('despesaId', this.selectedDespesa);
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    persistParam(name, value) {
        try {
            if (value === null) {
                localStorage.removeItem(`${STORAGE_PREFIX}${name}`);
            }
            else {
                localStorage.setItem(`${STORAGE_PREFIX}${name}`, String(value));
            }
        }
        catch {
            // storage unavailable: the param simply is not persisted
        }
    }
    readParam(name) {
        const fromUrl = new URLSearchParams(window.location.search).get(name);
        if (fromUrl !== null && fromUrl !== '')
            return fromUrl;
        try {
            const stored = localStorage.getItem(`${STORAGE_PREFIX}${name}`);
            if (stored !== null && stored !== '')
                return stored;
        }
        catch {
            // storage unavailable: no stored value
        }
        return null;
    }
    connectedCallback() {
        super.connectedCallback();
        const hydrated = ['despesas', 'despesa'];
        for (const member of hydrated) {
            const key = `ui.reembolsoDespesas.minhas_despesas.${member}`;
            const stored = getState(key);
            if (stored !== undefined)
                this.assignState(key, stored);
        }
        this.resetVisit();
        subscribe([...STATE_KEYS], this);
        this.applyEntryParams();
        void this.listarMinhasDespesas();
    }
    disconnectedCallback() {
        unsubscribe([...STATE_KEYS], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!(key in STATE_MEMBER_BY_KEY)) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('listarMinhasDespesasStatus', 'idle');
        this.publish('listarMinhasDespesasError', null);
        this.publish('obterDespesaStatus', 'idle');
        this.publish('obterDespesaError', null);
        this.resetCommandResults();
        this.publish('registrarDespesaDraft', emptyRegistrarDespesaDraft());
        this.publish('salvarCorrecaoDraft', emptySalvarCorrecaoDraft());
        this.publish('scenary', '');
    }
    resetCommandResults() {
        this.publish('registrarDespesaStatus', 'idle');
        this.publish('registrarDespesaError', null);
        this.publish('salvarCorrecaoStatus', 'idle');
        this.publish('salvarCorrecaoError', null);
        this.publish('enviarParaAprovacaoStatus', 'idle');
        this.publish('enviarParaAprovacaoError', null);
        this.publish('reenviarParaAprovacaoStatus', 'idle');
        this.publish('reenviarParaAprovacaoError', null);
    }
    applyEntryParams() {
        const rawStatus = this.readParam('status');
        this.publish('status', rawStatus !== null && isDespesaStatus(rawStatus) ? rawStatus : null);
        const rawPage = this.readParam('page');
        const parsedPage = rawPage !== null ? Number(rawPage) : NaN;
        this.publish('page', Number.isFinite(parsedPage) && parsedPage >= 1 ? parsedPage : null);
        const rawId = this.readParam('despesaId');
        if (rawId !== null) {
            void this.obterDespesa(rawId);
        }
        else {
            this.publish('selectedDespesa', null);
            this.publish('despesa', null);
        }
    }
    unexpectedError(error) {
        const name = error instanceof Error ? error.name : 'unknown';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    draftFromDespesa(despesa) {
        return {
            id: despesa.id,
            version: despesa.version,
            details: {
                dataDespesa: despesa.details.details.dataDespesa,
                categoria: despesa.details.details.categoria,
                valor: despesa.details.details.valor,
                descricao: despesa.details.details.descricao,
            },
        };
    }
    /** scene — publishes the visible scene of the page (any command result is cleared) */
    setScenario(value) {
        this.resetCommandResults();
        this.publish('scenary', value);
    }
    /** draft — replaces the form draft of a new expense (date, category, value, description); clears old command results */
    setRegistrarDespesaDraft(value) {
        this.resetCommandResults();
        this.publish('registrarDespesaDraft', value);
    }
    /** draft — replaces the form draft that corrects a rejected expense (prefilled by obterDespesa); clears old command results */
    setSalvarCorrecaoDraft(value) {
        this.resetCommandResults();
        this.publish('salvarCorrecaoDraft', value);
    }
    /** request listarMinhasDespesas — loads the collaborator's own expenses (newest expense date first), optionally by status; redraws despesas (replace, or append the next page when append is true), status and page (replace; append never writes page), pageStatus; options.status: new status filter (null clears it) and loads from page 1; options.page: page to load (pager); options.append: true adds the next page to the rows (load more), only when despesas.hasMore. Call with no arguments to reload. */
    async listarMinhasDespesas(options = {}) {
        if (this.listarMinhasDespesasStatus === 'loading')
            return;
        const append = options.append === true;
        if (append && (this.despesas === null || !this.despesas.hasMore))
            return;
        const newStatus = options.status;
        if (newStatus !== undefined) {
            this.publish('status', newStatus);
        }
        let requestedPage = 1;
        if (options.page !== undefined) {
            requestedPage = options.page;
        }
        else if (append && this.despesas !== null) {
            requestedPage = this.despesas.page + 1;
        }
        else if (newStatus === undefined && this.page !== null) {
            requestedPage = this.page;
        }
        const currentStatus = this.status;
        const input = {
            page: requestedPage,
            pageSize: PAGE_SIZE,
            ...(currentStatus !== null ? { status: currentStatus } : {}),
        };
        this.publish('listarMinhasDespesasStatus', 'loading');
        this.publish('listarMinhasDespesasError', null);
        if (!append) {
            this.publish('pageStatus', 'loading');
        }
        try {
            const response = await execBff('reembolsoDespesas.minhas_despesas.listarMinhasDespesas', input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish('listarMinhasDespesasError', response.error ?? this.unexpectedError(null));
                this.publish('listarMinhasDespesasStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            const result = response.data.despesas;
            const previous = this.despesas;
            if (append && previous !== null) {
                this.publish('despesas', { ...result, items: [...previous.items, ...result.items] });
            }
            else {
                this.publish('despesas', result);
                this.publish('page', result.page);
            }
            this.publish('listarMinhasDespesasStatus', 'success');
            const rows = this.despesas;
            this.publish('pageStatus', rows === null || rows.items.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('listarMinhasDespesasError', this.unexpectedError(error));
            this.publish('listarMinhasDespesasStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
    /** select — opens an expense: selects the id (selectedDespesa) and fetches the full record; redraws despesa (replace) and refills salvarCorrecaoDraft from it; id: the expense picked in the list, or null to clear the selection */
    async obterDespesa(id) {
        this.resetCommandResults();
        if (id === null || id === '') {
            this.publish('selectedDespesa', null);
            this.publish('despesa', null);
            this.publish('salvarCorrecaoDraft', emptySalvarCorrecaoDraft());
            this.publish('obterDespesaStatus', 'idle');
            this.publish('obterDespesaError', null);
            return;
        }
        if (this.obterDespesaStatus === 'loading' && this.selectedDespesa === id)
            return;
        this.publish('selectedDespesa', id);
        if (this.despesa !== null && this.despesa.id !== id) {
            this.publish('despesa', null);
            this.publish('salvarCorrecaoDraft', emptySalvarCorrecaoDraft());
        }
        this.publish('obterDespesaStatus', 'loading');
        this.publish('obterDespesaError', null);
        try {
            const input = { id };
            const response = await execBff('reembolsoDespesas.minhas_despesas.obterDespesa', input, { mode: 'silent' });
            if (this.selectedDespesa !== id)
                return;
            if (!response.ok || !response.data) {
                this.publish('obterDespesaError', response.error ?? this.unexpectedError(null));
                this.publish('obterDespesaStatus', 'error');
                return;
            }
            const record = response.data.despesa;
            this.publish('despesa', record);
            this.publish('salvarCorrecaoDraft', this.draftFromDespesa(record));
            this.publish('obterDespesaStatus', 'success');
        }
        catch (error) {
            if (this.selectedDespesa !== id)
                return;
            this.publish('obterDespesaError', this.unexpectedError(error));
            this.publish('obterDespesaStatus', 'error');
        }
    }
    setCommandState(request, status, error) {
        if (request === 'registrarDespesa') {
            this.publish('registrarDespesaError', error);
            this.publish('registrarDespesaStatus', status);
            return;
        }
        if (request === 'salvarCorrecao') {
            this.publish('salvarCorrecaoError', error);
            this.publish('salvarCorrecaoStatus', status);
            return;
        }
        if (request === 'enviarParaAprovacao') {
            this.publish('enviarParaAprovacaoError', error);
            this.publish('enviarParaAprovacaoStatus', status);
            return;
        }
        this.publish('reenviarParaAprovacaoError', error);
        this.publish('reenviarParaAprovacaoStatus', status);
    }
    async runCommand(request, route, input) {
        this.setCommandState(request, 'loading', null);
        try {
            const response = await runBlockingUiAction(signal => execBff(route, input, { mode: 'blocking', signal }));
            if (response === undefined) {
                this.setCommandState(request, 'error', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                return null;
            }
            if (!response.ok || !response.data) {
                this.setCommandState(request, 'error', response.error ?? this.unexpectedError(null));
                return null;
            }
            return response.data;
        }
        catch (error) {
            this.setCommandState(request, 'error', this.unexpectedError(error));
            return null;
        }
    }
    upsertItem(item) {
        const current = this.despesas;
        if (current === null)
            return;
        const belongs = this.status === null || item.status === this.status;
        const exists = current.items.some(row => row.id === item.id);
        let items;
        if (!belongs) {
            items = current.items.filter(row => row.id !== item.id);
        }
        else if (exists) {
            items = current.items.map(row => (row.id === item.id ? item : row));
        }
        else {
            items = [item, ...current.items];
        }
        this.publish('despesas', { ...current, items });
    }
    applyDespesaResult(output) {
        this.publish('despesa', output.despesa);
        this.publish('selectedDespesa', output.despesa.id);
        this.publish('salvarCorrecaoDraft', this.draftFromDespesa(output.despesa));
        this.upsertItem(output.item);
    }
    /** request registrarDespesa — registers a new expense as draft from registrarDespesaDraft (date, category, value and description are required); redraws despesa and selectedDespesa (the created expense opens in the detail), despesas (the row is inserted at the top, no reload, unless the status filter excludes it), salvarCorrecaoDraft (refilled) and clears registrarDespesaDraft; no arguments */
    async registrarDespesa() {
        const draft = this.registrarDespesaDraft;
        const { dataDespesa, categoria, valor, descricao } = draft.details;
        const missing = [];
        if (!isFilled(dataDespesa))
            missing.push('registrarDespesaDraft.details.dataDespesa');
        if (!isFilled(categoria))
            missing.push('registrarDespesaDraft.details.categoria');
        if (!isFilled(valor))
            missing.push('registrarDespesaDraft.details.valor');
        if (!isFilled(descricao))
            missing.push('registrarDespesaDraft.details.descricao');
        if (missing.length > 0 || dataDespesa === null || categoria === null || valor === null || descricao === null) {
            this.setCommandState('registrarDespesa', 'error', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            return;
        }
        const input = {
            colaboradorId: draft.colaboradorId ?? '',
            details: { dataDespesa, categoria, valor, descricao },
        };
        const output = await this.runCommand('registrarDespesa', 'reembolsoDespesas.minhas_despesas.registrarDespesa', input);
        if (!output)
            return;
        this.applyDespesaResult(output);
        this.publish('registrarDespesaDraft', emptyRegistrarDespesaDraft());
        this.setCommandState('registrarDespesa', 'success', null);
    }
    /** request salvarCorrecao — saves the correction of a rejected expense from salvarCorrecaoDraft (id, version and all details required); redraws despesa (replace), the row in despesas (updated in place) and refills salvarCorrecaoDraft from the saved record; no arguments */
    async salvarCorrecao() {
        const draft = this.salvarCorrecaoDraft;
        const { dataDespesa, categoria, valor, descricao } = draft.details;
        const missing = [];
        if (draft.id === null)
            missing.push('salvarCorrecaoDraft.id');
        if (draft.version === null)
            missing.push('salvarCorrecaoDraft.version');
        if (!isFilled(dataDespesa))
            missing.push('salvarCorrecaoDraft.details.dataDespesa');
        if (!isFilled(categoria))
            missing.push('salvarCorrecaoDraft.details.categoria');
        if (!isFilled(valor))
            missing.push('salvarCorrecaoDraft.details.valor');
        if (!isFilled(descricao))
            missing.push('salvarCorrecaoDraft.details.descricao');
        if (missing.length > 0 || draft.id === null || draft.version === null || dataDespesa === null || categoria === null || valor === null || descricao === null) {
            this.setCommandState('salvarCorrecao', 'error', { code: 'client.requiredMissing', message: '', details: { stateKeys: missing } });
            return;
        }
        const input = {
            id: draft.id,
            version: draft.version,
            details: { dataDespesa, categoria, valor, descricao },
        };
        const output = await this.runCommand('salvarCorrecao', 'reembolsoDespesas.minhas_despesas.salvarCorrecao', input);
        if (!output)
            return;
        this.applyDespesaResult(output);
        this.setCommandState('salvarCorrecao', 'success', null);
    }
    /** request enviarParaAprovacao — submits the open draft expense (despesa) for manager approval using its id and version; redraws despesa (new status, new version), the row in despesas (updated in place or removed when the status filter no longer matches) and salvarCorrecaoDraft; no arguments */
    async enviarParaAprovacao() {
        const current = this.despesa;
        if (current === null) {
            this.setCommandState('enviarParaAprovacao', 'error', { code: 'client.preconditionMissing', message: '', details: { stateKeys: ['despesa'] } });
            return;
        }
        const input = { id: current.id, version: current.version };
        const output = await this.runCommand('enviarParaAprovacao', 'reembolsoDespesas.minhas_despesas.enviarParaAprovacao', input);
        if (!output)
            return;
        this.applyDespesaResult(output);
        this.setCommandState('enviarParaAprovacao', 'success', null);
    }
    /** request reenviarParaAprovacao — resubmits, once, the open rejected and corrected expense (despesa) for a new manager review using its id and version; redraws despesa (new status, resubmission flag, new version), the row in despesas (updated in place or removed when the status filter no longer matches) and salvarCorrecaoDraft; no arguments */
    async reenviarParaAprovacao() {
        const current = this.despesa;
        if (current === null) {
            this.setCommandState('reenviarParaAprovacao', 'error', { code: 'client.preconditionMissing', message: '', details: { stateKeys: ['despesa'] } });
            return;
        }
        const input = { id: current.id, version: current.version };
        const output = await this.runCommand('reenviarParaAprovacao', 'reembolsoDespesas.minhas_despesas.reenviarParaAprovacao', input);
        if (!output)
            return;
        this.applyDespesaResult(output);
        this.setCommandState('reenviarParaAprovacao', 'success', null);
    }
}
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "despesas", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "despesa", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "selectedDespesa", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "status", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "page", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "registrarDespesaDraft", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "salvarCorrecaoDraft", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "listarMinhasDespesasStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "listarMinhasDespesasError", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "obterDespesaStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "obterDespesaError", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "registrarDespesaStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "registrarDespesaError", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "salvarCorrecaoStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "salvarCorrecaoError", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "enviarParaAprovacaoStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "enviarParaAprovacaoError", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "reenviarParaAprovacaoStatus", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "reenviarParaAprovacaoError", void 0);
__decorate([
    property({ attribute: false })
], ReembolsoDespesasMinhas_despesasShared.prototype, "scenary", void 0);

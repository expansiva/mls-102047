/// <mls fileReference="_102047_/l2/controleEstoque/web/shared/movimentacoes.ts" enhancement="_102020_/l2/enhancementAura"/>
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { createMovimentacaoEstoqueRoute, listMovimentacaoEstoqueRoute, listProdutoRoute } from '/_102047_/l2/controleEstoque/web/contracts/movimentacoes.defs.js';
const stateKeys = ['ui.movimentacoes.pageStatus', 'ui.movimentacoes.scenary', 'ui.movimentacoes.createMovimentacaoEstoque.input.produtoId', 'ui.movimentacoes.createMovimentacaoEstoque.input.movimentadoEm', 'ui.movimentacoes.createMovimentacaoEstoque.input.details.tipo', 'ui.movimentacoes.createMovimentacaoEstoque.input.details.quantidade', 'ui.movimentacoes.createMovimentacaoEstoque.status', 'ui.movimentacoes.createMovimentacaoEstoque.error', 'ui.movimentacoes.createMovimentacaoEstoque.result', 'ui.movimentacoes.listMovimentacaoEstoque.input.id', 'ui.movimentacoes.listMovimentacaoEstoque.input.produtoId', 'ui.movimentacoes.listMovimentacaoEstoque.input.movimentadoEm', 'ui.movimentacoes.listMovimentacaoEstoque.input.page', 'ui.movimentacoes.listMovimentacaoEstoque.status', 'ui.movimentacoes.listMovimentacaoEstoque.error', 'ui.movimentacoes.listMovimentacaoEstoque.result', 'ui.movimentacoes.listProduto.input.id', 'ui.movimentacoes.listProduto.input.details.identification.subtype', 'ui.movimentacoes.listProduto.input.details.identification.name', 'ui.movimentacoes.listProduto.input.details.identification.status', 'ui.movimentacoes.listProduto.input.page', 'ui.movimentacoes.listProduto.status', 'ui.movimentacoes.listProduto.error', 'ui.movimentacoes.listProduto.result'];
export class MovimentacoesShared extends StateLitElement {
    constructor() {
        super(...arguments);
        this.pageStatus = 'idle';
        this.scenary = 'base';
        this.stateCreateMovimentacaoEstoqueProdutoId = null;
        this.stateCreateMovimentacaoEstoqueMovimentadoEm = null;
        this.stateCreateMovimentacaoEstoqueDetailsTipo = null;
        this.stateCreateMovimentacaoEstoqueDetailsQuantidade = null;
        this.stateCreateMovimentacaoEstoqueStatus = 'idle';
        this.stateCreateMovimentacaoEstoqueError = null;
        this.stateCreateMovimentacaoEstoqueResult = null;
        this.stateListMovimentacaoEstoqueId = null;
        this.stateListMovimentacaoEstoqueProdutoId = null;
        this.stateListMovimentacaoEstoqueMovimentadoEm = null;
        this.stateListMovimentacaoEstoquePage = null;
        this.stateListMovimentacaoEstoqueStatus = 'idle';
        this.stateListMovimentacaoEstoqueError = null;
        this.stateListMovimentacaoEstoqueResult = [];
        this.stateListProdutoId = null;
        this.stateListProdutoDetailsIdentificationSubtype = null;
        this.stateListProdutoDetailsIdentificationName = null;
        this.stateListProdutoDetailsIdentificationStatus = null;
        this.stateListProdutoPage = null;
        this.stateListProdutoStatus = 'idle';
        this.stateListProdutoError = null;
        this.stateListProdutoResult = [];
    }
    feedback(error, fallback) { if (error && typeof error === 'object' && 'message' in error && typeof error.message === 'string') {
        const e = error;
        const r = { message: e.message };
        if (typeof e.code === 'string')
            r.code = e.code;
        if ('details' in e)
            r.details = e.details;
        return r;
    } return { message: fallback }; }
    publish(k, v) { setState(k, v); }
    required(v, label) { if (v !== null && v !== undefined && String(v) !== '')
        return true; this.setLocalError(label); return false; }
    setLocalError(m) { const e = { message: m }; this.stateCreateMovimentacaoEstoqueError = e; this.publish('ui.movimentacoes.createMovimentacaoEstoque.error', e); }
    buildNested(values) { const r = {}; for (const [p, v] of values) {
        if (v === null || v === undefined || v === '')
            continue;
        const a = p.split('.');
        let c = r;
        a.forEach((x, i) => { if (i === a.length - 1)
            c[x] = v;
        else {
            const q = c[x];
            if (!q || typeof q !== 'object' || Array.isArray(q))
                c[x] = {};
            c = c[x];
        } });
    } return r; }
    setScenario(v) { if (v === 'createMovimentacaoEstoque' && !this.createPreconditions())
        return; this.scenary = v; this.publish('ui.movimentacoes.scenary', v); this.requestUpdate(); }
    createPreconditions() { return this.required(this.stateCreateMovimentacaoEstoqueProdutoId, 'Produto é obrigatório.') && this.required(this.stateCreateMovimentacaoEstoqueMovimentadoEm, 'Data e hora da movimentação são obrigatórias.') && this.required(this.stateCreateMovimentacaoEstoqueDetailsTipo, 'Tipo de movimentação é obrigatório.') && this.required(this.stateCreateMovimentacaoEstoqueDetailsQuantidade, 'Quantidade é obrigatória.'); }
    setCreateMovimentacaoEstoqueMovimentadoEm(v) { this.stateCreateMovimentacaoEstoqueMovimentadoEm = v; this.publish('ui.movimentacoes.createMovimentacaoEstoque.input.movimentadoEm', v); }
    setCreateMovimentacaoEstoqueDetailsTipo(v) { this.stateCreateMovimentacaoEstoqueDetailsTipo = v; this.publish('ui.movimentacoes.createMovimentacaoEstoque.input.details.tipo', v); }
    setCreateMovimentacaoEstoqueDetailsQuantidade(v) { this.stateCreateMovimentacaoEstoqueDetailsQuantidade = v; this.publish('ui.movimentacoes.createMovimentacaoEstoque.input.details.quantidade', v); }
    setListMovimentacaoEstoqueId(v) { this.stateListMovimentacaoEstoqueId = v; this.publish('ui.movimentacoes.listMovimentacaoEstoque.input.id', v); }
    setListMovimentacaoEstoqueMovimentadoEm(v) { this.stateListMovimentacaoEstoqueMovimentadoEm = v; this.publish('ui.movimentacoes.listMovimentacaoEstoque.input.movimentadoEm', v); }
    setListProdutoId(v) { this.stateListProdutoId = v; this.publish('ui.movimentacoes.listProduto.input.id', v); }
    setListProdutoDetailsIdentificationSubtype(v) { this.stateListProdutoDetailsIdentificationSubtype = v; this.publish('ui.movimentacoes.listProduto.input.details.identification.subtype', v); }
    setListProdutoDetailsIdentificationName(v) { this.stateListProdutoDetailsIdentificationName = v; this.publish('ui.movimentacoes.listProduto.input.details.identification.name', v); }
    setListProdutoDetailsIdentificationStatus(v) { this.stateListProdutoDetailsIdentificationStatus = v; this.publish('ui.movimentacoes.listProduto.input.details.identification.status', v); }
    selectCreateMovimentacaoEstoqueProdutoId(v) { this.selectProduct(v, 'create'); }
    selectListMovimentacaoEstoqueProdutoId(v) { this.selectProduct(v, 'list'); }
    selectProduct(v, t) { if (v === null || v === '') {
        if (t === 'create') {
            this.stateCreateMovimentacaoEstoqueProdutoId = null;
            this.publish('ui.movimentacoes.createMovimentacaoEstoque.input.produtoId', null);
        }
        else {
            this.stateListMovimentacaoEstoqueProdutoId = null;
            this.publish('ui.movimentacoes.listMovimentacaoEstoque.input.produtoId', null);
        }
        return;
    } const row = this.stateListProdutoResult.find((x) => x.id === v); if (!row) {
        this.setLocalError('Selecione um produto presente na lista autorizada.');
        return;
    } if (t === 'create') {
        this.stateCreateMovimentacaoEstoqueProdutoId = row.id;
        this.publish('ui.movimentacoes.createMovimentacaoEstoque.input.produtoId', row.id);
    }
    else {
        this.stateListMovimentacaoEstoqueProdutoId = row.id;
        this.publish('ui.movimentacoes.listMovimentacaoEstoque.input.produtoId', row.id);
    } }
    async runCreateMovimentacaoEstoque() { if (this.stateCreateMovimentacaoEstoqueStatus === 'loading' || !this.createPreconditions())
        return; const input = this.buildNested([['produtoId', this.stateCreateMovimentacaoEstoqueProdutoId], ['movimentadoEm', this.stateCreateMovimentacaoEstoqueMovimentadoEm], ['details.tipo', this.stateCreateMovimentacaoEstoqueDetailsTipo], ['details.quantidade', this.stateCreateMovimentacaoEstoqueDetailsQuantidade]]); this.stateCreateMovimentacaoEstoqueStatus = 'loading'; this.stateCreateMovimentacaoEstoqueError = null; this.publish('ui.movimentacoes.createMovimentacaoEstoque.status', 'loading'); this.publish('ui.movimentacoes.createMovimentacaoEstoque.error', null); try {
        const response = await runBlockingUiAction(() => execBff(createMovimentacaoEstoqueRoute, input, { mode: 'blocking' }), { mode: 'blocking' });
        if (!response)
            throw new Error('A operação não retornou uma resposta.');
        if (response.ok && response.data !== null) {
            this.stateCreateMovimentacaoEstoqueResult = response.data;
            this.stateCreateMovimentacaoEstoqueStatus = 'success';
            this.publish('ui.movimentacoes.createMovimentacaoEstoque.result', response.data);
            this.publish('ui.movimentacoes.createMovimentacaoEstoque.status', 'success');
            await Promise.all([this.runListMovimentacaoEstoque(), this.runListProduto()]);
        }
        else {
            const fallback = response.error && typeof response.error === 'object' && 'message' in response.error && typeof response.error.message === 'string' ? response.error.message : 'Não foi possível registrar a movimentação.';
            const e = this.feedback(response.error, fallback);
            this.stateCreateMovimentacaoEstoqueError = e;
            this.stateCreateMovimentacaoEstoqueStatus = 'error';
            this.publish('ui.movimentacoes.createMovimentacaoEstoque.error', e);
            this.publish('ui.movimentacoes.createMovimentacaoEstoque.status', 'error');
        }
    }
    catch (e) {
        const f = this.feedback(e, 'Não foi possível registrar a movimentação.');
        this.stateCreateMovimentacaoEstoqueError = f;
        this.stateCreateMovimentacaoEstoqueStatus = 'error';
        this.publish('ui.movimentacoes.createMovimentacaoEstoque.error', f);
        this.publish('ui.movimentacoes.createMovimentacaoEstoque.status', 'error');
    } }
    async runListMovimentacaoEstoque() { this.stateListMovimentacaoEstoqueStatus = 'loading'; this.stateListMovimentacaoEstoqueError = null; this.pageStatus = 'loading'; this.publish('ui.movimentacoes.pageStatus', 'loading'); const i = this.buildNested([['id', this.stateListMovimentacaoEstoqueId], ['produtoId', this.stateListMovimentacaoEstoqueProdutoId], ['movimentadoEm', this.stateListMovimentacaoEstoqueMovimentadoEm], ['page', this.stateListMovimentacaoEstoquePage]]); await this.query(listMovimentacaoEstoqueRoute, i, (d) => { this.stateListMovimentacaoEstoqueResult = d; this.publish('ui.movimentacoes.listMovimentacaoEstoque.result', d); }, (e) => { this.stateListMovimentacaoEstoqueError = e; this.publish('ui.movimentacoes.listMovimentacaoEstoque.error', e); }); }
    async runListProduto() { this.stateListProdutoStatus = 'loading'; this.stateListProdutoError = null; const i = this.buildNested([['id', this.stateListProdutoId], ['details.identification.subtype', this.stateListProdutoDetailsIdentificationSubtype], ['details.identification.name', this.stateListProdutoDetailsIdentificationName], ['details.identification.status', this.stateListProdutoDetailsIdentificationStatus], ['page', this.stateListProdutoPage]]); await this.query(listProdutoRoute, i, (d) => { this.stateListProdutoResult = d; this.publish('ui.movimentacoes.listProduto.result', d); }, (e) => { this.stateListProdutoError = e; this.publish('ui.movimentacoes.listProduto.error', e); }); }
    async query(route, input, ok, fail) { try {
        const r = await execBff(route, input, { mode: 'silent' });
        if (r.ok && r.data !== null) {
            ok(r.data);
            this.pageStatus = Array.isArray(r.data) && r.data.length === 0 ? 'empty' : 'success';
        }
        else {
            const e = this.feedback(r.error, 'Não foi possível carregar os dados.');
            fail(e);
            this.pageStatus = 'error';
        }
    }
    catch (e) {
        fail(this.feedback(e, 'Não foi possível carregar os dados.'));
        this.pageStatus = 'error';
    } this.publish('ui.movimentacoes.pageStatus', this.pageStatus); }
    /** setter for state ui.movimentacoes.scenary */
    setUiScenary(value) {
        const allowed = ['base', 'createMovimentacaoEstoque'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        if (value === 'createMovimentacaoEstoque' && ((this.stateCreateMovimentacaoEstoqueProdutoId == null || String(this.stateCreateMovimentacaoEstoqueProdutoId) === '') || (this.stateCreateMovimentacaoEstoqueMovimentadoEm == null || String(this.stateCreateMovimentacaoEstoqueMovimentadoEm) === '') || (this.stateCreateMovimentacaoEstoqueDetailsTipo == null || String(this.stateCreateMovimentacaoEstoqueDetailsTipo) === '') || (this.stateCreateMovimentacaoEstoqueDetailsQuantidade == null || String(this.stateCreateMovimentacaoEstoqueDetailsQuantidade) === '')))
            next = 'base';
        this.scenary = next;
        setState('ui.movimentacoes.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const rawProdutoId = params.get('produtoId') || '';
        if (rawProdutoId) {
            if (this.stateCreateMovimentacaoEstoqueProdutoId == null || String(this.stateCreateMovimentacaoEstoqueProdutoId) === '') {
                this.stateCreateMovimentacaoEstoqueProdutoId = rawProdutoId;
                setState('ui.movimentacoes.createMovimentacaoEstoque.input.produtoId', rawProdutoId);
            }
        }
        const rawMovimentadoEm = params.get('movimentadoEm') || '';
        if (rawMovimentadoEm) {
            if (this.stateCreateMovimentacaoEstoqueMovimentadoEm == null || String(this.stateCreateMovimentacaoEstoqueMovimentadoEm) === '') {
                this.stateCreateMovimentacaoEstoqueMovimentadoEm = rawMovimentadoEm;
                setState('ui.movimentacoes.createMovimentacaoEstoque.input.movimentadoEm', rawMovimentadoEm);
            }
        }
        const rawTipo = params.get('tipo') || '';
        if (rawTipo) {
            if (this.stateCreateMovimentacaoEstoqueDetailsTipo == null || String(this.stateCreateMovimentacaoEstoqueDetailsTipo) === '') {
                if (['entrada', 'saida'].includes(rawTipo)) {
                    this.stateCreateMovimentacaoEstoqueDetailsTipo = rawTipo;
                    setState('ui.movimentacoes.createMovimentacaoEstoque.input.details.tipo', rawTipo);
                }
            }
        }
        const rawQuantidade = params.get('quantidade') || '';
        if (rawQuantidade) {
            if (this.stateCreateMovimentacaoEstoqueDetailsQuantidade == null || String(this.stateCreateMovimentacaoEstoqueDetailsQuantidade) === '') {
                const stateCreateMovimentacaoEstoqueDetailsQuantidadeNum = Number(rawQuantidade);
                if (Number.isFinite(stateCreateMovimentacaoEstoqueDetailsQuantidadeNum)) {
                    this.stateCreateMovimentacaoEstoqueDetailsQuantidade = stateCreateMovimentacaoEstoqueDetailsQuantidadeNum;
                    setState('ui.movimentacoes.createMovimentacaoEstoque.input.details.quantidade', stateCreateMovimentacaoEstoqueDetailsQuantidadeNum);
                }
            }
        }
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
    enterBaseScenario() { this.setScenario('base'); }
    enterCreateMovimentacaoEstoqueScenario() { if (this.createPreconditions())
        this.setScenario('createMovimentacaoEstoque'); }
    connectedCallback() { super.connectedCallback(); for (const k of stateKeys) {
        const v = getState(k);
        if (v !== undefined)
            this.handleIcaStateChange(k, v);
    } subscribe(stateKeys, this); this.applyUrlScenary(); void this.runListMovimentacaoEstoque(); void this.runListProduto(); }
    disconnectedCallback() { unsubscribe(stateKeys, this); super.disconnectedCallback(); }
    handleIcaStateChange(key, value) { if (value === undefined)
        return; const m = { 'ui.movimentacoes.pageStatus': 'pageStatus', 'ui.movimentacoes.scenary': 'scenary', 'ui.movimentacoes.createMovimentacaoEstoque.input.produtoId': 'stateCreateMovimentacaoEstoqueProdutoId', 'ui.movimentacoes.createMovimentacaoEstoque.input.movimentadoEm': 'stateCreateMovimentacaoEstoqueMovimentadoEm', 'ui.movimentacoes.createMovimentacaoEstoque.input.details.tipo': 'stateCreateMovimentacaoEstoqueDetailsTipo', 'ui.movimentacoes.createMovimentacaoEstoque.input.details.quantidade': 'stateCreateMovimentacaoEstoqueDetailsQuantidade', 'ui.movimentacoes.createMovimentacaoEstoque.status': 'stateCreateMovimentacaoEstoqueStatus', 'ui.movimentacoes.createMovimentacaoEstoque.error': 'stateCreateMovimentacaoEstoqueError', 'ui.movimentacoes.createMovimentacaoEstoque.result': 'stateCreateMovimentacaoEstoqueResult', 'ui.movimentacoes.listMovimentacaoEstoque.input.id': 'stateListMovimentacaoEstoqueId', 'ui.movimentacoes.listMovimentacaoEstoque.input.produtoId': 'stateListMovimentacaoEstoqueProdutoId', 'ui.movimentacoes.listMovimentacaoEstoque.input.movimentadoEm': 'stateListMovimentacaoEstoqueMovimentadoEm', 'ui.movimentacoes.listMovimentacaoEstoque.input.page': 'stateListMovimentacaoEstoquePage', 'ui.movimentacoes.listMovimentacaoEstoque.status': 'stateListMovimentacaoEstoqueStatus', 'ui.movimentacoes.listMovimentacaoEstoque.error': 'stateListMovimentacaoEstoqueError', 'ui.movimentacoes.listMovimentacaoEstoque.result': 'stateListMovimentacaoEstoqueResult', 'ui.movimentacoes.listProduto.input.id': 'stateListProdutoId', 'ui.movimentacoes.listProduto.input.details.identification.subtype': 'stateListProdutoDetailsIdentificationSubtype', 'ui.movimentacoes.listProduto.input.details.identification.name': 'stateListProdutoDetailsIdentificationName', 'ui.movimentacoes.listProduto.input.details.identification.status': 'stateListProdutoDetailsIdentificationStatus', 'ui.movimentacoes.listProduto.input.page': 'stateListProdutoPage', 'ui.movimentacoes.listProduto.status': 'stateListProdutoStatus', 'ui.movimentacoes.listProduto.error': 'stateListProdutoError', 'ui.movimentacoes.listProduto.result': 'stateListProdutoResult' }; const member = m[key]; if (member)
        this[member] = value; this.requestUpdate(); }
}
export { MovimentacoesShared as ControleEstoqueMovimentacoesBase };

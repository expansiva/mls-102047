/// <mls fileReference="_102047_/l2/controleEstoque/web/shared/produtos.ts" enhancement="_102020_/l2/enhancementAura"/>
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
import { createMovimentacaoEstoqueRoute, createProdutoRoute, listMovimentacaoEstoqueRoute, listProdutoRoute } from '/_102047_/l2/controleEstoque/web/contracts/produtos.defs.js';
export class ProdutosShared extends StateLitElement {
    constructor() {
        super(...arguments);
        this.pageStatus = 'idle';
        this.scenary = 'base';
        this.stateCreateMovimentacaoEstoqueProdutoId = null;
        this.stateCreateMovimentacaoEstoqueMovimentadoEm = null;
        this.stateCreateMovimentacaoEstoqueDetailsTipo = null;
        this.stateCreateMovimentacaoEstoqueDetailsQuantidade = null;
        this.stateCreateMovimentacaoEstoqueStatus = 'idle';
        this.stateCreateMovimentacaoEstoqueError = null;
        this.stateCreateMovimentacaoEstoqueResult = null;
        this.stateCreateProdutoDetailsIdentificationName = null;
        this.stateCreateProdutoDetailsProductUnitOfMeasure = null;
        this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima = null;
        this.stateCreateProdutoStatus = 'idle';
        this.stateCreateProdutoError = null;
        this.stateCreateProdutoResult = null;
        this.stateListMovimentacaoEstoqueId = null;
        this.stateListMovimentacaoEstoqueProdutoId = null;
        this.stateListMovimentacaoEstoqueMovimentadoEm = null;
        this.stateListMovimentacaoEstoquePage = null;
        this.stateListMovimentacaoEstoqueStatus = 'idle';
        this.stateListMovimentacaoEstoqueError = null;
        this.stateListMovimentacaoEstoqueResult = [];
        this.stateListProdutoId = null;
        this.stateListProdutoDetailsIdentificationSubtype = null;
        this.stateListProdutoDetailsIdentificationName = null;
        this.stateListProdutoDetailsIdentificationStatus = null;
        this.stateListProdutoPage = null;
        this.stateListProdutoStatus = 'idle';
        this.stateListProdutoError = null;
        this.stateListProdutoResult = [];
        this.subscribedStateKeys = ['ui.produtos.pageStatus', 'ui.produtos.scenary', 'ui.produtos.createMovimentacaoEstoque.input.produtoId', 'ui.produtos.createMovimentacaoEstoque.input.movimentadoEm', 'ui.produtos.createMovimentacaoEstoque.input.details.tipo', 'ui.produtos.createMovimentacaoEstoque.input.details.quantidade', 'ui.produtos.createMovimentacaoEstoque.status', 'ui.produtos.createMovimentacaoEstoque.error', 'ui.produtos.createMovimentacaoEstoque.result', 'ui.produtos.createProduto.input.details.identification.name', 'ui.produtos.createProduto.input.details.product.unitOfMeasure', 'ui.produtos.createProduto.input.details.controleEstoque.quantidadeMinima', 'ui.produtos.createProduto.status', 'ui.produtos.createProduto.error', 'ui.produtos.createProduto.result', 'ui.produtos.listMovimentacaoEstoque.input.id', 'ui.produtos.listMovimentacaoEstoque.input.produtoId', 'ui.produtos.listMovimentacaoEstoque.input.movimentadoEm', 'ui.produtos.listMovimentacaoEstoque.input.page', 'ui.produtos.listMovimentacaoEstoque.status', 'ui.produtos.listMovimentacaoEstoque.error', 'ui.produtos.listMovimentacaoEstoque.result', 'ui.produtos.listProduto.input.id', 'ui.produtos.listProduto.input.details.identification.subtype', 'ui.produtos.listProduto.input.details.identification.name', 'ui.produtos.listProduto.input.details.identification.status', 'ui.produtos.listProduto.input.page', 'ui.produtos.listProduto.status', 'ui.produtos.listProduto.error', 'ui.produtos.listProduto.result'];
    }
    errorFrom(error, fallback) { if (error && typeof error === 'object' && 'message' in error && typeof error.message === 'string')
        return { ...error, message: error.message }; return { code: 'frontend_error', message: fallback, details: error }; }
    publish(key, value) { setState(key, value); }
    async refresh(ids) { for (const id of ids) {
        if (id === 'listProduto')
            await this.runListProduto();
        if (id === 'listMovimentacaoEstoque')
            await this.runListMovimentacaoEstoque();
    } }
    connectedCallback() { super.connectedCallback(); for (const key of this.subscribedStateKeys) {
        const value = getState(key);
        if (value !== undefined)
            this.handleIcaStateChange(key, value);
    } subscribe(this.subscribedStateKeys, this); this.applyUrlScenary(); void this.runListMovimentacaoEstoque(); void this.runListProduto(); }
    disconnectedCallback() { unsubscribe(this.subscribedStateKeys, this); super.disconnectedCallback(); }
    handleIcaStateChange(key, value) { if (value === undefined)
        return; const v = { 'ui.produtos.pageStatus': x => this.pageStatus = x, 'ui.produtos.scenary': x => this.scenary = x, 'ui.produtos.createMovimentacaoEstoque.input.produtoId': x => this.stateCreateMovimentacaoEstoqueProdutoId = x, 'ui.produtos.createMovimentacaoEstoque.input.movimentadoEm': x => this.stateCreateMovimentacaoEstoqueMovimentadoEm = x, 'ui.produtos.createMovimentacaoEstoque.input.details.tipo': x => this.stateCreateMovimentacaoEstoqueDetailsTipo = x, 'ui.produtos.createMovimentacaoEstoque.input.details.quantidade': x => this.stateCreateMovimentacaoEstoqueDetailsQuantidade = x, 'ui.produtos.createMovimentacaoEstoque.status': x => this.stateCreateMovimentacaoEstoqueStatus = x, 'ui.produtos.createMovimentacaoEstoque.error': x => this.stateCreateMovimentacaoEstoqueError = x, 'ui.produtos.createMovimentacaoEstoque.result': x => this.stateCreateMovimentacaoEstoqueResult = x, 'ui.produtos.createProduto.input.details.identification.name': x => this.stateCreateProdutoDetailsIdentificationName = x, 'ui.produtos.createProduto.input.details.product.unitOfMeasure': x => this.stateCreateProdutoDetailsProductUnitOfMeasure = x, 'ui.produtos.createProduto.input.details.controleEstoque.quantidadeMinima': x => this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima = x, 'ui.produtos.createProduto.status': x => this.stateCreateProdutoStatus = x, 'ui.produtos.createProduto.error': x => this.stateCreateProdutoError = x, 'ui.produtos.createProduto.result': x => this.stateCreateProdutoResult = x, 'ui.produtos.listMovimentacaoEstoque.input.id': x => this.stateListMovimentacaoEstoqueId = x, 'ui.produtos.listMovimentacaoEstoque.input.produtoId': x => this.stateListMovimentacaoEstoqueProdutoId = x, 'ui.produtos.listMovimentacaoEstoque.input.movimentadoEm': x => this.stateListMovimentacaoEstoqueMovimentadoEm = x, 'ui.produtos.listMovimentacaoEstoque.input.page': x => this.stateListMovimentacaoEstoquePage = x, 'ui.produtos.listMovimentacaoEstoque.status': x => this.stateListMovimentacaoEstoqueStatus = x, 'ui.produtos.listMovimentacaoEstoque.error': x => this.stateListMovimentacaoEstoqueError = x, 'ui.produtos.listMovimentacaoEstoque.result': x => this.stateListMovimentacaoEstoqueResult = x, 'ui.produtos.listProduto.input.id': x => this.stateListProdutoId = x, 'ui.produtos.listProduto.input.details.identification.subtype': x => this.stateListProdutoDetailsIdentificationSubtype = x, 'ui.produtos.listProduto.input.details.identification.name': x => this.stateListProdutoDetailsIdentificationName = x, 'ui.produtos.listProduto.input.details.identification.status': x => this.stateListProdutoDetailsIdentificationStatus = x, 'ui.produtos.listProduto.input.page': x => this.stateListProdutoPage = x, 'ui.produtos.listProduto.status': x => this.stateListProdutoStatus = x, 'ui.produtos.listProduto.error': x => this.stateListProdutoError = x, 'ui.produtos.listProduto.result': x => this.stateListProdutoResult = x }; if (v[key])
        v[key](value); this.requestUpdate(); }
    put(key, value, assign) { assign(value); this.publish(key, value); }
    setCreateMovimentacaoEstoqueMovimentadoEm(v) { this.put('ui.produtos.createMovimentacaoEstoque.input.movimentadoEm', v, x => this.stateCreateMovimentacaoEstoqueMovimentadoEm = x); }
    setCreateMovimentacaoEstoqueDetailsTipo(v) { this.put('ui.produtos.createMovimentacaoEstoque.input.details.tipo', v, x => this.stateCreateMovimentacaoEstoqueDetailsTipo = x); }
    setCreateMovimentacaoEstoqueDetailsQuantidade(v) { this.put('ui.produtos.createMovimentacaoEstoque.input.details.quantidade', v, x => this.stateCreateMovimentacaoEstoqueDetailsQuantidade = x); }
    setCreateProdutoDetailsIdentificationName(v) { this.put('ui.produtos.createProduto.input.details.identification.name', v, x => this.stateCreateProdutoDetailsIdentificationName = x); }
    setCreateProdutoDetailsProductUnitOfMeasure(v) { this.put('ui.produtos.createProduto.input.details.product.unitOfMeasure', v, x => this.stateCreateProdutoDetailsProductUnitOfMeasure = x); }
    setCreateProdutoDetailsControleEstoqueQuantidadeMinima(v) { this.put('ui.produtos.createProduto.input.details.controleEstoque.quantidadeMinima', v, x => this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima = x); }
    setListMovimentacaoEstoqueId(v) { this.put('ui.produtos.listMovimentacaoEstoque.input.id', v, x => this.stateListMovimentacaoEstoqueId = x); }
    setListMovimentacaoEstoqueMovimentadoEm(v) { this.put('ui.produtos.listMovimentacaoEstoque.input.movimentadoEm', v, x => this.stateListMovimentacaoEstoqueMovimentadoEm = x); }
    setListProdutoId(v) { this.put('ui.produtos.listProduto.input.id', v, x => this.stateListProdutoId = x); }
    setListProdutoDetailsIdentificationSubtype(v) { this.put('ui.produtos.listProduto.input.details.identification.subtype', v, x => this.stateListProdutoDetailsIdentificationSubtype = x); }
    setListProdutoDetailsIdentificationName(v) { this.put('ui.produtos.listProduto.input.details.identification.name', v, x => this.stateListProdutoDetailsIdentificationName = x); }
    setListProdutoDetailsIdentificationStatus(v) { this.put('ui.produtos.listProduto.input.details.identification.status', v, x => this.stateListProdutoDetailsIdentificationStatus = x); }
    selectCreateMovimentacaoEstoqueProdutoId(id) { this.selectProduct('ui.produtos.createMovimentacaoEstoque.input.produtoId', id, true); }
    selectListMovimentacaoEstoqueProdutoId(id) { this.selectProduct('ui.produtos.listMovimentacaoEstoque.input.produtoId', id, false); }
    selectProduct(key, id, required) { if (id === null || id === '') {
        this.publish(key, null);
        if (required)
            this.stateCreateMovimentacaoEstoqueProdutoId = null;
        else
            this.stateListMovimentacaoEstoqueProdutoId = null;
        return;
    } const row = this.stateListProdutoResult.find((x) => x.id === id); if (!row) {
        const e = this.errorFrom(null, 'errors.selection.identityNotFound');
        if (required)
            this.setCreateMovimentacaoError(e);
        else {
            this.stateListProdutoError = e;
            this.publish('ui.produtos.listProduto.error', e);
        }
        return;
    } this.publish(key, row.id); if (required)
        this.stateCreateMovimentacaoEstoqueProdutoId = row.id;
    else
        this.stateListMovimentacaoEstoqueProdutoId = row.id; this.requestUpdate(); }
    setCreateMovimentacaoError(e) { this.stateCreateMovimentacaoEstoqueError = e; this.stateCreateMovimentacaoEstoqueStatus = 'error'; this.publish('ui.produtos.createMovimentacaoEstoque.error', e); this.publish('ui.produtos.createMovimentacaoEstoque.status', 'error'); }
    setCreateProdutoError(e) { this.stateCreateProdutoError = e; this.stateCreateProdutoStatus = 'error'; this.publish('ui.produtos.createProduto.error', e); this.publish('ui.produtos.createProduto.status', 'error'); }
    async runCreateMovimentacaoEstoque() { if (this.stateCreateMovimentacaoEstoqueStatus === 'loading')
        return; const produtoId = this.stateCreateMovimentacaoEstoqueProdutoId, movimentadoEm = this.stateCreateMovimentacaoEstoqueMovimentadoEm, tipo = this.stateCreateMovimentacaoEstoqueDetailsTipo, quantidade = this.stateCreateMovimentacaoEstoqueDetailsQuantidade; if (!produtoId || !movimentadoEm || !tipo || quantidade === null) {
        this.setCreateMovimentacaoError(this.errorFrom(null, 'errors.createMovimentacaoEstoque.required'));
        return;
    } this.stateCreateMovimentacaoEstoqueStatus = 'loading'; this.publish('ui.produtos.createMovimentacaoEstoque.status', 'loading'); this.publish('ui.produtos.createMovimentacaoEstoque.error', null); try {
        const response = await runBlockingUiAction((signal) => execBff(createMovimentacaoEstoqueRoute, { produtoId, movimentadoEm, details: { tipo, quantidade } }, { mode: 'blocking', signal }), { mode: 'blocking' });
        if (response === undefined) {
            this.setCreateMovimentacaoError(this.errorFrom(null, 'errors.createMovimentacaoEstoque.failed'));
            return;
        }
        if (!response.ok || response.data === null) {
            const feedback = response.error;
            const message = feedback && typeof feedback === 'object' && 'message' in feedback && typeof feedback.message === 'string' ? feedback.message : 'errors.createMovimentacaoEstoque.failed';
            this.setCreateMovimentacaoError(this.errorFrom(feedback, message));
            return;
        }
        this.stateCreateMovimentacaoEstoqueResult = response.data;
        this.publish('ui.produtos.createMovimentacaoEstoque.result', response.data);
        this.stateCreateMovimentacaoEstoqueStatus = 'success';
        this.publish('ui.produtos.createMovimentacaoEstoque.status', 'success');
        await this.refresh(['listMovimentacaoEstoque', 'listProduto']);
    }
    catch (e) {
        this.setCreateMovimentacaoError(this.errorFrom(e, 'errors.createMovimentacaoEstoque.failed'));
    } }
    async runCreateProduto() { if (this.stateCreateProdutoStatus === 'loading')
        return; const name = this.stateCreateProdutoDetailsIdentificationName, unit = this.stateCreateProdutoDetailsProductUnitOfMeasure, minimum = this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima; if (!name || !unit || minimum === null) {
        this.setCreateProdutoError(this.errorFrom(null, 'errors.createProduto.required'));
        return;
    } this.stateCreateProdutoStatus = 'loading'; this.publish('ui.produtos.createProduto.status', 'loading'); this.publish('ui.produtos.createProduto.error', null); try {
        const params = { details: { identification: { name }, product: { unitOfMeasure: unit }, controleEstoque: { quantidadeMinima: minimum } } };
        const response = await runBlockingUiAction((signal) => execBff(createProdutoRoute, params, { mode: 'blocking', signal }), { mode: 'blocking' });
        if (response === undefined) {
            this.setCreateProdutoError(this.errorFrom(null, 'errors.createProduto.failed'));
            return;
        }
        if (!response.ok || response.data === null) {
            const feedback = response.error;
            const message = feedback && typeof feedback === 'object' && 'message' in feedback && typeof feedback.message === 'string' ? feedback.message : 'errors.createProduto.failed';
            this.setCreateProdutoError(this.errorFrom(feedback, message));
            return;
        }
        this.stateCreateProdutoResult = response.data;
        this.publish('ui.produtos.createProduto.result', response.data);
        this.stateCreateProdutoStatus = 'success';
        this.publish('ui.produtos.createProduto.status', 'success');
        await this.refresh(['listProduto']);
    }
    catch (e) {
        this.setCreateProdutoError(this.errorFrom(e, 'errors.createProduto.failed'));
    } }
    async runListMovimentacaoEstoque() { this.stateListMovimentacaoEstoqueStatus = 'loading'; this.publish('ui.produtos.listMovimentacaoEstoque.status', 'loading'); const params = {}; if (this.stateListMovimentacaoEstoqueId)
        params.id = this.stateListMovimentacaoEstoqueId; if (this.stateListMovimentacaoEstoqueProdutoId)
        params.produtoId = this.stateListMovimentacaoEstoqueProdutoId; if (this.stateListMovimentacaoEstoqueMovimentadoEm)
        params.movimentadoEm = this.stateListMovimentacaoEstoqueMovimentadoEm; if (this.stateListMovimentacaoEstoquePage !== null)
        params.page = this.stateListMovimentacaoEstoquePage; try {
        const r = await execBff(listMovimentacaoEstoqueRoute, params, { mode: 'silent' });
        if (!r.ok || r.data === null) {
            const er = this.errorFrom(r.error, 'errors.listMovimentacaoEstoque.failed');
            this.stateListMovimentacaoEstoqueError = er;
            this.stateListMovimentacaoEstoqueStatus = 'error';
            this.publish('ui.produtos.listMovimentacaoEstoque.error', er);
            this.publish('ui.produtos.listMovimentacaoEstoque.status', 'error');
            return;
        }
        this.stateListMovimentacaoEstoqueResult = r.data;
        this.stateListMovimentacaoEstoqueStatus = 'success';
        this.publish('ui.produtos.listMovimentacaoEstoque.result', r.data);
        this.publish('ui.produtos.listMovimentacaoEstoque.status', 'success');
    }
    catch (e) {
        const er = this.errorFrom(e, 'errors.listMovimentacaoEstoque.failed');
        this.stateListMovimentacaoEstoqueError = er;
        this.stateListMovimentacaoEstoqueStatus = 'error';
        this.publish('ui.produtos.listMovimentacaoEstoque.error', er);
        this.publish('ui.produtos.listMovimentacaoEstoque.status', 'error');
    } }
    async runListProduto() { this.stateListProdutoStatus = 'loading'; this.publish('ui.produtos.listProduto.status', 'loading'); const params = {}; if (this.stateListProdutoId)
        params.id = this.stateListProdutoId; const identification = {}; if (this.stateListProdutoDetailsIdentificationSubtype)
        identification.subtype = this.stateListProdutoDetailsIdentificationSubtype; if (this.stateListProdutoDetailsIdentificationName)
        identification.name = this.stateListProdutoDetailsIdentificationName; if (this.stateListProdutoDetailsIdentificationStatus)
        identification.status = this.stateListProdutoDetailsIdentificationStatus; if (Object.keys(identification).length)
        params.details = { identification }; if (this.stateListProdutoPage !== null)
        params.page = this.stateListProdutoPage; try {
        const r = await execBff(listProdutoRoute, params, { mode: 'silent' });
        if (!r.ok || r.data === null) {
            const er = this.errorFrom(r.error, 'errors.listProduto.failed');
            this.stateListProdutoError = er;
            this.stateListProdutoStatus = 'error';
            this.publish('ui.produtos.listProduto.error', er);
            this.publish('ui.produtos.listProduto.status', 'error');
            return;
        }
        this.stateListProdutoResult = r.data;
        this.stateListProdutoStatus = 'success';
        this.publish('ui.produtos.listProduto.result', r.data);
        this.publish('ui.produtos.listProduto.status', 'success');
    }
    catch (e) {
        const er = this.errorFrom(e, 'errors.listProduto.failed');
        this.stateListProdutoError = er;
        this.stateListProdutoStatus = 'error';
        this.publish('ui.produtos.listProduto.error', er);
        this.publish('ui.produtos.listProduto.status', 'error');
    } }
    setScenario(value) { const checks = { base: [], detail: [this.stateListProdutoId], createMovimentacaoEstoque: [this.stateCreateMovimentacaoEstoqueProdutoId, this.stateCreateMovimentacaoEstoqueMovimentadoEm, this.stateCreateMovimentacaoEstoqueDetailsTipo, this.stateCreateMovimentacaoEstoqueDetailsQuantidade], createProduto: [this.stateCreateProdutoDetailsIdentificationName, this.stateCreateProdutoDetailsProductUnitOfMeasure, this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima] }; if (checks[value] === undefined || checks[value].some((x) => x === null || x === undefined || x === '')) {
        console.warn('errors.scenary.precondition');
        return;
    } this.scenary = value; this.publish('ui.produtos.scenary', value); this.requestUpdate(); }
    stateScenarioError(message) { console.warn(message); }
    enterBaseScenario() { this.setScenario('base'); }
    enterDetailScenario() { this.setScenario('detail'); }
    enterCreateMovimentacaoEstoqueScenario() { this.setScenario('createMovimentacaoEstoque'); }
    enterCreateProdutoScenario() { this.setScenario('createProduto'); }
    /** setter for state ui.produtos.scenary */
    setUiScenary(value) {
        const allowed = ['base', 'detail', 'createMovimentacaoEstoque', 'createProduto'];
        if (!allowed.includes(value)) {
            console.warn('setUiScenary: unknown value \'' + value + '\'');
            return;
        }
        let next = value;
        if (value === 'detail' && ((this.stateListProdutoId == null || String(this.stateListProdutoId) === '')))
            next = 'base';
        if (value === 'createMovimentacaoEstoque' && ((this.stateCreateMovimentacaoEstoqueProdutoId == null || String(this.stateCreateMovimentacaoEstoqueProdutoId) === '') || (this.stateCreateMovimentacaoEstoqueMovimentadoEm == null || String(this.stateCreateMovimentacaoEstoqueMovimentadoEm) === '') || (this.stateCreateMovimentacaoEstoqueDetailsTipo == null || String(this.stateCreateMovimentacaoEstoqueDetailsTipo) === '') || (this.stateCreateMovimentacaoEstoqueDetailsQuantidade == null || String(this.stateCreateMovimentacaoEstoqueDetailsQuantidade) === '')))
            next = 'base';
        if (value === 'createProduto' && ((this.stateCreateProdutoDetailsIdentificationName == null || String(this.stateCreateProdutoDetailsIdentificationName) === '') || (this.stateCreateProdutoDetailsProductUnitOfMeasure == null || String(this.stateCreateProdutoDetailsProductUnitOfMeasure) === '') || (this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima == null || String(this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima) === '')))
            next = 'base';
        this.scenary = next;
        setState('ui.produtos.scenary', next);
        this.syncScenaryQuery(next);
        this.requestUpdate();
    }
    /** handler for action set.uiScenary — bind UI events here */
    handleUiScenaryChange(event) {
        const custom = event;
        const fromDetail = custom.detail && typeof custom.detail.value === 'string' ? custom.detail.value : '';
        const target = event.target;
        const value = fromDetail || (target && 'value' in target ? String(target.value) : '');
        this.setUiScenary(value);
    }
    applyUrlScenary() {
        const params = new URLSearchParams(window.location.search);
        const rawId = params.get('id') || '';
        if (rawId) {
            if (this.stateListProdutoId == null || String(this.stateListProdutoId) === '') {
                this.stateListProdutoId = rawId;
                setState('ui.produtos.listProduto.input.id', rawId);
            }
        }
        const rawProdutoId = params.get('produtoId') || '';
        if (rawProdutoId) {
            if (this.stateCreateMovimentacaoEstoqueProdutoId == null || String(this.stateCreateMovimentacaoEstoqueProdutoId) === '') {
                this.stateCreateMovimentacaoEstoqueProdutoId = rawProdutoId;
                setState('ui.produtos.createMovimentacaoEstoque.input.produtoId', rawProdutoId);
            }
        }
        const rawMovimentadoEm = params.get('movimentadoEm') || '';
        if (rawMovimentadoEm) {
            if (this.stateCreateMovimentacaoEstoqueMovimentadoEm == null || String(this.stateCreateMovimentacaoEstoqueMovimentadoEm) === '') {
                this.stateCreateMovimentacaoEstoqueMovimentadoEm = rawMovimentadoEm;
                setState('ui.produtos.createMovimentacaoEstoque.input.movimentadoEm', rawMovimentadoEm);
            }
        }
        const rawTipo = params.get('tipo') || '';
        if (rawTipo) {
            if (this.stateCreateMovimentacaoEstoqueDetailsTipo == null || String(this.stateCreateMovimentacaoEstoqueDetailsTipo) === '') {
                if (['entrada', 'saida'].includes(rawTipo)) {
                    this.stateCreateMovimentacaoEstoqueDetailsTipo = rawTipo;
                    setState('ui.produtos.createMovimentacaoEstoque.input.details.tipo', rawTipo);
                }
            }
        }
        const rawQuantidade = params.get('quantidade') || '';
        if (rawQuantidade) {
            if (this.stateCreateMovimentacaoEstoqueDetailsQuantidade == null || String(this.stateCreateMovimentacaoEstoqueDetailsQuantidade) === '') {
                const stateCreateMovimentacaoEstoqueDetailsQuantidadeNum = Number(rawQuantidade);
                if (Number.isFinite(stateCreateMovimentacaoEstoqueDetailsQuantidadeNum)) {
                    this.stateCreateMovimentacaoEstoqueDetailsQuantidade = stateCreateMovimentacaoEstoqueDetailsQuantidadeNum;
                    setState('ui.produtos.createMovimentacaoEstoque.input.details.quantidade', stateCreateMovimentacaoEstoqueDetailsQuantidadeNum);
                }
            }
        }
        const rawName = params.get('name') || '';
        if (rawName) {
            if (this.stateCreateProdutoDetailsIdentificationName == null || String(this.stateCreateProdutoDetailsIdentificationName) === '') {
                this.stateCreateProdutoDetailsIdentificationName = rawName;
                setState('ui.produtos.createProduto.input.details.identification.name', rawName);
            }
        }
        const rawUnitOfMeasure = params.get('unitOfMeasure') || '';
        if (rawUnitOfMeasure) {
            if (this.stateCreateProdutoDetailsProductUnitOfMeasure == null || String(this.stateCreateProdutoDetailsProductUnitOfMeasure) === '') {
                this.stateCreateProdutoDetailsProductUnitOfMeasure = rawUnitOfMeasure;
                setState('ui.produtos.createProduto.input.details.product.unitOfMeasure', rawUnitOfMeasure);
            }
        }
        const rawQuantidadeMinima = params.get('quantidadeMinima') || '';
        if (rawQuantidadeMinima) {
            if (this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima == null || String(this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima) === '') {
                const stateCreateProdutoDetailsControleEstoqueQuantidadeMinimaNum = Number(rawQuantidadeMinima);
                if (Number.isFinite(stateCreateProdutoDetailsControleEstoqueQuantidadeMinimaNum)) {
                    this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima = stateCreateProdutoDetailsControleEstoqueQuantidadeMinimaNum;
                    setState('ui.produtos.createProduto.input.details.controleEstoque.quantidadeMinima', stateCreateProdutoDetailsControleEstoqueQuantidadeMinimaNum);
                }
            }
        }
        const requested = params.get('scenary') || 'base';
        this.setUiScenary(requested);
    }
    syncScenaryQuery(value) {
        const url = new URL(window.location.href);
        if (value === 'base')
            url.searchParams.delete('scenary');
        else
            url.searchParams.set('scenary', value);
        window.history.replaceState(window.history.state, '', `${url.pathname}${url.search}${url.hash}`);
    }
}
export { ProdutosShared as ControleEstoqueProdutosBase };

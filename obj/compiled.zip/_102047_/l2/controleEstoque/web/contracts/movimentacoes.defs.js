/// <mls fileReference="_102047_/l2/controleEstoque/web/contracts/movimentacoes.defs.ts" enhancement="_blank"/>
export {};

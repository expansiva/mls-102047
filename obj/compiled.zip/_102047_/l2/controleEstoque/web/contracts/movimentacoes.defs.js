/// <mls fileReference="_102047_/l2/controleEstoque/web/contracts/movimentacoes.defs.ts" enhancement="_blank"/>
export const createMovimentacaoEstoqueRoute = "controleEstoque.movimentacoes.cmdCreateMovimentacaoEstoque";
export const listMovimentacaoEstoqueRoute = "controleEstoque.movimentacoes.qryListMovimentacaoEstoque";
export const listProdutoRoute = "controleEstoque.movimentacoes.qryListProduto";

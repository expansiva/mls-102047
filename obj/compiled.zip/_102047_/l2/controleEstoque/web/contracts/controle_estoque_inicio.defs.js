export const listMovimentacaoEstoqueRoute = "controleEstoque.controle_estoque_inicio.qryListMovimentacaoEstoque";
export const listProdutoRoute = "controleEstoque.controle_estoque_inicio.qryListProduto";

export const createMovimentacaoEstoqueRoute = "controleEstoque.movimentacoes_estoque.cmdCreateMovimentacaoEstoque";
export const listMovimentacaoEstoqueRoute = "controleEstoque.movimentacoes_estoque.qryListMovimentacaoEstoque";
export const listProdutoRoute = "controleEstoque.movimentacoes_estoque.qryListProduto";

export const createMovimentacaoEstoqueRoute = "controleEstoque.produtos.cmdCreateMovimentacaoEstoque";
export const createProdutoRoute = "controleEstoque.produtos.cmdCreateProduto";
export const listMovimentacaoEstoqueRoute = "controleEstoque.produtos.qryListMovimentacaoEstoque";
export const listProdutoRoute = "controleEstoque.produtos.qryListProduto";

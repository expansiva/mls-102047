/// <mls fileReference="_102047_/l2/controleEstoque/web/contracts/produtos.defs.ts" enhancement="_blank"/>
export const createMovimentacaoEstoqueRoute = "controleEstoque.produtos.cmdCreateMovimentacaoEstoque";
export const createProdutoRoute = "controleEstoque.produtos.cmdCreateProduto";
export const listMovimentacaoEstoqueRoute = "controleEstoque.produtos.qryListMovimentacaoEstoque";
export const listProdutoRoute = "controleEstoque.produtos.qryListProduto";

/// <mls fileReference="_102047_/l2/controleEstoque/web/desktop/page11/produtos.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ProdutosShared } from '/_102047_/l2/controleEstoque/web/shared/produtos.js';
import '/_102020_/l2/molecules/ml-scenary.js';
import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.js';
import '/_102040_/l2/molecules/groupentertext/ml-enter-text.js';
import '/_102040_/l2/molecules/groupenternumber/ml-number-input.js';
import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
/// **collab_i18n_start**
const pageMessage_ptBR = {
    title: 'Produtos',
    loading: 'Carregando produtos…',
    empty: 'Nenhum produto encontrado.',
    error: 'Não foi possível consultar os produtos.',
    createMovimentacaoEstoqueSuccess: 'Movimentação registrada com sucesso.',
    createProdutoSuccess: 'Produto cadastrado com sucesso.'
};
const pageMessages = { 'pt-BR': pageMessage_ptBR };
let Produtos = class Produtos extends ProdutosShared {
    get msg() {
        const locale = document.documentElement.lang || 'pt-BR';
        return pageMessages[locale] ?? pageMessages['pt-BR'];
    }
    formatStatus(status) {
        const labels = { Active: 'Ativo', Inactive: 'Inativo', Merged: 'Mesclado', Blocked: 'Bloqueado' };
        return labels[status];
    }
    formatNumber(value) { return value === undefined ? '—' : new Intl.NumberFormat('pt-BR').format(value); }
    onNameInput(event) { const detail = event.detail; if (detail && typeof detail.value === 'string')
        this.setCreateProdutoDetailsIdentificationName(detail.value); }
    onUnitInput(event) { const detail = event.detail; if (detail && typeof detail.value === 'string')
        this.setCreateProdutoDetailsProductUnitOfMeasure(detail.value); }
    onMinimumInput(event) { const detail = event.detail; if (detail && (typeof detail.value === 'number' || detail.value === null))
        this.setCreateProdutoDetailsControleEstoqueQuantidadeMinima(detail.value); }
    onMovementQuantity(event) { const detail = event.detail; if (detail && (typeof detail.value === 'number' || detail.value === null))
        this.setCreateMovimentacaoEstoqueDetailsQuantidade(detail.value); }
    onMovementType(event) { const value = event.target?.value; this.setCreateMovimentacaoEstoqueDetailsTipo(value === 'entrada' || value === 'saida' ? value : null); }
    onMovementProduct(event) { this.selectCreateMovimentacaoEstoqueProdutoId(event.target?.value || null); }
    onMovementDate(event) { this.setCreateMovimentacaoEstoqueMovimentadoEm(event.target?.value || null); }
    onProductSelect(event) {
        const detail = event.detail;
        if (!detail || typeof detail.index !== 'number')
            return;
        const row = this.stateListProdutoResult[detail.index];
        if (row) {
            this.setListProdutoId(row.id);
            this.setUiScenary('detail');
        }
    }
    renderStatus(status, error) {
        if (status === 'loading')
            return html `<p role="status" aria-live="polite">${this.msg.loading}</p>`;
        if (status === 'error')
            return html `<p role="alert">${error?.message || this.msg.error}</p>`;
        if (status === 'success' && this.stateListProdutoResult.length === 0)
            return html `<p role="status">${this.msg.empty}</p>`;
        return html ``;
    }
    renderProductRows(rows) {
        return html `<groupviewdata--ml-vertical-record-list .hoverable=${true} @row-click=${(event) => this.onProductSelect(event)}>
<Columns><Column field="name" header="Produto"></Column><Column field="status" header="Situação"></Column><Column field="unit" header="Unidade"></Column><Column field="balance" header="Saldo"></Column><Column field="minimum" header="Mínimo"></Column><Column field="warning" header="Aviso"></Column></Columns>
<Rows>${rows.map((row) => html `<Row><Cell>${row.details.identification?.name || '—'}</Cell><Cell>${row.details.identification?.status ? this.formatStatus(row.details.identification.status) : '—'}</Cell><Cell>${row.details.product?.unitOfMeasure || '—'}</Cell><Cell>${this.formatNumber(row.details.controleEstoque?.saldoAtual)}</Cell><Cell>${this.formatNumber(row.details.controleEstoque?.quantidadeMinima)}</Cell><Cell>${row.details.controleEstoque?.saldoAbaixoDoMinimo ? 'Saldo baixo' : 'Normal'}</Cell></Row>`)}</Rows>
<Empty><span>${this.msg.empty}</span></Empty><Loading><span role="status">${this.msg.loading}</span></Loading>
</groupviewdata--ml-vertical-record-list>`;
    }
    renderBase() {
        const rows = this.stateListProdutoResult;
        return html `<section aria-labelledby="produtos-titulo"><div class="page-heading"><h1 id="produtos-titulo">${this.msg.title}</h1><p>Consulte saldos, mínimos configurados e avisos de estoque baixo.</p></div>
<div class="page-actions"><grouptriggeraction--ml-button-standard data-variant="primary" @action=${() => this.setUiScenary('createProduto')}><Label>Cadastrar produto</Label></grouptriggeraction--ml-button-standard><grouptriggeraction--ml-button-standard data-variant="secondary" @action=${() => this.setUiScenary('createMovimentacaoEstoque')}><Label>Registrar entrada ou saída</Label></grouptriggeraction--ml-button-standard></div>
<section aria-labelledby="estoque-resumo"><h2 id="estoque-resumo">Posição do estoque</h2>${this.renderStatus(this.stateListProdutoStatus, this.stateListProdutoError)}${this.renderProductRows(rows)}</section>
<section aria-labelledby="estoque-alertas"><h2 id="estoque-alertas">Produtos com saldo baixo</h2>${this.stateListProdutoStatus === 'loading' ? html `<p role="status">Carregando avisos…</p>` : nothing}${this.stateListProdutoStatus === 'error' ? html `<p role="alert">Não foi possível consultar os avisos de saldo baixo.</p>` : nothing}${this.stateListProdutoStatus === 'success' && rows.filter((row) => row.details.controleEstoque?.saldoAbaixoDoMinimo === true).length === 0 ? html `<p role="status">Nenhum produto sinalizado.</p>` : nothing}${rows.filter((row) => row.details.controleEstoque?.saldoAbaixoDoMinimo === true).map((row) => html `<p>${row.details.identification?.name || 'Produto'} — saldo ${this.formatNumber(row.details.controleEstoque?.saldoAtual)}, mínimo ${this.formatNumber(row.details.controleEstoque?.quantidadeMinima)}. Saldo baixo.</p>`)}</section>
</section>`;
    }
    renderDetail() {
        const product = this.stateListProdutoResult.find((row) => row.id === this.stateListProdutoId);
        if (this.stateListProdutoStatus === 'loading')
            return html `<p role="status">Consultando produto…</p>`;
        if (this.stateListProdutoStatus === 'error')
            return html `<p role="alert">${this.stateListProdutoError?.message || 'Não foi possível consultar o produto.'}</p>`;
        if (!product)
            return html `<p role="status">Produto indisponível.</p>`;
        return html `<section aria-labelledby="produto-detalhe"><h2 id="produto-detalhe">${product.details.identification?.name || 'Produto'}</h2><dl><dt>Situação</dt><dd>${product.details.identification?.status ? this.formatStatus(product.details.identification.status) : '—'}</dd><dt>Unidade de medida</dt><dd>${product.details.product?.unitOfMeasure || '—'}</dd><dt>Saldo atual</dt><dd>${this.formatNumber(product.details.controleEstoque?.saldoAtual)}</dd><dt>Quantidade mínima</dt><dd>${this.formatNumber(product.details.controleEstoque?.quantidadeMinima)}</dd><dt>Aviso</dt><dd>${product.details.controleEstoque?.saldoAbaixoDoMinimo ? 'Saldo baixo' : 'Normal'}</dd></dl></section>`;
    }
    renderCreateProduct() {
        const busy = this.stateCreateProdutoStatus === 'loading';
        return html `<section aria-labelledby="novo-produto"><h2 id="novo-produto">Cadastrar produto</h2><p>Informe a quantidade mínima, que deve ser maior ou igual a zero.</p><groupentertext--ml-enter-text .value=${this.stateCreateProdutoDetailsIdentificationName || ''} .isEditing=${true} required @input=${(event) => this.onNameInput(event)}><Label>Nome do produto</Label></groupentertext--ml-enter-text><groupentertext--ml-enter-text .value=${this.stateCreateProdutoDetailsProductUnitOfMeasure || ''} .isEditing=${true} required @input=${(event) => this.onUnitInput(event)}><Label>Unidade de medida</Label></groupentertext--ml-enter-text><groupenternumber--ml-number-input .value=${this.stateCreateProdutoDetailsControleEstoqueQuantidadeMinima} .isEditing=${true} .min=${0} required @input=${(event) => this.onMinimumInput(event)}><Label>Quantidade mínima</Label></groupenternumber--ml-number-input>${this.stateCreateProdutoError ? html `<p role="alert">${this.stateCreateProdutoError.message}</p>` : nothing}${this.stateCreateProdutoStatus === 'success' ? html `<p role="status">${this.msg.createProdutoSuccess}</p>` : nothing}<grouptriggeraction--ml-button-standard data-variant="primary" .loading=${busy} .disabled=${busy} @action=${() => void this.runCreateProduto()}><Label>Cadastrar produto</Label></grouptriggeraction--ml-button-standard></section>`;
    }
    renderCreateMovement() {
        const busy = this.stateCreateMovimentacaoEstoqueStatus === 'loading';
        const products = this.stateListProdutoResult;
        return html `<section aria-labelledby="nova-movimentacao"><h2 id="nova-movimentacao">Registrar entrada ou saída</h2><label>Produto <select .value=${this.stateCreateMovimentacaoEstoqueProdutoId || ''} @change=${(event) => this.onMovementProduct(event)}><option value="">Selecione um produto</option>${products.map((row) => html `<option value=${row.id}>${row.details.identification?.name || row.id}</option>`)}</select></label><label>Data e hora <input type="datetime-local" .value=${this.stateCreateMovimentacaoEstoqueMovimentadoEm || ''} @change=${(event) => this.onMovementDate(event)}></label><label>Tipo <select .value=${this.stateCreateMovimentacaoEstoqueDetailsTipo || ''} @change=${(event) => this.onMovementType(event)}><option value="">Selecione</option><option value="entrada">Entrada</option><option value="saida">Saída</option></select></label><groupenternumber--ml-number-input .value=${this.stateCreateMovimentacaoEstoqueDetailsQuantidade} .isEditing=${true} .min=${1} required @input=${(event) => this.onMovementQuantity(event)}><Label>Quantidade</Label></groupenternumber--ml-number-input>${this.stateCreateMovimentacaoEstoqueError ? html `<p role="alert">${this.stateCreateMovimentacaoEstoqueError.message}</p>` : nothing}${this.stateCreateMovimentacaoEstoqueStatus === 'success' ? html `<p role="status">${this.msg.createMovimentacaoEstoqueSuccess}</p>` : nothing}<grouptriggeraction--ml-button-standard data-variant="primary" .loading=${busy} .disabled=${busy} @action=${() => void this.runCreateMovimentacaoEstoque()}><Label>Registrar movimentação</Label></grouptriggeraction--ml-button-standard></section>`;
    }
    render() {
        const scenes = [html `<Scene value="base" title="Produtos">${this.renderBase()}</Scene>`, html `<Scene value="detail" title="Detalhes do produto">${this.renderDetail()}</Scene>`, html `<Scene value="createProduto" title="Cadastrar produto">${this.renderCreateProduct()}</Scene>`, html `<Scene value="createMovimentacaoEstoque" title="Registrar movimentação">${this.renderCreateMovement()}</Scene>`];
        return html `<main class="produtos-page"><molecules--ml-scenary-102020 mode="direct" .value=${this.scenary} @change=${(event) => this.handleUiScenaryChange(event)}>${scenes}</molecules--ml-scenary-102020></main>`;
    }
};
Produtos = __decorate([
    customElement('controle-estoque--web--desktop--page11--produtos-102047')
], Produtos);
export { Produtos };

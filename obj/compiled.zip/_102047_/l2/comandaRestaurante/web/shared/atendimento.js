/// <mls fileReference="_102047_/l2/comandaRestaurante/web/shared/atendimento.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.comandaRestaurante.atendimento.contextoAtendimento': 'contextoAtendimento',
    'ui.comandaRestaurante.atendimento.comanda': 'comanda',
    'ui.comandaRestaurante.atendimento.selectedComanda': 'selectedComanda',
    'ui.comandaRestaurante.atendimento.page': 'page',
    'ui.comandaRestaurante.atendimento.mesaTermo': 'mesaTermo',
    'ui.comandaRestaurante.atendimento.comandaNumero': 'comandaNumero',
    'ui.comandaRestaurante.atendimento.itemTermo': 'itemTermo',
    'ui.comandaRestaurante.atendimento.lancarItemDraft': 'lancarItemDraft',
    'ui.comandaRestaurante.atendimento.pageStatus': 'pageStatus',
    'ui.comandaRestaurante.atendimento.carregarAtendimentoStatus': 'carregarAtendimentoStatus',
    'ui.comandaRestaurante.atendimento.carregarAtendimentoError': 'carregarAtendimentoError',
    'ui.comandaRestaurante.atendimento.atualizarLocalizacaoAtendimentoStatus': 'atualizarLocalizacaoAtendimentoStatus',
    'ui.comandaRestaurante.atendimento.atualizarLocalizacaoAtendimentoError': 'atualizarLocalizacaoAtendimentoError',
    'ui.comandaRestaurante.atendimento.obterComandaAtendimentoStatus': 'obterComandaAtendimentoStatus',
    'ui.comandaRestaurante.atendimento.obterComandaAtendimentoError': 'obterComandaAtendimentoError',
    'ui.comandaRestaurante.atendimento.abrirComandaStatus': 'abrirComandaStatus',
    'ui.comandaRestaurante.atendimento.abrirComandaError': 'abrirComandaError',
    'ui.comandaRestaurante.atendimento.lancarItemStatus': 'lancarItemStatus',
    'ui.comandaRestaurante.atendimento.lancarItemError': 'lancarItemError',
    'ui.comandaRestaurante.atendimento.cancelarItemStatus': 'cancelarItemStatus',
    'ui.comandaRestaurante.atendimento.cancelarItemError': 'cancelarItemError',
    'ui.comandaRestaurante.atendimento.scenary': 'scenary'
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_SIZE = 20;
export class ComandaRestauranteAtendimentoShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state contextoAtendimento — independent collections used to locate the table, open tab and menu item; source carregarAtendimento.contextoAtendimento; organism lookupAtendimento */
        this.contextoAtendimento = null;
        /** state comanda — the selected tab with its table, all lines and calculated subtotal; source obterComandaAtendimento.comanda; organism detalheComanda */
        this.comanda = null;
        /** state selectedComanda — the selected tab identifier; source entry.params.comandaId; organism detalheComanda; persisted */
        this.selectedComanda = null;
        /** state page — the current lookup page; source entry.params.page; organism lookupAtendimento; persisted */
        this.page = null;
        /** state mesaTermo — the table-code lookup term; source entry.params.mesaTermo; organism lookupAtendimento; persisted */
        this.mesaTermo = null;
        /** state comandaNumero — the open-tab number lookup value; source entry.params.comandaNumero; organism lookupAtendimento; persisted */
        this.comandaNumero = null;
        /** state itemTermo — the menu-item name lookup term; source entry.params.itemTermo; organism lookupAtendimento; persisted */
        this.itemTermo = null;
        /** state lancarItemDraft — the menu-item launch form draft; source lancarItem.input; organism formularioLancamento */
        this.lancarItemDraft = this.emptyDraft();
        /** state pageStatus — the overall initial-load status; source pageStatus */
        this.pageStatus = 'idle';
        /** state carregarAtendimentoStatus — the initial lookup request status; source carregarAtendimentoStatus */
        this.carregarAtendimentoStatus = 'idle';
        /** state carregarAtendimentoError — the initial lookup request error; source carregarAtendimentoError */
        this.carregarAtendimentoError = null;
        /** state atualizarLocalizacaoAtendimentoStatus — the filtered lookup request status; source atualizarLocalizacaoAtendimentoStatus */
        this.atualizarLocalizacaoAtendimentoStatus = 'idle';
        /** state atualizarLocalizacaoAtendimentoError — the filtered lookup request error; source atualizarLocalizacaoAtendimentoError */
        this.atualizarLocalizacaoAtendimentoError = null;
        /** state obterComandaAtendimentoStatus — the selected-tab request status; source obterComandaAtendimentoStatus */
        this.obterComandaAtendimentoStatus = 'idle';
        /** state obterComandaAtendimentoError — the selected-tab request error; source obterComandaAtendimentoError */
        this.obterComandaAtendimentoError = null;
        /** state abrirComandaStatus — the open-tab command status; source abrirComandaStatus */
        this.abrirComandaStatus = 'idle';
        /** state abrirComandaError — the open-tab command error; source abrirComandaError */
        this.abrirComandaError = null;
        /** state lancarItemStatus — the launch-item command status; source lancarItemStatus */
        this.lancarItemStatus = 'idle';
        /** state lancarItemError — the launch-item command error; source lancarItemError */
        this.lancarItemError = null;
        /** state cancelarItemStatus — the cancel-item command status; source cancelarItemStatus */
        this.cancelarItemStatus = 'idle';
        /** state cancelarItemError — the cancel-item request error; source cancelarItemError */
        this.cancelarItemError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    connectedCallback() {
        super.connectedCallback();
        for (const key of ['ui.comandaRestaurante.atendimento.contextoAtendimento', 'ui.comandaRestaurante.atendimento.comanda']) {
            const value = getState(key);
            if (value !== undefined)
                this.assignState(key, value);
        }
        this.resetVisit();
        subscribe(STATE_KEYS, this);
        this.applyEntryParams();
        void this.initialLoad();
    }
    disconnectedCallback() {
        unsubscribe(STATE_KEYS, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_MEMBER_BY_KEY[key]) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined)
            return;
        this.assignState(key, value);
        this.requestUpdate();
    }
    /** function carregarAtendimento — loads the initial lookup context for available tables, open tabs and menu items; redraws contextoAtendimento by replacement; takes no arguments */
    async carregarAtendimento() {
        if (this.carregarAtendimentoStatus === 'loading')
            return;
        const input = { page: this.page ?? 1, pageSize: PAGE_SIZE };
        await this.query('carregarAtendimento', 'comandaRestaurante.atendimento.carregarAtendimento', input);
    }
    /** function atualizarLocalizacaoAtendimento — refreshes the independently filtered and paged lookup context; redraws contextoAtendimento by replacement; takes the table term, tab number, item term, page and page size */
    async atualizarLocalizacaoAtendimento(mesaTermo, comandaNumero, itemTermo, page = 1, pageSize = PAGE_SIZE) {
        this.publish('mesaTermo', mesaTermo);
        this.publish('comandaNumero', comandaNumero);
        this.publish('itemTermo', itemTermo);
        this.publish('page', page);
        const input = { page, pageSize, ...(mesaTermo !== null && mesaTermo !== '' ? { mesaTermo } : {}), ...(comandaNumero !== null ? { comandaNumero } : {}), ...(itemTermo !== null && itemTermo !== '' ? { itemTermo } : {}) };
        await this.query('atualizarLocalizacaoAtendimento', 'comandaRestaurante.atendimento.atualizarLocalizacaoAtendimento', input);
    }
    /** function obterComandaAtendimento — loads the selected tab with its table, lines and subtotal; redraws comanda by replacement; takes the selected tab identifier */
    async obterComandaAtendimento(comandaId) {
        this.publish('selectedComanda', comandaId);
        const input = { comandaId };
        await this.query('obterComandaAtendimento', 'comandaRestaurante.atendimento.obterComandaAtendimento', input);
    }
    /** select — selects or clears a tab identifier and loads its complete record when an identifier is supplied */
    selectComanda(value) {
        this.publish('selectedComanda', value);
        if (value === null) {
            this.publish('comanda', null);
            return;
        }
        void this.obterComandaAtendimento(value);
    }
    /** function abrirComanda — opens a tab for the selected available table; redraws comanda by upsert and declares contextoAtendimento for update; takes the table identifier */
    async abrirComanda(mesaId) {
        if (mesaId === null || mesaId === '') {
            this.publish('abrirComandaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['mesaId'] } });
            this.publish('abrirComandaStatus', 'error');
            return;
        }
        const input = { mesaId };
        await this.command('abrirComanda', 'comandaRestaurante.atendimento.abrirComanda', input, (output) => {
            this.publish('comanda', output.comanda);
            this.publish('selectedComanda', output.comanda.id);
        });
    }
    /** function lancarItem — adds the drafted menu item to the open tab; redraws comanda by upsert; takes no arguments because the form draft supplies the command input */
    async lancarItem() {
        const draft = this.lancarItemDraft;
        const cmmId = draft.comandaId ?? this.selectedComanda;
        if (cmmId === null || cmmId === '' || draft.itemCardapioId === null || draft.itemCardapioId === '' || draft.details.quantidade === null) {
            this.publish('lancarItemError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['lancarItemDraft.comandaId', 'lancarItemDraft.itemCardapioId', 'lancarItemDraft.details.quantidade'] } });
            this.publish('lancarItemStatus', 'error');
            return;
        }
        const input = { comandaId: cmmId, itemCardapioId: draft.itemCardapioId, details: { quantidade: draft.details.quantidade, ...(draft.details.observacao !== null && draft.details.observacao !== '' ? { observacao: draft.details.observacao } : {}) } };
        await this.command('lancarItem', 'comandaRestaurante.atendimento.lancarItem', input, (output) => {
            this.publish('comanda', output.comanda);
        });
    }
    /** function cancelarItem — cancels the selected launched line; redraws comanda by upsert; takes the line identifier and concurrency version */
    async cancelarItem(id, version) {
        if (id === null || id === '' || version === null) {
            this.publish('cancelarItemError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['id', 'version'] } });
            this.publish('cancelarItemStatus', 'error');
            return;
        }
        const input = { id, version };
        await this.command('cancelarItem', 'comandaRestaurante.atendimento.cancelarItem', input, (output) => {
            this.publish('comanda', output.comanda);
        });
    }
    /** draft — updates the menu-item launch form draft */
    setLancarItemDraft(value) {
        this.publish('lancarItemDraft', value);
    }
    /** state scenary — publishes the visible page scene */
    setScenario(value) {
        this.publish('scenary', value);
    }
    emptyDraft() {
        return { comandaId: null, itemCardapioId: null, details: { quantidade: null, observacao: null } };
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('carregarAtendimentoStatus', 'idle');
        this.publish('carregarAtendimentoError', null);
        this.publish('atualizarLocalizacaoAtendimentoStatus', 'idle');
        this.publish('atualizarLocalizacaoAtendimentoError', null);
        this.publish('obterComandaAtendimentoStatus', 'idle');
        this.publish('obterComandaAtendimentoError', null);
        this.publish('abrirComandaStatus', 'idle');
        this.publish('abrirComandaError', null);
        this.publish('lancarItemStatus', 'idle');
        this.publish('lancarItemError', null);
        this.publish('cancelarItemStatus', 'idle');
        this.publish('cancelarItemError', null);
        this.publish('lancarItemDraft', this.emptyDraft());
        this.publish('scenary', '');
    }
    applyEntryParams() {
        const params = new URLSearchParams(window.location.search);
        const page = this.readParam(params, 'page', 'number');
        const mesaTermo = this.readParam(params, 'mesaTermo', 'string');
        const comandaNumero = this.readParam(params, 'comandaNumero', 'number');
        const itemTermo = this.readParam(params, 'itemTermo', 'string');
        const comandaId = this.readParam(params, 'comandaId', 'string');
        const itemCardapioId = this.readParam(params, 'itemCardapioId', 'string');
        this.publish('page', page);
        this.publish('mesaTermo', mesaTermo);
        this.publish('comandaNumero', comandaNumero);
        this.publish('itemTermo', itemTermo);
        this.publish('selectedComanda', comandaId);
        if (itemCardapioId !== null)
            this.publish('lancarItemDraft', { ...this.lancarItemDraft, itemCardapioId });
    }
    readParam(params, name, type) {
        let raw = params.get(name);
        if (raw === null) {
            try {
                raw = localStorage.getItem(`comandaRestaurante.atendimento.${name}`);
            }
            catch {
                raw = null;
            }
        }
        if (raw === null || raw === '')
            return null;
        if (type === 'number') {
            const value = Number(raw);
            return Number.isFinite(value) ? value : null;
        }
        return raw;
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.comandaRestaurante.atendimento.${member}`, value);
        if (member === 'page' || member === 'mesaTermo' || member === 'comandaNumero' || member === 'itemTermo' || member === 'selectedComanda') {
            try {
                const storageKey = `comandaRestaurante.atendimento.${member === 'selectedComanda' ? 'comandaId' : member}`;
                if (value === null || value === '')
                    localStorage.removeItem(storageKey);
                else
                    localStorage.setItem(storageKey, String(value));
            }
            catch { }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member)
            this[member] = value;
    }
    async initialLoad() {
        this.publish('pageStatus', 'loading');
        await this.carregarAtendimento();
        if (this.carregarAtendimentoStatus === 'error') {
            this.publish('pageStatus', 'error');
            return;
        }
        const context = this.contextoAtendimento;
        const empty = context !== null && context.mesasDisponiveis.items.length === 0 && context.comandasAbertas.items.length === 0 && context.itensCardapio.items.length === 0;
        this.publish('pageStatus', empty ? 'empty' : 'success');
        if (this.selectedComanda !== null)
            await this.obterComandaAtendimento(this.selectedComanda);
    }
    async query(member, route, input) {
        const status = `${member}Status`;
        const error = `${member}Error`;
        if (this[status] === 'loading')
            return;
        this.publish(status, 'loading');
        this.publish(error, null);
        try {
            const response = await execBff(route, input, { mode: 'silent' });
            if (!response.ok || !response.data) {
                this.publish(error, response.error);
                this.publish(status, 'error');
                return;
            }
            if (member === 'obterComandaAtendimento')
                this.publish('comanda', response.data.comanda);
            else
                this.publish('contextoAtendimento', response.data.contextoAtendimento);
            this.publish(status, 'success');
        }
        catch (reason) {
            const name = reason instanceof Error ? reason.name : 'Error';
            this.publish(error, { code: 'client.unexpected', message: '', details: { name } });
            this.publish(status, 'error');
        }
    }
    async command(member, route, input, apply) {
        const status = `${member}Status`;
        const error = `${member}Error`;
        this.publish(status, 'loading');
        this.publish(error, null);
        try {
            const result = await runBlockingUiAction((signal) => execBff(route, input, { mode: 'blocking', signal }));
            if (result === undefined) {
                this.publish(error, { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                this.publish(status, 'error');
                return;
            }
            if (!result.ok || !result.data) {
                this.publish(error, result.error);
                this.publish(status, 'error');
                return;
            }
            apply(result.data);
            this.publish(status, 'success');
            this.publish('lancarItemDraft', this.emptyDraft());
        }
        catch (reason) {
            const name = reason instanceof Error ? reason.name : 'Error';
            this.publish(error, { code: 'client.unexpected', message: '', details: { name } });
            this.publish(status, 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "contextoAtendimento", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "comanda", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "selectedComanda", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "page", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "mesaTermo", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "comandaNumero", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "itemTermo", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "lancarItemDraft", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "carregarAtendimentoStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "carregarAtendimentoError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "atualizarLocalizacaoAtendimentoStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "atualizarLocalizacaoAtendimentoError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "obterComandaAtendimentoStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "obterComandaAtendimentoError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "abrirComandaStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "abrirComandaError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "lancarItemStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "lancarItemError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "cancelarItemStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "cancelarItemError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteAtendimentoShared.prototype, "scenary", void 0);

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/comandaRestaurante/web/shared/fechamento.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
import { runBlockingUiAction } from '/_102029_/l2/interactionRuntime.js';
const STATE_MEMBER_BY_KEY = {
    'ui.comandaRestaurante.fechamento.openComandas': 'openComandas',
    'ui.comandaRestaurante.fechamento.comanda': 'comanda',
    'ui.comandaRestaurante.fechamento.selectedComanda': 'selectedComanda',
    'ui.comandaRestaurante.fechamento.fecharComandaPagaInput': 'fecharComandaPagaInput',
    'ui.comandaRestaurante.fechamento.pageStatus': 'pageStatus',
    'ui.comandaRestaurante.fechamento.carregarFechamentoStatus': 'carregarFechamentoStatus',
    'ui.comandaRestaurante.fechamento.carregarFechamentoError': 'carregarFechamentoError',
    'ui.comandaRestaurante.fechamento.buscarComandasAbertasStatus': 'buscarComandasAbertasStatus',
    'ui.comandaRestaurante.fechamento.buscarComandasAbertasError': 'buscarComandasAbertasError',
    'ui.comandaRestaurante.fechamento.carregarMaisComandasAbertasStatus': 'carregarMaisComandasAbertasStatus',
    'ui.comandaRestaurante.fechamento.carregarMaisComandasAbertasError': 'carregarMaisComandasAbertasError',
    'ui.comandaRestaurante.fechamento.obterComandaParaFechamentoStatus': 'obterComandaParaFechamentoStatus',
    'ui.comandaRestaurante.fechamento.obterComandaParaFechamentoError': 'obterComandaParaFechamentoError',
    'ui.comandaRestaurante.fechamento.fecharComandaPagaStatus': 'fecharComandaPagaStatus',
    'ui.comandaRestaurante.fechamento.fecharComandaPagaError': 'fecharComandaPagaError',
    'ui.comandaRestaurante.fechamento.scenary': 'scenary'
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
const PAGE_SIZE = 20;
export class ComandaRestauranteFechamentoShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state openComandas — summary of open comandas available for locating and selecting the charge; source carregarFechamento.openComandas; organism openComandaList */
        this.openComandas = null;
        /** state comanda — selected comanda with valid lines, calculated totals, payment data and table availability; source obterComandaParaFechamento.comanda; organism comandaReview */
        this.comanda = null;
        /** state selectedComanda — the selected comanda identifier from the page context; source entry.params.comandaId; organism comandaReview; persisted */
        this.selectedComanda = null;
        /** state fecharComandaPagaInput — the local payment draft containing the optional discount and required payment method; source fecharComandaPaga.input; organism paymentForm */
        this.fecharComandaPagaInput = this.emptyFecharComandaPagaDraft();
        /** state pageStatus — overall initial-load status of the page; source pageStatus */
        this.pageStatus = 'idle';
        /** state carregarFechamentoStatus — status of the initial fechamento query; source carregarFechamentoStatus */
        this.carregarFechamentoStatus = 'idle';
        /** state carregarFechamentoError — error from the initial fechamento query; source carregarFechamentoError */
        this.carregarFechamentoError = null;
        /** state buscarComandasAbertasStatus — status of the open-comanda search query; source buscarComandasAbertasStatus */
        this.buscarComandasAbertasStatus = 'idle';
        /** state buscarComandasAbertasError — error from the open-comanda search query; source buscarComandasAbertasError */
        this.buscarComandasAbertasError = null;
        /** state carregarMaisComandasAbertasStatus — status of the additional-page query; source carregarMaisComandasAbertasStatus */
        this.carregarMaisComandasAbertasStatus = 'idle';
        /** state carregarMaisComandasAbertasError — error from the additional-page query; source carregarMaisComandasAbertasError */
        this.carregarMaisComandasAbertasError = null;
        /** state obterComandaParaFechamentoStatus — status of the selected-comanda query; source obterComandaParaFechamentoStatus */
        this.obterComandaParaFechamentoStatus = 'idle';
        /** state obterComandaParaFechamentoError — error from the selected-comanda query; source obterComandaParaFechamentoError */
        this.obterComandaParaFechamentoError = null;
        /** state fecharComandaPagaStatus — status of the close command; source fecharComandaPagaStatus */
        this.fecharComandaPagaStatus = 'idle';
        /** state fecharComandaPagaError — error from the close command; source fecharComandaPagaError */
        this.fecharComandaPagaError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
        this.numberFilter = null;
        this.mesaCodeFilter = null;
        this.detailFilterId = null;
        this.visitSubscribed = false;
        this.pageNumber = 1;
    }
    emptyFecharComandaPagaDraft() {
        return { discountAmount: null, paymentMethod: null };
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.comandaRestaurante.fechamento.${member}`, value);
        if (member === 'selectedComanda') {
            try {
                if (value === null || value === '') {
                    localStorage.removeItem('comandaRestaurante.fechamento.comandaId');
                }
                else {
                    localStorage.setItem('comandaRestaurante.fechamento.comandaId', String(value));
                }
            }
            catch {
            }
        }
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member) {
            this[member] = value;
        }
    }
    errorFromThrown(error) {
        const name = error instanceof Error ? error.name : 'Error';
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    errorFromResponse(error) {
        return error ?? { code: 'client.unexpected', message: '', details: { name: 'BffError' } };
    }
    readParam(name, persist) {
        const urlValue = new URLSearchParams(window.location.search).get(name);
        if (urlValue !== null) {
            return urlValue;
        }
        if (!persist) {
            return null;
        }
        try {
            return localStorage.getItem(`comandaRestaurante.fechamento.${name}`);
        }
        catch {
            return null;
        }
    }
    applyEntryParams() {
        const comandaId = this.readParam('comandaId', true);
        const numberValue = this.readParam('number', true);
        const mesaCode = this.readParam('mesaCode', true);
        const pageValue = this.readParam('page', true);
        const id = this.readParam('id', true);
        this.numberFilter = numberValue === null || numberValue === '' ? null : Number(numberValue);
        if (this.numberFilter !== null && !Number.isFinite(this.numberFilter)) {
            this.numberFilter = null;
        }
        this.mesaCodeFilter = mesaCode === null || mesaCode === '' ? null : mesaCode;
        this.detailFilterId = id === null || id === '' ? null : id;
        const page = pageValue === null || pageValue === '' ? 1 : Number(pageValue);
        const pageNumber = Number.isFinite(page) && page > 0 ? page : 1;
        this.publish('selectedComanda', comandaId === '' ? null : comandaId);
        this.pageNumber = pageNumber;
    }
    setQueryStatus(request, status) {
        if (request === 'carregarFechamento') {
            this.publish('carregarFechamentoStatus', status);
        }
        else if (request === 'buscarComandasAbertas') {
            this.publish('buscarComandasAbertasStatus', status);
        }
        else if (request === 'carregarMaisComandasAbertas') {
            this.publish('carregarMaisComandasAbertasStatus', status);
        }
        else {
            this.publish('obterComandaParaFechamentoStatus', status);
        }
    }
    setQueryError(request, error) {
        if (request === 'carregarFechamento') {
            this.publish('carregarFechamentoError', error);
        }
        else if (request === 'buscarComandasAbertas') {
            this.publish('buscarComandasAbertasError', error);
        }
        else if (request === 'carregarMaisComandasAbertas') {
            this.publish('carregarMaisComandasAbertasError', error);
        }
        else {
            this.publish('obterComandaParaFechamentoError', error);
        }
    }
    async query(request, input) {
        const response = await execBff(request, input, { mode: 'silent' });
        if (!response.ok || !response.data) {
            return null;
        }
        return response.data;
    }
    /** function carregarFechamento — loads open comandas and the contextual selected charge; redraws openComandas by replacement and comanda with the returned selected record; no arguments */
    async carregarFechamento() {
        if (this.carregarFechamentoStatus === 'loading') {
            return;
        }
        this.publish('pageStatus', 'loading');
        this.publish('carregarFechamentoStatus', 'loading');
        this.publish('carregarFechamentoError', null);
        const input = { page: this.pageNumber, pageSize: PAGE_SIZE, ...(this.selectedComanda !== null && this.selectedComanda !== '' ? { comandaId: this.selectedComanda } : {}), ...(this.numberFilter !== null ? { number: this.numberFilter } : {}), ...(this.mesaCodeFilter !== null && this.mesaCodeFilter !== '' ? { mesaCode: this.mesaCodeFilter } : {}) };
        try {
            const output = await this.query('comandaRestaurante.fechamento.carregarFechamento', input);
            if (!output) {
                this.publish('carregarFechamentoStatus', 'error');
                this.publish('carregarFechamentoError', { code: 'client.unexpected', message: '', details: { name: 'BffError' } });
                this.publish('pageStatus', 'error');
                return;
            }
            this.publish('openComandas', output.openComandas);
            this.publish('comanda', output.selectedComanda ?? null);
            this.publish('carregarFechamentoStatus', 'success');
            this.publish('pageStatus', output.openComandas.items.length === 0 ? 'empty' : 'success');
        }
        catch (error) {
            this.publish('carregarFechamentoStatus', 'error');
            this.publish('carregarFechamentoError', this.errorFromThrown(error));
            this.publish('pageStatus', 'error');
        }
    }
    /** function buscarComandasAbertas — replaces the location list with open comandas matching number and table filters; redraws openComandas by replacement; arguments are number and mesaCode filter values */
    async buscarComandasAbertas(number = this.numberFilter, mesaCode = this.mesaCodeFilter) {
        this.numberFilter = number;
        this.mesaCodeFilter = mesaCode;
        this.pageNumber = 1;
        if (this.buscarComandasAbertasStatus === 'loading') {
            return;
        }
        this.publish('buscarComandasAbertasStatus', 'loading');
        this.publish('buscarComandasAbertasError', null);
        const input = { page: 1, pageSize: PAGE_SIZE, ...(number !== null ? { number } : {}), ...(mesaCode !== null && mesaCode !== '' ? { mesaCode } : {}) };
        try {
            const output = await this.query('comandaRestaurante.fechamento.buscarComandasAbertas', input);
            if (!output) {
                this.publish('buscarComandasAbertasStatus', 'error');
                this.publish('buscarComandasAbertasError', { code: 'client.unexpected', message: '', details: { name: 'BffError' } });
                return;
            }
            this.publish('openComandas', output.openComandas);
            this.publish('buscarComandasAbertasStatus', 'success');
        }
        catch (error) {
            this.publish('buscarComandasAbertasStatus', 'error');
            this.publish('buscarComandasAbertasError', this.errorFromThrown(error));
        }
    }
    /** function carregarMaisComandasAbertas — loads the next open-comanda window without reloading existing summaries; redraws openComandas.items by append; no arguments */
    async carregarMaisComandasAbertas() {
        if (this.carregarMaisComandasAbertasStatus === 'loading' || !this.openComandas || !this.openComandas.hasMore) {
            return;
        }
        this.publish('carregarMaisComandasAbertasStatus', 'loading');
        this.publish('carregarMaisComandasAbertasError', null);
        const nextPage = this.openComandas.page + 1;
        const input = { page: nextPage, pageSize: this.openComandas.pageSize, ...(this.numberFilter !== null ? { number: this.numberFilter } : {}), ...(this.mesaCodeFilter !== null && this.mesaCodeFilter !== '' ? { mesaCode: this.mesaCodeFilter } : {}) };
        try {
            const output = await this.query('comandaRestaurante.fechamento.carregarMaisComandasAbertas', input);
            if (!output) {
                this.publish('carregarMaisComandasAbertasStatus', 'error');
                this.publish('carregarMaisComandasAbertasError', { code: 'client.unexpected', message: '', details: { name: 'BffError' } });
                return;
            }
            this.publish('openComandas', { ...output.openComandas, items: [...this.openComandas.items, ...output.openComandas.items] });
            this.publish('carregarMaisComandasAbertasStatus', 'success');
        }
        catch (error) {
            this.publish('carregarMaisComandasAbertasStatus', 'error');
            this.publish('carregarMaisComandasAbertasError', this.errorFromThrown(error));
        }
    }
    /** function obterComandaParaFechamento — obtains the selected open comanda composed for review and payment; redraws comanda by replacement; argument id is the selected comanda identifier */
    async obterComandaParaFechamento(id) {
        if (id === '') {
            return;
        }
        if (this.obterComandaParaFechamentoStatus === 'loading') {
            return;
        }
        this.publish('selectedComanda', id);
        this.publish('obterComandaParaFechamentoStatus', 'loading');
        this.publish('obterComandaParaFechamentoError', null);
        try {
            const output = await this.query('comandaRestaurante.fechamento.obterComandaParaFechamento', { id });
            if (!output) {
                this.publish('obterComandaParaFechamentoStatus', 'error');
                this.publish('obterComandaParaFechamentoError', { code: 'client.unexpected', message: '', details: { name: 'BffError' } });
                return;
            }
            this.publish('comanda', output.comanda);
            this.publish('obterComandaParaFechamentoStatus', 'success');
        }
        catch (error) {
            this.publish('obterComandaParaFechamentoStatus', 'error');
            this.publish('obterComandaParaFechamentoError', this.errorFromThrown(error));
        }
    }
    /** draft — updates the payment draft used by the close command */
    setFecharComandaPaga(value) {
        this.publish('fecharComandaPagaInput', value);
    }
    /** select — selects a comanda identifier and loads its composed review record; argument id is the selected row identifier, or null to clear selection */
    async selectComandaReview(id) {
        if (id === null) {
            this.publish('selectedComanda', null);
            this.publish('comanda', null);
            return;
        }
        await this.obterComandaParaFechamento(id);
    }
    /** function fecharComandaPaga — records payment, closes the comanda and confirms table release; redraws comanda by upsert and removes the closed row from openComandas; no arguments, using the payment draft and selected record */
    async fecharComandaPaga() {
        if (this.fecharComandaPagaStatus === 'loading') {
            return;
        }
        if (!this.comanda || this.fecharComandaPagaInput.paymentMethod === null) {
            this.publish('fecharComandaPagaStatus', 'error');
            this.publish('fecharComandaPagaError', { code: 'client.requiredMissing', message: '', details: { stateKeys: ['comanda', 'fecharComandaPagaInput.paymentMethod'] } });
            return;
        }
        const input = { id: this.comanda.id, version: this.comanda.version, details: { paymentMethod: this.fecharComandaPagaInput.paymentMethod, ...(this.fecharComandaPagaInput.discountAmount !== null && this.fecharComandaPagaInput.discountAmount !== '' ? { discountAmount: this.fecharComandaPagaInput.discountAmount } : {}) } };
        this.publish('fecharComandaPagaStatus', 'loading');
        this.publish('fecharComandaPagaError', null);
        try {
            const result = await runBlockingUiAction(signal => execBff('comandaRestaurante.fechamento.fecharComandaPaga', input, { mode: 'blocking', signal }));
            if (!result) {
                this.publish('fecharComandaPagaStatus', 'error');
                this.publish('fecharComandaPagaError', { code: 'client.unexpected', message: '', details: { name: 'aborted' } });
                return;
            }
            if (!result.ok || !result.data) {
                this.publish('fecharComandaPagaStatus', 'error');
                this.publish('fecharComandaPagaError', this.errorFromResponse(result.error));
                return;
            }
            const data = result.data;
            this.publish('comanda', data.comanda);
            if (this.openComandas) {
                this.publish('openComandas', { ...this.openComandas, items: this.openComandas.items.filter(item => item.id !== data.comanda.id) });
            }
            this.publish('fecharComandaPagaInput', this.emptyFecharComandaPagaDraft());
            this.publish('fecharComandaPagaStatus', 'success');
        }
        catch (error) {
            this.publish('fecharComandaPagaStatus', 'error');
            this.publish('fecharComandaPagaError', this.errorFromThrown(error));
        }
    }
    connectedCallback() {
        super.connectedCallback();
        const openComandas = getState('ui.comandaRestaurante.fechamento.openComandas');
        const comanda = getState('ui.comandaRestaurante.fechamento.comanda');
        if (openComandas !== undefined) {
            this.assignState('ui.comandaRestaurante.fechamento.openComandas', openComandas);
        }
        if (comanda !== undefined) {
            this.assignState('ui.comandaRestaurante.fechamento.comanda', comanda);
        }
        this.publish('pageStatus', 'idle');
        this.publish('carregarFechamentoStatus', 'idle');
        this.publish('carregarFechamentoError', null);
        this.publish('buscarComandasAbertasStatus', 'idle');
        this.publish('buscarComandasAbertasError', null);
        this.publish('carregarMaisComandasAbertasStatus', 'idle');
        this.publish('carregarMaisComandasAbertasError', null);
        this.publish('obterComandaParaFechamentoStatus', 'idle');
        this.publish('obterComandaParaFechamentoError', null);
        this.publish('fecharComandaPagaStatus', 'idle');
        this.publish('fecharComandaPagaError', null);
        this.publish('fecharComandaPagaInput', this.emptyFecharComandaPagaDraft());
        this.publish('scenary', '');
        if (!this.visitSubscribed) {
            subscribe(STATE_KEYS, this);
            this.visitSubscribed = true;
        }
        this.applyEntryParams();
        void this.carregarFechamento();
    }
    disconnectedCallback() {
        if (this.visitSubscribed) {
            unsubscribe(STATE_KEYS, this);
            this.visitSubscribed = false;
        }
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_MEMBER_BY_KEY[key]) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined) {
            return;
        }
        this.assignState(key, value);
        this.requestUpdate();
    }
    /** Sets the visible scene identifier for the page. */
    setScenario(value) {
        this.publish('scenary', value);
    }
}
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "openComandas", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "comanda", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "selectedComanda", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "fecharComandaPagaInput", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "carregarFechamentoStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "carregarFechamentoError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "buscarComandasAbertasStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "buscarComandasAbertasError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "carregarMaisComandasAbertasStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "carregarMaisComandasAbertasError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "obterComandaParaFechamentoStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "obterComandaParaFechamentoError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "fecharComandaPagaStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "fecharComandaPagaError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteFechamentoShared.prototype, "scenary", void 0);

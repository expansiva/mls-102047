var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102047_/l2/comandaRestaurante/web/shared/inicio.ts" enhancement="_102020_/l2/enhancementAura"/>
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { execBff } from '/_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '/_102029_/l2/collabState.js';
const STATE_MEMBER_BY_KEY = {
    'ui.comandaRestaurante.inicio.resumoOperacional': 'resumoOperacional',
    'ui.comandaRestaurante.inicio.pageStatus': 'pageStatus',
    'ui.comandaRestaurante.inicio.carregarResumoOperacionalStatus': 'carregarResumoOperacionalStatus',
    'ui.comandaRestaurante.inicio.carregarResumoOperacionalError': 'carregarResumoOperacionalError',
    'ui.comandaRestaurante.inicio.scenary': 'scenary'
};
const STATE_KEYS = Object.keys(STATE_MEMBER_BY_KEY);
export class ComandaRestauranteInicioShared extends StateLitElement {
    constructor() {
        super(...arguments);
        /** state resumoOperacional — Indicadores consolidados da operação do restaurante para a visão geral.; source carregarResumoOperacional.resumoOperacional; organism resumoOperacional */
        this.resumoOperacional = null;
        /** state pageStatus — the overall loading state of the page; source pageStatus */
        this.pageStatus = 'idle';
        /** state carregarResumoOperacionalStatus — the execution status of the operational summary query; source carregarResumoOperacional.status */
        this.carregarResumoOperacionalStatus = 'idle';
        /** state carregarResumoOperacionalError — the error returned by the operational summary query; source carregarResumoOperacional.error */
        this.carregarResumoOperacionalError = null;
        /** state scenary — the visible scene of the page; '' until the page shows its first scene */
        this.scenary = '';
    }
    publish(member, value) {
        this[member] = value;
        setState(`ui.comandaRestaurante.inicio.${member}`, value);
    }
    assignState(key, value) {
        const member = STATE_MEMBER_BY_KEY[key];
        if (member) {
            this[member] = value;
        }
    }
    unexpectedError(name) {
        return { code: 'client.unexpected', message: '', details: { name } };
    }
    resetVisit() {
        this.publish('pageStatus', 'idle');
        this.publish('carregarResumoOperacionalStatus', 'idle');
        this.publish('carregarResumoOperacionalError', null);
        this.publish('scenary', '');
    }
    connectedCallback() {
        super.connectedCallback();
        for (const key of STATE_KEYS) {
            const member = STATE_MEMBER_BY_KEY[key];
            if (member === 'resumoOperacional') {
                const value = getState(key);
                if (value !== undefined) {
                    this.assignState(key, value);
                }
            }
        }
        this.resetVisit();
        subscribe(STATE_KEYS, this);
        void this.carregarResumoOperacional();
    }
    disconnectedCallback() {
        unsubscribe(STATE_KEYS, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (!STATE_MEMBER_BY_KEY[key]) {
            super.handleIcaStateChange(key, value);
            return;
        }
        if (value === undefined) {
            return;
        }
        this.assignState(key, value);
        this.requestUpdate();
    }
    /** function setScenario — changes the visible scene of the page; redraws scenary by replacement; value is the scene identifier */
    setScenario(value) {
        this.publish('scenary', value);
    }
    /** function carregarResumoOperacional — loads the consolidated operational indicators used for quick consultation; redraws resumoOperacional by replacement; no arguments are required */
    async carregarResumoOperacional() {
        if (this.carregarResumoOperacionalStatus === 'loading') {
            return;
        }
        this.publish('pageStatus', 'loading');
        this.publish('carregarResumoOperacionalStatus', 'loading');
        this.publish('carregarResumoOperacionalError', null);
        try {
            const response = await execBff('comandaRestaurante.inicio.carregarResumoOperacional', {}, { mode: 'silent' });
            if (!response.ok || !response.data) {
                const error = response.error ?? this.unexpectedError('response');
                this.publish('carregarResumoOperacionalError', error);
                this.publish('carregarResumoOperacionalStatus', 'error');
                this.publish('pageStatus', 'error');
                return;
            }
            this.publish('resumoOperacional', response.data.resumoOperacional);
            this.publish('carregarResumoOperacionalStatus', 'success');
            this.publish('pageStatus', 'success');
        }
        catch (error) {
            const name = error instanceof Error ? error.name : 'unknown';
            this.publish('carregarResumoOperacionalError', this.unexpectedError(name));
            this.publish('carregarResumoOperacionalStatus', 'error');
            this.publish('pageStatus', 'error');
        }
    }
}
__decorate([
    property({ attribute: false })
], ComandaRestauranteInicioShared.prototype, "resumoOperacional", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteInicioShared.prototype, "pageStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteInicioShared.prototype, "carregarResumoOperacionalStatus", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteInicioShared.prototype, "carregarResumoOperacionalError", void 0);
__decorate([
    property({ attribute: false })
], ComandaRestauranteInicioShared.prototype, "scenary", void 0);

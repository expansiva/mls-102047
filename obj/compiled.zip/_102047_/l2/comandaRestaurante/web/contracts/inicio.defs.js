/// <mls fileReference="_102047_/l2/comandaRestaurante/web/contracts/inicio.defs.ts" enhancement="_blank"/>
export {};

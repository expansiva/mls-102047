/// <mls fileReference="_102047_/l2/comandaRestaurante/web/contracts/mesas.defs.ts" enhancement="_blank"/>
export {};

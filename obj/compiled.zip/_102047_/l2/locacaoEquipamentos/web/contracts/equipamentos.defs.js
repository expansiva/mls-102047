/// <mls fileReference="_102047_/l2/locacaoEquipamentos/web/contracts/equipamentos.defs.ts" enhancement="_blank"/>
export {};

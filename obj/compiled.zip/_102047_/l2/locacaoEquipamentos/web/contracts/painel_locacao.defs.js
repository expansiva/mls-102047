/// <mls fileReference="_102047_/l2/locacaoEquipamentos/web/contracts/painel_locacao.defs.ts" enhancement="_blank"/>
export {};

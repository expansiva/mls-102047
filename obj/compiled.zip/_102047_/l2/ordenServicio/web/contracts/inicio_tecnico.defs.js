export const listOrdenServicioRoute = "ordenServicio.inicio_tecnico.qryListOrdenServicio";

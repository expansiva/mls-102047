export const listOrdenServicioRoute = "ordenServicio.inicio_cliente.qryListOrdenServicio";

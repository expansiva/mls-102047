export const createOrdenServicioRoute = "ordenServicio.ordenes_recepcionista.cmdCreateOrdenServicio";
export const entregarYfinalizarRoute = "ordenServicio.ordenes_recepcionista.cmdEntregarYfinalizar";
export const listOrdenServicioRoute = "ordenServicio.ordenes_recepcionista.qryListOrdenServicio";

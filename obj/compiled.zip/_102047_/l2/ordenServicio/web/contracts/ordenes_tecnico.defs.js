export const emitirPresupuestoRoute = "ordenServicio.ordenes_tecnico.cmdEmitirPresupuesto";
export const marcarListaRoute = "ordenServicio.ordenes_tecnico.cmdMarcarLista";
export const updateOrdenServicioRoute = "ordenServicio.ordenes_tecnico.cmdUpdateOrdenServicio";
export const listOrdenServicioRoute = "ordenServicio.ordenes_tecnico.qryListOrdenServicio";

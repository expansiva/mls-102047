export const listOrdenServicioRoute = "ordenServicio.inicio_recepcionista.qryListOrdenServicio";

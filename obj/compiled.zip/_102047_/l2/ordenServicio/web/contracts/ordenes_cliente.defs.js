export const aprobarPresupuestoRoute = "ordenServicio.ordenes_cliente.cmdAprobarPresupuesto";
export const rechazarPresupuestoRoute = "ordenServicio.ordenes_cliente.cmdRechazarPresupuesto";
export const listOrdenServicioRoute = "ordenServicio.ordenes_cliente.qryListOrdenServicio";

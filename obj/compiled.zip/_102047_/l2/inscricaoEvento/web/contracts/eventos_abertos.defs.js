/// <mls fileReference="_102047_/l2/inscricaoEvento/web/contracts/eventos_abertos.defs.ts" enhancement="_blank"/>
export {};

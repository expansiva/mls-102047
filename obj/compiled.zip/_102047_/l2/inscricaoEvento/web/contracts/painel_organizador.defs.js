/// <mls fileReference="_102047_/l2/inscricaoEvento/web/contracts/painel_organizador.defs.ts" enhancement="_blank"/>
export {};

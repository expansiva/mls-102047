/// <mls fileReference="_102047_/l2/inscricaoEvento/web/contracts/gestao_eventos.defs.ts" enhancement="_blank"/>
export {};

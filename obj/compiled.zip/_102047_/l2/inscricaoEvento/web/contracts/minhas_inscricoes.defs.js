/// <mls fileReference="_102047_/l2/inscricaoEvento/web/contracts/minhas_inscricoes.defs.ts" enhancement="_blank"/>
export {};

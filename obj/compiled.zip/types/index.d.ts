declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/commentOpenTicket.defs" {
    export const commentOpenTicketController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "commentOpenTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "commentOpenTicket";
            readonly controllerName: "CommentOpenTicketController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "commentOpenTicket";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "commentOpenTicketQryLocateTicketHandler";
                readonly command: "qryLocateTicket";
                readonly bffId: "qryLocateTicket";
                readonly route: "controleChamados.commentOpenTicket.qryLocateTicket";
                readonly kind: "query";
                readonly usecaseRef: "locateTicket";
                readonly usecaseRefs: readonly ["locateTicket"];
                readonly inputTypeName: "LocateTicketInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "title";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "description";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "commentOpenTicketCmdRecordCommentHandler";
                readonly command: "cmdRecordComment";
                readonly bffId: "cmdRecordComment";
                readonly route: "controleChamados.commentOpenTicket.cmdRecordComment";
                readonly kind: "command";
                readonly usecaseRef: "recordComment";
                readonly usecaseRefs: readonly ["recordComment"];
                readonly inputTypeName: "RecordCommentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketId";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Chamado";
                }, {
                    readonly inputId: "commentText";
                    readonly fieldRef: "TicketComment.commentText";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "recordComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "recordComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "recordComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.commentOpenTicket.qryLocateTicket";
                readonly handlerName: "commentOpenTicketQryLocateTicketHandler";
            }, {
                readonly key: "controleChamados.commentOpenTicket.cmdRecordComment";
                readonly handlerName: "commentOpenTicketCmdRecordCommentHandler";
            }];
        };
    };
    export default commentOpenTicketController;
    export const pipeline: readonly [{
        readonly id: "commentOpenTicket__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/commentOpenTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/commentOpenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/usecases/locateTicket.d.ts", "_102047_/l4/controleChamados/contracts/commentOpenTicket--qryLocateTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/recordComment.d.ts", "_102047_/l4/controleChamados/contracts/commentOpenTicket--cmdRecordComment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102034_/l1/mdm/defs/ontology" {
    /**
     * MDM — Master Data Model
     * Ontology: conceptual source of truth for all shared entities.
     *
     * Storage strategy: hybrid
     *   - DynamoDB  → single document store, 3 columns: mdmId | version | details
     *   - PostgreSQL → two lean indexes:
     *       MdmEntity      → permanent, qualified, deduplicated records
     *       MdmProspect    → transient records (leads, unverified imports, anonymous captures)
     *
     * Every entity is identified by a universal mdmId.
     * The mdmId is stable from creation through promotion — references never break.
     * Any module may reference an mdmId without knowing its subtype.
     *
     * Default country: US (ISO 3166-1 alpha-2: "US")
     *
     * Naming: PascalCase for entity/type names, camelCase for fields.
     */
    export type MdmSubtype = 'Person' | 'Company' | 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel';
    export type MdmStatus = 'Active' | 'Inactive' | 'Merged' | 'Blocked';
    export type MdmProspectStatus = 'New' | 'InProgress' | 'PendingMerge' | 'Promoted' | 'Expired' | 'Discarded';
    export type DocType = 'SSN' | 'EIN' | 'Passport' | 'DriversLicense' | 'NationalId' | 'CPF' | 'CNPJ' | 'VAT' | 'Other';
    export type RelationshipType = 'Owns' | 'Employs' | 'OffersProduct' | 'OffersService' | 'StocksAt' | 'Teaches' | 'HappensAt' | 'FranchiseOf' | 'BelongsToGroup' | 'PartOfUnit' | 'ManagedBy' | 'ReportsTo' | 'AssignedTo' | 'Attends' | 'SuppliesProduct' | 'PartnersWith' | 'Family' | 'GuardianOf' | 'CustomerOf' | 'SupplierOf' | 'MemberOf' | 'HoldsAccount' | 'SubsidiaryOf' | 'LocatedAt' | 'Signed' | 'HasContact';
    /**
     * Address
     * Global address model based on Google / Apple / USPS international format.
     * Embedded as an array inside Person, Company, and AssetProperty documents.
     * Never stored as a standalone row or MDM entity.
     *
     * line1 + line2 + line3 cover the full range of international address formats:
     *   US:     line1="123 Main St", line2="Apt 4B"
     *   Brazil: line1="Rua das Flores 100", line2="Apto 42", line3="Jardim Paulista"
     *   Japan:  line1="1-2-3 Shinjuku", line2="Shinjuku-ku", line3="Tokyo"
     */
    export const Address: {
        readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
        readonly fields: {
            readonly type: {
                readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
            };
            readonly label: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Short human label for this address.";
                readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
            };
            readonly line1: {
                readonly type: "string";
                readonly description: "Primary address line: street and number, PO Box, or rural route.";
            };
            readonly line2: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Secondary line: apartment, suite, floor, unit, building.";
            };
            readonly line3: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
            };
            readonly city: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly stateOrProvince: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
            };
            readonly postalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                readonly constraints: "Default: US";
            };
            readonly formatted: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
            };
            readonly geolocation: {
                readonly type: "{ lat: number; lng: number } | null";
                readonly required: false;
            };
            readonly isPrimary: {
                readonly type: "boolean";
            };
        };
    };
    export const PrivacyConsent: {
        readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
        readonly fields: {
            readonly consentedAt: {
                readonly type: "timestamp";
            };
            readonly consentVersion: {
                readonly type: "string";
                readonly description: "Version of the privacy policy accepted.";
            };
            readonly channel: {
                readonly type: "string";
                readonly description: "How consent was obtained.";
                readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
            };
            readonly revokedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
            };
        };
    };
    /**
     * ContactSummary
     * Embedded inside every entity detail as part of contacts[].
     * Contains only mdmId + title — zero contact data inline.
     * Full contact data (channel type, value, verified status) lives in the ContactChannel entity document.
     * This ensures traceability without duplicating sensitive data.
     */
    export const ContactSummary: {
        readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
            };
            readonly title: {
                readonly type: "string";
                readonly description: "Human-readable label for this contact in the context of the parent entity.";
                readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
            };
        };
    };
    export const CompactRelationshipRefs: {
        readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
        readonly fields: {
            readonly ownedAssets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly owners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employees: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly employers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly partners: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly family: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly pets: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly guardians: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly customers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly suppliers: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly memberships: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly members: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly bankAccounts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly accountHolders: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly subsidiaries: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly parentCompanies: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locations: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly locatedEntities: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly documents: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly signedBy: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contacts: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly contactOwners: {
                readonly type: "string[]";
                readonly required: false;
            };
        };
    };
    /**
     * MdmDocument
     * Three top-level columns only. All entity data lives inside details.
     * DynamoDB is used as a pure document store — no GSIs, no top-level attribute queries.
     * All querying is done via the PostgreSQL indexes (MdmEntity or MdmProspect).
     */
    export const MdmDocument: {
        readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid)";
                readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
            };
            readonly version: {
                readonly type: "number";
                readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
            };
            readonly details: {
                readonly type: "object (JSON document)";
                readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
            };
        };
    };
    /**
     * MdmEntity
     * Permanent, qualified, deduplicated MDM records.
     * Contains only the fields needed for filtering, searching, joining, and deduplication.
     * Full entity data is always read from DynamoDB by dynamoPk.
     *
     * Sync strategy:
     *   SYNC  → written to PostgreSQL in the same request as DynamoDB
     *   async → propagated by the background worker after each DynamoDB write
     */
    export const MdmEntity: {
        readonly description: "PostgreSQL index for permanent MDM entities.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly sync: "SYNC";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
                readonly sync: "SYNC";
            };
            readonly name: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmStatus";
                readonly sync: "SYNC";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly sync: "SYNC";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "UNIQUE constraint on (docType, docId) — enforces deduplication for permanent records.";
                readonly constraints: "Formatted without punctuation.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly sync: "async";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly sync: "async";
                readonly required: false;
            };
            readonly searchVector: {
                readonly type: "tsvector";
                readonly sync: "async";
                readonly description: "Full-text search vector generated from name + aliases + docId.";
            };
            readonly mergedInto: {
                readonly type: "string (uuid) | null";
                readonly sync: "SYNC";
                readonly required: false;
                readonly description: "When status is Merged, points to the winning mdmId.";
            };
            readonly dynamoPk: {
                readonly type: "string";
                readonly sync: "SYNC";
                readonly description: "DynamoDB partition key for direct document reads.";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly sync: "async";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmEntity";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "docType", "docId", "mergedInto", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "searchVector", "createdAt", "updatedAt"];
            };
        };
    };
    /**
     * MdmProspect
     * Transient, unverified, or provisional entities: leads, anonymous visitors,
     * unconfirmed signups, bulk imports pending review.
     *
     * Key differences from MdmEntity:
     *   - No UNIQUE constraint on (docType, docId)
     *   - Has ttlExpiresAt for auto-expiry
     *   - Has promotionSource to track origin module
     *   - Status covers the full promotion lifecycle
     *
     * DynamoDB document structure is identical (mdmId, version, details).
     * The separation is PostgreSQL-only.
     *
     * Promotion flow:
     *   1. Module calls ctx.mdm.prospect.promoteToEntity({ mdmId: prospectMdmId })
     *   2. MDM runs dedup: does MdmEntity have matching (docType, docId)?
     *   3a. No match  → insert into MdmEntity, delete from MdmProspect. Same mdmId survives.
     *   3b. Match     → set status PendingMerge. Operator confirms merge.
     *   4. Calling module updates its extension table to point to the final mdmId.
     */
    export const MdmProspect: {
        readonly description: "PostgreSQL index for transient MDM records. Isolated from MdmEntity to preserve query performance and deduplication integrity.";
        readonly fields: {
            readonly mdmId: {
                readonly type: "string (uuid) PK";
                readonly description: "Same mdmId space as MdmEntity. Stable from creation through promotion.";
            };
            readonly subtype: {
                readonly type: "MdmSubtype";
            };
            readonly name: {
                readonly type: "string";
                readonly constraints: "max 200 chars";
            };
            readonly status: {
                readonly type: "MdmProspectStatus";
            };
            readonly docType: {
                readonly type: "DocType | null";
                readonly required: false;
            };
            readonly docId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "No UNIQUE constraint. Duplicates allowed — resolved on promotion.";
            };
            readonly countryCode: {
                readonly type: "string";
                readonly constraints: "Default: US";
            };
            readonly tags: {
                readonly type: "string[]";
                readonly required: false;
            };
            readonly promotionSource: {
                readonly type: "string";
                readonly description: "Module that created this prospect.";
                readonly constraints: "Examples: crm, marketing-automation, web-capture, bulk-import";
            };
            readonly promotedTo: {
                readonly type: "string (uuid) | null";
                readonly required: false;
                readonly description: "mdmId of the MdmEntity record this prospect was promoted or merged into.";
            };
            readonly ttlExpiresAt: {
                readonly type: "timestamp | null";
                readonly required: false;
                readonly description: "Auto-expiry timestamp. Null means no expiry.";
            };
            readonly dynamoPk: {
                readonly type: "string";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspect";
            readonly type: "MDM";
            readonly strategy: "remote-document";
            readonly remoteStore: "dynamodb";
            readonly consistencyContract: {
                readonly sync: readonly ["mdmId", "subtype", "name", "status", "dynamoPk"];
                readonly async: readonly ["countryCode", "tags", "ttlExpiresAt", "createdAt", "updatedAt"];
            };
        };
    };
    export const MdmRelationship: {
        readonly description: "Typed, versioned relationship between any two permanent MDM entities. PostgreSQL is the source of truth for relationship rows. DynamoDB details may also contain compact derived references in relationshipRefs for read optimization, and the full rows may be replicated to mdm_relationship_documents for recovery.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — must exist in MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — must exist in MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars. Examples: managing-partner, spouse, account-manager";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
                readonly description: "Rich relationship data as JSONB. See RelationshipCatalog for examples per type.";
            };
            readonly isBidirectional: {
                readonly type: "boolean";
                readonly description: "True for symmetric relationships (Family). False for directional (Employs, Owns).";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
                readonly description: "Null means currently active.";
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    /**
     * MdmProspectRelationship
     * Same schema as MdmRelationship, scoped to MdmProspect records.
     * fromId and toId may reference either MdmProspect or MdmEntity rows.
     * On promotion, relationships that reference a promoted entity are migrated
     * to MdmRelationship by the promotion workflow.
     */
    export const MdmProspectRelationship: {
        readonly description: "Relationship table for prospect entities. Same structure as MdmRelationship. Isolated to preserve query performance on the permanent relationship graph. Compact derived references may also appear in details.relationshipRefs, and full rows may be replicated to mdm_relationship_documents.";
        readonly fields: {
            readonly id: {
                readonly type: "string (uuid) PK";
            };
            readonly fromId: {
                readonly type: "string (uuid)";
                readonly description: "Origin mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly toId: {
                readonly type: "string (uuid)";
                readonly description: "Destination mdmId — may be in MdmProspect or MdmEntity";
            };
            readonly type: {
                readonly type: "RelationshipType";
            };
            readonly role: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly metadata: {
                readonly type: "Record<string, unknown>";
                readonly required: false;
            };
            readonly isBidirectional: {
                readonly type: "boolean";
            };
            readonly validFrom: {
                readonly type: "date";
            };
            readonly validTo: {
                readonly type: "date | null";
                readonly required: false;
            };
            readonly status: {
                readonly type: "'Active' | 'Inactive' | 'PendingConfirmation'";
            };
            readonly createdAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
            readonly updatedAt: {
                readonly type: "timestamp";
                readonly required: false;
            };
        };
        readonly persistence: {
            readonly module: "mdm";
            readonly table: "MdmProspectRelationship";
            readonly type: "MDM";
            readonly strategy: "relational";
        };
    };
    export const PersonDetail: {
        readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
        readonly fields: {
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly gender: {
                readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                readonly required: false;
            };
            readonly nationality: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ISO 3166-1 alpha-2 country of nationality.";
            };
            readonly occupation: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 120 chars";
            };
            readonly photoUrl: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly privacyConsent: {
                readonly type: "PrivacyConsent | null";
                readonly required: false;
                readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
    };
    export const CompanyDetail: {
        readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
        readonly fields: {
            readonly companyKind: {
                readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                readonly description: "Organizational classification for legal and internal structures.";
            };
            readonly parentCompanyId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId for organizational trees.";
            };
            readonly externalCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ERP/HR/legacy code used by consuming modules.";
            };
            readonly tradeName: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "DBA name. Also stored in aliases for full-text search.";
            };
            readonly legalName: {
                readonly type: "string";
                readonly description: "Official registered name.";
            };
            readonly legalType: {
                readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                readonly required: false;
            };
            readonly foundingDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly taxRegime: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
            };
            readonly industryCode: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
            };
            readonly website: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
        readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
    };
    export const ProductDetail: {
        readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
        readonly fields: {
            readonly sku: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Internal stock keeping unit.";
            };
            readonly productType: {
                readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly unitOfMeasure: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: unit, box, kg, liter, hour.";
            };
            readonly isInventoried: {
                readonly type: "boolean";
                readonly required: false;
                readonly description: "True when stock is tracked by location.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const ServiceDetail: {
        readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
        readonly fields: {
            readonly serviceCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly serviceKind: {
                readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                readonly required: false;
                readonly description: "Use Cohort for a concrete class/offering instance.";
            };
            readonly parentServiceId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
            };
            readonly serviceType: {
                readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                readonly required: false;
            };
            readonly durationMinutes: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly deliveryMode: {
                readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const LocationDetail: {
        readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
        readonly fields: {
            readonly locationType: {
                readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
            };
            readonly locationCode: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly parentLocationId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Optional parent mdmId when this place belongs to a larger place.";
            };
            readonly capacity: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 1000 chars";
            };
        };
    };
    export const AssetVehicleDetail: {
        readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
        readonly fields: {
            readonly plate: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly vin: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Vehicle Identification Number.";
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly year: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fuelType: {
                readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetPropertyDetail: {
        readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
        readonly fields: {
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Deed number, cadastral reference, or equivalent.";
            };
            readonly propertyAddress: {
                readonly type: "Address | null";
                readonly required: false;
            };
            readonly areaSqft: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square feet (primary unit for US).";
            };
            readonly areaM2: {
                readonly type: "number | null";
                readonly required: false;
                readonly description: "Area in square meters (non-US markets).";
            };
            readonly propertyType: {
                readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                readonly required: false;
            };
            readonly taxParcelId: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Tax parcel / assessor ID (US) or equivalent.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetEquipmentDetail: {
        readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
        readonly fields: {
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly brand: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly category: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: printer, server, forklift, medical device";
            };
            readonly acquisitionDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AssetGenericDetail: {
        readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
        readonly fields: {
            readonly assetCategory: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
            };
            readonly serialNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly manufacturer: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly model: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const AnimalDetail: {
        readonly description: "Subtype Animal — pets, livestock, working animals.";
        readonly fields: {
            readonly species: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
            };
            readonly breed: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly birthDate: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly sex: {
                readonly type: "'Male' | 'Female' | 'Unknown' | null";
                readonly required: false;
            };
            readonly color: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly microchip: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly registrationNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Breed registry, USDA tag, or official animal ID.";
            };
            readonly isNeutered: {
                readonly type: "boolean | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
    };
    export const BankAccountDetail: {
        readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
        readonly fields: {
            readonly bankRoutingNumber: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "ABA routing number (US). Use swift for international.";
            };
            readonly bankName: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountNumber: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly accountType: {
                readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                readonly required: false;
            };
            readonly swift: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "BIC/SWIFT for international transfers.";
            };
            readonly iban: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKey: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly pixKeyType: {
                readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                readonly required: false;
            };
            readonly isVerified: {
                readonly type: "boolean";
                readonly description: "Verified via micro-deposit, open banking, or manual review.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
    };
    export const DocumentDetail: {
        readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
        readonly fields: {
            readonly originModule: {
                readonly type: "string";
                readonly description: "Module that created this record.";
                readonly constraints: "Examples: legal, maintenance, hr, finance";
            };
            readonly docCategory: {
                readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
            };
            readonly storageBucket: {
                readonly type: "string";
                readonly description: "S3 bucket (or equivalent) where the file resides.";
            };
            readonly storagePath: {
                readonly type: "string";
                readonly description: "Relative path within the bucket. Immutable after creation.";
                readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
            };
            readonly fileName: {
                readonly type: "string";
            };
            readonly mimeType: {
                readonly type: "string | null";
                readonly required: false;
            };
            readonly fileSizeKb: {
                readonly type: "number | null";
                readonly required: false;
            };
            readonly issuedAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly expiresAt: {
                readonly type: "string (ISO date) | null";
                readonly required: false;
            };
            readonly issuer: {
                readonly type: "string | null";
                readonly required: false;
                readonly description: "Free text issuing authority name. Not an mdmId.";
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
    };
    export const ContactChannelDetail: {
        readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
        readonly fields: {
            readonly contactType: {
                readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
            };
            readonly value: {
                readonly type: "string";
                readonly description: "Full contact value. Stored unmasked.";
                readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
            };
            readonly isVerified: {
                readonly type: "boolean";
            };
            readonly verifiedAt: {
                readonly type: "timestamp | null";
                readonly required: false;
            };
            readonly notes: {
                readonly type: "string | null";
                readonly required: false;
                readonly constraints: "max 400 chars";
            };
        };
        readonly rules: readonly ["rule-contact-value-unique-per-type"];
    };
    export const RelationshipCatalog: {
        readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
        readonly entries: readonly [{
            readonly type: "Owns";
            readonly from: "Person | Company";
            readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
        }, {
            readonly type: "Employs";
            readonly from: "Company";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
        }, {
            readonly type: "OffersProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
        }, {
            readonly type: "OffersService";
            readonly from: "Company | Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
        }, {
            readonly type: "StocksAt";
            readonly from: "Product | AssetEquipment";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
        }, {
            readonly type: "Teaches";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
        }, {
            readonly type: "HappensAt";
            readonly from: "Service";
            readonly to: "Location";
            readonly bidirectional: false;
            readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
        }, {
            readonly type: "FranchiseOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
        }, {
            readonly type: "BelongsToGroup";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"subsidiary-brand\" }";
        }, {
            readonly type: "PartOfUnit";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
        }, {
            readonly type: "ManagedBy";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
        }, {
            readonly type: "ReportsTo";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"direct-report\" }";
        }, {
            readonly type: "AssignedTo";
            readonly from: "Person";
            readonly to: "Company | Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
        }, {
            readonly type: "Attends";
            readonly from: "Person";
            readonly to: "Service";
            readonly bidirectional: false;
            readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
        }, {
            readonly type: "SuppliesProduct";
            readonly from: "Company";
            readonly to: "Product";
            readonly bidirectional: false;
            readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
        }, {
            readonly type: "PartnersWith";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
        }, {
            readonly type: "Family";
            readonly from: "Person";
            readonly to: "Person";
            readonly bidirectional: true;
            readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
        }, {
            readonly type: "GuardianOf";
            readonly from: "Person";
            readonly to: "Animal";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
        }, {
            readonly type: "CustomerOf";
            readonly from: "Person | Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
        }, {
            readonly type: "SupplierOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
        }, {
            readonly type: "MemberOf";
            readonly from: "Person";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
        }, {
            readonly type: "HoldsAccount";
            readonly from: "Person | Company";
            readonly to: "BankAccount";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
        }, {
            readonly type: "SubsidiaryOf";
            readonly from: "Company";
            readonly to: "Company";
            readonly bidirectional: false;
            readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
        }, {
            readonly type: "LocatedAt";
            readonly from: "Person | Company";
            readonly to: "AssetProperty";
            readonly bidirectional: false;
            readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
        }, {
            readonly type: "Signed";
            readonly from: "Person | Company";
            readonly to: "Document";
            readonly bidirectional: false;
            readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
        }, {
            readonly type: "HasContact";
            readonly from: "any";
            readonly to: "ContactChannel";
            readonly bidirectional: false;
            readonly metadataExample: "{ isPrimary: true }";
        }];
    };
    export const MdmOntology: {
        readonly module: "mdm";
        readonly description: "Master Data Model — shared reference entities for all platform modules";
        readonly defaultCountry: "US";
        readonly storageStrategy: "hybrid";
        readonly storageNotes: readonly ["DynamoDB is the source of truth. Three columns per document: mdmId | version | details.", "details is a structured JSON document object containing all entity fields.", "details may embed compact relationshipRefs arrays for fast reads and restore support.", "Full relationship rows are replicated to DynamoDB table mdm_relationship_documents for backup and PostgreSQL rebuilds.", "No DynamoDB GSIs. All querying goes through PostgreSQL indexes.", "PostgreSQL has two index tables: MdmEntity (permanent) and MdmProspect (transient).", "MdmEntity enforces UNIQUE(docType, docId). MdmProspect does not.", "SYNC fields are written to PostgreSQL in the same request as DynamoDB.", "Async fields are propagated by a background worker reading updatedAt from details.", "Module extensions use a separate table per module (e.g. CrmMdmExt) with mdmId as FK.", "MDM has no knowledge of any consuming module — dependency is always module → MDM.", "On prospect promotion: mdmId is preserved. Merge conflicts require operator confirmation."];
        readonly postgresIndexes: {
            readonly MdmEntity: "Permanent, qualified, deduplicated records. UNIQUE(docType, docId).";
            readonly MdmProspect: "Transient records. No unique constraint on docId. Supports TTL expiry.";
            readonly MdmRelationship: "Relationship graph for permanent entities.";
            readonly MdmProspectRelationship: "Relationship graph for prospect entities. Same schema as MdmRelationship.";
        };
        readonly dynamoDocumentSchema: {
            readonly description: "DynamoDB document structure for all MDM entities. Three columns only.";
            readonly fields: {
                readonly mdmId: {
                    readonly type: "string (uuid)";
                    readonly description: "Partition key. Matches the mdmId in the PostgreSQL index.";
                };
                readonly version: {
                    readonly type: "number";
                    readonly description: "Monotonically incrementing integer. Incremented on every write. Used for optimistic concurrency — a write is rejected if version has changed since the last read.";
                };
                readonly details: {
                    readonly type: "object (JSON document)";
                    readonly description: "Structured document containing all entity fields: subtype, name, addresses[], contacts[] (ContactSummary), relationshipRefs (CompactRelationshipRefs), optional module namespaced blocks such as compras, and all subtype-specific fields. Each module-owned namespaced block should stay compact, with a recommended ceiling of 50KB per module block. The async worker reads updatedAt from inside details to determine what needs syncing to PostgreSQL.";
                };
            };
        };
        readonly entitySubtypes: {
            readonly Person: {
                readonly description: "Subtype Person — natural persons: customers, employees, partners, dependents.";
                readonly fields: {
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly gender: {
                        readonly type: "'Male' | 'Female' | 'NonBinary' | 'NotDisclosed' | null";
                        readonly required: false;
                    };
                    readonly nationality: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ISO 3166-1 alpha-2 country of nationality.";
                    };
                    readonly occupation: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 120 chars";
                    };
                    readonly photoUrl: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly privacyConsent: {
                        readonly type: "PrivacyConsent | null";
                        readonly required: false;
                        readonly description: "Required for BR (LGPD) and EU (GDPR) residents.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-person-ssn-unique-for-us", "rule-person-privacy-consent-required-br-eu"];
            };
            readonly Company: {
                readonly description: "Subtype Company — corporations, LLCs, nonprofits, government entities.";
                readonly fields: {
                    readonly companyKind: {
                        readonly type: "'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg'";
                        readonly description: "Organizational classification for legal and internal structures.";
                    };
                    readonly parentCompanyId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId for organizational trees.";
                    };
                    readonly externalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ERP/HR/legacy code used by consuming modules.";
                    };
                    readonly tradeName: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "DBA name. Also stored in aliases for full-text search.";
                    };
                    readonly legalName: {
                        readonly type: "string";
                        readonly description: "Official registered name.";
                    };
                    readonly legalType: {
                        readonly type: "'Corporation' | 'LLC' | 'SoleProp' | 'Partnership' | 'Nonprofit' | 'Government' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly foundingDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly taxRegime: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Country-specific tax class. Examples: S-Corp, C-Corp (US); Simples Nacional (BR).";
                    };
                    readonly industryCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "NAICS code (US), CNAE (BR), or equivalent.";
                    };
                    readonly website: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
                readonly rules: readonly ["rule-company-ein-unique-for-us", "rule-company-legal-name-required"];
            };
            readonly Product: {
                readonly description: "Subtype Product — inventory or catalog item that may be bought, stocked, sold, or offered by suppliers.";
                readonly fields: {
                    readonly sku: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Internal stock keeping unit.";
                    };
                    readonly productType: {
                        readonly type: "'Physical' | 'Digital' | 'Bundle' | 'Consumable' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly unitOfMeasure: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: unit, box, kg, liter, hour.";
                    };
                    readonly isInventoried: {
                        readonly type: "boolean";
                        readonly required: false;
                        readonly description: "True when stock is tracked by location.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Service: {
                readonly description: "Subtype Service — reusable service or offering that may be sold, scheduled, taught, or assigned to a location. Also covers course-like offerings.";
                readonly fields: {
                    readonly serviceCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly serviceKind: {
                        readonly type: "'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType'";
                        readonly required: false;
                        readonly description: "Use Cohort for a concrete class/offering instance.";
                    };
                    readonly parentServiceId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Parent mdmId when this service is a cohort or derived offering from a base service.";
                    };
                    readonly serviceType: {
                        readonly type: "'Course' | 'Consulting' | 'Maintenance' | 'Appointment' | 'Subscription' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly durationMinutes: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly deliveryMode: {
                        readonly type: "'Onsite' | 'Remote' | 'Hybrid' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly Location: {
                readonly description: "Subtype Location — room, warehouse, campus, store, branch, shelf area, or any physical place used for stock or service allocation.";
                readonly fields: {
                    readonly locationType: {
                        readonly type: "'Room' | 'Warehouse' | 'Building' | 'Campus' | 'Store' | 'Office' | 'Shelf' | 'Other'";
                    };
                    readonly locationCode: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly parentLocationId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Optional parent mdmId when this place belongs to a larger place.";
                    };
                    readonly capacity: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 1000 chars";
                    };
                };
            };
            readonly AssetGeneric: {
                readonly description: "Subtype AssetGeneric — fallback asset for cases that do not fit vehicle, property, or equipment cleanly.";
                readonly fields: {
                    readonly assetCategory: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Examples: furniture, lab-item, signage, toolkit, decor.";
                    };
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly manufacturer: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetVehicle: {
                readonly description: "Subtype AssetVehicle — cars, trucks, motorcycles, boats.";
                readonly fields: {
                    readonly plate: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly vin: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Vehicle Identification Number.";
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly year: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fuelType: {
                        readonly type: "'Gasoline' | 'Diesel' | 'Electric' | 'Hybrid' | 'Flex' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetProperty: {
                readonly description: "Subtype AssetProperty — residential, commercial, rural, or industrial real estate.";
                readonly fields: {
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Deed number, cadastral reference, or equivalent.";
                    };
                    readonly propertyAddress: {
                        readonly type: "Address | null";
                        readonly required: false;
                    };
                    readonly areaSqft: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square feet (primary unit for US).";
                    };
                    readonly areaM2: {
                        readonly type: "number | null";
                        readonly required: false;
                        readonly description: "Area in square meters (non-US markets).";
                    };
                    readonly propertyType: {
                        readonly type: "'Residential' | 'Commercial' | 'Rural' | 'UrbanLot' | 'Industrial' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly taxParcelId: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tax parcel / assessor ID (US) or equivalent.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly AssetEquipment: {
                readonly description: "Subtype AssetEquipment — machinery, devices, infrastructure equipment.";
                readonly fields: {
                    readonly serialNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly brand: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly model: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly category: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: printer, server, forklift, medical device";
                    };
                    readonly acquisitionDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly Animal: {
                readonly description: "Subtype Animal — pets, livestock, working animals.";
                readonly fields: {
                    readonly species: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "Examples: Dog, Cat, Horse, Bovine, Bird";
                    };
                    readonly breed: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly birthDate: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly sex: {
                        readonly type: "'Male' | 'Female' | 'Unknown' | null";
                        readonly required: false;
                    };
                    readonly color: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly microchip: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly registrationNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Breed registry, USDA tag, or official animal ID.";
                    };
                    readonly isNeutered: {
                        readonly type: "boolean | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
            };
            readonly BankAccount: {
                readonly description: "Subtype BankAccount — routing data only. Balances and transactions belong in the finance module.";
                readonly fields: {
                    readonly bankRoutingNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ABA routing number (US). Use swift for international.";
                    };
                    readonly bankName: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountNumber: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly accountType: {
                        readonly type: "'Checking' | 'Savings' | 'MoneyMarket' | 'Payment' | 'Other' | null";
                        readonly required: false;
                    };
                    readonly swift: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "BIC/SWIFT for international transfers.";
                    };
                    readonly iban: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKey: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly pixKeyType: {
                        readonly type: "'CPF' | 'CNPJ' | 'Phone' | 'Email' | 'RandomKey' | null";
                        readonly required: false;
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                        readonly description: "Verified via micro-deposit, open banking, or manual review.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-bank-account-holder-via-relationship", "rule-bank-account-routing-required-for-us"];
            };
            readonly Document: {
                readonly description: "Subtype Document — indexed reference to an external file. The file never lives in MDM.";
                readonly fields: {
                    readonly originModule: {
                        readonly type: "string";
                        readonly description: "Module that created this record.";
                        readonly constraints: "Examples: legal, maintenance, hr, finance";
                    };
                    readonly docCategory: {
                        readonly type: "'Contract' | 'Certificate' | 'IdDocument' | 'Invoice' | 'Receipt' | 'Report' | 'Photo' | 'Other'";
                    };
                    readonly storageBucket: {
                        readonly type: "string";
                        readonly description: "S3 bucket (or equivalent) where the file resides.";
                    };
                    readonly storagePath: {
                        readonly type: "string";
                        readonly description: "Relative path within the bucket. Immutable after creation.";
                        readonly constraints: "Example: doc/2026/03/17/contract-001.pdf";
                    };
                    readonly fileName: {
                        readonly type: "string";
                    };
                    readonly mimeType: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly fileSizeKb: {
                        readonly type: "number | null";
                        readonly required: false;
                    };
                    readonly issuedAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly expiresAt: {
                        readonly type: "string (ISO date) | null";
                        readonly required: false;
                    };
                    readonly issuer: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Free text issuing authority name. Not an mdmId.";
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-document-parties-via-relationships", "rule-document-path-immutable"];
            };
            readonly ContactChannel: {
                readonly description: "Subtype ContactChannel — phone, email, or social handle as a first-class traceable communication channel.";
                readonly fields: {
                    readonly contactType: {
                        readonly type: "'Phone' | 'Email' | 'WhatsApp' | 'Instagram' | 'LinkedIn' | 'X' | 'Other'";
                    };
                    readonly value: {
                        readonly type: "string";
                        readonly description: "Full contact value. Stored unmasked.";
                        readonly constraints: "Access control enforced at the BFF layer. Examples: +12125550100, john@company.com";
                    };
                    readonly isVerified: {
                        readonly type: "boolean";
                    };
                    readonly verifiedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly constraints: "max 400 chars";
                    };
                };
                readonly rules: readonly ["rule-contact-value-unique-per-type"];
            };
        };
        readonly embeddedTypes: {
            readonly Address: {
                readonly description: "A physical or mailing address. Embedded inline in entity documents — not a standalone MDM entity.";
                readonly fields: {
                    readonly type: {
                        readonly type: "'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other'";
                    };
                    readonly label: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Short human label for this address.";
                        readonly constraints: "max 60 chars. Examples: home, headquarters, warehouse, branch";
                    };
                    readonly line1: {
                        readonly type: "string";
                        readonly description: "Primary address line: street and number, PO Box, or rural route.";
                    };
                    readonly line2: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Secondary line: apartment, suite, floor, unit, building.";
                    };
                    readonly line3: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Tertiary line: neighborhood, district, borough, ward. Required in some countries (Brazil, India, Japan).";
                    };
                    readonly city: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                    readonly stateOrProvince: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "State, province, prefecture, or canton. For US use 2-letter code (CA, NY, TX).";
                    };
                    readonly postalCode: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "ZIP, postcode, CEP, PIN — format varies by country. MDM does not enforce format.";
                    };
                    readonly countryCode: {
                        readonly type: "string";
                        readonly description: "ISO 3166-1 alpha-2. Drives address format display in UI.";
                        readonly constraints: "Default: US";
                    };
                    readonly formatted: {
                        readonly type: "string | null";
                        readonly required: false;
                        readonly description: "Cached full address string as it would appear on an envelope. Async-generated. Avoids per-country format reconstruction at render time.";
                    };
                    readonly geolocation: {
                        readonly type: "{ lat: number; lng: number } | null";
                        readonly required: false;
                    };
                    readonly isPrimary: {
                        readonly type: "boolean";
                    };
                };
            };
            readonly PrivacyConsent: {
                readonly description: "Privacy / data protection consent record embedded in Person documents. Required when countryCode is BR (LGPD) or an EU member state (GDPR).";
                readonly fields: {
                    readonly consentedAt: {
                        readonly type: "timestamp";
                    };
                    readonly consentVersion: {
                        readonly type: "string";
                        readonly description: "Version of the privacy policy accepted.";
                    };
                    readonly channel: {
                        readonly type: "string";
                        readonly description: "How consent was obtained.";
                        readonly constraints: "Examples: web-signup, paper-form, whatsapp, verbal";
                    };
                    readonly revokedAt: {
                        readonly type: "timestamp | null";
                        readonly required: false;
                    };
                    readonly notes: {
                        readonly type: "string | null";
                        readonly required: false;
                    };
                };
            };
            readonly ContactSummary: {
                readonly description: "Slim reference to a ContactChannel entity. Embedded in the detail of any entity that has associated contacts.";
                readonly fields: {
                    readonly mdmId: {
                        readonly type: "string (uuid)";
                        readonly description: "mdmId of the ContactChannel entity. Required for traceability and cross-module linking.";
                    };
                    readonly title: {
                        readonly type: "string";
                        readonly description: "Human-readable label for this contact in the context of the parent entity.";
                        readonly constraints: "max 60 chars. Examples: Work email, Mobile, Support line, Personal WhatsApp";
                    };
                };
            };
            readonly CompactRelationshipRefs: {
                readonly description: "Compact relationship reference buckets embedded in details. Each field stores only mdmId arrays and is derived from the relational relationship tables.";
                readonly fields: {
                    readonly ownedAssets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly owners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employees: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly employers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly partners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly family: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly pets: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly guardians: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly customers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly suppliers: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly memberships: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly members: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly bankAccounts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly accountHolders: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly subsidiaries: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly parentCompanies: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locations: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly locatedEntities: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly documents: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly signedBy: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contacts: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                    readonly contactOwners: {
                        readonly type: "string[]";
                        readonly required: false;
                    };
                };
            };
        };
        readonly relationships: {
            readonly description: "All supported relationship types with cardinality, bidirectionality, and metadata examples.";
            readonly entries: readonly [{
                readonly type: "Owns";
                readonly from: "Person | Company";
                readonly to: "AssetGeneric | AssetVehicle | AssetProperty | AssetEquipment";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2022-01-01\", ownershipPct: 100 }";
            }, {
                readonly type: "Employs";
                readonly from: "Company";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"Software Engineer\", department: \"Engineering\", startDate: \"2023-06-01\" }";
            }, {
                readonly type: "OffersProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", supplierSku: \"CHAIR-01\" }";
            }, {
                readonly type: "OffersService";
                readonly from: "Company | Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2024-01-01\", priceTable: \"default\" }";
            }, {
                readonly type: "StocksAt";
                readonly from: "Product | AssetEquipment";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ quantity: 20, unit: \"unit\", minLevel: 5 }";
            }, {
                readonly type: "Teaches";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"primary-instructor\", since: \"2026-03-01\" }";
            }, {
                readonly type: "HappensAt";
                readonly from: "Service";
                readonly to: "Location";
                readonly bidirectional: false;
                readonly metadataExample: "{ scheduleLabel: \"Engineering 1 - morning\", weekday: \"Mon\" }";
            }, {
                readonly type: "FranchiseOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ contractId: \"uuid\", territory: \"south-zone\" }";
            }, {
                readonly type: "BelongsToGroup";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"subsidiary-brand\" }";
            }, {
                readonly type: "PartOfUnit";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"department\" | \"team\" | \"branch-unit\" }";
            }, {
                readonly type: "ManagedBy";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"manager\" | \"coordinator\" }";
            }, {
                readonly type: "ReportsTo";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"direct-report\" }";
            }, {
                readonly type: "AssignedTo";
                readonly from: "Person";
                readonly to: "Company | Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"member\" | \"assistant\" | \"instructor\" }";
            }, {
                readonly type: "Attends";
                readonly from: "Person";
                readonly to: "Service";
                readonly bidirectional: false;
                readonly metadataExample: "{ attendanceStatus: \"enrolled\" | \"completed\" }";
            }, {
                readonly type: "SuppliesProduct";
                readonly from: "Company";
                readonly to: "Product";
                readonly bidirectional: false;
                readonly metadataExample: "{ leadTimeDays: 7, catalogCode: \"SUP-001\" }";
            }, {
                readonly type: "PartnersWith";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 30, role: \"managing-partner\" }";
            }, {
                readonly type: "Family";
                readonly from: "Person";
                readonly to: "Person";
                readonly bidirectional: true;
                readonly metadataExample: "{ degree: \"spouse\" | \"child\" | \"parent\" | \"sibling\" }";
            }, {
                readonly type: "GuardianOf";
                readonly from: "Person";
                readonly to: "Animal";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2020-05-10\", guardianType: \"owner\" | \"foster\" }";
            }, {
                readonly type: "CustomerOf";
                readonly from: "Person | Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ since: \"2021-01-01\", segment: \"retail\" }";
            }, {
                readonly type: "SupplierOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ category: \"raw-materials\", contractMdmId: \"uuid\" }";
            }, {
                readonly type: "MemberOf";
                readonly from: "Person";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"board-member\", membershipType: \"honorary\" }";
            }, {
                readonly type: "HoldsAccount";
                readonly from: "Person | Company";
                readonly to: "BankAccount";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true, since: \"2019-03-15\" }";
            }, {
                readonly type: "SubsidiaryOf";
                readonly from: "Company";
                readonly to: "Company";
                readonly bidirectional: false;
                readonly metadataExample: "{ equityPct: 100, type: \"wholly-owned\" | \"affiliate\" }";
            }, {
                readonly type: "LocatedAt";
                readonly from: "Person | Company";
                readonly to: "AssetProperty";
                readonly bidirectional: false;
                readonly metadataExample: "{ locationType: \"headquarters\" | \"branch\" | \"warehouse\" }";
            }, {
                readonly type: "Signed";
                readonly from: "Person | Company";
                readonly to: "Document";
                readonly bidirectional: false;
                readonly metadataExample: "{ role: \"contractor\" | \"client\" | \"witness\" | \"notary\" }";
            }, {
                readonly type: "HasContact";
                readonly from: "any";
                readonly to: "ContactChannel";
                readonly bidirectional: false;
                readonly metadataExample: "{ isPrimary: true }";
            }];
        };
    };
}
declare module "_102034_/l1/mdm/module" {
    import type { DocType, MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type AddressType = 'Residential' | 'Commercial' | 'Billing' | 'Delivery' | 'Other';
    export type RelationshipStatus = 'Active' | 'Inactive' | 'PendingConfirmation';
    export interface AddressValue {
        type: AddressType;
        label?: string | null;
        line1: string;
        line2?: string | null;
        line3?: string | null;
        city?: string | null;
        stateOrProvince?: string | null;
        postalCode?: string | null;
        countryCode: string;
        formatted?: string | null;
        geolocation?: {
            lat: number;
            lng: number;
        } | null;
        isPrimary: boolean;
    }
    export interface PrivacyConsentValue {
        consentedAt: string;
        consentVersion: string;
        channel: string;
        revokedAt?: string | null;
        notes?: string | null;
    }
    export interface ContactSummaryValue {
        mdmId: string;
        title: string;
    }
    export type CompanyKind = 'LegalEntity' | 'Branch' | 'Franchise' | 'BusinessUnit' | 'Group' | 'Team' | 'Department' | 'InternalOrg';
    export type ServiceKind = 'Service' | 'Course' | 'Cohort' | 'Subscription' | 'AppointmentType';
    export type MdmModuleNamespaceValue = Record<string, unknown>;
    export type CompactRelationshipRefKey = 'ownedAssets' | 'owners' | 'employees' | 'employers' | 'offeredProducts' | 'productSuppliers' | 'offeredServices' | 'serviceProviders' | 'stockLocations' | 'stockedItems' | 'taughtServices' | 'instructors' | 'serviceLocations' | 'scheduledServices' | 'franchisees' | 'franchisors' | 'groupParents' | 'groupMembers' | 'unitParents' | 'unitChildren' | 'managedOrganizations' | 'managers' | 'reports' | 'reportManagers' | 'assignments' | 'assignees' | 'attendedServices' | 'attendees' | 'suppliedProducts' | 'productVendors' | 'partners' | 'family' | 'pets' | 'guardians' | 'customers' | 'suppliers' | 'memberships' | 'members' | 'bankAccounts' | 'accountHolders' | 'subsidiaries' | 'parentCompanies' | 'locations' | 'locatedEntities' | 'documents' | 'signedBy' | 'contacts' | 'contactOwners';
    export type CompactRelationshipRefs = Partial<Record<CompactRelationshipRefKey, string[]>>;
    export interface BaseMdmDetailRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        aliases: string[];
        contacts: ContactSummaryValue[];
        relationshipRefs: CompactRelationshipRefs;
        addresses: AddressValue[];
        mergedInto?: string | null;
        createdAt: string;
        updatedAt: string;
        [moduleNamespace: string]: unknown;
    }
    export interface PersonDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Person';
        privacyConsent?: PrivacyConsentValue | null;
        birthDate?: string | null;
        gender?: string | null;
        nationality?: string | null;
        occupation?: string | null;
        photoUrl?: string | null;
        notes?: string | null;
    }
    export interface CompanyDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Company';
        companyKind: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        legalName: string;
        tradeName?: string | null;
        legalType?: string | null;
        foundingDate?: string | null;
        taxRegime?: string | null;
        industryCode?: string | null;
        website?: string | null;
        notes?: string | null;
    }
    export interface ProductDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Product';
        sku?: string | null;
        productType?: string | null;
        category?: string | null;
        brand?: string | null;
        unitOfMeasure?: string | null;
        isInventoried?: boolean;
        notes?: string | null;
    }
    export interface ServiceDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Service';
        serviceCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        serviceType?: string | null;
        durationMinutes?: number | null;
        deliveryMode?: string | null;
        notes?: string | null;
    }
    export interface LocationDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Location';
        locationType: string;
        locationCode?: string | null;
        parentLocationId?: string | null;
        capacity?: number | null;
        propertyAddress?: AddressValue | null;
        notes?: string | null;
    }
    export interface AssetGenericDetailRecord extends BaseMdmDetailRecord {
        subtype: 'AssetGeneric';
        assetCategory?: string | null;
        serialNumber?: string | null;
        manufacturer?: string | null;
        model?: string | null;
        notes?: string | null;
    }
    export interface ContactChannelDetailRecord extends BaseMdmDetailRecord {
        subtype: 'ContactChannel';
        contactType: string;
        value: string;
        isVerified?: boolean;
        verifiedAt?: string | null;
        notes?: string | null;
    }
    export interface DocumentDetailRecord extends BaseMdmDetailRecord {
        subtype: 'Document';
        storageBucket: string;
        storagePath: string;
        originModule: string;
        docCategory: string;
        fileName: string;
        mimeType?: string | null;
        notes?: string | null;
    }
    export interface BankAccountDetailRecord extends BaseMdmDetailRecord {
        subtype: 'BankAccount';
        bankRoutingNumber?: string | null;
        bankName?: string | null;
        accountNumber?: string | null;
        accountType?: string | null;
        swift?: string | null;
        iban?: string | null;
        pixKey?: string | null;
        pixKeyType?: string | null;
        isVerified?: boolean;
        notes?: string | null;
    }
    export interface ProspectLifecycleFields {
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
    }
    export interface GenericMdmDetailRecord extends BaseMdmDetailRecord, ProspectLifecycleFields {
        subtype: 'Product' | 'Service' | 'Location' | 'AssetGeneric' | 'AssetVehicle' | 'AssetProperty' | 'AssetEquipment' | 'Animal' | 'BankAccount' | 'Document' | 'ContactChannel' | 'Person' | 'Company';
        legalName?: string;
        companyKind?: CompanyKind;
        parentCompanyId?: string | null;
        externalCode?: string | null;
        serviceKind?: ServiceKind;
        parentServiceId?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    }
    export type MdmDetailRecord = (PersonDetailRecord & ProspectLifecycleFields) | (CompanyDetailRecord & ProspectLifecycleFields) | (ProductDetailRecord & ProspectLifecycleFields) | (ServiceDetailRecord & ProspectLifecycleFields) | (LocationDetailRecord & ProspectLifecycleFields) | (AssetGenericDetailRecord & ProspectLifecycleFields) | (ContactChannelDetailRecord & ProspectLifecycleFields) | (DocumentDetailRecord & ProspectLifecycleFields) | (BankAccountDetailRecord & ProspectLifecycleFields) | GenericMdmDetailRecord;
    export type CreateableMdmDetailInput = {
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus | MdmProspectStatus;
        moduleTypes?: string[];
        docType?: DocType | null;
        docId?: string | null;
        countryCode?: string;
        tags?: string[];
        aliases?: string[];
        contacts?: ContactSummaryValue[];
        relationshipRefs?: CompactRelationshipRefs;
        addresses?: AddressValue[];
        mergedInto?: string | null;
        promotionSource?: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        privacyConsent?: PrivacyConsentValue | null;
        legalName?: string;
        contactType?: string;
        value?: string;
        storageBucket?: string;
        storagePath?: string;
        [key: string]: unknown;
    };
    export interface MdmDocumentRecord {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }
    type DistributiveOmit<T, K extends keyof T> = T extends unknown ? Omit<T, K> : never;
    export type MdmDetailInput = DistributiveOmit<MdmDetailRecord, 'mdmId'> & {
        mdmId?: string;
    };
    export interface MdmDocumentInput {
        mdmId: string;
        version: number;
        details: MdmDetailInput;
    }
    export interface MdmEntityIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        searchVector: string;
        mergedInto?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmProspectIndexRecord {
        mdmId: string;
        subtype: MdmSubtype;
        name: string;
        status: MdmProspectStatus;
        docType?: DocType | null;
        docId?: string | null;
        countryCode: string;
        tags: string[];
        promotionSource: string;
        promotedTo?: string | null;
        ttlExpiresAt?: string | null;
        dynamoPk: string;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipRecord {
        id: string;
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        isBidirectional: boolean;
        validFrom: string;
        validTo?: string | null;
        status: RelationshipStatus;
        createdAt: string;
        updatedAt: string;
    }
    export interface MdmRelationshipDocumentRecord extends MdmRelationshipRecord {
        scope: 'entity' | 'prospect';
    }
    export type MdmAuditAction = 'create' | 'update' | 'delete' | 'restore' | 'transitionStatus';
    export type MdmActorType = 'user' | 'agent' | 'system';
    export type MdmAuditDiffType = 'CHANGE' | 'CREATE' | 'REMOVE';
    export interface MdmAuditDiffEntry {
        type: MdmAuditDiffType;
        path: Array<string | number>;
        oldValue?: unknown;
        value?: unknown;
    }
    export interface MdmAuditLogIndexRecord {
        id: string;
        entityType: string;
        entityId: string;
        action: MdmAuditAction;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        createdAt: string;
    }
    export interface MdmAuditLogDocumentRecord extends MdmAuditLogIndexRecord {
        diff: MdmAuditDiffEntry[] | null;
    }
    export interface MdmMonitoringWriteRecord {
        id: string;
        entityType: string;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        success: boolean;
        durationMs: number;
        startedAt: string;
        finishedAt: string;
        actorType: MdmActorType;
        source: 'http' | 'message' | 'test' | 'system';
        errorCode?: string | null;
    }
    export interface MdmErrorLogRecord {
        id: string;
        entityType?: string | null;
        entityId?: string | null;
        module: string;
        routine: string;
        action: MdmAuditAction;
        errorCode: string;
        message: string;
        details?: Record<string, unknown> | null;
        stack?: string | null;
        createdAt: string;
    }
    export interface MdmStatusHistoryRecord {
        id: string;
        entityType: string;
        entityId: string;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        actorId: string;
        actorType: MdmActorType;
        module: string;
        routine: string;
        metadata?: Record<string, unknown> | null;
        createdAt: string;
    }
    export interface MdmTagRecord {
        id: string;
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy: string;
        createdByType: MdmActorType;
        createdAt: string;
    }
    export interface MdmCommentRecord {
        id: string;
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        authorId: string;
        authorType: MdmActorType;
        module: string;
        isSystemGenerated: boolean;
        editedAt?: string | null;
        deletedAt?: string | null;
        createdAt: string;
    }
    export interface MdmAttachmentRecord {
        id: string;
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy: string;
        uploadedAt: string;
        deletedAt?: string | null;
        details?: Record<string, unknown> | null;
    }
    export type NumberSequenceScopeType = 'global' | 'company' | 'branch';
    export interface MdmNumberSequenceRecord {
        id: string;
        sequenceKey: string;
        prefix?: string | null;
        currentValue: number;
        increment: number;
        padding?: number | null;
        yearSegment: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        lastIssuedAt: string;
        createdAt: string;
        details?: Record<string, unknown> | null;
    }
    export interface MdmKvRecord {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface MdmOutboxRecord {
        id: string;
        topic: string;
        aggregateType: 'MdmDocument' | 'MdmRelationship' | 'MdmAuditLog' | 'MdmTag' | 'MdmComment' | 'MdmAttachment' | 'MdmNumberSequence' | 'RegistryTable';
        aggregateId: string;
        eventType: 'UpsertDocument' | 'DeleteDocument' | 'UpsertRelationship' | 'DeleteRelationship' | 'UpsertAuditLog' | 'UpsertTag' | 'UpsertComment' | 'UpsertAttachment' | 'UpsertNumberSequence' | 'UpsertRegistryTableRecord' | 'DeleteRegistryTableRecord';
        payload: Record<string, unknown>;
        attemptCount: number;
        processedAt?: string | null;
        lastError?: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface CreateRecordParams<TDetail extends CreateableMdmDetailInput = CreateableMdmDetailInput> {
        detail: TDetail;
    }
    export interface UpdateRecordParams {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface ListRecordsParams {
        subtype?: MdmSubtype;
        status?: string;
        countryCode?: string;
        limit?: number;
        orderBy?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface PromoteProspectParams {
        mdmId: string;
    }
    export interface MergeEntityParams {
        winnerMdmId: string;
        loserMdmId: string;
    }
    export interface CreateRelationshipParams {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface UpdateRelationshipParams {
        id: string;
        patch: Partial<Pick<MdmRelationshipRecord, 'role' | 'metadata' | 'validFrom' | 'validTo' | 'status'>>;
    }
    export interface ListRelationshipsParams {
        entityId?: string;
        scope?: 'entity' | 'prospect' | 'all';
        status?: RelationshipStatus;
        type?: RelationshipType;
    }
    export interface SearchParams {
        query?: string;
        subtype?: MdmSubtype;
        status?: string;
        scope?: 'entity' | 'prospect' | 'all';
        limit?: number;
    }
    export interface AddTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        namespace?: string | null;
        module: string;
        createdBy?: string;
        createdByType?: MdmActorType;
    }
    export interface RemoveTagParams {
        entityType: string;
        entityId: string;
        tag: string;
        module: string;
    }
    export interface FindTagsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface FindTagsByTagParams {
        entityType: string;
        tag: string;
        module?: string;
        namespace?: string | null;
    }
    export interface AddCommentParams {
        entityType: string;
        entityId: string;
        parentCommentId?: string | null;
        text: string;
        module: string;
        authorId?: string;
        authorType?: MdmActorType;
        isSystemGenerated?: boolean;
    }
    export interface EditCommentParams {
        id: string;
        text: string;
        editorId?: string;
    }
    export interface RemoveCommentParams {
        id: string;
    }
    export interface FindCommentsByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface AttachFileParams {
        entityType: string;
        entityId: string;
        fileName: string;
        mimeType: string;
        sizeBytes: number;
        storageKey: string;
        storageProvider: 's3' | 'local';
        category?: string | null;
        uploadedBy?: string;
        details?: Record<string, unknown> | null;
    }
    export interface DetachFileParams {
        id: string;
    }
    export interface FindAttachmentsByEntityParams {
        entityType: string;
        entityId: string;
        category?: string | null;
    }
    export interface NumberSequenceNextParams {
        sequenceKey: string;
        prefix?: string | null;
        increment?: number;
        padding?: number | null;
        yearSegment?: boolean;
        scopeType: NumberSequenceScopeType;
        scopeId?: string | null;
        details?: Record<string, unknown> | null;
    }
    export interface GetMdmKvParams {
        key: string;
    }
    export interface PutMdmKvParams {
        key: string;
        value: Record<string, unknown> | null;
    }
    export interface FindStatusHistoryByEntityParams {
        entityType: string;
        entityId: string;
        limit?: number;
    }
    export interface FindLatestStatusByEntityParams {
        entityType: string;
        entityId: string;
    }
    export interface RecordDetailResponse {
        index: MdmEntityIndexRecord | MdmProspectIndexRecord;
        document: MdmDocumentRecord;
        details: MdmDetailRecord;
    }
    export type ModuleIdStrategy = 'uuidv7';
    export type ModuleLocalStore = 'postgres';
    export type ModuleRemoteStore = 'dynamodb';
    export type ModuleWriteMode = 'sync' | 'writeBehind';
    export interface ModulePersistenceConfig {
        idStrategy: ModuleIdStrategy;
        localStore: ModuleLocalStore;
        remoteStore: ModuleRemoteStore;
        writeMode: ModuleWriteMode;
        remoteSourceOfTruth: boolean;
        restoreLocalFromRemote: boolean;
    }
    export interface ModuleConfig {
        moduleId: 'mdm';
        persistence: ModulePersistenceConfig;
    }
    export interface EntityDef<TDetail, TIndex> {
        entityType: string;
        moduleName: string;
        getIndexRuntime(runtime: import("_102034_/l1/server/layer_1_external/data/runtime").IDataRuntime): import("_102034_/l1/server/layer_1_external/data/runtime").ITableRuntime<TIndex>;
        buildIndex(detail: TDetail): TIndex;
        toDocument(detail: TDetail, version: number): MdmDocumentRecord;
        getId(detail: TDetail): string;
        getAuditSnapshot(detail: TDetail, index: TIndex): Record<string, unknown>;
    }
    export const moduleConfig: ModuleConfig;
}
declare module "_102034_/l1/server/layer_1_external/config/storageConfig" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    type StorageConfig = {
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
    };
    export function getStorageConfig(appEnv: AppEnv['appEnv']): StorageConfig;
}
declare module "_102034_/l1/server/layer_1_external/storage/attachmentLimits" {
    export const DEFAULT_ATTACHMENT_MAX_BYTES: number;
    export const DEFAULT_ATTACHMENT_ALLOWED_MIME: readonly ["image/jpeg", "image/png", "image/webp", "image/gif", "application/pdf"];
    export interface AttachmentLimits {
        maxBytes: number;
        allowedMime: readonly string[];
    }
    export function defaultAttachmentLimits(): AttachmentLimits;
    export function parseAllowedMime(value: string | undefined): string[];
    export function validateAttachmentPayload(input: {
        mimeType: string;
        sizeBytes: number;
        limits?: AttachmentLimits;
    }): void;
    /** Decode the body of a dedicated upload route. `data:` URLs are stripped; raw base64 is accepted. */
    export function decodeAttachmentBase64(raw: string): Buffer;
}
declare module "_102034_/l1/server/layer_1_external/storage/objectBuckets" {
    /**
     * Object-storage buckets of a published app.
     *
     * One PERMANENT bucket per client project, named with the project id (default `collab-{projectId}`).
     * Business attachments (a pet photo, a signed PDF) live there and nowhere else — a lifecycle rule
     * that expires objects would leave `mdm_attachment` pointing at a dead key.
     *
     * A second, OPTIONAL tmp bucket (default `collab-{projectId}-tmp`) exists for ephemeral artifacts
     * (LLM images that may vanish). MDM attachments never use it. Empty `S3_BUCKET_TMP` disables it.
     *
     * Without AWS credentials, without a resolvable project id, or with `S3_BUCKET` explicitly empty,
     * the runtime falls back to local disk. The reason is always named — never a generic S3 crash.
     */
    export type ObjectBucketKind = 'permanent' | 'tmp';
    export type ObjectStorageProvider = 's3' | 'local';
    export const DEFAULT_PERMANENT_BUCKET_PATTERN = "collab-{projectId}";
    export const DEFAULT_TMP_BUCKET_PATTERN = "collab-{projectId}-tmp";
    export interface ObjectBucketResolution {
        provider: ObjectStorageProvider;
        projectId: string;
        /** Permanent bucket name (S3) or directory leaf (local). Always set. */
        permanent: string;
        /** Tmp bucket name, or null when the operator disabled it. MDM attach never reads this. */
        tmp: string | null;
        /** Why we are on `local`, empty when S3 is ready. */
        localReason: string;
    }
    export interface ObjectBucketEnv {
        s3BucketPattern?: string | null;
        s3BucketTmpPattern?: string | null;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        projectId?: string;
    }
    export function applyProjectId(pattern: string, projectId: string): string;
    export function resolveObjectBuckets(env: ObjectBucketEnv): ObjectBucketResolution;
    export function bucketFor(kind: ObjectBucketKind, resolution: ObjectBucketResolution): string | null;
}
declare module "_102034_/l1/server/layer_1_external/config/env" {
    export interface AppEnv {
        appEnv: 'development' | 'staging' | 'production';
        port: number;
        pgHost: string;
        pgPort: number;
        pgDatabase: string;
        pgUser: string;
        pgPassword: string;
        dynamoTableMdm: string;
        dynamoTableMdmRelationship: string;
        dynamoTableMdmProspectRelationship: string;
        dynamoTableMdmAuditLog: string;
        dynamoTableMdmTag: string;
        dynamoTableMdmComment: string;
        dynamoTableMdmAttachment: string;
        dynamoTableMdmNumberSequence: string;
        awsRegion: string;
        awsAccessKeyId?: string;
        awsSecretAccessKey?: string;
        awsSessionToken?: string;
        writeBehindEnabled: boolean;
        logLevel: string;
        runtimeMode: 'memory' | 'postgres';
        testsEnabled: boolean;
        projectId?: string;
        projectDomain?: string;
        studioEnabled: boolean;
        activeCompanyId?: string;
        activeUnitId?: string;
        currentWorkspaceId?: string;
        actorId?: string;
        actorScope: string[];
        /**
         * Permanent object-storage bucket pattern. `{projectId}` is replaced with the client project
         * (default `collab-{projectId}`). Empty string forces local disk.
         */
        s3BucketPattern: string;
        /** Optional tmp bucket pattern (default `collab-{projectId}-tmp`). Empty disables it. MDM never uses it. */
        s3BucketTmpPattern: string;
        attachmentMaxBytes: number;
        attachmentAllowedMime: string[];
        attachmentLocalDir?: string;
    }
    export function readAppEnv(): AppEnv;
}
declare module "_102029_/l2/runtimeConfigTypes" {
    export type ProjectType = 'master frontend' | 'master backend' | 'client' | 'lib';
    export interface ProjectModuleFrontendEntrypoint {
        entrypoint: string;
        componentTag: string;
    }
    export interface ProjectFrontendPageConfig {
        pageId: string;
        route: string;
        source: string;
        definition?: string;
        componentTag: string;
        title?: string;
    }
    export interface ProjectModuleFrontendConfig {
        layer?: 'l2' | string;
        moduleEntrypoint?: string;
        moduleSource?: string;
        pages?: ProjectFrontendPageConfig[];
        pageTests?: string[];
    }
    export interface ProjectPersistenceModuleConfig {
        moduleId: string;
        persistenceEntrypoint?: string;
        tableDefsDir?: string;
    }
    export interface ProjectRegionRendererConfig {
        entrypoint: string;
        tag: string;
        source?: string;
    }
    export interface ProjectDynamicRegionConfig {
        renderer: ProjectRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface ProjectShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, ProjectDynamicRegionConfig>;
    }
    export interface ProjectClientShellConfig {
        mode: 'spa' | 'pwa';
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: ProjectShellRegionProfiles;
            aside?: ProjectShellRegionProfiles;
        };
    }
    export interface ProjectNavigationEntry {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface ProjectModuleConfig {
        moduleId: string;
        basePath: string;
        shellMode: 'spa' | 'pwa';
        languages?: string[];
        designSystems?: string[];
        navigation?: ProjectNavigationEntry[];
        frontendEntrypoints?: {
            desktop?: ProjectModuleFrontendEntrypoint;
            mobile?: ProjectModuleFrontendEntrypoint;
        };
        frontend?: ProjectModuleFrontendConfig;
        backendRouter?: string;
        backendControllers?: string;
        backend?: Record<string, unknown>;
    }
    export interface ProjectConfigRecord {
        root: string;
        type?: ProjectType;
        role?: string;
        runtime?: ProjectRuntimeMetadata;
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    export interface ProjectRuntimeMetadata {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface ProjectsConfig {
        defaultProjectId: string;
        shellTemplates: {
            spa: string;
            pwa: string;
        };
        clientShell?: ProjectClientShellConfig;
        projects: Record<string, ProjectConfigRecord>;
    }
    /** System modules a production master ships with (e.g. 102034: mdm, monitor, audit).
     *  The publish composer merges this into projects[<runtimeProject>] of the composed
     *  config.json — the master stays self-describing and agnostic to clients. */
    export interface MasterRuntimeManifest {
        modules?: ProjectModuleConfig[];
        persistenceModules?: ProjectPersistenceModuleConfig[];
    }
    /** Signature written by a change agent: who generated this side of the project. */
    export interface L5MasterSignature {
        /** Studio (dev) project that hosts the agent, e.g. 102020 / 102021. */
        masterProject: number;
        /** Agent folder inside <masterProject>/l2; the publish resolves the composer at
         *  mls-<masterProject>/l2/<agentFolder>/nodejsSaveConfigJson.ts */
        agentFolder: string;
        /** Production master referenced in the composed config.json, e.g. 102033 / 102034. */
        runtimeProject: number;
    }
    export interface L5Masters {
        frontend?: L5MasterSignature;
        backend?: L5MasterSignature;
    }
    export interface L5ModuleBackendConfig {
        backendControllers: string;
        persistence: {
            tableDefsDir: string;
        };
        routeKeys: string[];
    }
    export interface L5Module {
        moduleName: string;
        backend?: L5ModuleBackendConfig;
    }
    export interface L5Dependency {
        projectId: string;
        kind?: string;
    }
    export interface L5Language {
        language: string;
        name?: string;
        path?: string;
    }
    export interface L5Layout {
        name?: string;
        [key: string]: unknown;
    }
    /** Brand identity shown by a header profile (resolved by AuraHeaderBase at runtime). */
    export interface AppHeaderBrand {
        title: string;
        subtitle?: string;
        /**
         * Inline SVG markup of the mark (what agentGenerateLogo writes). Preferred over `logoUrl`: an
         * inlined mark inherits `currentColor`, so it follows the design system in light and dark, which
         * an `<img src="*.svg">` cannot do (an external SVG never sees the page's CSS).
         */
        logoSvg?: string;
        /** `.svg` only — that is the asset kind that lands in dist. Colors are baked (no theme switch). */
        logoUrl?: string;
        logoAlt?: string;
        href?: string;
    }
    /** Optional actions a generated header may render (all off unless listed). */
    export type AppHeaderAction = 'language' | 'designSystem' | 'modules' | 'search' | 'user';
    /** Manual customization carried by the client project; composers translate these
     *  fields into the generated config.json instead of hand-editing it (the composed
     *  file is overwritten on every publish). */
    export interface L5RuntimeCustomize {
        clientShell?: ProjectClientShellConfig;
        shellTemplates?: {
            spa: string;
            pwa: string;
        };
        navigationLabels?: Record<string, string>;
    }
    export interface L5ProjectJson {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
        orgName?: string;
        designSystems?: Array<Record<string, unknown>>;
        languages?: L5Language[];
        layouts?: Record<string, L5Layout>;
        plugins?: Record<string, unknown>;
        reasons?: Record<string, unknown>;
        services?: unknown[];
        links?: unknown[];
        servicesConfigEnabled?: boolean;
        masters?: L5Masters;
        modules?: L5Module[];
        dependencies?: L5Dependency[];
        customize?: L5RuntimeCustomize;
    }
    export type L4ContextSource = 'userInput' | 'actorSession' | 'businessContext' | 'currentWorkspace' | 'selectedEntity' | 'activeLifecycleInstance' | 'workflowState' | 'routeParam' | 'previousStepOutput' | 'systemDefault';
    export const L4_CONTEXT_ORIGIN_CATALOG: {
        readonly actorSession: readonly ["actorSession.actorId", "actorSession.scope"];
        readonly businessContext: readonly ["businessContext.activeCompanyId", "businessContext.activeUnitId"];
        readonly currentWorkspace: readonly ["currentWorkspace.workspaceId"];
        readonly systemDefault: readonly ["systemDefault.now", "systemDefault.uuid", "systemDefault.locale"];
    };
    export interface L4ContextResolution {
        inputId?: string;
        /** Entity.field, input.<inputId>, filter.<name>, or a catalogued runtime context attribute. */
        targetRef: string;
        source: L4ContextSource;
        originRef: string;
        description: string;
    }
    export type L5GenerationTodoLayer = 'frontend' | 'backend';
    export type L5GenerationTodoStatus = 'toCreate' | 'toUpdate' | 'toRemove' | 'inProgress' | 'done';
    export type L5GenerationTodoOwnerType = 'workflow' | 'operation';
    export interface L5GenerationTodoOwner {
        ownerType: L5GenerationTodoOwnerType;
        ownerId: string;
        title: string;
        status: L5GenerationTodoStatus;
        defPath: string;
        pageId?: string;
        commandName?: string;
        bffName?: string;
        capabilityId?: string;
    }
    export interface L5GenerationTodo {
        schemaVersion: string;
        moduleName: string;
        layer: L5GenerationTodoLayer;
        updatedAt: string;
        owners: L5GenerationTodoOwner[];
    }
}
declare module "_102034_/l1/server/layer_1_external/config/projectConfig" {
    import type { ProjectsConfig } from "_102029_/l2/runtimeConfigTypes";
    export type { ProjectClientShellConfig, ProjectConfigRecord, ProjectDynamicRegionConfig, ProjectFrontendPageConfig, ProjectModuleConfig, ProjectModuleFrontendConfig, ProjectModuleFrontendEntrypoint, ProjectNavigationEntry, ProjectPersistenceModuleConfig, ProjectRegionRendererConfig, ProjectShellRegionProfiles, ProjectType, ProjectsConfig, } from "_102029_/l2/runtimeConfigTypes";
    export function projectsConfigExists(): boolean;
    export function readProjectsConfig(): ProjectsConfig;
    export function resetProjectsConfigCache(): void;
    export function resolveProjectsPath(relativePath: string): string;
    export function resolveProjectDistPath(relativePath: string): string;
    export function resolveWebDistPath(relativePath?: string): string;
    export function resolveProjectModuleImportUrl(relativePath: string): string;
}
declare module "_102034_/l1/server/layer_1_external/config/projectMode" {
    export type ProjectMode = 'production' | 'homologation' | 'development' | 'presentation';
    /** A generated module is born in `presentation`; anything unreadable falls back to it, loudly. */
    export const DEFAULT_PROJECT_MODE: ProjectMode;
    export function isProjectMode(value: unknown): value is ProjectMode;
    /** Test modes run against the TEST database and may be written to by the test runner. */
    export function isTestMode(mode: ProjectMode): boolean;
    /**
     * The mode declared by `l5/project.json` of a project. Absent or invalid ⇒ `presentation` with a warning:
     * defaulting to production would point a freshly generated module at real data, which is the one mistake
     * this whole concept exists to prevent.
     */
    /**
     * Did the project DECLARE its mode, or is it running on the default?
     *
     * The difference decides whether a missing `DATABASE_URL_TEST` is a failure: a project that explicitly
     * says `presentation` and has no test connection string is misconfigured and must say so; a project that
     * declared nothing at all is simply older than the modes, and breaking its boot over a default would be
     * this feature's worst outcome.
     */
    export function hasDeclaredProjectMode(projectId?: string | number): boolean;
    export function readProjectMode(projectId?: string | number): ProjectMode;
    /** Which env var holds the connection string for this mode. */
    export function databaseUrlEnvFor(mode: ProjectMode): 'DATABASE_URL' | 'DATABASE_URL_TEST';
    /**
     * The connection string for a mode — and a LEGIBLE failure when a test mode has none.
     *
     * Falling back to `DATABASE_URL` here would be the worst possible bug of this feature: a presentation
     * module quietly writing curated seeds over production data. So the absence is an error, not a default.
     */
    export function resolveDatabaseUrl(mode: ProjectMode): string;
    /**
     * Create the TEST database when it does not exist yet.
     *
     * "Nothing manual per project": provisioning a generated app flows through the publish, so a test mode
     * that points at a database nobody created should create it instead of demanding an SSH session. Only the
     * DATABASE is created — the schema is the bootstrap's job — and only in a test mode: nobody
     * auto-provisions production. Returns what happened, so the caller can log it; a missing privilege is
     * reported, not swallowed, because then the legible failure IS the answer.
     */
    export function ensureTestDatabase(mode: ProjectMode, connect: (adminUrl: string) => Promise<{
        exists: (database: string) => Promise<boolean>;
        create: (database: string) => Promise<void>;
        end: () => Promise<void>;
    }>): Promise<{
        created: boolean;
        database: string;
        reason: string;
    }>;
    /** The database name of a connection string, plus the same string pointed at `postgres` (admin). */
    export function parseDatabaseUrl(url: string): {
        database: string;
        adminUrl: string;
    } | null;
    export interface WriteAttempt {
        /** Where the request came from — the transport stamps it; `test` is the monitor runner. */
        source?: 'http' | 'message' | 'test';
        /** The routine's command segment (`cmdCreateClient`, `qryListClient`). */
        command?: string;
    }
    /**
     * May this request write? The SERVER half of the two defences.
     *
     * The runner is supposed to keep its destructive suite for test modes, but "supposed to" is what let a
     * production run write junk once. The generated vocabulary makes the check deterministic: `cmd*` mutates,
     * `qry*` reads. A read-only smoke from the runner stays allowed everywhere, which is what makes production
     * still observable.
     */
    export function refuseTestWrite(mode: ProjectMode, attempt: WriteAttempt): string;
}
declare module "_102034_/l1/server/layer_1_external/data/postgres/pg" {
    import { Pool, type PoolClient } from "_102034_/l1/server/layer_1_external/data/postgres/pg";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function getSharedPgPool(env: AppEnv): Pool;
    export function withPgTransaction<TValue>(pool: Pool, callback: (client: PoolClient) => Promise<TValue>): Promise<TValue>;
    export function queryRows<TRow>(client: Pool | PoolClient, sql: string, params?: unknown[]): Promise<TRow[]>;
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102034_/l1/server/layer_1_external/persistence/contracts" {
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export type TablePurpose = 'mdm' | 'cadastro' | 'transacao' | 'controle' | 'fila' | 'cache';
    export type StorageProfile = 'postgres' | 'postgresHotBackup' | 'dynamoOnly' | 'dynamoWithPostgresIndex';
    export type TableWriteMode = 'sync' | 'writeBehind';
    export interface TableColumnDefinition {
        name: string;
        postgresType: string;
        nullable?: boolean;
        defaultSql?: string;
        description?: string;
    }
    export type TableIndexColumnDefinition = string | {
        name: string;
        direction?: 'asc' | 'desc';
    };
    export interface TableIndexDefinition {
        name: string;
        columns: TableIndexColumnDefinition[];
        unique?: boolean;
    }
    export interface DynamoTableConfig {
        tableName?: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        partitionKey: string;
        sortKey?: string;
        ttlField?: string;
    }
    export interface TableTimescaleConfig {
        hypertable: {
            timeColumn: string;
            chunkTimeInterval?: string;
        };
    }
    export interface ViewDefinition {
        moduleId: string;
        viewName: string;
        /** SQL statements executed in order after all tables and hypertables are created. */
        statements: string[];
    }
    export interface TableDefinition {
        moduleId: string;
        repositoryName?: string;
        tableName: string;
        tableNameByEnv?: Partial<Record<AppEnv['appEnv'], string>>;
        purpose: TablePurpose;
        description: string;
        backupHot: boolean;
        storageProfile: StorageProfile;
        writeMode: TableWriteMode;
        columns: TableColumnDefinition[];
        primaryKey: string[];
        indexes?: TableIndexDefinition[];
        postgres?: {
            unlogged?: boolean;
        };
        timescale?: TableTimescaleConfig;
        dynamo?: DynamoTableConfig;
        retentionDays?: number;
        version: number;
        seedRows?: Array<Record<string, unknown>>;
    }
    /** Seed rows shipped in a separate file inside the module's tableDefsDir (so generated
     *  table definitions stay untouched). Discovered by shape, like TableDefinition. */
    export interface TableSeedRows {
        seedFor: string;
        rows: Array<Record<string, unknown>>;
    }
    export interface ResolvedTableDefinition extends TableDefinition {
        projectId: string;
        repositoryName: string;
        logicalTableName: string;
        dynamoResolvedTableName: string | null;
    }
    /** Column fields the Postgres rebuild materializes. Seed rows are not part of the snapshot. */
    export interface SchemaSnapshotColumn {
        name: string;
        postgresType: string;
        nullable: boolean;
        defaultSql: string | null;
    }
    export interface SchemaSnapshot {
        id: string;
        hash: string;
        appliedAt: string;
        tables: Array<{
            projectId: string;
            moduleId: string;
            repositoryName: string;
            tableName: string;
            storageProfile: StorageProfile;
            backupHot: boolean;
            dynamoTableName: string | null;
            version: number;
            columns: SchemaSnapshotColumn[];
        }>;
    }
    export function resolveRepositoryName(definition: TableDefinition): string;
    export function resolveDynamoTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string | null;
    export function resolvePostgresTableName(definition: TableDefinition, env: Pick<AppEnv, 'appEnv'>): string;
    /** A project is namespaced when it owns application (client) tables. Platform tables live in
     *  master-backend / lib projects and stay on their canonical, shared names. */
    export function isClientProjectType(projectType: string | undefined): boolean;
    /** Physical-name prefix for a client project. `mls` keeps the identifier unquoted-safe in Postgres
     *  (a bare `102051_order` would require quoting everywhere), and readable. */
    export function projectTableNamespacePrefix(projectId: string): string;
    /** Lowercased module token used as the physical-name prefix. `listaAssinatura3` → `listaassinatura3_`.
     *  Keep in sync with `moduleTableNamespacePrefix` in mls-102021 (l2 cannot import this file). */
    export function moduleTableNamespacePrefix(moduleId: string): string;
    /** Strip the module prefix CB now emits on `tableName`, so lookup stays `petition_signature`.
     *  Idempotent on older tables that were generated without the prefix. */
    export function logicalTableNameFromEmitted(emittedName: string, moduleId: string): string;
    /** Lookup keys: repositoryName, unprefixed logical name, physical name, and the CB-emitted
     *  (module-prefixed, pre-project) name adapters copy from TableDefinition.tableName. */
    export function matchesTableLookup(definition: Pick<ResolvedTableDefinition, 'repositoryName' | 'logicalTableName' | 'tableName' | 'projectId'>, key: string): boolean;
    /**
     * Namespaces a physical storage name (Postgres table or DynamoDB table) with the owning project when
     * that project owns application tables, so several client projects can share one database/schema on a
     * VM without colliding on generic names (`order`, `daily_shift`, ...). Platform tables (mdm_*, monitor,
     * _schema_migrations) belong to master/lib projects and are left on their canonical names. Idempotent:
     * a name already carrying the prefix is returned unchanged.
     */
    export function applyProjectTableNamespace(physicalName: string, projectId: string, projectType: string | undefined): string;
    export function usesPostgres(definition: TableDefinition): boolean;
    export function usesDynamo(definition: TableDefinition): boolean;
    export function requiresWriteBehind(definition: TableDefinition): boolean;
}
declare module "_102034_/l1/server/layer_1_external/persistence/registry" {
    import type { ResolvedTableDefinition, SchemaSnapshot, ViewDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    export function loadResolvedTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function resetResolvedTableDefinitionsCache(): void;
    export function loadResolvedPostgresTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    export function loadResolvedDynamoTableDefinitions(env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition[]>;
    /** Snapshot row used for the schema hash. Columns in; seedRows out — a seed-only edit must not rebuild. */
    export function toSchemaSnapshotTable(definition: ResolvedTableDefinition): SchemaSnapshot['tables'][number];
    export function buildSchemaSnapshot(env: Pick<AppEnv, 'appEnv'>): Promise<SchemaSnapshot>;
    export function loadViewDefinitions(): Promise<ViewDefinition[]>;
    export function findResolvedTableDefinition(repositoryNameOrTableName: string, env: Pick<AppEnv, 'appEnv'>): Promise<ResolvedTableDefinition>;
}
declare module "_102034_/l1/server/layer_1_external/data/moduleDataRuntime" {
    import type { Pool, PoolClient } from 'pg';
    import type { AppEnv } from "_102034_/l1/server/layer_1_external/config/env";
    import type { ResolvedTableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    type PgExecutor = Pool | PoolClient;
    export interface IFindManyInput<TWhere> {
        where?: Partial<TWhere>;
        /** Case-insensitive substring per column (`ILIKE` in Postgres). Empty/absent values are ignored. */
        ilike?: Partial<TWhere>;
        orderBy?: {
            field: keyof TWhere;
            direction: 'asc' | 'desc';
        };
        limit?: number;
        /** Rows to skip after filtering/ordering. Absent = 0. `findMany` without limit/offset is unchanged. */
        offset?: number;
    }
    /** Default page size when a list asks to paginate without saying how many. */
    export const DEFAULT_PAGE_SIZE = 20;
    /** Hard cap: a requested pageSize above this is cut, and the envelope declares the effective size. */
    export const MAX_PAGE_SIZE = 200;
    export interface ResolvedListPage {
        page: number;
        pageSize: number;
        limit: number;
        offset: number;
    }
    /**
     * Convert optional page/pageSize into LIMIT/OFFSET. Default 20, cap 200 — the cut is declared
     * (returned pageSize is the effective one), never silent and never a rejection.
     */
    export function resolveListPage(input?: {
        page?: number;
        pageSize?: number;
    }): ResolvedListPage;
    export function applyFindManyWindow<TRecord>(rows: TRecord[], input?: Pick<IFindManyInput<TRecord>, 'limit' | 'offset'>): TRecord[];
    export interface ITableRepository<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        /** Rows matching the filter, ignoring limit/offset. Same WHERE as findMany. */
        count(input?: IFindManyInput<TRecord>): Promise<number>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        upsert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRepository<TDocument> {
        get(input: {
            key: Record<string, unknown>;
        }): Promise<TDocument | null>;
        put(input: {
            document: TDocument;
        }): Promise<void>;
        delete(input: {
            key: Record<string, unknown>;
        }): Promise<void>;
        scanAll(): Promise<TDocument[]>;
    }
    export interface IModuleDataRuntime {
        getTable<TRecord extends object>(repositoryNameOrTableName: string): Promise<ITableRepository<TRecord>>;
        listTables(): Promise<ResolvedTableDefinition[]>;
        runInTransaction<TValue>(callback: (runtime: IModuleDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
    export function buildFindManySql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    export function buildCountSql<TRecord>(tableName: string, input?: IFindManyInput<TRecord>): {
        sql: string;
        params: unknown[];
    };
    export function createMemoryModuleDataRuntime(env: AppEnv): IModuleDataRuntime;
    export function createPostgresModuleDataRuntime(env: AppEnv, executor?: PgExecutor): IModuleDataRuntime;
    /** In-memory ITableRepository without the persistence registry — fixture for tests, not a generated app. */
    export function createMemoryTableRepository<TRecord extends object>(records: TRecord[]): ITableRepository<TRecord>;
}
declare module "_102034_/l1/server/layer_1_external/data/runtime" {
    import type { MdmAuditLogIndexRecord, MdmAttachmentRecord, MdmCommentRecord, MdmDocumentRecord, MdmDocumentInput, MdmErrorLogRecord, MdmEntityIndexRecord, MdmMonitoringWriteRecord, MdmNumberSequenceRecord, MdmOutboxRecord, MdmProspectIndexRecord, MdmRelationshipRecord, MdmStatusHistoryRecord, MdmTagRecord } from "_102034_/l1/mdm/module";
    import type { IFindManyInput, IModuleDataRuntime } from "_102034_/l1/server/layer_1_external/data/moduleDataRuntime";
    export interface ITableRuntime<TRecord> {
        findOne(input: {
            where: Partial<TRecord>;
        }): Promise<TRecord | null>;
        findMany(input?: IFindManyInput<TRecord>): Promise<TRecord[]>;
        findManyByValues<TKey extends keyof TRecord>(input: {
            field: TKey;
            values: Array<NonNullable<TRecord[TKey]>>;
            limit?: number;
        }): Promise<TRecord[]>;
        insert(input: {
            record: TRecord;
        }): Promise<void>;
        update(input: {
            where: Partial<TRecord>;
            patch: Partial<TRecord>;
        }): Promise<void>;
        delete(input: {
            where: Partial<TRecord>;
        }): Promise<void>;
    }
    export interface IDocumentRuntime {
        get(input: {
            mdmId: string;
        }): Promise<MdmDocumentRecord | null>;
        getMany(input: {
            mdmIds: string[];
        }): Promise<MdmDocumentRecord[]>;
        put(input: {
            record: MdmDocumentInput;
            expectedVersion?: number | null;
        }): Promise<void>;
        delete(input: {
            mdmId: string;
        }): Promise<void>;
    }
    export interface IQueueRuntime {
        publish(input: {
            topic: string;
            payload: unknown;
        }): Promise<void>;
        list(input?: {
            topic?: string;
        }): Promise<Array<{
            topic: string;
            payload: unknown;
        }>>;
    }
    export interface IDataRuntime {
        mode: 'memory' | 'postgres';
        mdmDocument: IDocumentRuntime;
        mdmEntityIndex: ITableRuntime<MdmEntityIndexRecord>;
        mdmProspectIndex: ITableRuntime<MdmProspectIndexRecord>;
        mdmRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmProspectRelationship: ITableRuntime<MdmRelationshipRecord>;
        mdmAuditLog: ITableRuntime<MdmAuditLogIndexRecord>;
        mdmComment: ITableRuntime<MdmCommentRecord>;
        mdmAttachment: ITableRuntime<MdmAttachmentRecord>;
        mdmNumberSequence: ITableRuntime<MdmNumberSequenceRecord>;
        mdmMonitoringWrite: ITableRuntime<MdmMonitoringWriteRecord>;
        mdmErrorLog: ITableRuntime<MdmErrorLogRecord>;
        mdmStatusHistory: ITableRuntime<MdmStatusHistoryRecord>;
        mdmTag: ITableRuntime<MdmTagRecord>;
        mdmOutbox: ITableRuntime<MdmOutboxRecord>;
        pgQueue: IQueueRuntime;
        moduleData: IModuleDataRuntime;
        runInTransaction<TValue>(callback: (runtime: IDataRuntime) => Promise<TValue>): Promise<TValue>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmDocumentStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmDetailRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export class MdmDocumentEntity {
        static get(ctx: RequestContext, mdmId: string): Promise<MdmDocumentRecord>;
        static parseDetails(document: MdmDocumentRecord): MdmDetailRecord;
        static create(ctx: RequestContext, record: MdmDocumentRecord): Promise<void>;
        static replace(ctx: RequestContext, record: MdmDocumentRecord, expectedVersion: number): Promise<void>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRelationshipStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    export class MdmRelationshipEntity {
        static findOne(ctx: RequestContext, id: string): Promise<{
            scope: 'entity' | 'prospect';
            relationship: MdmRelationshipRecord;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/MdmRecordStore" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export class MdmRecordEntity {
        static getEntityIndex(ctx: RequestContext, mdmId: string): Promise<MdmEntityIndexRecord>;
        static getProspectIndex(ctx: RequestContext, mdmId: string): Promise<MdmProspectIndexRecord>;
        static findEntityByDocument(ctx: RequestContext, docType?: string | null, docId?: string | null): Promise<MdmEntityIndexRecord | null>;
        static findEntityByContact(ctx: RequestContext, contactType?: string | null, value?: string | null): Promise<MdmEntityIndexRecord | null>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmSupport" {
    import type { MdmProspectStatus, MdmStatus, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    import type { CreateRecordParams, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord, MdmRelationshipRecord } from "_102034_/l1/mdm/module";
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    type RelationshipScope = 'entity' | 'prospect';
    export function getMdmModuleTypes(detail: MdmDetailRecord | Record<string, unknown>): string[];
    export function refreshRelationshipRefs(ctx: RequestContext, relationshipScope: RelationshipScope, mdmIds: string[], enqueueDocumentWrite: (document: {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    }) => Promise<void>): Promise<void>;
    export function normalizeCountryCode(countryCode?: string | null): string;
    export function normalizeDocumentId(docId?: string | null): string | null;
    export function normalizeContactValue(value?: string | null): string | null;
    export function isProtectedPrivacyCountry(countryCode: string): boolean;
    export function normalizeDetailInput(input: CreateRecordParams['detail'], ctx: RequestContext, mdmId: string): MdmDetailRecord;
    export function applyPatchToDetail(currentDetail: MdmDetailRecord, patch: Partial<MdmDetailRecord>, ctx: RequestContext): MdmDetailRecord;
    export function normalizeStatus(detail: MdmDetailRecord): MdmStatus | MdmProspectStatus;
    export function validateDetail(detail: MdmDetailRecord): void;
    export function toDocumentRecord(detail: MdmDetailRecord, version: number): {
        mdmId: string;
        version: number;
        details: MdmDetailRecord;
    };
    export function buildEntityIndex(detail: MdmDetailRecord): MdmEntityIndexRecord;
    export function buildProspectIndex(detail: MdmDetailRecord): MdmProspectIndexRecord;
    export function normalizeEntityStatus(detail: MdmDetailRecord): MdmStatus;
    export function normalizeProspectStatus(detail: MdmDetailRecord): MdmProspectStatus;
    export function buildSearchVector(detail: MdmDetailRecord): string;
    export function relationshipIsBidirectional(type: RelationshipType): boolean;
    export function migrateProspectRelationships(ctx: RequestContext, prospectMdmId: string): Promise<{
        affectedIds: string[];
        migratedRelationships: MdmRelationshipRecord[];
    }>;
    export function buildRelationshipSearchText(relationship: MdmRelationshipRecord): string;
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/microdiff" {
    import type { MdmAuditDiffEntry } from "_102034_/l1/mdm/module";
    export function microdiff(obj: Record<string, unknown> | unknown[], newObj: Record<string, unknown> | unknown[], stack?: Record<string, unknown>[]): MdmAuditDiffEntry[];
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/DataRecordService" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { EntityDef, MdmActorType, MdmAuditAction, MdmAuditLogIndexRecord, MdmDocumentRecord } from "_102034_/l1/mdm/module";
    export interface DataWriteActor {
        actorId?: string;
        actorType?: MdmActorType;
        source?: 'http' | 'message' | 'test' | 'system';
    }
    export interface DataWriteMeta extends DataWriteActor {
        module: string;
        routine: string;
        action: MdmAuditAction;
        entityType: string;
        entityId?: string | null;
    }
    export interface DataRecordCreateInput<TDetail> {
        after: TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'create'>;
        };
    }
    export interface DataRecordUpdateInput<TDetail> {
        id: string;
        before: MdmDocumentRecord;
        expectedVersion: number;
        patch?: Partial<TDetail>;
        after?: TDetail;
        applyPatch?: (before: TDetail, patch: Partial<TDetail>, ctx: RequestContext) => TDetail;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'update'>;
        };
    }
    export interface DataRecordTransitionStatusInput<TDetail> {
        before: MdmDocumentRecord;
        expectedVersion: number;
        after: TDetail;
        fromStatus?: string | null;
        toStatus: string;
        reason?: string | null;
        reasonCode?: string | null;
        metadata?: Record<string, unknown> | null;
        afterPersist?: (runtime: RequestContext['data'], state: {
            before: MdmDocumentRecord;
            after: TDetail;
            document: MdmDocumentRecord;
        }) => Promise<void>;
        meta: Omit<DataWriteMeta, 'entityType' | 'entityId' | 'action'> & {
            action?: Extract<MdmAuditAction, 'transitionStatus'>;
        };
    }
    export class AuditLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            action: MdmAuditAction;
            module: string;
            routine: string;
            before?: Record<string, unknown> | null;
            after?: Record<string, unknown> | null;
            actor?: DataWriteActor;
            createdAt?: string;
        }): Promise<MdmAuditLogIndexRecord>;
    }
    export class MonitoringWriteService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            success: boolean;
            startedAt: string;
            finishedAt: string;
            durationMs: number;
            errorCode?: string | null;
        }): Promise<void>;
    }
    export class ErrorLogService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: DataWriteMeta & {
            error: unknown;
        }): Promise<void>;
    }
    export class StatusHistoryService {
        static record(ctx: RequestContext, runtime: RequestContext['data'], input: {
            entityType: string;
            entityId: string;
            fromStatus?: string | null;
            toStatus: string;
            reason?: string | null;
            reasonCode?: string | null;
            module: string;
            routine: string;
            actor?: DataWriteActor;
            metadata?: Record<string, unknown> | null;
        }): Promise<void>;
    }
    export function runMonitoredWrite<TValue>(ctx: RequestContext, meta: DataWriteMeta, callback: () => Promise<TValue>): Promise<TValue>;
    export class DataRecordService {
        static create<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordCreateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static update<TDetail extends object, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordUpdateInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
        static transitionStatus<TDetail extends {
            status?: string;
        }, TIndex extends object>(ctx: RequestContext, def: EntityDef<TDetail, TIndex>, input: DataRecordTransitionStatusInput<TDetail>): Promise<{
            version: number;
            after: TDetail;
            index: TIndex;
        }>;
    }
}
declare module "_102034_/l1/mdm/layer_3_usecases/core/mdmEntityDefs" {
    import type { EntityDef, MdmDetailRecord, MdmEntityIndexRecord, MdmProspectIndexRecord } from "_102034_/l1/mdm/module";
    export const mdmEntityDef: EntityDef<MdmDetailRecord, MdmEntityIndexRecord>;
    export const mdmProspectDef: EntityDef<MdmDetailRecord, MdmProspectIndexRecord>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/entityPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateRecordParams, ListRecordsParams, MergeEntityParams, MdmDocumentRecord, MdmRelationshipDocumentRecord, PromoteProspectParams, RecordDetailResponse, UpdateRecordParams } from "_102034_/l1/mdm/module";
    export function enqueueWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], document: MdmDocumentRecord): Promise<void>;
    export function enqueueRelationshipWriteBehind(ctx: RequestContext, runtime: RequestContext['data'], relationship: MdmRelationshipDocumentRecord): Promise<void>;
    export function createEntity(ctx: RequestContext, params: CreateRecordParams): Promise<{
        alreadyExists: boolean;
        mdmId: string;
        version?: undefined;
    } | {
        alreadyExists: boolean;
        mdmId: string;
        version: number;
    }>;
    export function createProspect(ctx: RequestContext, params: CreateRecordParams): Promise<{
        mdmId: string;
        version: number;
    }>;
    export function getEntity(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function getProspect(ctx: RequestContext, mdmId: string): Promise<RecordDetailResponse>;
    export function listEntities(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord[]>;
    export function listProspects(ctx: RequestContext, params: ListRecordsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord[]>;
    export function updateEntity(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
    }>;
    export function updateProspect(ctx: RequestContext, params: UpdateRecordParams): Promise<{
        mdmId: string;
        version: number;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus | import("_102034_/l1/mdm/defs/ontology").MdmProspectStatus;
    }>;
    export function promoteProspect(ctx: RequestContext, params: PromoteProspectParams): Promise<{
        promoted: boolean;
        status: string;
        mdmId: string;
        prospectMdmId: string;
        candidateMdmId: string;
    } | {
        promoted: boolean;
        status: import("_102034_/l1/mdm/defs/ontology").MdmStatus;
        mdmId: string;
    }>;
    export function mergeEntity(ctx: RequestContext, params: MergeEntityParams): Promise<{
        winnerMdmId: string;
        loserMdmId: string;
        status: string;
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/internal/relationshipPersistence" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { CreateRelationshipParams, ListRelationshipsParams, SearchParams, UpdateRelationshipParams } from "_102034_/l1/mdm/module";
    export function createRelationship(ctx: RequestContext, params: CreateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            role: string;
            metadata: Record<string, unknown>;
            isBidirectional: boolean;
            validFrom: string;
            validTo: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            createdAt: string;
            updatedAt: string;
        };
    }>;
    export function listRelationships(ctx: RequestContext, params: ListRelationshipsParams): Promise<import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[]>;
    export function updateRelationship(ctx: RequestContext, params: UpdateRelationshipParams): Promise<{
        scope: "entity" | "prospect";
        relationship: {
            updatedAt: string;
            status: import("/_102034_/l1/mdm/module.js").RelationshipStatus;
            role?: string | null;
            metadata?: Record<string, unknown>;
            validFrom: string;
            validTo?: string | null;
            id: string;
            fromId: string;
            toId: string;
            type: import("_102034_/l1/mdm/defs/ontology").RelationshipType;
            isBidirectional: boolean;
            createdAt: string;
        };
    }>;
    export function runSearch(ctx: RequestContext, params: SearchParams): Promise<{
        records: (import("/_102034_/l1/mdm/module.js").MdmEntityIndexRecord | import("/_102034_/l1/mdm/module.js").MdmProspectIndexRecord)[];
        relationships: import("/_102034_/l1/mdm/module.js").MdmRelationshipRecord[];
    }>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/attachmentUsecases" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord } from "_102034_/l1/mdm/module";
    export function attachFile(ctx: RequestContext, params: AttachFileParams): Promise<MdmAttachmentRecord>;
    export function detachFile(ctx: RequestContext, params: DetachFileParams): Promise<MdmAttachmentRecord>;
    export function findAttachmentsByEntity(ctx: RequestContext, params: FindAttachmentsByEntityParams): Promise<MdmAttachmentRecord[]>;
}
declare module "_102034_/l1/mdm/layer_3_usecases/mdmFacade" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { AttachFileParams, DetachFileParams, FindAttachmentsByEntityParams, MdmAttachmentRecord, CompactRelationshipRefKey, CreateableMdmDetailInput, MdmDetailRecord, MdmDocumentRecord, MdmEntityIndexRecord, MdmProspectIndexRecord, RelationshipStatus } from "_102034_/l1/mdm/module";
    import type { MdmProspectStatus, MdmStatus, MdmSubtype, RelationshipType } from "_102034_/l1/mdm/defs/ontology";
    export type MdmEntityCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmEntityCreateInput {
        details: MdmEntityCreateDetails;
    }
    export type MdmProspectCreateDetails = Omit<CreateableMdmDetailInput, 'status'> & Partial<Pick<CreateableMdmDetailInput, 'status'>>;
    export interface MdmProspectCreateInput {
        details: MdmProspectCreateDetails;
    }
    export interface MdmEntityUpdateInput {
        mdmId: string;
        expectedVersion: number;
        patch: Partial<MdmDetailRecord>;
    }
    export interface MdmProspectUpdateInput extends MdmEntityUpdateInput {
    }
    export interface MdmEntityGetInput {
        mdmId: string;
    }
    export interface MdmProspectGetInput extends MdmEntityGetInput {
    }
    export interface MdmProspectPromoteToEntityInput {
        mdmId: string;
    }
    export interface MdmEntityInactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    /** Mirror of MdmEntityInactivateInput: the cadastral cycle is symmetric, so its input is too. */
    export interface MdmEntityReactivateInput {
        mdmId: string;
        expectedVersion: number;
        reason?: string | null;
    }
    export interface MdmEntityDeleteInput {
        mdmId: string;
        allowActiveRelationships?: boolean;
    }
    export interface MdmLinkInput {
        fromId: string;
        toId: string;
        type: RelationshipType;
        role?: string | null;
        metadata?: Record<string, unknown>;
        validFrom?: string;
        validTo?: string | null;
        status?: RelationshipStatus;
        isBidirectional?: boolean;
    }
    export interface MdmUnlinkInput {
        relationshipId: string;
    }
    export interface MdmGetManyInput {
        mdmIds: string[];
        chunkSize?: number;
    }
    export interface MdmListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmProspectListByTypeInput {
        type: string;
        subtype?: MdmSubtype;
        tags?: string[];
        status?: MdmProspectStatus;
        name?: string;
        page?: number;
        pageSize?: number;
        sort?: {
            field: 'name' | 'createdAt' | 'updatedAt' | 'status';
            direction: 'asc' | 'desc';
        };
    }
    export interface MdmHydrateManyInput extends MdmGetManyInput {
        sections?: string[];
        includeRelationshipRefs?: boolean;
    }
    export interface MdmRelatedOfManyInput {
        mdmIds: string[];
        type?: RelationshipType;
        status?: RelationshipStatus;
    }
    export interface MdmRelatedRef {
        mdmId: string;
        relationshipId: string;
        type: RelationshipType;
        direction: 'from' | 'to';
        role?: string | null;
        metadata?: Record<string, unknown>;
    }
    export interface MdmEntityReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmEntityIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmEntityWriteResult extends MdmEntityReadResult {
        alreadyExists?: boolean;
    }
    export interface MdmProspectReadResult {
        mdmId: string;
        version: number;
        document: MdmDocumentRecord;
        index: MdmProspectIndexRecord;
        details: MdmDetailRecord;
        related(key: CompactRelationshipRefKey): string[];
    }
    export interface MdmProspectWriteResult extends MdmProspectReadResult {
    }
    export interface MdmProspectListByTypeResult {
        items: MdmProspectIndexRecord[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmProspectPromoteToEntityResult {
        promoted: boolean;
        status: MdmStatus | MdmProspectStatus;
        mdmId: string;
        prospectMdmId?: string;
        candidateMdmId?: string;
    }
    export interface MdmDeleteResult {
        mdmId: string;
        deleted: true;
    }
    export interface MdmListByTypeResult {
        items: MdmEntityIndexRecord[];
        page: number;
        pageSize: number;
        total: number;
    }
    export interface MdmHydratedEntity {
        mdmId: string;
        version: number;
        details: Partial<MdmDetailRecord>;
    }
    export interface MdmFacade {
        entity: MdmEntity;
        prospect: MdmProspect;
        collection: MdmCollection;
        attachment: MdmAttachment;
    }
    export class MdmEntity {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmEntityCreateInput): Promise<MdmEntityWriteResult>;
        get(input: MdmEntityGetInput): Promise<MdmEntityReadResult>;
        update(input: MdmEntityUpdateInput): Promise<MdmEntityWriteResult>;
        inactivate(input: MdmEntityInactivateInput): Promise<MdmEntityWriteResult>;
        /**
         * The other half of the cadastral cycle. An MDM entity is NEVER deleted by a generated module: the
         * tier-1 catalogue emits `inactivate`/`reactivate` for `storage.target: 'mdm'` instead of `delete`,
         * so a generated `cmdReactivate*` had no target here at all until this method existed.
         *
         * Deliberately the exact mirror of `inactivate` — same optimistic version, same single-field patch —
         * because any asymmetry between the two halves shows up as a record that can be hidden and not
         * brought back.
         */
        reactivate(input: MdmEntityReactivateInput): Promise<MdmEntityWriteResult>;
        delete(input: MdmEntityDeleteInput): Promise<MdmDeleteResult>;
        link(input: MdmLinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                role: string;
                metadata: Record<string, unknown>;
                isBidirectional: boolean;
                validFrom: string;
                validTo: string;
                status: RelationshipStatus;
                createdAt: string;
                updatedAt: string;
            };
        }>;
        unlink(input: MdmUnlinkInput): Promise<{
            scope: "entity" | "prospect";
            relationship: {
                updatedAt: string;
                status: RelationshipStatus;
                role?: string | null;
                metadata?: Record<string, unknown>;
                validFrom: string;
                validTo?: string | null;
                id: string;
                fromId: string;
                toId: string;
                type: RelationshipType;
                isBidirectional: boolean;
                createdAt: string;
            };
        }>;
    }
    export class MdmProspect {
        private readonly ctx;
        constructor(ctx: RequestContext);
        create(input: MdmProspectCreateInput): Promise<MdmProspectWriteResult>;
        get(input: MdmProspectGetInput): Promise<MdmProspectReadResult>;
        update(input: MdmProspectUpdateInput): Promise<MdmProspectWriteResult>;
        listByType(input: MdmProspectListByTypeInput): Promise<MdmProspectListByTypeResult>;
        promoteToEntity(input: MdmProspectPromoteToEntityInput): Promise<MdmProspectPromoteToEntityResult>;
    }
    export class MdmCollection {
        private readonly ctx;
        constructor(ctx: RequestContext);
        getMany(input: MdmGetManyInput): Promise<MdmEntityReadResult[]>;
        listByType(input: MdmListByTypeInput): Promise<MdmListByTypeResult>;
        relatedOfMany(input: MdmRelatedOfManyInput): Promise<Record<string, MdmRelatedRef[]>>;
        hydrateMany(input: MdmHydrateManyInput): Promise<MdmHydratedEntity[]>;
    }
    /**
     * Attachments of any record, through the facade.
     *
     * The usecases already existed (`attachFile`/`detachFile`/`findAttachmentsByEntity`, with write-behind and
     * audit) but nothing in a generated module could reach them: `ctx.mdm` exposed only entity/prospect/
     * collection. This is the wiring, nothing more — no new rule, no new storage.
     *
     * An attachment is ORTHOGONAL to the record it belongs to (`entityType` + `entityId` + `category`), which
     * is why a photo never becomes a field of the ontology. AUTHORIZATION v1 is the owner's: whoever may read
     * or edit the record may list and attach — the caller has already been through the route's own gate, and a
     * finer rule needs the party/dataScope work that is not here yet.
     *
     * The BYTES are not this API's business: it registers metadata plus a `storageKey`. Uploading through
     * `/execBff` (JSON) is never right; that is what the presigned-URL entry point is for.
     */
    export class MdmAttachment {
        private readonly ctx;
        constructor(ctx: RequestContext);
        attach(input: AttachFileParams): Promise<MdmAttachmentRecord>;
        detach(input: DetachFileParams): Promise<{
            id: string;
            deleted: true;
        }>;
        /**
         * LIVE attachments of a record (optionally one category).
         *
         * `detach` is a SOFT delete — it stamps `deletedAt` — and the underlying query does not filter it, so a
         * gallery built straight on it would keep showing a photo the user removed. Filtering here keeps the
         * usecase (and the existing `mdm.attachment.*` route, which returns the full history) untouched, and
         * `includeDetached` is there for whoever wants the history on purpose.
         */
        listByEntity(input: FindAttachmentsByEntityParams & {
            includeDetached?: boolean;
        }): Promise<MdmAttachmentRecord[]>;
    }
    export function createMdmFacade(ctx: RequestContext): MdmFacade;
}
declare module "_102034_/l1/server/layer_2_controllers/contracts" {
    import type { IDataRuntime } from "_102034_/l1/server/layer_1_external/data/runtime";
    import type { MdmFacade } from "_102034_/l1/mdm/layer_3_usecases/mdmFacade";
    export interface BffRequestTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    export interface BffRequest {
        routine: string;
        params: unknown;
        meta?: {
            requestId?: string;
            /** What the CLIENT says the user's email is. Telemetry; never an identity the server acts on. */
            userId?: string;
            authToken?: string;
            /**
             * Identity the TRANSPORT verified (collab-auth claims: `sub` and `email`). A client cannot set these
             * usefully — the http transport overwrites them from the JWKS-verified token, and every other
             * identity field of this meta is discarded on that transport. This is the only channel through which
             * a request may tell execBff who it is.
             */
            verifiedUserId?: string;
            verifiedEmail?: string;
            /** The module's authorities (`<moduleId>:<actorId>`) from the verified claims — becomes actorScope. */
            verifiedAuthorities?: string[];
            traceId?: string;
            source?: 'http' | 'message' | 'test';
            actorId?: string;
            actorScope?: string[];
            activeCompanyId?: string;
            activeUnitId?: string;
            workspaceId?: string;
            telemetry?: BffRequestTelemetryEvent[];
        };
    }
    export type ShellMode = 'spa' | 'pwa';
    export type DeviceKind = 'desktop' | 'mobile';
    export type FrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface FrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface FrontendAppLayout {
        regions: {
            desktop: FrontendRegionVisibility;
            mobile: FrontendRegionVisibility;
        };
        asideMode: {
            desktop: FrontendAsideMode;
            mobile: FrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface FrontendRegionRendererRegistration {
        entrypoint: string;
        tag: string;
    }
    export type FrontendRegionName = 'header' | 'aside' | 'content';
    export interface FrontendDynamicRegionConfig {
        renderer: FrontendRegionRendererRegistration;
        widthPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface FrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, FrontendDynamicRegionConfig>;
    }
    export interface FrontendClientShellConfig {
        mode: ShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: FrontendShellRegionProfiles;
            aside?: FrontendShellRegionProfiles;
        };
    }
    export type FrontendRouteMatchMode = 'exact' | 'prefix';
    export interface FrontendRouteRegistration {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: FrontendRouteMatchMode;
    }
    export interface FrontendModuleShellPreferences {
        layout?: Partial<FrontendAppLayout>;
    }
    export interface FrontendNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface BffError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface BffResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: BffError | null;
        telemetryReceived?: number;
    }
    export interface ILogger {
        info(message: string, data?: unknown): void;
        error(message: string, data?: unknown): void;
    }
    export interface IClock {
        nowIso(): string;
    }
    export interface IIdGenerator {
        newId(): string;
    }
    export interface RequestBusinessContext {
        activeCompanyId?: string;
        activeUnitId?: string;
    }
    export interface RequestActorSession {
        actorId?: string;
        scope?: string[];
    }
    export interface RequestCurrentWorkspace {
        workspaceId?: string;
    }
    export interface RequestProjectContext {
        projectId?: string;
        domain?: string;
        port?: number;
        databaseName?: string;
        environment?: string;
        studioEnabled?: boolean;
    }
    export interface RequestSessionContext {
        activeCompanyId?: string;
        activeUnitId?: string;
        actorId?: string;
        actorScope?: string[];
        workspaceId?: string;
        businessContext: RequestBusinessContext;
        actorSession: RequestActorSession;
        currentWorkspace: RequestCurrentWorkspace;
        project: RequestProjectContext;
    }
    export interface RequestContext {
        data: IDataRuntime;
        mdm: MdmFacade;
        log: ILogger;
        clock: IClock;
        idGenerator: IIdGenerator;
        sessionContext: RequestSessionContext;
        sandbox?: boolean;
        requestMeta?: {
            requestId?: string;
            /**
             * The EMAIL of the user executing the request — unique, unlike a display name (standard set on
             * 2026-08-18). TELEMETRY ONLY: it comes from the client and the session/authorization never reads it.
             */
            userId?: string;
            traceId?: string;
            source?: 'http' | 'message' | 'test';
        };
    }
    export interface IRequestEnvelope {
        request: BffRequest;
        ctx: RequestContext;
    }
    export type BffHandler = (input: IRequestEnvelope) => Promise<BffResponse>;
    export interface ControllerRoute {
        key: string;
        handler: BffHandler;
    }
    export interface ModuleBffRegistration {
        projectId: string;
        moduleId: string;
        frontendBasePath: string;
        frontendEntrypoint: string;
        loadRouter: () => Promise<Map<string, BffHandler>>;
    }
    export interface FrontendAppRegistration {
        projectId: string;
        appId: string;
        basePath: string;
        indexHtmlPath: string;
        assetRoots: string[];
        routePatterns: string[];
        shellMode: ShellMode;
        languages?: string[];
        designSystems?: string[];
        routes: FrontendRouteRegistration[];
        headerRenderer?: FrontendRegionRendererRegistration;
        asideRenderer?: FrontendRegionRendererRegistration;
        layout: FrontendAppLayout;
        device?: DeviceKind;
        pageTitle?: string;
        navigation?: FrontendNavigationItem[];
        moduleLinks?: FrontendNavigationItem[];
        clientShell?: FrontendClientShellConfig;
    }
    export interface RoutineResolution {
        moduleId: string;
        routineName: string;
        registration: ModuleBffRegistration;
    }
    export class AppError extends Error {
        readonly code: string;
        readonly statusCode: number;
        readonly details?: unknown;
        constructor(code: string, message: string, statusCode?: number, details?: unknown);
    }
    export function ok<TData>(data: TData): BffResponse<TData>;
    export function fail(error: AppError): BffResponse;
}
declare module "_102034_/l1/server/layer_2_application/repositoryRegistry" {
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export type RepositoryFactory<T> = (ctx: RequestContext) => T;
    /** Bind a repository port name to the factory that builds its concrete adapter for a request ctx. */
    export function registerRepository<T>(portName: string, factory: RepositoryFactory<T>): void;
    /** Resolve the concrete repository adapter for a port name, bound to the current request ctx. */
    export function resolveRepository<T>(ctx: RequestContext, portName: string): T;
    export function hasRepository(portName: string): boolean;
    /** Test/boot helper: clear all registered factories. */
    export function clearRepositories(): void;
}
declare module "_102047_/l1/controleChamados/layer_3_domain/entities/ticket" {
    export type TicketStatus = 'open' | 'closed';
    export interface Ticket {
        ticketId: string;
        title: string;
        description: string;
        status: TicketStatus;
    }
    export const TICKET_STATUS_TRANSITIONS: Record<TicketStatus, TicketStatus[]>;
    export function canTransitionTicket(from: TicketStatus, to: TicketStatus): boolean;
    export function ticketStartsOpen(ticket: Pick<Ticket, 'status'>): boolean;
    export function canAddCommentToTicket(ticket: Pick<Ticket, 'status'>): boolean;
}
declare module "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository" {
    import type { Ticket, TicketStatus } from "_102047_/l1/controleChamados/layer_3_domain/entities/ticket";
    export type TicketId = string;
    export interface TicketListFilter {
        status?: TicketStatus;
        search?: string;
        sortBy?: 'title' | 'status';
        sortOrder?: 'asc' | 'desc';
    }
    export interface ITicketRepository {
        getById(id: TicketId): Promise<Ticket | null>;
        list(filter: TicketListFilter): Promise<Ticket[]>;
        save(aggregate: Ticket): Promise<void>;
        delete(id: TicketId): Promise<void>;
    }
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/locateTicket" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface LocateTicketInput {
    }
    export interface LocateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export function locateTicket(ctx: RequestContext, _input: LocateTicketInput): Promise<LocateTicketOutput>;
}
declare module "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment" {
    export interface TicketComment {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    /**
     * Validates the declared minimum-length constraint for a comment.
     */
    export function hasValidTicketCommentText(commentText: string): boolean;
    /**
     * A comment may be added only while its ticket is open.
     */
    export function canAddTicketComment(ticketStatus: string): boolean;
}
declare module "_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository" {
    import type { TicketComment } from "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment";
    export type TicketCommentId = string;
    export interface TicketCommentListFilter {
        ticketId?: string;
    }
    export interface ITicketCommentRepository {
        getById(id: TicketCommentId): Promise<TicketComment | null>;
        list(filter: TicketCommentListFilter): Promise<TicketComment[]>;
        save(aggregate: TicketComment): Promise<void>;
        delete(id: TicketCommentId): Promise<void>;
    }
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/recordComment" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface RecordCommentInput {
        ticketId: string;
        commentText: string;
    }
    export interface RecordCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export function recordComment(ctx: RequestContext, input: RecordCommentInput): Promise<RecordCommentOutput>;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/commentOpenTicket" {
    import { type BffHandler, type ControllerRoute } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const commentOpenTicketQryLocateTicketHandler: BffHandler;
    export const commentOpenTicketCmdRecordCommentHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCatalogue.defs" {
    export const ticketCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "ticketCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "ticketCatalogue";
            readonly controllerName: "TicketCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "ticketCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "ticketCatalogueQryListTicketHandler";
                readonly command: "qryListTicket";
                readonly bffId: "qryListTicket";
                readonly route: "controleChamados.ticketCatalogue.qryListTicket";
                readonly kind: "query";
                readonly usecaseRef: "listTicket";
                readonly usecaseRefs: readonly ["listTicket"];
                readonly inputTypeName: "ListTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "search";
                    readonly fieldRef: "Ticket.title";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Buscar por Título.";
                }, {
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Ticket.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Ticket.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "title";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "description";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCatalogueCmdCreateTicketHandler";
                readonly command: "cmdCreateTicket";
                readonly bffId: "cmdCreateTicket";
                readonly route: "controleChamados.ticketCatalogue.cmdCreateTicket";
                readonly kind: "command";
                readonly usecaseRef: "createTicket";
                readonly usecaseRefs: readonly ["createTicket"];
                readonly inputTypeName: "CreateTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "title";
                    readonly fieldRef: "Ticket.title";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Ticket.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Ticket.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação atual do chamado durante o atendimento.";
                    readonly enumValues: readonly ["open", "closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "createTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "title";
                        readonly operationId: "createTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "description";
                        readonly operationId: "createTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "createTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCatalogueCmdUpdateTicketHandler";
                readonly command: "cmdUpdateTicket";
                readonly bffId: "cmdUpdateTicket";
                readonly route: "controleChamados.ticketCatalogue.cmdUpdateTicket";
                readonly kind: "command";
                readonly usecaseRef: "updateTicket";
                readonly usecaseRefs: readonly ["updateTicket"];
                readonly inputTypeName: "UpdateTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketId";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                }, {
                    readonly inputId: "title";
                    readonly fieldRef: "Ticket.title";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "Ticket.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Ticket.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Situação atual do chamado durante o atendimento.";
                    readonly enumValues: readonly ["open", "closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "updateTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "title";
                        readonly operationId: "updateTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "description";
                        readonly operationId: "updateTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "updateTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCatalogueCmdDeleteTicketHandler";
                readonly command: "cmdDeleteTicket";
                readonly bffId: "cmdDeleteTicket";
                readonly route: "controleChamados.ticketCatalogue.cmdDeleteTicket";
                readonly kind: "command";
                readonly usecaseRef: "deleteTicket";
                readonly usecaseRefs: readonly ["deleteTicket"];
                readonly inputTypeName: "DeleteTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketId";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "deleteTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "title";
                        readonly operationId: "deleteTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "description";
                        readonly operationId: "deleteTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "deleteTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCatalogueQryGetTicketHandler";
                readonly command: "qryGetTicket";
                readonly bffId: "qryGetTicket";
                readonly route: "controleChamados.ticketCatalogue.qryGetTicket";
                readonly kind: "query";
                readonly usecaseRef: "getTicket";
                readonly usecaseRefs: readonly ["getTicket"];
                readonly inputTypeName: "GetTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketId";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "getTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "title";
                        readonly operationId: "getTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "description";
                        readonly operationId: "getTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "getTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCatalogueQryLocateTicketHandler";
                readonly command: "qryLocateTicket";
                readonly bffId: "qryLocateTicket";
                readonly route: "controleChamados.ticketCatalogue.qryLocateTicket";
                readonly kind: "query";
                readonly usecaseRef: "locateTicket";
                readonly usecaseRefs: readonly ["locateTicket"];
                readonly inputTypeName: "LocateTicketInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "title";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "description";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "locateTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCatalogueCmdDecideClosureHandler";
                readonly command: "cmdDecideClosure";
                readonly bffId: "cmdDecideClosure";
                readonly route: "controleChamados.ticketCatalogue.cmdDecideClosure";
                readonly kind: "command";
                readonly usecaseRef: "decideClosure";
                readonly usecaseRefs: readonly ["decideClosure"];
                readonly inputTypeName: "DecideClosureInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketId";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Chamado";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Ticket.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Decisão tomada.";
                    readonly enumValues: readonly ["closed"];
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "decideClosure";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "title";
                        readonly operationId: "decideClosure";
                        readonly path: readonly ["title"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "description";
                        readonly operationId: "decideClosure";
                        readonly path: readonly ["description"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "status";
                        readonly operationId: "decideClosure";
                        readonly path: readonly ["status"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.ticketCatalogue.qryListTicket";
                readonly handlerName: "ticketCatalogueQryListTicketHandler";
            }, {
                readonly key: "controleChamados.ticketCatalogue.cmdCreateTicket";
                readonly handlerName: "ticketCatalogueCmdCreateTicketHandler";
            }, {
                readonly key: "controleChamados.ticketCatalogue.cmdUpdateTicket";
                readonly handlerName: "ticketCatalogueCmdUpdateTicketHandler";
            }, {
                readonly key: "controleChamados.ticketCatalogue.cmdDeleteTicket";
                readonly handlerName: "ticketCatalogueCmdDeleteTicketHandler";
            }, {
                readonly key: "controleChamados.ticketCatalogue.qryGetTicket";
                readonly handlerName: "ticketCatalogueQryGetTicketHandler";
            }, {
                readonly key: "controleChamados.ticketCatalogue.qryLocateTicket";
                readonly handlerName: "ticketCatalogueQryLocateTicketHandler";
            }, {
                readonly key: "controleChamados.ticketCatalogue.cmdDecideClosure";
                readonly handlerName: "ticketCatalogueCmdDecideClosureHandler";
            }];
        };
    };
    export default ticketCatalogueController;
    export const pipeline: readonly [{
        readonly id: "ticketCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCatalogue.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/usecases/listTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--qryListTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/createTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdCreateTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdUpdateTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdDeleteTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/getTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--qryGetTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/locateTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--qryLocateTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/decideClosure.d.ts", "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdDecideClosure.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/listTicket" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface ListTicketInput {
        search?: string;
        sortBy?: 'title' | 'status';
        sortOrder?: 'asc' | 'desc';
    }
    export interface ListTicketItem {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export type ListTicketOutput = ListTicketItem[];
    export function listTicket(ctx: RequestContext, input: ListTicketInput): Promise<ListTicketOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/createTicket" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface CreateTicketInput {
        title: string;
        description: string;
    }
    export interface CreateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export function createTicket(ctx: RequestContext, input: CreateTicketInput): Promise<CreateTicketOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicket" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface UpdateTicketInput {
        ticketId: string;
        title: string;
        description: string;
    }
    export interface UpdateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export function updateTicket(ctx: RequestContext, input: UpdateTicketInput): Promise<UpdateTicketOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicket" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface DeleteTicketInput {
        ticketId: string;
    }
    export interface DeleteTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export function deleteTicket(ctx: RequestContext, input: DeleteTicketInput): Promise<DeleteTicketOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/getTicket" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface GetTicketInput {
        ticketId: string;
    }
    export interface GetTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export function getTicket(ctx: RequestContext, input: GetTicketInput): Promise<GetTicketOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/decideClosure" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface DecideClosureInput {
        ticketId: string;
        status: string;
    }
    export interface DecideClosureOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export function decideClosure(ctx: RequestContext, input: DecideClosureInput): Promise<DecideClosureOutput>;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCatalogue" {
    import { type BffHandler, type ControllerRoute } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const ticketCatalogueQryListTicketHandler: BffHandler;
    export const ticketCatalogueCmdCreateTicketHandler: BffHandler;
    export const ticketCatalogueCmdUpdateTicketHandler: BffHandler;
    export const ticketCatalogueCmdDeleteTicketHandler: BffHandler;
    export const ticketCatalogueQryGetTicketHandler: BffHandler;
    export const ticketCatalogueQryLocateTicketHandler: BffHandler;
    export const ticketCatalogueCmdDecideClosureHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCommentCatalogue.defs" {
    export const ticketCommentCatalogueController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "ticketCommentCatalogue";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "ticketCommentCatalogue";
            readonly controllerName: "TicketCommentCatalogueController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "ticketCommentCatalogueQryListTicketCommentHandler";
                readonly command: "qryListTicketComment";
                readonly bffId: "qryListTicketComment";
                readonly route: "controleChamados.ticketCommentCatalogue.qryListTicketComment";
                readonly kind: "query";
                readonly usecaseRef: "listTicketComment";
                readonly usecaseRefs: readonly ["listTicketComment"];
                readonly inputTypeName: "ListTicketCommentInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "listTicketComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "listTicketComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "listTicketComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCommentCatalogueCmdCreateTicketCommentHandler";
                readonly command: "cmdCreateTicketComment";
                readonly bffId: "cmdCreateTicketComment";
                readonly route: "controleChamados.ticketCommentCatalogue.cmdCreateTicketComment";
                readonly kind: "command";
                readonly usecaseRef: "createTicketComment";
                readonly usecaseRefs: readonly ["createTicketComment"];
                readonly inputTypeName: "CreateTicketCommentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketId";
                    readonly fieldRef: "TicketComment.ticketId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
                }, {
                    readonly inputId: "commentText";
                    readonly fieldRef: "TicketComment.commentText";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "createTicketComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "createTicketComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "createTicketComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCommentCatalogueCmdUpdateTicketCommentHandler";
                readonly command: "cmdUpdateTicketComment";
                readonly bffId: "cmdUpdateTicketComment";
                readonly route: "controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment";
                readonly kind: "command";
                readonly usecaseRef: "updateTicketComment";
                readonly usecaseRefs: readonly ["updateTicketComment"];
                readonly inputTypeName: "UpdateTicketCommentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketCommentId";
                    readonly fieldRef: "TicketComment.ticketCommentId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                }, {
                    readonly inputId: "ticketId";
                    readonly fieldRef: "TicketComment.ticketId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
                }, {
                    readonly inputId: "commentText";
                    readonly fieldRef: "TicketComment.commentText";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "updateTicketComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "updateTicketComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "updateTicketComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCommentCatalogueCmdDeleteTicketCommentHandler";
                readonly command: "cmdDeleteTicketComment";
                readonly bffId: "cmdDeleteTicketComment";
                readonly route: "controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment";
                readonly kind: "command";
                readonly usecaseRef: "deleteTicketComment";
                readonly usecaseRefs: readonly ["deleteTicketComment"];
                readonly inputTypeName: "DeleteTicketCommentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketCommentId";
                    readonly fieldRef: "TicketComment.ticketCommentId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "deleteTicketComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "deleteTicketComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "deleteTicketComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCommentCatalogueQryGetTicketCommentHandler";
                readonly command: "qryGetTicketComment";
                readonly bffId: "qryGetTicketComment";
                readonly route: "controleChamados.ticketCommentCatalogue.qryGetTicketComment";
                readonly kind: "query";
                readonly usecaseRef: "getTicketComment";
                readonly usecaseRefs: readonly ["getTicketComment"];
                readonly inputTypeName: "GetTicketCommentInput";
                readonly inputContract: readonly [{
                    readonly inputId: "ticketCommentId";
                    readonly fieldRef: "TicketComment.ticketCommentId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                }];
                readonly projection: {
                    readonly kind: "object";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [];
                    readonly topFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "getTicketComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "getTicketComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: false;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "getTicketComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: false;
                    }];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketCommentCatalogueQryTicketPickerHandler";
                readonly command: "qryTicketPicker";
                readonly bffId: "qryTicketPicker";
                readonly route: "controleChamados.ticketCommentCatalogue.qryTicketPicker";
                readonly kind: "query";
                readonly usecaseRef: "listTicket";
                readonly usecaseRefs: readonly ["listTicket"];
                readonly inputTypeName: "ListTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "search";
                    readonly fieldRef: "Ticket.title";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Buscar por Título.";
                }, {
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Ticket.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Ticket.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "title";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "description";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.ticketCommentCatalogue.qryListTicketComment";
                readonly handlerName: "ticketCommentCatalogueQryListTicketCommentHandler";
            }, {
                readonly key: "controleChamados.ticketCommentCatalogue.cmdCreateTicketComment";
                readonly handlerName: "ticketCommentCatalogueCmdCreateTicketCommentHandler";
            }, {
                readonly key: "controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment";
                readonly handlerName: "ticketCommentCatalogueCmdUpdateTicketCommentHandler";
            }, {
                readonly key: "controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment";
                readonly handlerName: "ticketCommentCatalogueCmdDeleteTicketCommentHandler";
            }, {
                readonly key: "controleChamados.ticketCommentCatalogue.qryGetTicketComment";
                readonly handlerName: "ticketCommentCatalogueQryGetTicketCommentHandler";
            }, {
                readonly key: "controleChamados.ticketCommentCatalogue.qryTicketPicker";
                readonly handlerName: "ticketCommentCatalogueQryTicketPickerHandler";
            }];
        };
    };
    export default ticketCommentCatalogueController;
    export const pipeline: readonly [{
        readonly id: "ticketCommentCatalogue__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCommentCatalogue.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCommentCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/usecases/listTicketComment.d.ts", "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--qryListTicketComment.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/createTicketComment.d.ts", "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--cmdCreateTicketComment.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicketComment.d.ts", "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--cmdUpdateTicketComment.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicketComment.d.ts", "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--cmdDeleteTicketComment.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/getTicketComment.d.ts", "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--qryGetTicketComment.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/listTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--qryTicketPicker.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/listTicketComment" {
    import type { RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface ListTicketCommentInput {
    }
    export interface ListTicketCommentItem {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export type ListTicketCommentOutput = ListTicketCommentItem[];
    export function listTicketComment(ctx: RequestContext, _input: ListTicketCommentInput): Promise<ListTicketCommentOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/createTicketComment" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface CreateTicketCommentInput {
        ticketId: string;
        commentText: string;
    }
    export interface CreateTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export function createTicketComment(ctx: RequestContext, input: CreateTicketCommentInput): Promise<CreateTicketCommentOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicketComment" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface UpdateTicketCommentInput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export interface UpdateTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export function updateTicketComment(ctx: RequestContext, input: UpdateTicketCommentInput): Promise<UpdateTicketCommentOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicketComment" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface DeleteTicketCommentInput {
        ticketCommentId: string;
    }
    export interface DeleteTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export function deleteTicketComment(ctx: RequestContext, input: DeleteTicketCommentInput): Promise<DeleteTicketCommentOutput>;
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/getTicketComment" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    export interface GetTicketCommentInput {
        ticketCommentId: string;
    }
    export interface GetTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export function getTicketComment(ctx: RequestContext, input: GetTicketCommentInput): Promise<GetTicketCommentOutput>;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketCommentCatalogue" {
    import { type BffHandler, type ControllerRoute } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const ticketCommentCatalogueQryListTicketCommentHandler: BffHandler;
    export const ticketCommentCatalogueCmdCreateTicketCommentHandler: BffHandler;
    export const ticketCommentCatalogueCmdUpdateTicketCommentHandler: BffHandler;
    export const ticketCommentCatalogueCmdDeleteTicketCommentHandler: BffHandler;
    export const ticketCommentCatalogueQryGetTicketCommentHandler: BffHandler;
    export const ticketCommentCatalogueQryTicketPickerHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketHub.defs" {
    export const ticketHubController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "ticketHub";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "ticketHub";
            readonly controllerName: "TicketHubController";
            readonly ownerKind: "workspace";
            readonly workspaceId: "ticketHub";
            readonly actors: readonly ["atendente"];
            readonly allowedScopes: readonly ["internal"];
            readonly handlers: readonly [{
                readonly handlerName: "ticketHubQryListTicketHandler";
                readonly command: "qryListTicket";
                readonly bffId: "qryListTicket";
                readonly route: "controleChamados.ticketHub.qryListTicket";
                readonly kind: "query";
                readonly usecaseRef: "listTicket";
                readonly usecaseRefs: readonly ["listTicket"];
                readonly inputTypeName: "ListTicketInput";
                readonly inputContract: readonly [{
                    readonly inputId: "search";
                    readonly fieldRef: "Ticket.title";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Buscar por Título.";
                }, {
                    readonly inputId: "sortBy";
                    readonly fieldRef: "Ticket.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Campo de ordenação da listagem.";
                    readonly enumValues: readonly ["status"];
                }, {
                    readonly inputId: "sortOrder";
                    readonly fieldRef: "Ticket.status";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Direção da ordenação.";
                    readonly enumValues: readonly ["asc", "desc"];
                }];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketId";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "title";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["title"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "description";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["description"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "status";
                        readonly operationId: "listTicket";
                        readonly path: readonly ["status"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }, {
                readonly handlerName: "ticketHubQryListTicketCommentHandler";
                readonly command: "qryListTicketComment";
                readonly bffId: "qryListTicketComment";
                readonly route: "controleChamados.ticketHub.qryListTicketComment";
                readonly kind: "query";
                readonly usecaseRef: "listTicketComment";
                readonly usecaseRefs: readonly ["listTicketComment"];
                readonly inputTypeName: "ListTicketCommentInput";
                readonly inputContract: readonly [];
                readonly projection: {
                    readonly kind: "list";
                    readonly arrayFieldName: any;
                    readonly itemFields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly operationId: "listTicketComment";
                        readonly path: readonly ["ticketCommentId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "ticketId";
                        readonly operationId: "listTicketComment";
                        readonly path: readonly ["ticketId"];
                        readonly fromItems: true;
                    }, {
                        readonly name: "commentText";
                        readonly operationId: "listTicketComment";
                        readonly path: readonly ["commentText"];
                        readonly fromItems: true;
                    }];
                    readonly topFields: readonly [];
                };
                readonly optionalUses: readonly [];
            }];
            readonly routes: readonly [{
                readonly key: "controleChamados.ticketHub.qryListTicket";
                readonly handlerName: "ticketHubQryListTicketHandler";
            }, {
                readonly key: "controleChamados.ticketHub.qryListTicketComment";
                readonly handlerName: "ticketHubQryListTicketCommentHandler";
            }];
        };
    };
    export default ticketHubController;
    export const pipeline: readonly [{
        readonly id: "ticketHub__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketHub.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketHub.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/usecases/listTicket.d.ts", "_102047_/l4/controleChamados/contracts/ticketHub--qryListTicket.defs.ts", "_102047_/l1/controleChamados/layer_2_application/usecases/listTicketComment.d.ts", "_102047_/l4/controleChamados/contracts/ticketHub--qryListTicketComment.defs.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/http/controllers/ticketHub" {
    import { type BffHandler, type ControllerRoute } from "_102034_/l1/server/layer_2_controllers/contracts";
    export const ticketHubQryListTicketHandler: BffHandler;
    export const ticketHubQryListTicketCommentHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketRepositoryAdapter" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ITicketRepository } from "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository";
    export function createTicketRepositoryAdapter(ctx: RequestContext): ITicketRepository;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketCommentRepositoryAdapter" {
    import { type RequestContext } from "_102034_/l1/server/layer_2_controllers/contracts";
    import type { ITicketCommentRepository } from "_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository";
    export function createTicketCommentRepositoryAdapter(ctx: RequestContext): ITicketCommentRepository;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/registerRepositories" { }
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.defs" {
    export const seedsDefs: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "seeds";
        readonly artifactId: "seeds";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbSeeds";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly version: 1;
            readonly language: "en";
            readonly plan: {
                readonly summary: "Three ticket comments attached to the three existing open support tickets, providing distinct customer-support conversation history.";
                readonly localTables: readonly [{
                    readonly tableId: "Ticket";
                    readonly rows: readonly [{
                        readonly key: "ticket-1";
                        readonly columns: readonly [{
                            readonly name: "title";
                            readonly value: "Unable to update pet profile";
                        }, {
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "description";
                            readonly value: "The customer cannot save the pet's updated weight and vaccination details.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "ticket-2";
                        readonly columns: readonly [{
                            readonly name: "title";
                            readonly value: "Appointment confirmation missing";
                        }, {
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "description";
                            readonly value: "The customer completed an appointment request but has not received a confirmation message.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "ticket-3";
                        readonly columns: readonly [{
                            readonly name: "title";
                            readonly value: "Question about grooming service";
                        }, {
                            readonly name: "status";
                            readonly value: "open";
                        }];
                        readonly details: readonly [{
                            readonly name: "description";
                            readonly value: "The customer is asking which grooming services are included in the selected package.";
                        }];
                        readonly children: readonly [];
                    }];
                }, {
                    readonly tableId: "TicketComment";
                    readonly rows: readonly [{
                        readonly key: "comment-1";
                        readonly columns: readonly [{
                            readonly name: "ticket_id";
                            readonly value: {
                                readonly ref: "local:Ticket.ticket-1";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "ticketId";
                            readonly value: {
                                readonly ref: "local:Ticket.ticket-1";
                            };
                        }, {
                            readonly name: "commentText";
                            readonly value: "I am available this afternoon if you need any additional information.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "comment-2";
                        readonly columns: readonly [{
                            readonly name: "ticket_id";
                            readonly value: {
                                readonly ref: "local:Ticket.ticket-2";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "ticketId";
                            readonly value: {
                                readonly ref: "local:Ticket.ticket-2";
                            };
                        }, {
                            readonly name: "commentText";
                            readonly value: "Thank you for the update; I will send the requested document shortly.";
                        }];
                        readonly children: readonly [];
                    }, {
                        readonly key: "comment-3";
                        readonly columns: readonly [{
                            readonly name: "ticket_id";
                            readonly value: {
                                readonly ref: "local:Ticket.ticket-3";
                            };
                        }];
                        readonly details: readonly [{
                            readonly name: "ticketId";
                            readonly value: {
                                readonly ref: "local:Ticket.ticket-3";
                            };
                        }, {
                            readonly name: "commentText";
                            readonly value: "The issue is still occurring after restarting the application.";
                        }];
                        readonly children: readonly [];
                    }];
                }];
                readonly mdmEntities: readonly [];
            };
        };
    };
    export default seedsDefs;
    export const pipeline: readonly [{
        readonly id: "seeds__persistenceSeeds";
        readonly type: "persistenceSeeds";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/seeds.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceSeeds.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const seedIds: {
        readonly ticket1: string;
        readonly ticket2: string;
        readonly ticket3: string;
        readonly ticketCommentComment1: string;
        readonly ticketCommentComment2: string;
        readonly ticketCommentComment3: string;
    };
    export const seedSpares: {
        readonly Ticket: {
            readonly title: string[];
        };
    };
    export const ticketSeeds: TableSeedRows;
    export const ticketCommentSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticket.defs" {
    export const ticketTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Ticket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Ticket";
            readonly tableName: "controlechamados_ticket";
            readonly columns: readonly [{
                readonly name: "ticket_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Primary key and foreign-key identifier for the ticket.";
            }, {
                readonly name: "title";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "Searchable ticket title.";
            }, {
                readonly name: "status";
                readonly type: "text";
                readonly nullable: false;
                readonly description: "Ticket status.";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "Non-indexed ticket fields and child collections.";
            }];
            readonly primaryKey: readonly ["ticket_id"];
            readonly indexes: readonly [{
                readonly indexName: "controlechamados_ticket_title_idx";
                readonly columns: readonly ["title"];
                readonly unique: false;
            }, {
                readonly indexName: "controlechamados_ticket_status_idx";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "controle";
            readonly retentionDays: 0;
        };
    };
    export default ticketTableDefinition;
    export const pipeline: readonly [{
        readonly id: "ticket__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticket" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const ticketTableDef: TableDefinition;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketComment.defs" {
    export const ticketCommentTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "TicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "TicketComment";
            readonly tableName: "controlechamados_ticket_comment";
            readonly columns: readonly [{
                readonly name: "ticket_comment_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Primary key and foreign-key identifier for the ticket comment.";
            }, {
                readonly name: "ticket_id";
                readonly type: "uuid";
                readonly nullable: false;
                readonly description: "Foreign key identifying the ticket.";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: false;
                readonly description: "Non-indexed comment fields and child collections.";
            }];
            readonly primaryKey: readonly ["ticket_comment_id"];
            readonly indexes: readonly [{
                readonly indexName: "controlechamados_ticket_comment_ticket_id_idx";
                readonly columns: readonly ["ticket_id"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly columnName: "details";
                readonly childCollections: readonly [];
            };
            readonly appendOnly: false;
            readonly purpose: "controle";
            readonly retentionDays: 0;
        };
    };
    export default ticketCommentTableDefinition;
    export const pipeline: readonly [{
        readonly id: "ticketComment__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketComment" {
    import type { TableDefinition } from "_102034_/l1/server/layer_1_external/persistence/contracts";
    export const ticketCommentTableDef: TableDefinition;
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketCommentRepositoryAdapter.defs" {
    export const ticketCommentRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "TicketCommentRepositoryAdapter";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TicketComment";
            readonly className: "TicketCommentRepositoryAdapter";
            readonly portRef: "ITicketCommentRepository";
            readonly tableRef: "ticket_comment";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Implement async delete(id), getById(id), list(filter?), and save(aggregate) using only ctx.data.moduleData.getTable<Row>('ticket_comment').", "Map real columns ticketCommentId and ticketId to snake_case ticket_comment_id and ticket_id; store commentText in details JSONB under the verbatim key commentText.", "getById and list map rows back to TicketComment, reading details.commentText.", "list supports optional filter.search with findMany ilike on the applicable text field when present; filter.sortBy/sortOrder uses orderBy, with enum fields sorted in memory by declared enum order rather than SQL text.", "Use the table API's insert/update/delete/findOne/findMany operations and do not keep adapter state outside the runtime table store.", "Implement every port method: delete, getById, list, save."];
            readonly portMethods: readonly ["delete", "getById", "list", "save"];
        };
    };
    export default ticketCommentRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "ticketCommentRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketCommentRepositoryAdapter.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketCommentRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketComment.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketRepositoryAdapter.defs" {
    export const ticketRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "TicketRepositoryAdapter";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Ticket";
            readonly className: "TicketRepositoryAdapter";
            readonly portRef: "ITicketRepository";
            readonly tableRef: "ticket";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Implement async delete(id), getById(id), list(filter?), and save(aggregate) using only ctx.data.moduleData.getTable<Row>('ticket').", "Map real columns ticketId, title, status to snake_case ticket_id, title, status; store description in details JSONB under the verbatim key description.", "getById and list map rows back to the Ticket aggregate, reading details.description.", "list supports optional filter.search with findMany ilike on title, filter.sortBy/sortOrder via orderBy; if sorting status, sort in memory using the declared domain enum order rather than SQL text.", "Use the table API's insert/update/delete/findOne/findMany operations and do not keep adapter state outside the runtime table store.", "Implement every port method: delete, getById, list, save."];
            readonly portMethods: readonly ["delete", "getById", "list", "save"];
        };
    };
    export default ticketRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "ticketRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketRepositoryAdapter.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticketRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_1_external/adapters/persistence/ticket.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.defs" {
    export const ticketCommentRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "TicketCommentRepository";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TicketComment";
            readonly interfaceName: "ITicketCommentRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: TicketCommentId"];
                readonly returns: "TicketComment | null";
                readonly description: "Retrieves a ticket comment aggregate by its identifier.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: TicketCommentListFilter"];
                readonly returns: "TicketComment[]";
                readonly description: "Lists ticket comment aggregates matching domain filter criteria.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: TicketComment"];
                readonly returns: "void";
                readonly description: "Persists a ticket comment aggregate.";
            }, {
                readonly name: "delete";
                readonly params: readonly ["id: TicketCommentId"];
                readonly returns: "void";
                readonly description: "Deletes a ticket comment aggregate by its identifier.";
            }];
            readonly requiredMethods: readonly ["delete"];
        };
    };
    export default ticketCommentRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "ticketCommentRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.defs" {
    export const ticketRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "TicketRepository";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Ticket";
            readonly interfaceName: "ITicketRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: TicketId"];
                readonly returns: "Ticket | null";
                readonly description: "Retrieves a ticket aggregate by its identifier.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: TicketListFilter"];
                readonly returns: "Ticket[]";
                readonly description: "Lists ticket aggregates matching domain filter criteria.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Ticket"];
                readonly returns: "void";
                readonly description: "Persists a ticket aggregate.";
            }, {
                readonly name: "delete";
                readonly params: readonly ["id: TicketId"];
                readonly returns: "void";
                readonly description: "Deletes a ticket aggregate by its identifier.";
            }];
            readonly requiredMethods: readonly ["delete"];
        };
    };
    export default ticketRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "ticketRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/createTicket.defs" {
    export const createTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createTicket";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createTicket";
                readonly inputTypeName: "CreateTicketInput";
                readonly outputTypeName: "CreateTicketOutput";
                readonly input: readonly [{
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.title";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.description";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Resolve the initial status as the Ticket lifecycle initial state, open, using the system default rather than client input.", "Validate the required title and description fields.", "Generate the ticketId with the platform id generator and construct a Ticket with status open.", "Persist the Ticket through the Ticket port within the transaction.", "Return the created ticketId, title, description, and status."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "createTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/createTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/createTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/createTicketComment.defs" {
    export const createTicketCommentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createTicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createTicketComment";
            readonly ports: readonly ["TicketComment", "Ticket"];
            readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
            readonly functions: readonly [{
                readonly functionName: "createTicketComment";
                readonly inputTypeName: "CreateTicketCommentInput";
                readonly outputTypeName: "CreateTicketCommentOutput";
                readonly input: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Selected ticket to which the comment belongs.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Comment text to record in the ticket history.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.commentText";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }];
                readonly ports: readonly ["TicketComment", "Ticket"];
                readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Ticket aggregate through the Ticket port using the public ticketId.", "Apply onlyOpenTicketCanReceiveComment: reject with a machine-readable rule identifier and an English user-facing message when the ticket status is not open.", "Create a TicketComment through the TicketComment port with a generated ticketCommentId, the selected ticketId, and commentText.", "Return the created comment using the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketCommentId";
                    }, {
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketId";
                    }, {
                        readonly name: "commentText";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.commentText";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createTicketCommentUsecase;
    export const pipeline: readonly [{
        readonly id: "createTicketComment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/createTicketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/createTicketComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/decideClosure.defs" {
    export const decideClosureUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "decideClosure";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "decideClosure";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly ["onlyOpenTicketCanBeClosed"];
            readonly functions: readonly [{
                readonly functionName: "decideClosure";
                readonly inputTypeName: "DecideClosureInput";
                readonly outputTypeName: "DecideClosureOutput";
                readonly input: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Decisão tomada.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly ["onlyOpenTicketCanBeClosed"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Ticket aggregate by ticketId through the Ticket port.", "Validate the requested status is closed; field enum constraint requires rejecting other values.", "Apply rule onlyOpenTicketCanBeClosed: reject with rule id in error details unless the current ticket status is open.", "Call the Ticket domain canTransition helper using the lifecycle matrix, which permits open to closed and treats closed as terminal.", "Set the Ticket status to closed and save the parent Ticket aggregate through the Ticket port inside the transaction.", "Return the canonical Ticket output shape: ticketId, title, description, and status."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default decideClosureUsecase;
    export const pipeline: readonly [{
        readonly id: "decideClosure__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/decideClosure.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/decideClosure.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanBeClosed"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicket.defs" {
    export const deleteTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteTicket";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteTicket";
                readonly inputTypeName: "DeleteTicketInput";
                readonly outputTypeName: "DeleteTicketOutput";
                readonly input: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Stable identifier of the ticket to delete.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Resolve the Ticket port and load the ticket by ticketId.", "If the ticket does not exist, propagate the repository not-found error.", "Capture ticketId, title, description, and status from the loaded ticket.", "Delete the ticket through the Ticket port within the transaction.", "Return the captured deleted-ticket fields using the canonical output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deleteTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicketComment.defs" {
    export const deleteTicketCommentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "deleteTicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "deleteTicketComment";
            readonly ports: readonly ["TicketComment"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "deleteTicketComment";
                readonly inputTypeName: "DeleteTicketCommentInput";
                readonly outputTypeName: "DeleteTicketCommentOutput";
                readonly input: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Stable identifier of the comment to delete.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.ticketCommentId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }];
                readonly ports: readonly ["TicketComment"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Resolve the selected TicketComment by ticketCommentId through the TicketComment port.", "If the comment does not exist, apply the repository/domain not-found behavior and do not perform a delete.", "Capture ticketCommentId, ticketId, and commentText for the response before deletion.", "Delete the TicketComment through the TicketComment port within the transaction wrapper.", "Return the deleted comment projection matching the declared output shape."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketCommentId";
                    }, {
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketId";
                    }, {
                        readonly name: "commentText";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.commentText";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default deleteTicketCommentUsecase;
    export const pipeline: readonly [{
        readonly id: "deleteTicketComment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/deleteTicketComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/getTicket.defs" {
    export const getTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getTicket";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getTicket";
                readonly inputTypeName: "GetTicketInput";
                readonly outputTypeName: "GetTicketOutput";
                readonly input: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Stable identifier of the ticket, used to retrieve it and link it to comments and service workflows.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Resolve the selected ticketId from the request.", "Load the Ticket aggregate through the Ticket port using ticketId.", "Return ticketId, title, description, and status from the loaded Ticket.", "If no Ticket is found, return the repository/domain not-found error."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default getTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "getTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/getTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/getTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/getTicketComment.defs" {
    export const getTicketCommentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "getTicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "getTicketComment";
            readonly ports: readonly ["TicketComment"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "getTicketComment";
                readonly inputTypeName: "GetTicketCommentInput";
                readonly outputTypeName: "GetTicketCommentOutput";
                readonly input: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.ticketCommentId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }];
                readonly ports: readonly ["TicketComment"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load the TicketComment aggregate through the TicketComment port using ticketCommentId.", "Return ticketCommentId, ticketId, and commentText according to the canonical output shape.", "If the comment is not found, apply the repository/domain not-found behavior without inventing an additional L4 validation rule."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketCommentId";
                    }, {
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketId";
                    }, {
                        readonly name: "commentText";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.commentText";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default getTicketCommentUsecase;
    export const pipeline: readonly [{
        readonly id: "getTicketComment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/getTicketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/getTicketComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/listTicket.defs" {
    export const listTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listTicket";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listTicket";
                readonly inputTypeName: "ListTicketInput";
                readonly outputTypeName: "ListTicketOutput";
                readonly input: readonly [{
                    readonly name: "search";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Search by title.";
                    readonly fieldRef: "Ticket.title";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "sortBy";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Listing sort field.";
                    readonly fieldRef: "Ticket.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "sortOrder";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Listing sort direction.";
                    readonly fieldRef: "Ticket.status";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Load tickets through the Ticket port.", "Apply the optional title search filter in memory or through the repository query.", "Apply the requested status sort and direction; default to repository order when omitted.", "Return the list projection containing ticketId, title, description, and status."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "listTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/listTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/listTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/listTicketComment.defs" {
    export const listTicketCommentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "listTicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "listTicketComment";
            readonly ports: readonly ["TicketComment"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "listTicketComment";
                readonly inputTypeName: "ListTicketCommentInput";
                readonly outputTypeName: "ListTicketCommentOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }];
                readonly ports: readonly ["TicketComment"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Query all TicketComment records through the TicketComment port.", "Return the selected ticketCommentId, ticketId, and commentText fields as the list output."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketCommentId";
                    }, {
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketId";
                    }, {
                        readonly name: "commentText";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.commentText";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default listTicketCommentUsecase;
    export const pipeline: readonly [{
        readonly id: "listTicketComment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/listTicketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/listTicketComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/locateTicket.defs" {
    export const locateTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "locateTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "locateTicket";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "locateTicket";
                readonly inputTypeName: "LocateTicketInput";
                readonly outputTypeName: "LocateTicketOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly [];
                readonly transactional: false;
                readonly steps: readonly ["Query the Ticket port for the open ticket.", "Return the selected ticket projection with ticketId, title, description, and status.", "If no open ticket exists, return an empty collection."];
                readonly outputShape: {
                    readonly kind: "list";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default locateTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "locateTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/locateTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/locateTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/recordComment.defs" {
    export const recordCommentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "recordComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "recordComment";
            readonly ports: readonly ["TicketComment", "Ticket"];
            readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
            readonly functions: readonly [{
                readonly functionName: "recordComment";
                readonly inputTypeName: "RecordCommentInput";
                readonly outputTypeName: "RecordCommentOutput";
                readonly input: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Chamado";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.commentText";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }];
                readonly ports: readonly ["TicketComment", "Ticket"];
                readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
                readonly transactional: true;
                readonly steps: readonly ["Load the Ticket through the Ticket port using the route ticketId.", "Reject with rule details onlyOpenTicketCanReceiveComment when the ticket does not exist or its status is not open; the rule requires that only an open ticket can receive comments.", "Generate the TicketComment identifier with ctx.idGenerator.", "Create the TicketComment through the TicketComment port with ticketId and commentText, then persist it within the transaction wrapper.", "Return the created comment identifier, ticket identifier, and comment text."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketCommentId";
                    }, {
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketId";
                    }, {
                        readonly name: "commentText";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.commentText";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default recordCommentUsecase;
    export const pipeline: readonly [{
        readonly id: "recordComment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/recordComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/recordComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicket.defs" {
    export const updateTicketUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTicket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTicket";
            readonly ports: readonly ["Ticket"];
            readonly rulesApplied: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateTicket";
                readonly inputTypeName: "UpdateTicketInput";
                readonly outputTypeName: "UpdateTicketOutput";
                readonly input: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Identificador estável do chamado.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.title";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                    readonly ofEntity: "Ticket";
                    readonly fieldRef: "Ticket.description";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Ticket";
                }];
                readonly ports: readonly ["Ticket"];
                readonly rulesApplied: readonly [];
                readonly transactional: true;
                readonly steps: readonly ["Load the Ticket aggregate through the Ticket port using ticketId.", "Update the Ticket title and description with the supplied values.", "Preserve the current Ticket status; this operation does not request a status transition.", "Save the Ticket aggregate through the Ticket port in the transaction.", "Return ticketId, title, description, and status from the updated Ticket."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.ticketId";
                    }, {
                        readonly name: "title";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.title";
                    }, {
                        readonly name: "description";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.description";
                    }, {
                        readonly name: "status";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "Ticket.status";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateTicketUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTicket__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicketComment.defs" {
    export const updateTicketCommentUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTicketComment";
            readonly ports: readonly ["TicketComment", "Ticket"];
            readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
            readonly functions: readonly [{
                readonly functionName: "updateTicketComment";
                readonly inputTypeName: "UpdateTicketCommentInput";
                readonly outputTypeName: "UpdateTicketCommentOutput";
                readonly input: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Stable identifier of the comment to update.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.ticketCommentId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Selected ticket identifier to which the comment belongs.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.ticketId";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Updated comment text recorded in the ticket history.";
                    readonly ofEntity: "TicketComment";
                    readonly fieldRef: "TicketComment.commentText";
                    readonly item: {
                        readonly fields: readonly [];
                    };
                }];
                readonly output: readonly [{
                    readonly name: "ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "ticketId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }, {
                    readonly name: "commentText";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TicketComment";
                }];
                readonly ports: readonly ["TicketComment", "Ticket"];
                readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
                readonly transactional: true;
                readonly steps: readonly ["Within a single transaction wrapper, load the TicketComment by ticketCommentId through the TicketComment port and load the Ticket by ticketId through the Ticket port.", "Validate that the referenced Ticket has status open; if not, reject with an English AppError whose machine-readable details include ruleId onlyOpenTicketCanReceiveComment.", "Update the commentText on the loaded TicketComment, preserving its ticketCommentId and ticketId, and save it through the TicketComment port.", "Return the updated TicketComment projected as ticketCommentId, ticketId, and commentText."];
                readonly outputShape: {
                    readonly kind: "object";
                    readonly fields: readonly [{
                        readonly name: "ticketCommentId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketCommentId";
                    }, {
                        readonly name: "ticketId";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.ticketId";
                    }, {
                        readonly name: "commentText";
                        readonly type: "string";
                        readonly required: true;
                        readonly fieldRef: "TicketComment.commentText";
                    }];
                };
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateTicketCommentUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTicketComment__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_2_application/usecases/updateTicketComment.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l1/controleChamados/layer_2_application/ports/ticketCommentRepository.d.ts", "_102047_/l1/controleChamados/layer_2_application/ports/ticketRepository.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.d.ts", "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.defs" {
    export const ticketDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Ticket";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Ticket";
            readonly title: "Chamado";
            readonly fields: readonly [{
                readonly fieldId: "ticketId";
                readonly title: "Identificador do chamado";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                readonly constraints: readonly [{
                    readonly constraintId: "uniqueTicketId";
                    readonly kind: "unique";
                    readonly value: "true";
                    readonly description: "Cada chamado possui um identificador estável e exclusivo.";
                    readonly source: "inferred";
                }];
            }, {
                readonly fieldId: "title";
                readonly title: "Título";
                readonly type: "string";
                readonly required: true;
                readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "description";
                readonly title: "Descrição";
                readonly type: "text";
                readonly required: true;
                readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "status";
                readonly title: "Status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Situação atual do chamado durante o atendimento.";
                readonly constraints: readonly [{
                    readonly constraintId: "ticketStatusEnum";
                    readonly kind: "enum";
                    readonly value: "[\"open\",\"closed\"]";
                    readonly description: "Estados permitidos para o ciclo de vida do chamado.";
                    readonly source: "journey";
                }];
                readonly enum: readonly ["open", "closed"];
            }];
            readonly valueObjects: readonly [];
            readonly statusEnum: readonly ["open", "closed"];
            readonly lifecycle: {
                readonly workflowId: "ticketLifecycle";
                readonly entityRef: "Ticket";
                readonly states: readonly ["closed", "open"];
                readonly initialState: "open";
                readonly terminalStates: readonly ["closed"];
                readonly allowed: {
                    readonly closed: readonly [];
                    readonly open: readonly ["closed"];
                };
            };
            readonly invariants: readonly ["ticketId must be unique and stable for each ticket.", "A ticket's status must be either open or closed.", "A ticket can only be closed when its current status is open.", "A closed ticket cannot be reopened; its status cannot change back to open.", "Only a ticket with status open can receive comments."];
        };
    };
    export default ticketDomainEntity;
    export const pipeline: readonly [{
        readonly id: "ticket__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_3_domain/entities/ticket.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.defs" {
    export const ticketCommentDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "TicketComment";
        readonly moduleName: "controleChamados";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TicketComment";
            readonly title: "Comentário do chamado";
            readonly fields: readonly [{
                readonly fieldId: "ticketCommentId";
                readonly title: "Identificador do comentário";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                readonly constraints: readonly [{
                    readonly constraintId: "uniqueTicketCommentId";
                    readonly kind: "unique";
                    readonly value: "true";
                    readonly description: "Cada comentário possui um identificador estável e exclusivo.";
                    readonly source: "inferred";
                }];
            }, {
                readonly fieldId: "ticketId";
                readonly title: "Chamado";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
                readonly constraints: readonly [];
            }, {
                readonly fieldId: "commentText";
                readonly title: "Comentário";
                readonly type: "text";
                readonly required: true;
                readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                readonly constraints: readonly [{
                    readonly constraintId: "commentTextMinLength";
                    readonly kind: "minLength";
                    readonly value: "1";
                    readonly description: "O comentário deve conter uma atualização escrita pelo atendente.";
                    readonly source: "journey";
                }];
            }];
            readonly valueObjects: readonly [];
            readonly statusEnum: readonly [];
            readonly invariants: readonly ["ticketCommentId must be unique and stable.", "commentText must contain at least 1 character.", "A comment may be added only to a ticket whose status is open."];
        };
    };
    export default ticketCommentDomainEntity;
    export const pipeline: readonly [{
        readonly id: "ticketComment__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.ts";
        readonly defPath: "_102047_/l1/controleChamados/layer_3_domain/entities/ticketComment.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102047_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102047_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102047_/l2/controleChamados/web/contracts/commentOpenTicket" {
    export interface QryLocateTicketInput {
    }
    export interface QryLocateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const qryLocateTicketRoute: "controleChamados.commentOpenTicket.qryLocateTicket";
    export interface CmdRecordCommentInput {
        ticketId: string;
        commentText: string;
    }
    export interface CmdRecordCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdRecordCommentRoute: "controleChamados.commentOpenTicket.cmdRecordComment";
}
declare module "_102047_/l2/controleChamados/web/contracts/ticketCatalogue" {
    export interface QryListTicketInput {
        search?: string;
        sortBy?: 'open' | 'closed';
        sortOrder?: 'asc' | 'desc';
    }
    export interface QryListTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const qryListTicketRoute: "controleChamados.ticketCatalogue.qryListTicket";
    export interface CmdCreateTicketInput {
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export interface CmdCreateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const cmdCreateTicketRoute: "controleChamados.ticketCatalogue.cmdCreateTicket";
    export interface CmdUpdateTicketInput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export interface CmdUpdateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const cmdUpdateTicketRoute: "controleChamados.ticketCatalogue.cmdUpdateTicket";
    export interface CmdDeleteTicketInput {
        ticketId: string;
    }
    export interface CmdDeleteTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const cmdDeleteTicketRoute: "controleChamados.ticketCatalogue.cmdDeleteTicket";
    export interface QryGetTicketInput {
        ticketId: string;
    }
    export interface QryGetTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const qryGetTicketRoute: "controleChamados.ticketCatalogue.qryGetTicket";
    export interface QryLocateTicketInput {
    }
    export interface QryLocateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const qryLocateTicketRoute: "controleChamados.ticketCatalogue.qryLocateTicket";
    export interface CmdDecideClosureInput {
        ticketId: string;
        status: 'open' | 'closed';
    }
    export interface CmdDecideClosureOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const cmdDecideClosureRoute: "controleChamados.ticketCatalogue.cmdDecideClosure";
}
declare module "_102047_/l2/controleChamados/web/contracts/ticketCommentCatalogue" {
    export interface QryListTicketCommentInput {
    }
    export interface QryListTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const qryListTicketCommentRoute: "controleChamados.ticketCommentCatalogue.qryListTicketComment";
    export interface CmdCreateTicketCommentInput {
        ticketId: string;
        commentText: string;
    }
    export interface CmdCreateTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdCreateTicketCommentRoute: "controleChamados.ticketCommentCatalogue.cmdCreateTicketComment";
    export interface CmdUpdateTicketCommentInput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export interface CmdUpdateTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdUpdateTicketCommentRoute: "controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment";
    export interface CmdDeleteTicketCommentInput {
        ticketCommentId: string;
    }
    export interface CmdDeleteTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdDeleteTicketCommentRoute: "controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment";
    export interface QryGetTicketCommentInput {
        ticketCommentId: string;
    }
    export interface QryGetTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const qryGetTicketCommentRoute: "controleChamados.ticketCommentCatalogue.qryGetTicketComment";
    export interface QryTicketPickerInput {
        search?: string;
        sortBy?: 'open' | 'closed';
        sortOrder?: 'asc' | 'desc';
    }
    export interface QryTicketPickerOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const qryTicketPickerRoute: "controleChamados.ticketCommentCatalogue.qryTicketPicker";
}
declare module "_102047_/l2/controleChamados/web/contracts/ticketHub" {
    export interface QryListTicketInput {
        search?: string;
        sortBy?: 'open' | 'closed';
        sortOrder?: 'asc' | 'desc';
    }
    export interface QryListTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export const qryListTicketRoute: "controleChamados.ticketHub.qryListTicket";
    export interface QryListTicketCommentInput {
    }
    export interface QryListTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const qryListTicketCommentRoute: "controleChamados.ticketHub.qryListTicketComment";
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/commentOpenTicket.defs" {
    export const definition = "page: Registrar coment\u00E1rio em chamado aberto\nactor: atendente\npurpose: Documentar o andamento do atendimento em um chamado aberto.\nuxExperience: processWizard\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "commentOpenTicket__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page11/commentOpenTicket.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page11/commentOpenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/commentOpenTicketDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["commentOpenTicket__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/contracts/bootstrap" {
    import type { ProjectNavigationEntry } from "_102029_/l2/runtimeConfigTypes";
    export type MasterFrontendShellMode = 'spa' | 'pwa';
    export type MasterFrontendDeviceKind = 'desktop' | 'mobile';
    export type MasterFrontendAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type Platform = "web" | "mobile";
    export type ISkillConfig = "layer1" | "layer2" | "layer3" | "layer4" | "contract" | "architecture" | "definition";
    export type PathConfig = {
        sharedPath: string;
        sharedSkill: string;
    };
    export type ISkill = Partial<Record<ISkillConfig, {
        skillPath: string[];
    }>>;
    export type IPaths = Partial<Record<Platform, PathConfig>>;
    export interface IGenomeConfig {
        device: MasterFrontendDeviceKind;
        designSystem: string;
        layout: string;
    }
    export interface MasterFrontendRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export type MasterFrontendRegionName = 'header' | 'aside' | 'content';
    export interface MasterFrontendLayoutConfig {
        regions: {
            desktop: MasterFrontendRegionVisibility;
            mobile: MasterFrontendRegionVisibility;
        };
        asideMode: {
            desktop: MasterFrontendAsideMode;
            mobile: MasterFrontendAsideMode;
        };
        asideSize?: {
            desktopWidthPx?: number;
            drawerWidthPx?: number;
        };
    }
    export interface MasterFrontendRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export interface MasterFrontendDynamicRegionConfig {
        renderer: MasterFrontendRegionRendererConfig;
        widthPx?: number;
        /** Fixed header band height. Equal values across profiles = no layout shift on switch. */
        heightPx?: number;
        source?: string;
        switchWithoutRouteReload?: boolean;
        props?: Record<string, unknown>;
        brand?: Record<string, unknown>;
        component?: string;
        appsMenuSource?: string;
        [key: string]: unknown;
    }
    export interface MasterFrontendShellRegionProfiles {
        activeProfile: string;
        switchWithoutRouteReload?: boolean;
        profiles: Record<string, MasterFrontendDynamicRegionConfig>;
    }
    export interface MasterFrontendClientShellConfig {
        mode: MasterFrontendShellMode;
        activeProfile?: string;
        runtimeControls?: Record<string, string>;
        regions: {
            header?: MasterFrontendShellRegionProfiles;
            aside?: MasterFrontendShellRegionProfiles;
        };
    }
    export type MasterFrontendRouteMatchMode = 'exact' | 'prefix';
    export interface MasterFrontendRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: MasterFrontendRouteMatchMode;
    }
    export interface MasterFrontendModuleFrontendDefinition {
        pageTitle?: string;
        device?: MasterFrontendDeviceKind;
        navigation?: ProjectNavigationEntry[];
        routes: MasterFrontendRouteDefinition[];
        headerRenderer?: MasterFrontendRegionRendererConfig;
        asideRenderer?: MasterFrontendRegionRendererConfig;
    }
    export interface MasterFrontendModuleShellPreferences {
        layout?: Partial<MasterFrontendLayoutConfig>;
    }
    export interface MasterFrontendBootConfig {
        projectId: string;
        /**
         * The environment mode the SERVER resolved for this project (`production | homologation | development |
         * presentation`). The client only displays it; it never decides it. Absent on a runtime older than the
         * modes.
         */
        appEnv?: string;
        moduleId: string;
        basePath: string;
        shellMode: MasterFrontendShellMode;
        device: MasterFrontendDeviceKind;
        languages?: string[];
        designSystem?: string;
        designSystems?: string[];
        routes: MasterFrontendRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: ProjectNavigationEntry[];
        moduleLinks?: ProjectNavigationEntry[];
        layout: MasterFrontendLayoutConfig;
        clientShell?: MasterFrontendClientShellConfig;
    }
    export type MasterFrontendInteractionMode = 'blocking' | 'silent';
    export type MasterFrontendBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface MasterFrontendNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface MasterFrontendBlockingErrorState {
        title: string;
        error: MasterFrontendNormalizedError;
        canRetry: boolean;
    }
    export interface MasterFrontendInteractionState {
        busy: boolean;
        busyPhase: MasterFrontendBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: MasterFrontendBlockingErrorState;
    }
    global {
        interface Window {
            collabMasterFrontendShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
                setHeaderRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setAsideRenderer: (renderer: MasterFrontendRegionRendererConfig, props?: Record<string, unknown>) => Promise<void>;
                setShellProfile: (profileName: string) => Promise<void>;
            };
            /** Unified nav3 (runtime): content-region tabs hosting arbitrary elements. */
            collabRuntimeNav3?: {
                openTab: (tab: {
                    id: string;
                    title: string;
                    element: unknown;
                    closable?: boolean;
                }) => void;
                closeTab: (id: string) => void;
                activateTab: (id: string) => void;
                listTabs: () => string[];
            };
        }
        interface Window {
            collabBoot?: MasterFrontendBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabMasterFrontendInteractionState?: MasterFrontendInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        private errorCounts;
        private errorEventsPushed;
        constructor();
        /**
         * Error-specific push: dedupes repeats (same message/source) bumping a
         * repeatCount instead of flooding, skips browser-extension noise, caps the
         * session volume, and never throws (an error handler must not error).
         */
        private pushError;
        private errorFlushTimer;
        /** Coalesce error bursts: wait 1s before the beacon so repeats dedupe into the queued event. */
        private scheduleErrorFlush;
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { MasterFrontendInteractionMode, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: MasterFrontendNormalizedError | null;
        telemetryReceived?: number;
    }
    export interface BffClientRequest {
        routine: string;
        params: unknown;
        meta: {
            source: 'http' | 'test';
            userId: string;
            telemetry: ClientTelemetryEvent[];
        };
    }
    export type BffDirectResult<TData = unknown> = BffClientResponse<TData> | {
        response: BffClientResponse<TData>;
        statusCode?: number;
    };
    export interface BffDirectTransport {
        execBff<TData = unknown>(request: BffClientRequest, options?: BffClientOptions): Promise<BffDirectResult<TData>>;
    }
    global {
        interface Window {
            collabBffTransport?: BffDirectTransport;
            collabBffTransportModule?: string;
        }
    }
    /** The event the shell listens for to send the user back to the collab-auth login. */
    export const BFF_UNAUTHENTICATED_EVENT = "collab-bff-unauthenticated";
    /** Explicit override (email). Empty string clears it and the session cookie takes over again. */
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102029_/l2/interactionRuntime" {
    import type { MasterFrontendInteractionMode, MasterFrontendInteractionState, MasterFrontendNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: MasterFrontendInteractionState) => void;
    interface BlockingActionOptions {
        mode?: MasterFrontendInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): MasterFrontendInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): MasterFrontendNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102047_/l2/controleChamados/web/shared/commentOpenTicket" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { QryLocateTicketOutput, CmdRecordCommentOutput } from "_102047_/l2/controleChamados/web/contracts/commentOpenTicket";
    export type { QryLocateTicketInput, QryLocateTicketOutput, CmdRecordCommentInput, CmdRecordCommentOutput, } from "_102047_/l2/controleChamados/web/contracts/commentOpenTicket";
    export class ControleChamadosCommentOpenTicketBase extends CollabLitElement {
        /** state status — pageStatus */
        status: string;
        /** state ui.commentOpenTicket.scenary — uiScenary, values: base|recordComment */
        uiScenary: 'base' | 'recordComment';
        /** state qryLocateTicketState — actionStatus, values: idle|loading|success|error */
        qryLocateTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state qryLocateTicketData — queryResult, outputShape: array */
        qryLocateTicketData: QryLocateTicketOutput[];
        /** state cmdRecordCommentState — actionStatus, values: idle|loading|success|error */
        cmdRecordCommentState: 'idle' | 'loading' | 'success' | 'error';
        /** state cmdRecordCommentTicketId — input */
        cmdRecordCommentTicketId: string;
        /** state cmdRecordCommentCommentText — input */
        cmdRecordCommentCommentText: string;
        /** state cmdRecordCommentOutput — commandOutput */
        cmdRecordCommentOutput: CmdRecordCommentOutput | null;
        /** state cmdRecordCommentError — actionError */
        cmdRecordCommentError: string;
        /** Lifecycle connection for state initialization and initial data loading. */
        connectedCallback(): void;
        /** Lifecycle disconnection for removing shared-state subscriptions. */
        disconnectedCallback(): void;
        /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private syncRouteParams;
        /** setter for state ui.commentOpenTicket.scenary */
        setUiScenary(value: string): void;
        /** handler for action set.uiScenary — bind UI events here */
        handleUiScenaryChange(event: Event): void;
        private applyUrlScenary;
        private syncScenaryQuery;
        private readErrorMessage;
        /** action qryLocateTicket (query) — route controleChamados.commentOpenTicket.qryLocateTicket; inputs none; writes ui.commentOpenTicket.data.qryLocateTicket; status ui.commentOpenTicket.action.qryLocateTicket.status */
        loadQryLocateTicket(): Promise<void>;
        /** handler for action qryLocateTicket — bind UI events here */
        handleQryLocateTicketClick(event?: Event): void;
        /** action cmdRecordComment (command) — route controleChamados.commentOpenTicket.cmdRecordComment; inputs ticketId, commentText; writes ui.commentOpenTicket.output.cmdRecordComment; status ui.commentOpenTicket.action.cmdRecordComment.status; feedback keys action.cmdRecordComment.success / action.cmdRecordComment.error */
        cmdRecordComment(): Promise<void>;
        /** handler for action cmdRecordComment — bind UI events here */
        handleCmdRecordCommentClick(event?: Event): void;
        /** setter for state ui.commentOpenTicket.input.cmdRecordComment.ticketId */
        setCmdRecordCommentTicketId(value: string): void;
        /** handler for action set.cmdRecordCommentTicketId — bind UI events here */
        handleCmdRecordCommentTicketIdChange(event: Event): void;
        /** setter for state ui.commentOpenTicket.input.cmdRecordComment.commentText */
        setCmdRecordCommentCommentText(value: string): void;
        /** handler for action set.cmdRecordCommentCommentText — bind UI events here */
        handleCmdRecordCommentCommentTextChange(event: Event): void;
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102033_/l2/moleculeBase" {
    import { TemplateResult, PropertyValues } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    /**
     * Registra a tag da molécula UMA vez.
     *
     * O runtime pode acabar com duas cópias do mesmo módulo no mesmo documento:
     * o service worker do mls serve a forma crua (do IndexedDB) para imports sem
     * extensão e para `.defs.js`/`.test.js` — caminho que o servidor nem vê —
     * enquanto o import com `.js` pede o zip. Com `@customElement`, a segunda
     * avaliação lança `already been used with this registry`, o módulo fica marcado
     * como falho no module map do browser e a rota morre até o reload.
     *
     * Isto só é seguro porque o Lit é UM só (mls-102033/l2/shared/litRuntime.json):
     * as duas cópias estendem o mesmo `ReactiveElement`, então ficar com a primeira
     * registrada é equivalente. Antes disso, a guarda seria máscara — deixaria um
     * componente construído sobre a classe base errada, e em silêncio.
     *
     * Devolve `true` quando registrou, `false` quando já havia.
     */
    export function defineMoleculeOnce(tag: string, ctor: CustomElementConstructor): boolean;
    export class MoleculeAuraElement extends StateLitElement {
        cssClass: string;
        protected slotTags: string[];
        /**
         * Opt in to LIVE slots: the consumer's slot content is MOVED into place as real
         * DOM nodes, instead of being read as a string and re-emitted with unsafeHTML.
         *
         * Why this exists: the snapshot path serializes slot children via `outerHTML` and
         * re-parses them. Serializing destroys event bindings and component identity, so
         * anything interactive the consumer puts in a slot is dead on arrival — and nested
         * molecules had to be made inert to keep the parent's snapshot readable. That makes
         * slots content-only, which defeats composition.
         *
         * With live slots the nodes are never serialized: they are moved, and moving preserves
         * listeners, Lit part references and nested custom elements. A molecule that opts in
         * also stops forcing its slotted descendants to be inert — they render normally.
         *
         * Opt-in per molecule so the two mechanisms coexist. Keep the snapshot path where the
         * slot carries DATA to be parsed (`TableHead key=…`, `Item value=…`); use live slots
         * where it carries CONTENT or CONTROLS (`Action`, `Label`, `Icon`, `Trigger`).
         */
        protected usesLiveSlots: boolean;
        /**
         * The consumer's live nodes, per slot tag, held by reference.
         *
         * Holding them is what makes the mechanism survive the anchor coming and going. When a
         * template branch leaves the render (a hidden modal, a collapsed region), Lit removes
         * the anchor and everything under it — including these nodes. Removing a node from the
         * DOM does not destroy it while something still references it, and its listeners stay
         * attached, so the next projection can simply put it back.
         */
        private _liveNodes;
        /** Last anchor that held each key — see `_currentNodes`. */
        private _liveHosts;
        /** Detached holder per key, so eviction does not lose content. */
        private _liveHolders;
        /**
         * Per-element anchors, for molecules that don't pass a slot through but TRANSFORM it.
         *
         * A table is the motivating case: it reads `TableBody > TableRow > TableCell`, sorts and
         * paginates, then re-emits real `<tr>`/`<td>`. The source of a cell's content is a nested
         * element, not a direct child, and there are N×M of them — so an anchor keyed by tag name
         * can't address it. These map an id to the source element instead.
         *
         * The id lives in a WeakMap so the SAME element always gets the SAME id across renders,
         * which is what lets `_liveNodes` survive a row leaving the page and coming back.
         */
        private _liveRefSeq;
        private _liveRefIds;
        private _liveRefs;
        /**
         * Renders the placeholder where a live slot's content lands.
         *
         * The anchor must stay free of Lit bindings: Lit does not manage children it did not
         * create, so nodes appended here survive every re-render. Put bindings around the
         * anchor, never inside it.
         */
        protected renderLiveSlot(tag: string, cls?: string): TemplateResult;
        /**
         * Same as `renderLiveSlot`, but bound to a specific source ELEMENT instead of a tag.
         *
         * Use it when the molecule transforms the slot structure and one tag maps to many
         * destinations — a table cell, a list item. Pass the LIVE element (from `getLiveSlot`),
         * never a snapshot clone: a clone's children are copies, and moving copies projects
         * dead nodes.
         */
        protected renderLiveSlotFrom(source: Element | null | undefined, cls?: string): TemplateResult;
        /**
         * Text currently rendered for a source element, projected or not.
         *
         * A transforming molecule that sorts or filters by cell text cannot read the source
         * element after projection — its children were moved out, so `textContent` is empty.
         * This reads the projected nodes instead, which keeps the value CURRENT: caching the
         * text at capture time would go stale the moment the consumer changed it.
         */
        protected getLiveText(source: Element | null | undefined): string;
        /**
         * The LIVE slot element for `tag` — not the snapshot clone.
         *
         * Structure reads (how many rows, which attributes) should come from here in a molecule
         * that projects, because the snapshot goes stale between mutations and, worse, a
         * re-snapshot after projection reads the emptied sources.
         */
        protected getLiveSlot(tag: string): Element | null;
        /**
         * Moves each live slot's children into its anchor.
         *
         * Runs from `update()` — right after Lit commits the DOM, so the anchors exist. It is
         * deliberately NOT in `updated()`: most molecules override that without calling super,
         * which would silently skip projection.
         */
        private _projectLiveSlots;
        /** Capture-once + reattach-when-empty, shared by both anchor kinds. */
        private _fillAnchor;
        /**
         * Holder per key: a detached element where the nodes wait while they have no anchor.
         * It exists so eviction does not lose content.
         */
        private _holderFor;
        /**
         * The CURRENT nodes for a key, which are not always the captured ones.
         *
         * `_liveNodes` is the list taken at capture time. It goes stale when the consumer REPLACES the
         * slot's content instead of just updating values — `${loading ? spinner : table}`, for example:
         * Lit removes the old nodes and inserts different ones between the same markers, which are
         * still in the anchor. Reattaching the capture list would hand back only the already-discarded
         * nodes, and the region would come back EMPTY when reopened. Measured on 2026-08-04 with
         * demotable--pedidosdetalhe: opening, closing and opening again showed a blank row.
         *
         * Hence the order of preference: the last anchor that held the key (Lit removes the anchor from
         * the DOM, but its children stay INSIDE it), then the holder, and only then the capture.
         */
        private _currentNodes;
        /** The consumer's slot element for `tag`, among this element's own children. */
        private _findSlotChild;
        /**
         * When true, this molecule is inside another molecule's slot tag.
         * It should NOT render — it exists only as raw HTML for the parent
         * molecule to read via getSlotContent().
         */
        private _isInert;
        /**
         * Checks if this element is inside a slot tag of a parent molecule.
         * Walks up the DOM looking for a parent MoleculeAuraElement whose
         * slot tags include one of our ancestors.
         */
        private _checkIfInert;
        private _snapshot;
        /**
         * Returns a parsed Document snapshot for querying slot tags.
         */
        private getSnapshot;
        /**
         * Takes a snapshot: reads outerHTML from slot tag children,
         * parses into isolated Document.
         */
        private _takeSnapshot;
        private _slotObserver;
        private _updateDebounceTimer;
        _mutationLock: boolean;
        connectedCallback(): void;
        /**
         * Projection hook.
         *
         * `update()` is where Lit commits the template to the DOM, so the anchors exist right
         * after `super.update()`. Chosen over `updated()` on purpose: most molecules override
         * `updated()` without calling super, and projection would silently never run. No
         * molecule overrides `update()`.
         */
        protected update(changed: PropertyValues): void;
        disconnectedCallback(): void;
        private _stopNativeFormEvent;
        private _hideSlotTags;
        private _setupSlotObserver;
        private _isInsideSlotTag;
        private _teardownSlotObserver;
        private _debouncedSlotUpdate;
        /**
         * Called when slot tag content changes.
         * Re-takes snapshot, re-hides, re-renders.
         */
        _onSlotTagsChanged(): void;
        protected getSlot(tag: string): Element | null;
        protected getSlots(tag: string): Element[];
        protected getSlotAttr(tag: string, attr: string): string | null;
        protected getSlotContent(tag: string): string;
        protected hasSlot(tag: string): boolean;
        protected getSlotClass(tag: string): string;
    }
}
declare module "_102033_/l2/shared/molecules/cn" {
    export function cn(...inputs: (string | undefined | null | false)[]): string;
}
declare module "_102020_/l2/molecules/mlScenaryLogic" {
    export type ScenaryMode = 'scenary' | 'tabs';
    export interface SceneInput {
        value: string;
        title: string;
        nav: string | null;
        backTo: string | null;
        disabled: boolean;
    }
    export interface SceneRecord {
        value: string;
        title: string;
        navBack: boolean;
        backTo: string | null;
        disabled: boolean;
    }
    export interface SceneHostChild {
        tagName: string;
        getAttribute(name: string): string | null;
        hasAttribute(name: string): boolean;
    }
    export function normalizeMode(mode: string | null | undefined): ScenaryMode;
    export function readSceneElements(parent: {
        children: ArrayLike<SceneHostChild>;
    }): SceneInput[];
    export function parseScenes(inputs: SceneInput[]): SceneRecord[];
    export function firstEnabled(scenes: SceneRecord[]): SceneRecord | null;
    export function resolveActive(scenes: SceneRecord[], value: string | null | undefined): string | null;
    export function isDirectRender(scenes: SceneRecord[], revealall: boolean): boolean;
    export function showTabs(mode: ScenaryMode, scenes: SceneRecord[], revealall: boolean): boolean;
    export function showBack(mode: ScenaryMode, scene: SceneRecord | undefined, scenes: SceneRecord[], revealall: boolean): boolean;
    export function resolveBackTarget(scenes: SceneRecord[], scene: SceneRecord): string | null;
    export function sceneHidden(scene: SceneRecord, active: string | null, revealall: boolean): boolean;
    export function stepEnabled(scenes: SceneRecord[], current: string | null, direction: 1 | -1): string | null;
    export function shouldEmitChange(opts: {
        internal: boolean;
        revealall: boolean;
        disabled: boolean;
        loading: boolean;
        previous: string | null;
        next: string | null;
    }): boolean;
    export function changeDetail(scenes: SceneRecord[], previous: string | null, next: string): {
        value: string;
        previous: string | null;
        title: string;
    };
}
declare module "_102020_/l2/molecules/ml-scenary" {
    import { MoleculeAuraElement } from "_102033_/l2/moleculeBase";
    export const ML_SCENARY_TAG = "molecules--ml-scenary-102020";
    export class MlScenaryMolecule extends MoleculeAuraElement {
        slotTags: string[];
        protected usesLiveSlots: boolean;
        mode: string;
        value: string | null;
        backLabel: string;
        disabled: boolean;
        loading: boolean;
        revealall: boolean;
        private uid;
        private pendingFocus;
        private scenes;
        private sceneSource;
        private toSafeId;
        private headingId;
        private tabId;
        private panelId;
        private navigate;
        private handleTabClick;
        private handleBack;
        private handleKeyDown;
        updated(changed: Map<string | number | symbol, unknown>): void;
        private renderBack;
        private renderBadge;
        private renderPanel;
        render(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/commentOpenTicket" {
    import { ControleChamadosCommentOpenTicketBase } from "_102047_/l2/controleChamados/web/shared/commentOpenTicket";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.locateTicket.title': string;
        'organism.qryLocateTicket.title': string;
        'intent.qryLocateTicket.list.title': string;
        'intent.qryLocateTicket.list.empty': string;
        'intent.qryLocateTicket.list.column.ticketId.label': string;
        'intent.qryLocateTicket.list.column.title.label': string;
        'intent.qryLocateTicket.list.column.description.label': string;
        'intent.qryLocateTicket.list.column.status.label': string;
        'section.recordComment.title': string;
        'organism.cmdRecordComment.title': string;
        'intent.cmdRecordComment.form.title': string;
        'intent.cmdRecordComment.form.action.cmdRecordComment': string;
        'intent.cmdRecordComment.form.field.commentText.label': string;
        'action.cmdRecordComment.success': string;
        'action.cmdRecordComment.error': string;
        'section.ticket-context.title': string;
        'section.comment-action.title': string;
        'scenary.base': string;
        'scenary.recordComment': string;
        'common.refresh': string;
        'common.loading': string;
        'common.selectTicket': string;
        'common.back': string;
        'common.requiredTicket': string;
        'common.noDescription': string;
        'common.status.open': string;
        'common.status.inProgress': string;
        'common.status.pending': string;
        'common.status.closed': string;
        'common.status.cancelled': string;
        'common.status.unknown': string;
        'common.commentProgress': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage11CommentOpenTicketPage extends ControleChamadosCommentOpenTicketBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
        renderScenaryRecordComment(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/ticketCatalogue.defs" {
    export const definition = "page: Chamado\nactor: atendente\npurpose: Cadastro de Chamado.\nuxExperience: entityRecordManagement\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketCatalogue__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page11/ticketCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page11/ticketCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketCatalogueDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketCatalogue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/shared/ticketCatalogue" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { QryListTicketOutput, CmdCreateTicketOutput, CmdUpdateTicketOutput, CmdDeleteTicketOutput, QryGetTicketOutput, QryLocateTicketOutput, CmdDecideClosureOutput } from "_102047_/l2/controleChamados/web/contracts/ticketCatalogue";
    export type { QryListTicketInput, QryListTicketOutput, CmdCreateTicketInput, CmdCreateTicketOutput, CmdUpdateTicketInput, CmdUpdateTicketOutput, CmdDeleteTicketInput, CmdDeleteTicketOutput, QryGetTicketInput, QryGetTicketOutput, QryLocateTicketInput, QryLocateTicketOutput, CmdDecideClosureInput, CmdDecideClosureOutput, } from "_102047_/l2/controleChamados/web/contracts/ticketCatalogue";
    export class ControleChamadosTicketCatalogueBase extends CollabLitElement {
        /** state status — pageStatus */
        status: string;
        /** state ui.ticketCatalogue.scenary — values: base|detail|createTicket|updateTicket|decideClosure */
        uiScenary: 'base' | 'detail' | 'createTicket' | 'updateTicket' | 'decideClosure';
        /** state qryListTicketState — actionStatus, values: idle|loading|success|error */
        qryListTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state qryListTicketSearch — input */
        qryListTicketSearch: string;
        /** state qryListTicketSortBy — input, values: open|closed */
        qryListTicketSortBy: string;
        /** state qryListTicketSortOrder — input, values: asc|desc */
        qryListTicketSortOrder: string;
        /** state qryListTicketData — queryResult, outputShape: array */
        qryListTicketData: QryListTicketOutput[];
        /** state cmdCreateTicketState — actionStatus, values: idle|loading|success|error */
        cmdCreateTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state cmdCreateTicketTitle — input */
        cmdCreateTicketTitle: string;
        /** state cmdCreateTicketDescription — input */
        cmdCreateTicketDescription: string;
        /** state cmdCreateTicketStatus — input, values: open|closed */
        cmdCreateTicketStatus: string;
        /** state cmdCreateTicketOutput — commandOutput */
        cmdCreateTicketOutput: CmdCreateTicketOutput | null;
        /** state cmdCreateTicketError — actionError */
        cmdCreateTicketError: string;
        /** state cmdUpdateTicketState — actionStatus, values: idle|loading|success|error */
        cmdUpdateTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state cmdUpdateTicketTicketId — input */
        cmdUpdateTicketTicketId: string;
        /** state cmdUpdateTicketTitle — input */
        cmdUpdateTicketTitle: string;
        /** state cmdUpdateTicketDescription — input */
        cmdUpdateTicketDescription: string;
        /** state cmdUpdateTicketStatus — input, values: open|closed */
        cmdUpdateTicketStatus: string;
        /** state cmdUpdateTicketOutput — commandOutput */
        cmdUpdateTicketOutput: CmdUpdateTicketOutput | null;
        /** state cmdUpdateTicketError — actionError */
        cmdUpdateTicketError: string;
        /** state cmdDeleteTicketState — actionStatus, values: idle|loading|success|error */
        cmdDeleteTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state cmdDeleteTicketTicketId — input */
        cmdDeleteTicketTicketId: string;
        /** state cmdDeleteTicketOutput — commandOutput */
        cmdDeleteTicketOutput: CmdDeleteTicketOutput | null;
        /** state cmdDeleteTicketError — actionError */
        cmdDeleteTicketError: string;
        /** state qryGetTicketState — actionStatus, values: idle|loading|success|error */
        qryGetTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state qryGetTicketTicketId — input */
        qryGetTicketTicketId: string;
        /** state qryGetTicketData — queryResult, outputShape: object */
        qryGetTicketData: QryGetTicketOutput | null;
        /** state qryLocateTicketState — actionStatus, values: idle|loading|success|error */
        qryLocateTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state qryLocateTicketData — queryResult, outputShape: array */
        qryLocateTicketData: QryLocateTicketOutput[];
        /** state cmdDecideClosureState — actionStatus, values: idle|loading|success|error */
        cmdDecideClosureState: 'idle' | 'loading' | 'success' | 'error';
        /** state cmdDecideClosureTicketId — input */
        cmdDecideClosureTicketId: string;
        /** state cmdDecideClosureStatus — input, values: open|closed */
        cmdDecideClosureStatus: string;
        /** state cmdDecideClosureOutput — commandOutput */
        cmdDecideClosureOutput: CmdDecideClosureOutput | null;
        /** state cmdDecideClosureError — actionError */
        cmdDecideClosureError: string;
        connectedCallback(): void;
        disconnectedCallback(): void;
        /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private syncRouteParams;
        /** setter for state ui.ticketCatalogue.scenary */
        setUiScenary(value: string): void;
        /** handler for action set.uiScenary — bind UI events here */
        handleUiScenaryChange(event: Event): void;
        private applyUrlScenary;
        private syncScenaryQuery;
        private readErrorMessage;
        /** action qryListTicket (query) "Listar Chamado" — route controleChamados.ticketCatalogue.qryListTicket; inputs: search, sortBy, sortOrder; writes ui.ticketCatalogue.data.qryListTicket; status ui.ticketCatalogue.action.qryListTicket.status */
        loadQryListTicket(): Promise<void>;
        /** handler for action qryListTicket "Listar Chamado" — bind UI events here */
        handleQryListTicketClick(event?: Event): void;
        /** action cmdCreateTicket (command) "Criar Chamado" — route controleChamados.ticketCatalogue.cmdCreateTicket; inputs: title, description, status; writes ui.ticketCatalogue.output.cmdCreateTicket; status ui.ticketCatalogue.action.cmdCreateTicket.status; feedback keys action.cmdCreateTicket.success / action.cmdCreateTicket.error */
        cmdCreateTicket(): Promise<void>;
        /** handler for action cmdCreateTicket "Criar Chamado" — bind UI events here */
        handleCmdCreateTicketClick(event?: Event): void;
        /** action cmdUpdateTicket (command) "Atualizar Chamado" — route controleChamados.ticketCatalogue.cmdUpdateTicket; inputs: ticketId, title, description, status; writes ui.ticketCatalogue.output.cmdUpdateTicket; status ui.ticketCatalogue.action.cmdUpdateTicket.status; feedback keys action.cmdUpdateTicket.success / action.cmdUpdateTicket.error */
        cmdUpdateTicket(): Promise<void>;
        /** handler for action cmdUpdateTicket "Atualizar Chamado" — bind UI events here */
        handleCmdUpdateTicketClick(event?: Event): void;
        /** action cmdDeleteTicket (command) "Excluir Chamado" — route controleChamados.ticketCatalogue.cmdDeleteTicket; inputs: ticketId; writes ui.ticketCatalogue.output.cmdDeleteTicket; status ui.ticketCatalogue.action.cmdDeleteTicket.status; feedback keys action.cmdDeleteTicket.success / action.cmdDeleteTicket.error */
        cmdDeleteTicket(): Promise<void>;
        /** handler for action cmdDeleteTicket "Excluir Chamado" — bind UI events here */
        handleCmdDeleteTicketClick(event?: Event): void;
        /** action qryGetTicket (query) "Obter Chamado" — route controleChamados.ticketCatalogue.qryGetTicket; inputs: ticketId; writes ui.ticketCatalogue.data.qryGetTicket; status ui.ticketCatalogue.action.qryGetTicket.status */
        loadQryGetTicket(): Promise<void>;
        /** handler for action qryGetTicket "Obter Chamado" — bind UI events here */
        handleQryGetTicketClick(event?: Event): void;
        /** action qryLocateTicket (query) "Localizar o chamado aberto" — route controleChamados.ticketCatalogue.qryLocateTicket; inputs: (none); writes ui.ticketCatalogue.data.qryLocateTicket; status ui.ticketCatalogue.action.qryLocateTicket.status */
        loadQryLocateTicket(): Promise<void>;
        /** handler for action qryLocateTicket "Localizar o chamado aberto" — bind UI events here */
        handleQryLocateTicketClick(event?: Event): void;
        /** action cmdDecideClosure (command) "Confirmar o fechamento do chamado" — route controleChamados.ticketCatalogue.cmdDecideClosure; inputs: ticketId, status; writes ui.ticketCatalogue.output.cmdDecideClosure; status ui.ticketCatalogue.action.cmdDecideClosure.status; feedback keys action.cmdDecideClosure.success / action.cmdDecideClosure.error */
        cmdDecideClosure(): Promise<void>;
        /** handler for action cmdDecideClosure "Confirmar o fechamento do chamado" — bind UI events here */
        handleCmdDecideClosureClick(event?: Event): void;
        /** setter for state ui.ticketCatalogue.input.qryListTicket.search */
        setQryListTicketSearch(value: string): void;
        /** handler for action set.qryListTicketSearch — bind UI events here */
        handleQryListTicketSearchChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.qryListTicket.sortBy */
        setQryListTicketSortBy(value: string): void;
        /** handler for action set.qryListTicketSortBy — bind UI events here */
        handleQryListTicketSortByChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.qryListTicket.sortOrder */
        setQryListTicketSortOrder(value: string): void;
        /** handler for action set.qryListTicketSortOrder — bind UI events here */
        handleQryListTicketSortOrderChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdCreateTicket.title */
        setCmdCreateTicketTitle(value: string): void;
        /** handler for action set.cmdCreateTicketTitle — bind UI events here */
        handleCmdCreateTicketTitleChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdCreateTicket.description */
        setCmdCreateTicketDescription(value: string): void;
        /** handler for action set.cmdCreateTicketDescription — bind UI events here */
        handleCmdCreateTicketDescriptionChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdCreateTicket.status */
        setCmdCreateTicketStatus(value: string): void;
        /** handler for action set.cmdCreateTicketStatus — bind UI events here */
        handleCmdCreateTicketStatusChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.ticketId */
        setCmdUpdateTicketTicketId(value: string): void;
        /** handler for action set.cmdUpdateTicketTicketId — bind UI events here */
        handleCmdUpdateTicketTicketIdChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.title */
        setCmdUpdateTicketTitle(value: string): void;
        /** handler for action set.cmdUpdateTicketTitle — bind UI events here */
        handleCmdUpdateTicketTitleChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.description */
        setCmdUpdateTicketDescription(value: string): void;
        /** handler for action set.cmdUpdateTicketDescription — bind UI events here */
        handleCmdUpdateTicketDescriptionChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdUpdateTicket.status */
        setCmdUpdateTicketStatus(value: string): void;
        /** handler for action set.cmdUpdateTicketStatus — bind UI events here */
        handleCmdUpdateTicketStatusChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdDeleteTicket.ticketId */
        setCmdDeleteTicketTicketId(value: string): void;
        /** handler for action set.cmdDeleteTicketTicketId — bind UI events here */
        handleCmdDeleteTicketTicketIdChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.qryGetTicket.ticketId */
        setQryGetTicketTicketId(value: string): void;
        /** handler for action set.qryGetTicketTicketId — bind UI events here */
        handleQryGetTicketTicketIdChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdDecideClosure.ticketId */
        setCmdDecideClosureTicketId(value: string): void;
        /** handler for action set.cmdDecideClosureTicketId — bind UI events here */
        handleCmdDecideClosureTicketIdChange(event: Event): void;
        /** setter for state ui.ticketCatalogue.input.cmdDecideClosure.status */
        setCmdDecideClosureStatus(value: string): void;
        /** handler for action set.cmdDecideClosureStatus — bind UI events here */
        handleCmdDecideClosureStatusChange(event: Event): void;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/ticketCatalogue" {
    import { ControleChamadosTicketCatalogueBase } from "_102047_/l2/controleChamados/web/shared/ticketCatalogue";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.recordList.title': string;
        'organism.qryListTicket.title': string;
        'intent.qryListTicket.list.title': string;
        'intent.qryListTicket.list.empty': string;
        'intent.qryListTicket.list.column.ticketId.label': string;
        'intent.qryListTicket.list.column.title.label': string;
        'intent.qryListTicket.list.column.description.label': string;
        'intent.qryListTicket.list.column.status.label': string;
        'intent.qryListTicket.list.filter.search.label': string;
        'intent.qryListTicket.list.filter.sortBy.label': string;
        'intent.qryListTicket.list.filter.sortOrder.label': string;
        'organism.qryLocateTicket.title': string;
        'intent.qryLocateTicket.list.title': string;
        'intent.qryLocateTicket.list.empty': string;
        'intent.qryLocateTicket.list.column.ticketId.label': string;
        'intent.qryLocateTicket.list.column.title.label': string;
        'intent.qryLocateTicket.list.column.description.label': string;
        'intent.qryLocateTicket.list.column.status.label': string;
        'organism.cmdDeleteTicket.title': string;
        'intent.cmdDeleteTicket.form.title': string;
        'intent.cmdDeleteTicket.form.action.cmdDeleteTicket': string;
        'organism.qryGetTicket.title': string;
        'intent.qryGetTicket.list.title': string;
        'intent.qryGetTicket.list.empty': string;
        'intent.qryGetTicket.list.column.ticketId.label': string;
        'intent.qryGetTicket.list.column.title.label': string;
        'intent.qryGetTicket.list.column.description.label': string;
        'intent.qryGetTicket.list.column.status.label': string;
        'section.recordForm.title': string;
        'organism.cmdCreateTicket.title': string;
        'intent.cmdCreateTicket.form.title': string;
        'intent.cmdCreateTicket.form.action.cmdCreateTicket': string;
        'intent.cmdCreateTicket.form.field.title.label': string;
        'intent.cmdCreateTicket.form.field.description.label': string;
        'intent.cmdCreateTicket.form.field.status.label': string;
        'organism.cmdUpdateTicket.title': string;
        'intent.cmdUpdateTicket.form.title': string;
        'intent.cmdUpdateTicket.form.action.cmdUpdateTicket': string;
        'intent.cmdUpdateTicket.form.field.title.label': string;
        'intent.cmdUpdateTicket.form.field.description.label': string;
        'intent.cmdUpdateTicket.form.field.status.label': string;
        'section.decideClosure.title': string;
        'organism.cmdDecideClosure.title': string;
        'intent.cmdDecideClosure.form.title': string;
        'intent.cmdDecideClosure.form.action.cmdDecideClosure': string;
        'intent.cmdDecideClosure.form.field.status.label': string;
        'action.cmdCreateTicket.success': string;
        'action.cmdCreateTicket.error': string;
        'action.cmdUpdateTicket.success': string;
        'action.cmdUpdateTicket.error': string;
        'action.cmdDeleteTicket.success': string;
        'action.cmdDeleteTicket.error': string;
        'action.cmdDecideClosure.success': string;
        'action.cmdDecideClosure.error': string;
        'scenary.base': string;
        'scenary.detail': string;
        'scenary.createTicket': string;
        'scenary.updateTicket': string;
        'scenary.decideClosure': string;
        'scenary.back': string;
        'page.title': string;
        'common.loading': string;
        'common.refresh': string;
        'common.create': string;
        'common.edit': string;
        'common.close': string;
        'common.delete': string;
        'common.cancel': string;
        'common.select': string;
        'common.selected': string;
        'common.chooseStatus': string;
        'filter.all': string;
        'filter.open': string;
        'filter.closed': string;
        'status.open': string;
        'status.closed': string;
        'feedback.noSelection': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage11TicketCataloguePage extends ControleChamadosTicketCatalogueBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        render(): any;
        renderScenaryBase(): any;
        renderScenaryDetail(): any;
        renderScenaryCreateTicket(): any;
        renderScenaryUpdateTicket(): any;
        renderScenaryDecideClosure(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/ticketCommentCatalogue.defs" {
    export const definition = "page: Coment\u00E1rio do chamado\nactor: atendente\npurpose: Cadastro de Coment\u00E1rio do chamado.\nuxExperience: entityRecordManagement\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketCommentCatalogue__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page11/ticketCommentCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page11/ticketCommentCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketCommentCatalogueDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketCommentCatalogue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { QryListTicketCommentOutput, CmdCreateTicketCommentOutput, CmdUpdateTicketCommentOutput, CmdDeleteTicketCommentOutput, QryGetTicketCommentOutput, QryTicketPickerOutput } from "_102047_/l2/controleChamados/web/contracts/ticketCommentCatalogue";
    export type { QryListTicketCommentInput, QryListTicketCommentOutput, CmdCreateTicketCommentInput, CmdCreateTicketCommentOutput, CmdUpdateTicketCommentInput, CmdUpdateTicketCommentOutput, CmdDeleteTicketCommentInput, CmdDeleteTicketCommentOutput, QryGetTicketCommentInput, QryGetTicketCommentOutput, QryTicketPickerInput, QryTicketPickerOutput } from "_102047_/l2/controleChamados/web/contracts/ticketCommentCatalogue";
    type ActionStatus = 'idle' | 'loading' | 'success' | 'error';
    type Scenary = 'base' | 'detail' | 'createTicketComment' | 'updateTicketComment';
    export class ControleChamadosTicketCommentCatalogueBase extends CollabLitElement {
        /** state status — pageStatus */ status: string;
        /** state ui.ticketCommentCatalogue.scenary — uiScenary, values: base|detail|createTicketComment|updateTicketComment */ uiScenary: Scenary;
        /** state qryListTicketCommentState — actionStatus, values: idle|loading|success|error */ qryListTicketCommentState: ActionStatus;
        /** state qryListTicketCommentData — queryResult, outputShape: array */ qryListTicketCommentData: QryListTicketCommentOutput[];
        /** state cmdCreateTicketCommentState — actionStatus, values: idle|loading|success|error */ cmdCreateTicketCommentState: ActionStatus;
        /** state cmdCreateTicketCommentTicketId — input */ cmdCreateTicketCommentTicketId: string;
        /** state cmdCreateTicketCommentCommentText — input */ cmdCreateTicketCommentCommentText: string;
        /** state cmdCreateTicketCommentOutput — commandOutput */ cmdCreateTicketCommentOutput: CmdCreateTicketCommentOutput | null;
        /** state cmdCreateTicketCommentError — actionError */ cmdCreateTicketCommentError: string;
        /** state cmdUpdateTicketCommentState — actionStatus, values: idle|loading|success|error */ cmdUpdateTicketCommentState: ActionStatus;
        /** state cmdUpdateTicketCommentTicketCommentId — input */ cmdUpdateTicketCommentTicketCommentId: string;
        /** state cmdUpdateTicketCommentTicketId — input */ cmdUpdateTicketCommentTicketId: string;
        /** state cmdUpdateTicketCommentCommentText — input */ cmdUpdateTicketCommentCommentText: string;
        /** state cmdUpdateTicketCommentOutput — commandOutput */ cmdUpdateTicketCommentOutput: CmdUpdateTicketCommentOutput | null;
        /** state cmdUpdateTicketCommentError — actionError */ cmdUpdateTicketCommentError: string;
        /** state cmdDeleteTicketCommentState — actionStatus, values: idle|loading|success|error */ cmdDeleteTicketCommentState: ActionStatus;
        /** state cmdDeleteTicketCommentTicketCommentId — input */ cmdDeleteTicketCommentTicketCommentId: string;
        /** state cmdDeleteTicketCommentOutput — commandOutput */ cmdDeleteTicketCommentOutput: CmdDeleteTicketCommentOutput | null;
        /** state cmdDeleteTicketCommentError — actionError */ cmdDeleteTicketCommentError: string;
        /** state qryGetTicketCommentState — actionStatus, values: idle|loading|success|error */ qryGetTicketCommentState: ActionStatus;
        /** state qryGetTicketCommentTicketCommentId — input */ qryGetTicketCommentTicketCommentId: string;
        /** state qryGetTicketCommentData — queryResult, outputShape: object */ qryGetTicketCommentData: QryGetTicketCommentOutput | null;
        /** state qryTicketPickerState — actionStatus, values: idle|loading|success|error */ qryTicketPickerState: ActionStatus;
        /** state qryTicketPickerSearch — input */ qryTicketPickerSearch: string;
        /** state qryTicketPickerSortBy — input, values: open|closed */ qryTicketPickerSortBy: string;
        /** state qryTicketPickerSortOrder — input, values: asc|desc */ qryTicketPickerSortOrder: string;
        /** state qryTicketPickerData — queryResult, outputShape: array */ qryTicketPickerData: QryTicketPickerOutput[];
        connectedCallback(): void;
        disconnectedCallback(): void;
        /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        private assignState;
        /** setter for state ui.ticketCommentCatalogue.scenary */
        setUiScenary(value: string): void;
        /** handler for action set.uiScenary — bind UI events here */
        handleUiScenaryChange(event: Event): void;
        private applyUrlScenary;
        private syncScenaryQuery;
        private readErrorMessage;
        private setStatus;
        private refresh;
        /** action qryListTicketComment (query) — route controleChamados.ticketCommentCatalogue.qryListTicketComment; inputs none; writes ui.ticketCommentCatalogue.data.qryListTicketComment; status ui.ticketCommentCatalogue.action.qryListTicketComment.status */
        loadQryListTicketComment(): Promise<void>;
        /** handler for action qryListTicketComment — bind UI events here */
        handleQryListTicketCommentClick(event?: Event): void;
        /** action cmdCreateTicketComment (command) — route controleChamados.ticketCommentCatalogue.cmdCreateTicketComment; inputs ticketId, commentText; writes ui.ticketCommentCatalogue.output.cmdCreateTicketComment; status ui.ticketCommentCatalogue.action.cmdCreateTicketComment.status; feedback keys action.cmdCreateTicketComment.success / action.cmdCreateTicketComment.error */
        cmdCreateTicketComment(): Promise<void>;
        /** handler for action cmdCreateTicketComment — bind UI events here */
        handleCmdCreateTicketCommentClick(event?: Event): void;
        /** action cmdUpdateTicketComment (command) — route controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment; inputs ticketCommentId, ticketId, commentText; writes ui.ticketCommentCatalogue.output.cmdUpdateTicketComment; status ui.ticketCommentCatalogue.action.cmdUpdateTicketComment.status; feedback keys action.cmdUpdateTicketComment.success / action.cmdUpdateTicketComment.error */
        cmdUpdateTicketComment(): Promise<void>;
        /** handler for action cmdUpdateTicketComment — bind UI events here */
        handleCmdUpdateTicketCommentClick(event?: Event): void;
        /** action cmdDeleteTicketComment (command) — route controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment; inputs ticketCommentId; writes ui.ticketCommentCatalogue.output.cmdDeleteTicketComment; status ui.ticketCommentCatalogue.action.cmdDeleteTicketComment.status; feedback keys action.cmdDeleteTicketComment.success / action.cmdDeleteTicketComment.error */
        cmdDeleteTicketComment(): Promise<void>;
        /** handler for action cmdDeleteTicketComment — bind UI events here */
        handleCmdDeleteTicketCommentClick(event?: Event): void;
        /** action qryGetTicketComment (query) — route controleChamados.ticketCommentCatalogue.qryGetTicketComment; inputs ticketCommentId; writes ui.ticketCommentCatalogue.data.qryGetTicketComment; status ui.ticketCommentCatalogue.action.qryGetTicketComment.status */
        loadQryGetTicketComment(): Promise<void>;
        /** handler for action qryGetTicketComment — bind UI events here */
        handleQryGetTicketCommentClick(event?: Event): void;
        /** action qryTicketPicker (query) — route controleChamados.ticketCommentCatalogue.qryTicketPicker; inputs search, sortBy, sortOrder; writes ui.ticketCommentCatalogue.data.qryTicketPicker; status ui.ticketCommentCatalogue.action.qryTicketPicker.status */
        loadQryTicketPicker(): Promise<void>;
        /** handler for action qryTicketPicker — bind UI events here */
        handleQryTicketPickerClick(event?: Event): void;
        private inputValue;
        /** setter for state ui.ticketCommentCatalogue.input.cmdCreateTicketComment.ticketId */
        setCmdCreateTicketCommentTicketId(value: string): void;
        /** handler for action set.cmdCreateTicketCommentTicketId — bind UI events here */ handleCmdCreateTicketCommentTicketIdChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.cmdCreateTicketComment.commentText */
        setCmdCreateTicketCommentCommentText(value: string): void;
        /** handler for action set.cmdCreateTicketCommentCommentText — bind UI events here */ handleCmdCreateTicketCommentCommentTextChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketCommentId */
        setCmdUpdateTicketCommentTicketCommentId(value: string): void;
        /** handler for action set.cmdUpdateTicketCommentTicketCommentId — bind UI events here */ handleCmdUpdateTicketCommentTicketCommentIdChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.ticketId */
        setCmdUpdateTicketCommentTicketId(value: string): void;
        /** handler for action set.cmdUpdateTicketCommentTicketId — bind UI events here */ handleCmdUpdateTicketCommentTicketIdChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.cmdUpdateTicketComment.commentText */
        setCmdUpdateTicketCommentCommentText(value: string): void;
        /** handler for action set.cmdUpdateTicketCommentCommentText — bind UI events here */ handleCmdUpdateTicketCommentCommentTextChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.cmdDeleteTicketComment.ticketCommentId */
        setCmdDeleteTicketCommentTicketCommentId(value: string): void;
        /** handler for action set.cmdDeleteTicketCommentTicketCommentId — bind UI events here */ handleCmdDeleteTicketCommentTicketCommentIdChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.qryGetTicketComment.ticketCommentId */
        setQryGetTicketCommentTicketCommentId(value: string): void;
        /** handler for action set.qryGetTicketCommentTicketCommentId — bind UI events here */ handleQryGetTicketCommentTicketCommentIdChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.qryTicketPicker.search */
        setQryTicketPickerSearch(value: string): void;
        /** handler for action set.qryTicketPickerSearch — bind UI events here */ handleQryTicketPickerSearchChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.qryTicketPicker.sortBy */
        setQryTicketPickerSortBy(value: string): void;
        /** handler for action set.qryTicketPickerSortBy — bind UI events here */ handleQryTicketPickerSortByChange(event: Event): void;
        /** setter for state ui.ticketCommentCatalogue.input.qryTicketPicker.sortOrder */
        setQryTicketPickerSortOrder(value: string): void;
        /** handler for action set.qryTicketPickerSortOrder — bind UI events here */ handleQryTicketPickerSortOrderChange(event: Event): void;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/ticketCommentCatalogue" {
    import { ControleChamadosTicketCommentCatalogueBase } from "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.recordList.title': string;
        'organism.qryListTicketComment.title': string;
        'intent.qryListTicketComment.list.title': string;
        'intent.qryListTicketComment.list.empty': string;
        'intent.qryListTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryListTicketComment.list.column.ticketId.label': string;
        'intent.qryListTicketComment.list.column.commentText.label': string;
        'organism.qryGetTicketComment.title': string;
        'intent.qryGetTicketComment.list.title': string;
        'intent.qryGetTicketComment.list.empty': string;
        'intent.qryGetTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryGetTicketComment.list.column.ticketId.label': string;
        'intent.qryGetTicketComment.list.column.commentText.label': string;
        'organism.cmdDeleteTicketComment.title': string;
        'intent.cmdDeleteTicketComment.form.title': string;
        'intent.cmdDeleteTicketComment.form.action.cmdDeleteTicketComment': string;
        'section.recordForm.title': string;
        'organism.cmdCreateTicketComment.title': string;
        'intent.cmdCreateTicketComment.form.title': string;
        'intent.cmdCreateTicketComment.form.action.cmdCreateTicketComment': string;
        'intent.cmdCreateTicketComment.form.field.commentText.label': string;
        'organism.cmdUpdateTicketComment.title': string;
        'intent.cmdUpdateTicketComment.form.title': string;
        'intent.cmdUpdateTicketComment.form.action.cmdUpdateTicketComment': string;
        'intent.cmdUpdateTicketComment.form.field.commentText.label': string;
        'organism.qryTicketPicker.title': string;
        'intent.qryTicketPicker.list.title': string;
        'intent.qryTicketPicker.list.empty': string;
        'intent.qryTicketPicker.list.column.ticketId.label': string;
        'intent.qryTicketPicker.list.column.title.label': string;
        'intent.qryTicketPicker.list.column.description.label': string;
        'intent.qryTicketPicker.list.column.status.label': string;
        'intent.qryTicketPicker.list.filter.search.label': string;
        'intent.qryTicketPicker.list.filter.sortBy.label': string;
        'intent.qryTicketPicker.list.filter.sortOrder.label': string;
        'action.cmdCreateTicketComment.success': string;
        'action.cmdCreateTicketComment.error': string;
        'action.cmdUpdateTicketComment.success': string;
        'action.cmdUpdateTicketComment.error': string;
        'action.cmdDeleteTicketComment.success': string;
        'action.cmdDeleteTicketComment.error': string;
        'section.commentWorkspace.title': string;
        'section.commentCreation.title': string;
        'scenary.base': string;
        'scenary.detail': string;
        'scenary.createTicketComment': string;
        'scenary.updateTicketComment': string;
        'scenary.back': string;
        'action.delete.confirm': string;
        'form.ticket.choose': string;
        'form.comment.placeholder': string;
        'form.cancel': string;
        'query.refresh': string;
        'query.loading': string;
        'query.select': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage11TicketCommentCataloguePage extends ControleChamadosTicketCommentCatalogueBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        render(): any;
        renderScenaryBase(): any;
        renderScenaryDetail(): any;
        renderScenaryCreateTicketComment(): any;
        renderScenaryUpdateTicketComment(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/ticketHub.defs" {
    export const definition = "page: Chamado\nactor: atendente\npurpose: Painel de Chamado.\nuxExperience: dashboardCommandCenter\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketHub__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page11/ticketHub.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page11/ticketHub.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketHubDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketHub__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/shared/ticketHub" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import type { QryListTicketOutput, QryListTicketCommentOutput } from "_102047_/l2/controleChamados/web/contracts/ticketHub";
    export type { QryListTicketInput, QryListTicketOutput, QryListTicketCommentInput, QryListTicketCommentOutput, } from "_102047_/l2/controleChamados/web/contracts/ticketHub";
    export class ControleChamadosTicketHubBase extends CollabLitElement {
        /** state status — pageStatus */
        status: string;
        /** state ui.ticketHub.scenary — uiScenary, values: base */
        uiScenary: 'base';
        /** state qryListTicketState — actionStatus, values: idle|loading|success|error */
        qryListTicketState: 'idle' | 'loading' | 'success' | 'error';
        /** state qryListTicketSearch — input */
        qryListTicketSearch: string;
        /** state qryListTicketSortBy — input, values: open|closed */
        qryListTicketSortBy: string;
        /** state qryListTicketSortOrder — input, values: asc|desc */
        qryListTicketSortOrder: string;
        /** state qryListTicketData — queryResult, outputShape: array */
        qryListTicketData: QryListTicketOutput[];
        /** state qryListTicketCommentState — actionStatus, values: idle|loading|success|error */
        qryListTicketCommentState: 'idle' | 'loading' | 'success' | 'error';
        /** state qryListTicketCommentData — queryResult, outputShape: array */
        qryListTicketCommentData: QryListTicketCommentOutput[];
        /** lifecycle — initialize shared state, subscriptions and initial query loads */
        connectedCallback(): void;
        /** lifecycle — remove shared-state subscriptions */
        disconnectedCallback(): void;
        /** handleIcaStateChange — collabState notify contract; maps state keys onto class fields */
        handleIcaStateChange(key: string, value: unknown): void;
        private initStateValue;
        /** setter for state ui.ticketHub.scenary */
        setUiScenary(value: string): void;
        /** handler for action set.uiScenary — bind UI events here */
        handleUiScenaryChange(event: Event): void;
        private applyUrlScenary;
        private syncScenaryQuery;
        /** action qryListTicket (query) — route controleChamados.ticketHub.qryListTicket; inputs: search, sortBy, sortOrder; writes ui.ticketHub.data.qryListTicket; status ui.ticketHub.action.qryListTicket.status */
        loadQryListTicket(): Promise<void>;
        /** handler for action qryListTicket — bind UI events here */
        handleQryListTicketClick(event?: Event): void;
        /** action qryListTicketComment (query) — route controleChamados.ticketHub.qryListTicketComment; inputs: none; writes ui.ticketHub.data.qryListTicketComment; status ui.ticketHub.action.qryListTicketComment.status */
        loadQryListTicketComment(): Promise<void>;
        /** handler for action qryListTicketComment — bind UI events here */
        handleQryListTicketCommentClick(event?: Event): void;
        /** setter for state ui.ticketHub.input.qryListTicket.search */
        setQryListTicketSearch(value: string): void;
        /** handler for action set.qryListTicketSearch — bind UI events here */
        handleQryListTicketSearchChange(event: Event): void;
        /** setter for state ui.ticketHub.input.qryListTicket.sortBy */
        setQryListTicketSortBy(value: string): void;
        /** handler for action set.qryListTicketSortBy — bind UI events here */
        handleQryListTicketSortByChange(event: Event): void;
        /** setter for state ui.ticketHub.input.qryListTicket.sortOrder */
        setQryListTicketSortOrder(value: string): void;
        /** handler for action set.qryListTicketSortOrder — bind UI events here */
        handleQryListTicketSortOrderChange(event: Event): void;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page11/ticketHub" {
    import { ControleChamadosTicketHubBase } from "_102047_/l2/controleChamados/web/shared/ticketHub";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.collection.title': string;
        'organism.qryListTicket.title': string;
        'intent.qryListTicket.list.title': string;
        'intent.qryListTicket.list.empty': string;
        'intent.qryListTicket.list.column.ticketId.label': string;
        'intent.qryListTicket.list.column.title.label': string;
        'intent.qryListTicket.list.column.description.label': string;
        'intent.qryListTicket.list.column.status.label': string;
        'intent.qryListTicket.list.filter.search.label': string;
        'intent.qryListTicket.list.filter.sortBy.label': string;
        'intent.qryListTicket.list.filter.sortOrder.label': string;
        'section.record.title': string;
        'organism.qryListTicketComment.title': string;
        'intent.qryListTicketComment.list.title': string;
        'intent.qryListTicketComment.list.empty': string;
        'intent.qryListTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryListTicketComment.list.column.ticketId.label': string;
        'intent.qryListTicketComment.list.column.commentText.label': string;
        'section.ticket-workspace.title': string;
        'section.ticket-context.title': string;
        'scenary.base': string;
        'page.search.placeholder': string;
        'page.filter.all': string;
        'page.sortBy.open': string;
        'page.sortBy.closed': string;
        'page.sortOrder.asc': string;
        'page.sortOrder.desc': string;
        'page.refresh': string;
        'page.refreshComments': string;
        'page.loading': string;
        'page.error': string;
        'page.comments.empty': string;
        'page.comment.ticket': string;
        'page.status.open': string;
        'page.status.closed': string;
        'page.status.pending': string;
        'page.status.inProgress': string;
        'page.status.completed': string;
        'page.status.cancelled': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage11TicketHubPage extends ControleChamadosTicketHubBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/commentOpenTicket.defs" {
    export const definition = "page: Registrar coment\u00E1rio em chamado aberto\nactor: atendente\npurpose: Documentar o andamento do atendimento em um chamado aberto.\nuxExperience: processWizard\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "commentOpenTicket__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page21/commentOpenTicket.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page21/commentOpenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/commentOpenTicketDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["commentOpenTicket__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/processWizard/page21.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/commentOpenTicket" {
    import { ControleChamadosCommentOpenTicketBase } from "_102047_/l2/controleChamados/web/shared/commentOpenTicket";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.locateTicket.title': string;
        'organism.qryLocateTicket.title': string;
        'intent.qryLocateTicket.list.title': string;
        'intent.qryLocateTicket.list.empty': string;
        'intent.qryLocateTicket.list.column.ticketId.label': string;
        'intent.qryLocateTicket.list.column.title.label': string;
        'intent.qryLocateTicket.list.column.description.label': string;
        'intent.qryLocateTicket.list.column.status.label': string;
        'section.recordComment.title': string;
        'organism.cmdRecordComment.title': string;
        'intent.cmdRecordComment.form.title': string;
        'intent.cmdRecordComment.form.action.cmdRecordComment': string;
        'intent.cmdRecordComment.form.field.commentText.label': string;
        'action.cmdRecordComment.success': string;
        'action.cmdRecordComment.error': string;
        'section.ticket-context.title': string;
        'section.comment-action.title': string;
        'scenary.base': string;
        'scenary.recordComment': string;
        'journey.step.locate': string;
        'journey.step.comment': string;
        'journey.selected': string;
        'journey.continue': string;
        'journey.back': string;
        'journey.required': string;
        'journey.loading': string;
        'journey.retry': string;
        'journey.running': string;
        'journey.ticketMissing': string;
        'journey.commentHint': string;
        'journey.change': string;
        'journey.completed': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage21CommentOpenTicketPage extends ControleChamadosCommentOpenTicketBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
        renderScenaryRecordComment(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/ticketCatalogue.defs" {
    export const definition = "page: Chamado\nactor: atendente\npurpose: Cadastro de Chamado.\nuxExperience: entityRecordManagement\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketCatalogue__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page21/ticketCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page21/ticketCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketCatalogueDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketCatalogue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/entityRecordManagement/page21.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/ticketCatalogue" {
    import { ControleChamadosTicketCatalogueBase } from "_102047_/l2/controleChamados/web/shared/ticketCatalogue";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.recordList.title': string;
        'organism.qryListTicket.title': string;
        'intent.qryListTicket.list.title': string;
        'intent.qryListTicket.list.empty': string;
        'intent.qryListTicket.list.column.ticketId.label': string;
        'intent.qryListTicket.list.column.title.label': string;
        'intent.qryListTicket.list.column.description.label': string;
        'intent.qryListTicket.list.column.status.label': string;
        'intent.qryListTicket.list.filter.search.label': string;
        'intent.qryListTicket.list.filter.sortBy.label': string;
        'intent.qryListTicket.list.filter.sortOrder.label': string;
        'organism.qryLocateTicket.title': string;
        'intent.qryLocateTicket.list.title': string;
        'intent.qryLocateTicket.list.empty': string;
        'intent.qryLocateTicket.list.column.ticketId.label': string;
        'intent.qryLocateTicket.list.column.title.label': string;
        'intent.qryLocateTicket.list.column.description.label': string;
        'intent.qryLocateTicket.list.column.status.label': string;
        'organism.cmdDeleteTicket.title': string;
        'intent.cmdDeleteTicket.form.title': string;
        'intent.cmdDeleteTicket.form.action.cmdDeleteTicket': string;
        'organism.qryGetTicket.title': string;
        'intent.qryGetTicket.list.title': string;
        'intent.qryGetTicket.list.empty': string;
        'intent.qryGetTicket.list.column.ticketId.label': string;
        'intent.qryGetTicket.list.column.title.label': string;
        'intent.qryGetTicket.list.column.description.label': string;
        'intent.qryGetTicket.list.column.status.label': string;
        'section.recordForm.title': string;
        'organism.cmdCreateTicket.title': string;
        'intent.cmdCreateTicket.form.title': string;
        'intent.cmdCreateTicket.form.action.cmdCreateTicket': string;
        'intent.cmdCreateTicket.form.field.title.label': string;
        'intent.cmdCreateTicket.form.field.description.label': string;
        'intent.cmdCreateTicket.form.field.status.label': string;
        'organism.cmdUpdateTicket.title': string;
        'intent.cmdUpdateTicket.form.title': string;
        'intent.cmdUpdateTicket.form.action.cmdUpdateTicket': string;
        'intent.cmdUpdateTicket.form.field.title.label': string;
        'intent.cmdUpdateTicket.form.field.description.label': string;
        'intent.cmdUpdateTicket.form.field.status.label': string;
        'section.decideClosure.title': string;
        'organism.cmdDecideClosure.title': string;
        'intent.cmdDecideClosure.form.title': string;
        'intent.cmdDecideClosure.form.action.cmdDecideClosure': string;
        'intent.cmdDecideClosure.form.field.status.label': string;
        'action.cmdCreateTicket.success': string;
        'action.cmdCreateTicket.error': string;
        'action.cmdUpdateTicket.success': string;
        'action.cmdUpdateTicket.error': string;
        'action.cmdDeleteTicket.success': string;
        'action.cmdDeleteTicket.error': string;
        'action.cmdDecideClosure.success': string;
        'action.cmdDecideClosure.error': string;
        'scenary.base': string;
        'scenary.detail': string;
        'scenary.createTicket': string;
        'scenary.updateTicket': string;
        'scenary.decideClosure': string;
        'scenary.back': string;
        'form.newRecord': string;
        'form.currentRecord': string;
        'form.required': string;
        'form.open': string;
        'form.closed': string;
        'form.chooseStatus': string;
        'form.create': string;
        'form.save': string;
        'form.close': string;
        'form.reopen': string;
        'form.delete': string;
        'form.deleteConfirm': string;
        'form.loading': string;
        'form.saving': string;
        'form.closing': string;
        'form.noRecord': string;
        'form.selectRecord': string;
        'form.createGroup': string;
        'form.updateGroup': string;
        'form.descriptionHelp': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage21TicketCataloguePage extends ControleChamadosTicketCatalogueBase {
        #private;
        protected get msg(): PageMessageType;
        render(): any;
        renderScenaryBase(): any;
        renderScenaryDetail(): any;
        renderScenaryCreateTicket(): any;
        renderScenaryUpdateTicket(): any;
        renderScenaryDecideClosure(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/ticketCommentCatalogue.defs" {
    export const definition = "page: Coment\u00E1rio do chamado\nactor: atendente\npurpose: Cadastro de Coment\u00E1rio do chamado.\nuxExperience: entityRecordManagement\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketCommentCatalogue__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page21/ticketCommentCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page21/ticketCommentCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketCommentCatalogueDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketCommentCatalogue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/entityRecordManagement/page21.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/ticketCommentCatalogue" {
    import { ControleChamadosTicketCommentCatalogueBase } from "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.recordList.title': string;
        'organism.qryListTicketComment.title': string;
        'intent.qryListTicketComment.list.title': string;
        'intent.qryListTicketComment.list.empty': string;
        'intent.qryListTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryListTicketComment.list.column.ticketId.label': string;
        'intent.qryListTicketComment.list.column.commentText.label': string;
        'organism.qryGetTicketComment.title': string;
        'intent.qryGetTicketComment.list.title': string;
        'intent.qryGetTicketComment.list.empty': string;
        'intent.qryGetTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryGetTicketComment.list.column.ticketId.label': string;
        'intent.qryGetTicketComment.list.column.commentText.label': string;
        'organism.cmdDeleteTicketComment.title': string;
        'intent.cmdDeleteTicketComment.form.title': string;
        'intent.cmdDeleteTicketComment.form.action.cmdDeleteTicketComment': string;
        'section.recordForm.title': string;
        'organism.cmdCreateTicketComment.title': string;
        'intent.cmdCreateTicketComment.form.title': string;
        'intent.cmdCreateTicketComment.form.action.cmdCreateTicketComment': string;
        'intent.cmdCreateTicketComment.form.field.commentText.label': string;
        'organism.cmdUpdateTicketComment.title': string;
        'intent.cmdUpdateTicketComment.form.title': string;
        'intent.cmdUpdateTicketComment.form.action.cmdUpdateTicketComment': string;
        'intent.cmdUpdateTicketComment.form.field.commentText.label': string;
        'organism.qryTicketPicker.title': string;
        'intent.qryTicketPicker.list.title': string;
        'intent.qryTicketPicker.list.empty': string;
        'intent.qryTicketPicker.list.column.ticketId.label': string;
        'intent.qryTicketPicker.list.column.title.label': string;
        'intent.qryTicketPicker.list.column.description.label': string;
        'intent.qryTicketPicker.list.column.status.label': string;
        'intent.qryTicketPicker.list.filter.search.label': string;
        'intent.qryTicketPicker.list.filter.sortBy.label': string;
        'intent.qryTicketPicker.list.filter.sortOrder.label': string;
        'action.cmdCreateTicketComment.success': string;
        'action.cmdCreateTicketComment.error': string;
        'action.cmdUpdateTicketComment.success': string;
        'action.cmdUpdateTicketComment.error': string;
        'action.cmdDeleteTicketComment.success': string;
        'action.cmdDeleteTicketComment.error': string;
        'section.commentWorkspace.title': string;
        'section.commentCreation.title': string;
        'scenary.base': string;
        'scenary.detail': string;
        'scenary.createTicketComment': string;
        'scenary.updateTicketComment': string;
        'scenary.back': string;
        'comment.new': string;
        'comment.saved': string;
        'comment.edit': string;
        'comment.ticket': string;
        'comment.chooseTicket': string;
        'comment.required': string;
        'comment.save': string;
        'comment.update': string;
        'comment.cancel': string;
        'comment.loading': string;
        'comment.noRecord': string;
        'comment.delete': string;
        'comment.deleteConfirm': string;
        'comment.selectExisting': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage21TicketCommentCataloguePage extends ControleChamadosTicketCommentCatalogueBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
        renderScenaryDetail(): any;
        renderScenaryCreateTicketComment(): any;
        renderScenaryUpdateTicketComment(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/ticketHub.defs" {
    export const definition = "page: Chamado\nactor: atendente\npurpose: Painel de Chamado.\nuxExperience: dashboardCommandCenter\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketHub__page21__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page21/ticketHub.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page21/ticketHub.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketHubDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketHub__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/dashboardCommandCenter/page21.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page21/ticketHub" {
    import { ControleChamadosTicketHubBase } from "_102047_/l2/controleChamados/web/shared/ticketHub";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.collection.title': string;
        'organism.qryListTicket.title': string;
        'intent.qryListTicket.list.title': string;
        'intent.qryListTicket.list.empty': string;
        'intent.qryListTicket.list.column.ticketId.label': string;
        'intent.qryListTicket.list.column.title.label': string;
        'intent.qryListTicket.list.column.description.label': string;
        'intent.qryListTicket.list.column.status.label': string;
        'intent.qryListTicket.list.filter.search.label': string;
        'intent.qryListTicket.list.filter.sortBy.label': string;
        'intent.qryListTicket.list.filter.sortOrder.label': string;
        'section.record.title': string;
        'organism.qryListTicketComment.title': string;
        'intent.qryListTicketComment.list.title': string;
        'intent.qryListTicketComment.list.empty': string;
        'intent.qryListTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryListTicketComment.list.column.ticketId.label': string;
        'intent.qryListTicketComment.list.column.commentText.label': string;
        'section.ticket-workspace.title': string;
        'section.ticket-context.title': string;
        'scenary.base': string;
        'triage.headline': string;
        'triage.lane': string;
        'triage.clear': string;
        'triage.health': string;
        'triage.total': string;
        'triage.comments': string;
        'triage.loading': string;
        'triage.error': string;
        'triage.retry': string;
        'ticket.status.open': string;
        'ticket.status.closed': string;
        'ticket.status.unknown': string;
        'ticket.untitled': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage21TicketHubPage extends ControleChamadosTicketHubBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/commentOpenTicket.defs" {
    export const definition = "page: Registrar coment\u00E1rio em chamado aberto\nactor: atendente\npurpose: Documentar o andamento do atendimento em um chamado aberto.\nuxExperience: processWizard\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "commentOpenTicket__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page31/commentOpenTicket.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page31/commentOpenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/commentOpenTicketDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["commentOpenTicket__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/processWizard/page31.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/commentOpenTicket" {
    import { ControleChamadosCommentOpenTicketBase } from "_102047_/l2/controleChamados/web/shared/commentOpenTicket";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.locateTicket.title': string;
        'organism.qryLocateTicket.title': string;
        'intent.qryLocateTicket.list.title': string;
        'intent.qryLocateTicket.list.empty': string;
        'intent.qryLocateTicket.list.column.ticketId.label': string;
        'intent.qryLocateTicket.list.column.title.label': string;
        'intent.qryLocateTicket.list.column.description.label': string;
        'intent.qryLocateTicket.list.column.status.label': string;
        'section.recordComment.title': string;
        'organism.cmdRecordComment.title': string;
        'intent.cmdRecordComment.form.title': string;
        'intent.cmdRecordComment.form.action.cmdRecordComment': string;
        'intent.cmdRecordComment.form.field.commentText.label': string;
        'action.cmdRecordComment.success': string;
        'action.cmdRecordComment.error': string;
        'section.ticket-context.title': string;
        'section.comment-action.title': string;
        'scenary.base': string;
        'scenary.recordComment': string;
        'query.loading': string;
        'query.error': string;
        'comment.opening': string;
        'comment.choose': string;
        'comment.context': string;
        'comment.required': string;
        'comment.continue': string;
        'comment.back': string;
        'comment.saving': string;
        'comment.discard': string;
        'comment.success.detail': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage31CommentOpenTicketPage extends ControleChamadosCommentOpenTicketBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
        renderScenaryRecordComment(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/ticketCatalogue.defs" {
    export const definition = "page: Chamado\nactor: atendente\npurpose: Cadastro de Chamado.\nuxExperience: entityRecordManagement\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketCatalogue__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page31/ticketCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page31/ticketCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketCatalogueDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketCatalogue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/entityRecordManagement/page31.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/ticketCatalogue" {
    import { ControleChamadosTicketCatalogueBase } from "_102047_/l2/controleChamados/web/shared/ticketCatalogue";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.recordList.title': string;
        'organism.qryListTicket.title': string;
        'intent.qryListTicket.list.title': string;
        'intent.qryListTicket.list.empty': string;
        'intent.qryListTicket.list.column.ticketId.label': string;
        'intent.qryListTicket.list.column.title.label': string;
        'intent.qryListTicket.list.column.description.label': string;
        'intent.qryListTicket.list.column.status.label': string;
        'intent.qryListTicket.list.filter.search.label': string;
        'intent.qryListTicket.list.filter.sortBy.label': string;
        'intent.qryListTicket.list.filter.sortOrder.label': string;
        'organism.qryLocateTicket.title': string;
        'intent.qryLocateTicket.list.title': string;
        'intent.qryLocateTicket.list.empty': string;
        'intent.qryLocateTicket.list.column.ticketId.label': string;
        'intent.qryLocateTicket.list.column.title.label': string;
        'intent.qryLocateTicket.list.column.description.label': string;
        'intent.qryLocateTicket.list.column.status.label': string;
        'organism.cmdDeleteTicket.title': string;
        'intent.cmdDeleteTicket.form.title': string;
        'intent.cmdDeleteTicket.form.action.cmdDeleteTicket': string;
        'organism.qryGetTicket.title': string;
        'intent.qryGetTicket.list.title': string;
        'intent.qryGetTicket.list.empty': string;
        'intent.qryGetTicket.list.column.ticketId.label': string;
        'intent.qryGetTicket.list.column.title.label': string;
        'intent.qryGetTicket.list.column.description.label': string;
        'intent.qryGetTicket.list.column.status.label': string;
        'section.recordForm.title': string;
        'organism.cmdCreateTicket.title': string;
        'intent.cmdCreateTicket.form.title': string;
        'intent.cmdCreateTicket.form.action.cmdCreateTicket': string;
        'intent.cmdCreateTicket.form.field.title.label': string;
        'intent.cmdCreateTicket.form.field.description.label': string;
        'intent.cmdCreateTicket.form.field.status.label': string;
        'organism.cmdUpdateTicket.title': string;
        'intent.cmdUpdateTicket.form.title': string;
        'intent.cmdUpdateTicket.form.action.cmdUpdateTicket': string;
        'intent.cmdUpdateTicket.form.field.title.label': string;
        'intent.cmdUpdateTicket.form.field.description.label': string;
        'intent.cmdUpdateTicket.form.field.status.label': string;
        'section.decideClosure.title': string;
        'organism.cmdDecideClosure.title': string;
        'intent.cmdDecideClosure.form.title': string;
        'intent.cmdDecideClosure.form.action.cmdDecideClosure': string;
        'intent.cmdDecideClosure.form.field.status.label': string;
        'action.cmdCreateTicket.success': string;
        'action.cmdCreateTicket.error': string;
        'action.cmdUpdateTicket.success': string;
        'action.cmdUpdateTicket.error': string;
        'action.cmdDeleteTicket.success': string;
        'action.cmdDeleteTicket.error': string;
        'action.cmdDecideClosure.success': string;
        'action.cmdDecideClosure.error': string;
        'scenary.base': string;
        'scenary.detail': string;
        'scenary.createTicket': string;
        'scenary.updateTicket': string;
        'scenary.decideClosure': string;
        'scenary.back': string;
        'status.open': string;
        'status.closed': string;
        'form.required': string;
        'action.cancel': string;
        'action.open': string;
        'action.edit': string;
        'action.close': string;
        'action.delete': string;
        'feedback.loading': string;
        'feedback.select': string;
        'feedback.queryLoading': string;
        'feedback.detailLoading': string;
        'feedback.noDetail': string;
        'header.identity': string;
        'header.facts': string;
        'tab.details': string;
        'tab.create': string;
        'tab.update': string;
        'tab.closure': string;
        'form.createSection': string;
        'form.updateSection': string;
        'form.closureSection': string;
        'feedback.required': string;
        'confirm.delete': string;
        'confirm.transition': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage31TicketCataloguePage extends ControleChamadosTicketCatalogueBase {
        #private;
        protected get msg(): PageMessageType;
        render(): any;
        renderScenaryBase(): any;
        renderScenaryDetail(): any;
        renderScenaryCreateTicket(): any;
        renderScenaryUpdateTicket(): any;
        renderScenaryDecideClosure(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/ticketCommentCatalogue.defs" {
    export const definition = "page: Coment\u00E1rio do chamado\nactor: atendente\npurpose: Cadastro de Coment\u00E1rio do chamado.\nuxExperience: entityRecordManagement\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketCommentCatalogue__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page31/ticketCommentCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page31/ticketCommentCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketCommentCatalogueDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketCommentCatalogue__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/entityRecordManagement/page31.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/ticketCommentCatalogue" {
    import { ControleChamadosTicketCommentCatalogueBase } from "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.recordList.title': string;
        'organism.qryListTicketComment.title': string;
        'intent.qryListTicketComment.list.title': string;
        'intent.qryListTicketComment.list.empty': string;
        'intent.qryListTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryListTicketComment.list.column.ticketId.label': string;
        'intent.qryListTicketComment.list.column.commentText.label': string;
        'organism.qryGetTicketComment.title': string;
        'intent.qryGetTicketComment.list.title': string;
        'intent.qryGetTicketComment.list.empty': string;
        'intent.qryGetTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryGetTicketComment.list.column.ticketId.label': string;
        'intent.qryGetTicketComment.list.column.commentText.label': string;
        'organism.cmdDeleteTicketComment.title': string;
        'intent.cmdDeleteTicketComment.form.title': string;
        'intent.cmdDeleteTicketComment.form.action.cmdDeleteTicketComment': string;
        'section.recordForm.title': string;
        'organism.cmdCreateTicketComment.title': string;
        'intent.cmdCreateTicketComment.form.title': string;
        'intent.cmdCreateTicketComment.form.action.cmdCreateTicketComment': string;
        'intent.cmdCreateTicketComment.form.field.commentText.label': string;
        'organism.cmdUpdateTicketComment.title': string;
        'intent.cmdUpdateTicketComment.form.title': string;
        'intent.cmdUpdateTicketComment.form.action.cmdUpdateTicketComment': string;
        'intent.cmdUpdateTicketComment.form.field.commentText.label': string;
        'organism.qryTicketPicker.title': string;
        'intent.qryTicketPicker.list.title': string;
        'intent.qryTicketPicker.list.empty': string;
        'intent.qryTicketPicker.list.column.ticketId.label': string;
        'intent.qryTicketPicker.list.column.title.label': string;
        'intent.qryTicketPicker.list.column.description.label': string;
        'intent.qryTicketPicker.list.column.status.label': string;
        'intent.qryTicketPicker.list.filter.search.label': string;
        'intent.qryTicketPicker.list.filter.sortBy.label': string;
        'intent.qryTicketPicker.list.filter.sortOrder.label': string;
        'action.cmdCreateTicketComment.success': string;
        'action.cmdCreateTicketComment.error': string;
        'action.cmdUpdateTicketComment.success': string;
        'action.cmdUpdateTicketComment.error': string;
        'action.cmdDeleteTicketComment.success': string;
        'action.cmdDeleteTicketComment.error': string;
        'section.commentWorkspace.title': string;
        'section.commentCreation.title': string;
        'scenary.base': string;
        'scenary.detail': string;
        'scenary.createTicketComment': string;
        'scenary.updateTicketComment': string;
        'scenary.back': string;
        'ui.loading': string;
        'ui.selectTicket': string;
        'ui.chooseComment': string;
        'ui.deleteConfirm': string;
        'ui.required': string;
        'ui.createNew': string;
        'ui.edit': string;
        'ui.delete': string;
        'ui.retry': string;
        'ui.saved': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage31TicketCommentCataloguePage extends ControleChamadosTicketCommentCatalogueBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
        renderScenaryDetail(): any;
        renderScenaryCreateTicketComment(): any;
        renderScenaryUpdateTicketComment(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/ticketHub.defs" {
    export const definition = "page: Chamado\nactor: atendente\npurpose: Painel de Chamado.\nuxExperience: dashboardCommandCenter\nThe page extends the shared base class of this workspace: the shared travels in this pipeline and already carries the states, actions and handlers the page inherits. Render the experience around that intent \u2014 do not list fields and do not list routines.";
    export const pipeline: readonly [{
        readonly id: "ticketHub__page31__l2_page";
        readonly type: "l2_page";
        readonly outputPath: "_102047_/l2/controleChamados/web/desktop/page31/ticketHub.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/desktop/page31/ticketHub.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/shared/ticketHubDts.txt", "_102047_/l2/designSystem.ts"];
        readonly dependsOn: readonly ["ticketHub__l2_shared"];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfePage21RenderTs.ts", "_102020_/l4/collabux/templates/dashboardCommandCenter/page31.md"];
        readonly visualStyle: {};
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/desktop/page31/ticketHub" {
    import { ControleChamadosTicketHubBase } from "_102047_/l2/controleChamados/web/shared/ticketHub";
    import "_102020_/l2/molecules/ml-scenary";
    const pageMessage_pt_br: {
        'section.collection.title': string;
        'organism.qryListTicket.title': string;
        'intent.qryListTicket.list.title': string;
        'intent.qryListTicket.list.empty': string;
        'intent.qryListTicket.list.column.ticketId.label': string;
        'intent.qryListTicket.list.column.title.label': string;
        'intent.qryListTicket.list.column.description.label': string;
        'intent.qryListTicket.list.column.status.label': string;
        'intent.qryListTicket.list.filter.search.label': string;
        'intent.qryListTicket.list.filter.sortBy.label': string;
        'intent.qryListTicket.list.filter.sortOrder.label': string;
        'section.record.title': string;
        'organism.qryListTicketComment.title': string;
        'intent.qryListTicketComment.list.title': string;
        'intent.qryListTicketComment.list.empty': string;
        'intent.qryListTicketComment.list.column.ticketCommentId.label': string;
        'intent.qryListTicketComment.list.column.ticketId.label': string;
        'intent.qryListTicketComment.list.column.commentText.label': string;
        'section.ticket-workspace.title': string;
        'section.ticket-context.title': string;
        'scenary.base': string;
        'stat.tickets': string;
        'stat.comments': string;
        'board.search.placeholder': string;
        'board.sort.open': string;
        'board.sort.closed': string;
        'board.order.asc': string;
        'board.order.desc': string;
        'board.refresh': string;
        'board.loading': string;
        'board.error': string;
        'board.retry': string;
        'board.comments.loading': string;
        'board.comments.error': string;
        'board.comments.retry': string;
        'board.seeAll': string;
        'board.noDescription': string;
        'board.status.open': string;
        'board.status.closed': string;
        'board.status.other': string;
    };
    type PageMessageType = typeof pageMessage_pt_br;
    export class ControleChamadosDesktopPage31TicketHubPage extends ControleChamadosTicketHubBase {
        #private;
        /** i18n catalog — resolved once per language, refreshed only when the document language changes. */
        protected get msg(): PageMessageType;
        /** Main render. The scenary host and Scene list are fixed — fill renderScenary<X>(), not this. */
        render(): any;
        renderScenaryBase(): any;
    }
}
declare module "_102047_/l2/controleChamados/web/shared/commentOpenTicket.defs" {
    /**
     * uiScenary contract (page skeleton reads `scenaries[].value` as <Scene value>):
     *   scenaries[]: { value, kind: "base"|"detail"|"command", commandName?, preconditions: stateKey[] }
     *   preconditions = required route/selection inputs (skill rule 8). Unsatisfied → base, silently.
     *   URL `?scenary=` is a request; the shared setter is the source of truth.
     *   destructiveCommandIds never become scenes (confirmation stays a modal).
     */
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            tsPath: string;
            contracts: {
                commandName: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            valueSet?: undefined;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: any[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        scenaries: {
            value: string;
            kind: string;
            commandName: string;
            preconditions: string[];
        }[];
        destructiveCommandIds: any[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            kind: string;
            stateKey: string;
            inputStateKeys: string[];
            inputs: {
                name: string;
                stateKey: string;
                source: string;
                required: boolean;
                presentation: string;
            }[];
            selection: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
            runtimeLocales: string[];
        };
        i18n: {
            "section.locateTicket.title": string;
            "organism.qryLocateTicket.title": string;
            "intent.qryLocateTicket.list.title": string;
            "intent.qryLocateTicket.list.empty": string;
            "intent.qryLocateTicket.list.column.ticketId.label": string;
            "intent.qryLocateTicket.list.column.title.label": string;
            "intent.qryLocateTicket.list.column.description.label": string;
            "intent.qryLocateTicket.list.column.status.label": string;
            "section.recordComment.title": string;
            "organism.cmdRecordComment.title": string;
            "intent.cmdRecordComment.form.title": string;
            "intent.cmdRecordComment.form.action.cmdRecordComment": string;
            "intent.cmdRecordComment.form.field.commentText.label": string;
            "action.cmdRecordComment.success": string;
            "action.cmdRecordComment.error": string;
            "section.ticket-context.title": string;
            "section.comment-action.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "commentOpenTicket__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102047_/l2/controleChamados/web/shared/commentOpenTicket.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/shared/commentOpenTicket.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/contracts/commentOpenTicket.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/shared/ticketCatalogue.defs" {
    /**
     * uiScenary contract (page skeleton reads `scenaries[].value` as <Scene value>):
     *   scenaries[]: { value, kind: "base"|"detail"|"command", commandName?, preconditions: stateKey[] }
     *   preconditions = required route/selection inputs (skill rule 8). Unsatisfied → base, silently.
     *   URL `?scenary=` is a request; the shared setter is the source of truth.
     *   destructiveCommandIds never become scenes (confirmation stays a modal).
     */
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            tsPath: string;
            contracts: {
                commandName: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: string[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            prefill: {
                command: string;
                sourceStateKey: string;
                sourceOutputShape: string;
                matchField: string;
                fields: {
                    itemField: string;
                    targetStateKey: string;
                }[];
            };
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        })[];
        scenaries: {
            value: string;
            kind: string;
            commandName: string;
            preconditions: string[];
        }[];
        destructiveCommandIds: string[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        dataBindings: ({
            id: string;
            source: string;
            command: string;
            description: string;
            kind: string;
            stateKey: string;
            inputStateKeys: string[];
            inputs: {
                name: string;
                stateKey: string;
                source: string;
                required: boolean;
                presentation: string;
            }[];
            selection: string;
            destructive?: undefined;
        } | {
            id: string;
            source: string;
            command: string;
            description: string;
            kind: string;
            stateKey: string;
            inputStateKeys: string[];
            inputs: {
                name: string;
                stateKey: string;
                source: string;
                required: boolean;
                presentation: string;
            }[];
            selection: string;
            destructive: boolean;
        })[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
            runtimeLocales: string[];
        };
        i18n: {
            "section.recordList.title": string;
            "organism.qryListTicket.title": string;
            "intent.qryListTicket.list.title": string;
            "intent.qryListTicket.list.empty": string;
            "intent.qryListTicket.list.column.ticketId.label": string;
            "intent.qryListTicket.list.column.title.label": string;
            "intent.qryListTicket.list.column.description.label": string;
            "intent.qryListTicket.list.column.status.label": string;
            "intent.qryListTicket.list.filter.search.label": string;
            "intent.qryListTicket.list.filter.sortBy.label": string;
            "intent.qryListTicket.list.filter.sortOrder.label": string;
            "organism.qryLocateTicket.title": string;
            "intent.qryLocateTicket.list.title": string;
            "intent.qryLocateTicket.list.empty": string;
            "intent.qryLocateTicket.list.column.ticketId.label": string;
            "intent.qryLocateTicket.list.column.title.label": string;
            "intent.qryLocateTicket.list.column.description.label": string;
            "intent.qryLocateTicket.list.column.status.label": string;
            "organism.cmdDeleteTicket.title": string;
            "intent.cmdDeleteTicket.form.title": string;
            "intent.cmdDeleteTicket.form.action.cmdDeleteTicket": string;
            "organism.qryGetTicket.title": string;
            "intent.qryGetTicket.list.title": string;
            "intent.qryGetTicket.list.empty": string;
            "intent.qryGetTicket.list.column.ticketId.label": string;
            "intent.qryGetTicket.list.column.title.label": string;
            "intent.qryGetTicket.list.column.description.label": string;
            "intent.qryGetTicket.list.column.status.label": string;
            "section.recordForm.title": string;
            "organism.cmdCreateTicket.title": string;
            "intent.cmdCreateTicket.form.title": string;
            "intent.cmdCreateTicket.form.action.cmdCreateTicket": string;
            "intent.cmdCreateTicket.form.field.title.label": string;
            "intent.cmdCreateTicket.form.field.description.label": string;
            "intent.cmdCreateTicket.form.field.status.label": string;
            "organism.cmdUpdateTicket.title": string;
            "intent.cmdUpdateTicket.form.title": string;
            "intent.cmdUpdateTicket.form.action.cmdUpdateTicket": string;
            "intent.cmdUpdateTicket.form.field.title.label": string;
            "intent.cmdUpdateTicket.form.field.description.label": string;
            "intent.cmdUpdateTicket.form.field.status.label": string;
            "section.decideClosure.title": string;
            "organism.cmdDecideClosure.title": string;
            "intent.cmdDecideClosure.form.title": string;
            "intent.cmdDecideClosure.form.action.cmdDecideClosure": string;
            "intent.cmdDecideClosure.form.field.status.label": string;
            "action.cmdCreateTicket.success": string;
            "action.cmdCreateTicket.error": string;
            "action.cmdUpdateTicket.success": string;
            "action.cmdUpdateTicket.error": string;
            "action.cmdDeleteTicket.success": string;
            "action.cmdDeleteTicket.error": string;
            "action.cmdDecideClosure.success": string;
            "action.cmdDecideClosure.error": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ticketCatalogue__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102047_/l2/controleChamados/web/shared/ticketCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/shared/ticketCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/contracts/ticketCatalogue.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue.defs" {
    /**
     * uiScenary contract (page skeleton reads `scenaries[].value` as <Scene value>):
     *   scenaries[]: { value, kind: "base"|"detail"|"command", commandName?, preconditions: stateKey[] }
     *   preconditions = required route/selection inputs (skill rule 8). Unsatisfied → base, silently.
     *   URL `?scenary=` is a request; the shared setter is the source of truth.
     *   destructiveCommandIds never become scenes (confirmation stays a modal).
     */
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            tsPath: string;
            contracts: {
                commandName: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            defaultValue: any;
            valueSet?: undefined;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            defaultValue: string;
            valueSet?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
            source?: undefined;
            presentation?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey: string;
            feedback: {
                successMessageKey: string;
                errorMessageKey: string;
                dismissible: boolean;
            };
            clearInputStateKeys: string[];
            refreshActionIds: string[];
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: string[];
            outputStateKeys: string[];
            statusStateKey: string;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            stateKey?: undefined;
            prefill?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            prefill: {
                command: string;
                sourceStateKey: string;
                sourceOutputShape: string;
                matchField: string;
                fields: {
                    itemField: string;
                    targetStateKey: string;
                }[];
            };
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
            errorStateKey?: undefined;
            feedback?: undefined;
            clearInputStateKeys?: undefined;
            refreshActionIds?: undefined;
            prefill?: undefined;
        })[];
        scenaries: {
            value: string;
            kind: string;
            commandName: string;
            preconditions: string[];
        }[];
        destructiveCommandIds: string[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        dataBindings: ({
            id: string;
            source: string;
            command: string;
            description: string;
            kind: string;
            stateKey: string;
            inputStateKeys: string[];
            inputs: {
                name: string;
                stateKey: string;
                source: string;
                required: boolean;
                presentation: string;
            }[];
            selection: string;
            destructive?: undefined;
        } | {
            id: string;
            source: string;
            command: string;
            description: string;
            kind: string;
            stateKey: string;
            inputStateKeys: string[];
            inputs: {
                name: string;
                stateKey: string;
                source: string;
                required: boolean;
                presentation: string;
            }[];
            selection: string;
            destructive: boolean;
        })[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
            runtimeLocales: string[];
        };
        i18n: {
            "section.recordList.title": string;
            "organism.qryListTicketComment.title": string;
            "intent.qryListTicketComment.list.title": string;
            "intent.qryListTicketComment.list.empty": string;
            "intent.qryListTicketComment.list.column.ticketCommentId.label": string;
            "intent.qryListTicketComment.list.column.ticketId.label": string;
            "intent.qryListTicketComment.list.column.commentText.label": string;
            "organism.qryGetTicketComment.title": string;
            "intent.qryGetTicketComment.list.title": string;
            "intent.qryGetTicketComment.list.empty": string;
            "intent.qryGetTicketComment.list.column.ticketCommentId.label": string;
            "intent.qryGetTicketComment.list.column.ticketId.label": string;
            "intent.qryGetTicketComment.list.column.commentText.label": string;
            "organism.cmdDeleteTicketComment.title": string;
            "intent.cmdDeleteTicketComment.form.title": string;
            "intent.cmdDeleteTicketComment.form.action.cmdDeleteTicketComment": string;
            "section.recordForm.title": string;
            "organism.cmdCreateTicketComment.title": string;
            "intent.cmdCreateTicketComment.form.title": string;
            "intent.cmdCreateTicketComment.form.action.cmdCreateTicketComment": string;
            "intent.cmdCreateTicketComment.form.field.commentText.label": string;
            "organism.cmdUpdateTicketComment.title": string;
            "intent.cmdUpdateTicketComment.form.title": string;
            "intent.cmdUpdateTicketComment.form.action.cmdUpdateTicketComment": string;
            "intent.cmdUpdateTicketComment.form.field.commentText.label": string;
            "organism.qryTicketPicker.title": string;
            "intent.qryTicketPicker.list.title": string;
            "intent.qryTicketPicker.list.empty": string;
            "intent.qryTicketPicker.list.column.ticketId.label": string;
            "intent.qryTicketPicker.list.column.title.label": string;
            "intent.qryTicketPicker.list.column.description.label": string;
            "intent.qryTicketPicker.list.column.status.label": string;
            "intent.qryTicketPicker.list.filter.search.label": string;
            "intent.qryTicketPicker.list.filter.sortBy.label": string;
            "intent.qryTicketPicker.list.filter.sortOrder.label": string;
            "action.cmdCreateTicketComment.success": string;
            "action.cmdCreateTicketComment.error": string;
            "action.cmdUpdateTicketComment.success": string;
            "action.cmdUpdateTicketComment.error": string;
            "action.cmdDeleteTicketComment.success": string;
            "action.cmdDeleteTicketComment.error": string;
            "section.commentWorkspace.title": string;
            "section.commentCreation.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ticketCommentCatalogue__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/shared/ticketCommentCatalogue.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/contracts/ticketCommentCatalogue.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102047_/l2/controleChamados/web/shared/ticketHub.defs" {
    /**
     * uiScenary contract (page skeleton reads `scenaries[].value` as <Scene value>):
     *   scenaries[]: { value, kind: "base"|"detail"|"command", commandName?, preconditions: stateKey[] }
     *   preconditions = required route/selection inputs (skill rule 8). Unsatisfied → base, silently.
     *   URL `?scenary=` is a request; the shared setter is the source of truth.
     *   destructiveCommandIds never become scenes (confirmation stays a modal).
     */
    export const definition: {
        pageId: string;
        pageName: string;
        moduleName: string;
        baseClassName: string;
        routePattern: string;
        sourceKind: string;
        ownerIds: string[];
        operationIds: string[];
        origin: {
            source: string;
            workspaceId: string;
            workspaceKind: string;
            actor: string;
            entity: string;
            owners: {
                kind: string;
                id: string;
                defPath: string;
            }[];
            microUserFlow: {
                source: string;
                workflowSteps: any[];
                operations: {
                    operationId: string;
                    commandName: string;
                    steps: string[];
                }[];
            };
        };
        contractRef: {
            tsPath: string;
            contracts: {
                commandName: string;
                routeConst: string;
            }[];
        };
        layoutRef: {
            defPath: string;
            layoutId: string;
        };
        states: ({
            stateKey: string;
            name: string;
            kind: string;
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            actionRef: string;
            valueSet: string[];
            defaultValue: string;
            source?: undefined;
            presentation?: undefined;
            contractRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            defaultValue: string;
            valueSet?: undefined;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            source: string;
            presentation: string;
            contractRef: {
                commandName: string;
                direction: string;
                field: string;
            };
            valueSet: string[];
            defaultValue: string;
            actionRef?: undefined;
            outputShape?: undefined;
            collection?: undefined;
        } | {
            stateKey: string;
            name: string;
            kind: string;
            contractRef: {
                commandName: string;
                direction: string;
                field?: undefined;
            };
            outputShape: string;
            collection: boolean;
            defaultValue: any[];
            valueSet?: undefined;
            actionRef?: undefined;
            source?: undefined;
            presentation?: undefined;
        })[];
        actions: ({
            actionId: string;
            kind: string;
            commandRef: string;
            routeKey: string;
            purpose: string;
            methodName: string;
            handlerName: string;
            inputStateKeys: string[];
            routeParamInputStateKeys: any[];
            selectedEntityInputStateKeys: any[];
            outputStateKeys: string[];
            statusStateKey: string;
            stateKey?: undefined;
        } | {
            actionId: string;
            kind: string;
            stateKey: string;
            methodName: string;
            handlerName: string;
            commandRef?: undefined;
            routeKey?: undefined;
            purpose?: undefined;
            inputStateKeys?: undefined;
            routeParamInputStateKeys?: undefined;
            selectedEntityInputStateKeys?: undefined;
            outputStateKeys?: undefined;
            statusStateKey?: undefined;
        })[];
        scenaries: {
            value: string;
            kind: string;
            commandName: string;
            preconditions: any[];
        }[];
        destructiveCommandIds: any[];
        initialLoads: {
            actionId: string;
            stateKey: string;
        }[];
        dataBindings: {
            id: string;
            source: string;
            command: string;
            description: string;
            kind: string;
            stateKey: string;
            inputStateKeys: string[];
            inputs: {
                name: string;
                stateKey: string;
                source: string;
                required: boolean;
                presentation: string;
            }[];
            selection: string;
        }[];
        businessContextRefs: any[];
        navigationRefs: any[];
        i18nMeta: {
            defaultLocale: string;
            activeLocales: string[];
            runtimeLocales: string[];
        };
        i18n: {
            "section.collection.title": string;
            "organism.qryListTicket.title": string;
            "intent.qryListTicket.list.title": string;
            "intent.qryListTicket.list.empty": string;
            "intent.qryListTicket.list.column.ticketId.label": string;
            "intent.qryListTicket.list.column.title.label": string;
            "intent.qryListTicket.list.column.description.label": string;
            "intent.qryListTicket.list.column.status.label": string;
            "intent.qryListTicket.list.filter.search.label": string;
            "intent.qryListTicket.list.filter.sortBy.label": string;
            "intent.qryListTicket.list.filter.sortOrder.label": string;
            "section.record.title": string;
            "organism.qryListTicketComment.title": string;
            "intent.qryListTicketComment.list.title": string;
            "intent.qryListTicketComment.list.empty": string;
            "intent.qryListTicketComment.list.column.ticketCommentId.label": string;
            "intent.qryListTicketComment.list.column.ticketId.label": string;
            "intent.qryListTicketComment.list.column.commentText.label": string;
            "section.ticket-workspace.title": string;
            "section.ticket-context.title": string;
        };
        automation: {
            statePrefix: string;
            stateKeys: string[];
            actionIds: string[];
        };
    };
    export const pipeline: readonly [{
        readonly id: "ticketHub__l2_shared";
        readonly type: "l2_shared";
        readonly outputPath: "_102047_/l2/controleChamados/web/shared/ticketHub.ts";
        readonly defPath: "_102047_/l2/controleChamados/web/shared/ticketHub.defs.ts";
        readonly dependsFiles: readonly ["_102047_/l2/controleChamados/web/contracts/ticketHub.ts", "_102029_.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"];
        readonly rulesApplied: readonly [];
        readonly agent: "agentCfeMaterializeGen";
    }];
}
declare module "_102020_/l2/agentNewSolution/helpers/ns4Core" {
    export const NS4_FLOW_ID: "agentNewSolution";
    export const NS4_FLOW_VERSION: "2026-08-14-ns4-flow-v40";
    export const NS4_E4_MAX_PARALLEL: 20;
    export const NS4_E7_MAX_PARALLEL: 20;
    export const NS4_E8_MAX_PARALLEL: 20;
    export const NS4_MODULE_SCHEMA_VERSION: "2026-08-06-ns4-module-v4";
    export const NS4_PIPELINE_SCHEMA_VERSION: "2026-08-06-ns4-pipeline-v5";
    export type Ns4PermanentFlowVersion = typeof NS4_FLOW_VERSION | '2026-08-14-ns4-flow-v39' | '2026-08-14-ns4-flow-v38' | '2026-08-14-ns4-flow-v37' | '2026-08-14-ns4-flow-v36' | '2026-08-14-ns4-flow-v35' | '2026-08-14-ns4-flow-v34' | '2026-08-13-ns4-flow-v33' | '2026-08-13-ns4-flow-v32' | '2026-08-13-ns4-flow-v31' | '2026-08-12-ns4-flow-v30' | '2026-08-11-ns4-flow-v24' | '2026-08-11-ns4-flow-v22' | '2026-08-10-ns4-flow-v21' | '2026-08-10-ns4-flow-v20' | '2026-08-09-ns4-flow-v19' | '2026-08-09-ns4-flow-v18' | '2026-08-08-ns4-flow-v17';
    export const NS4_PLAN_IDS: readonly ["e1-clarification", "e1-compile", "e2-journeys", "e3-access-matrix", "e4-ontology", "e5-rules", "e6-behaviors", "e7-realization", "e8-workspaces", "e9-navigation-compiler", "e10-validation"];
    export type Ns4PlanId = typeof NS4_PLAN_IDS[number];
    export const NS4_HUMAN_CHECKPOINT_ICON: "\uD83D\uDC64";
    export const NS4_AUTOMATED_JUDGE_ICON: "\uD83D\uDD0E";
    export type Ns4ApprovedBy = 'human' | 'auto';
    export type Ns4E1Status = 'running' | 'approved' | 'failed';
    export type Ns4E2Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E3Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E5Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E6Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E7Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E8Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E9Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E10Status = 'running' | 'approved' | 'failed';
    export type Ns4CompletedStepId = 'e1' | 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation';
    export type Ns4NextStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation' | 'complete';
    export interface Ns4ClarificationQuestion {
        type: 'open';
        question: string;
        answer: string;
    }
    export interface Ns4Clarification {
        planId: 'e1-clarification';
        userLanguage: string;
        title: string;
        legends: string[];
        questions: Record<string, Ns4ClarificationQuestion>;
    }
    export interface Ns4Presentation {
        userLanguage: string;
        stepTitles: Record<Ns4PlanId, string>;
    }
    export interface Ns4RootPlan {
        validPrompt: boolean;
        invalidReason?: string;
        userPrompt: string;
        presentation: Ns4Presentation;
        clarification: Ns4Clarification;
    }
    export interface Ns4ModuleArtifact {
        schemaVersion: typeof NS4_MODULE_SCHEMA_VERSION;
        presentation: Ns4Presentation;
        module: {
            moduleName: string;
            title: string;
            purpose: string;
            languages: string[];
        };
        designContext: {
            initialPrompt: string;
            clarification: {
                mainActors: string;
                mainGoal: string;
                boundaries: string;
            };
        };
        reviewPolicy: {
            mode: 'guided' | 'smart' | 'automatic';
        };
        solutionStrategy: {
            mode: 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
            rationale: string;
            databaseChangePolicy: 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Array<{
                actorId: string;
                title: string;
                kind: 'internal' | 'external' | 'system';
                expectedOutcome: string;
            }>;
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        specStatus: {
            flowId: typeof NS4_FLOW_ID;
            /** v17 remains readable by tsc, but isNs4Pipeline deliberately rejects it for runtime resume. */
            flowVersion: Ns4PermanentFlowVersion;
            state: 'inProgress' | 'complete';
            artifactCompleteness: 'partial' | 'full';
            completedSteps: Array<{
                stepId: Ns4CompletedStepId;
                status: 'approved';
                approvedBy: Ns4ApprovedBy;
                approvedAt: string;
                /** Present when smart skipped the human checkpoint. */
                autoReason?: string;
            }>;
            nextStep: Ns4NextStep;
            updatedAt: string;
        };
    }
    export interface Ns4PipelineState {
        schemaVersion: typeof NS4_PIPELINE_SCHEMA_VERSION;
        flowId: typeof NS4_FLOW_ID;
        flowVersion: typeof NS4_FLOW_VERSION;
        moduleName: string;
        sourcePrompt: string;
        presentation: Ns4Presentation;
        status: 'inProgress' | 'complete' | 'failed';
        /** Audit of the last explicit regeneration: which step it restarted from, and when. */
        rebuiltFrom?: Ns4RebuildFrom;
        rebuiltAt?: string;
        /** Counts from `/rebuild all` (l1/l2/l4/l5 wipe). Survives on the regenerated pipeline for runNN_*.json. */
        rebuildAll?: Ns4RebuildAllReport;
        steps: {
            e1: {
                status: Ns4E1Status;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                skippedDefaults?: {
                    productLanguages: string[];
                    defaultLanguage: string;
                    moduleName: string;
                };
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e2?: {
                status: Ns4E2Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e3?: {
                status: Ns4E3Status;
                reviewRound: number;
                draftPath?: string;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4?: {
                status: Ns4E4Status;
                reviewRound: number;
                solutionMode: 'new';
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e5?: {
                status: Ns4E5Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e6?: {
                status: Ns4E6Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e7?: {
                status: Ns4E7Status;
                planPath?: string;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e8?: {
                status: Ns4E8Status;
                reviewRound: number;
                skeletonPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e9?: {
                status: Ns4E9Status;
                artifactPaths?: string[];
                repairStep?: 'e8-workspaces' | 'e9-navigation-compiler';
                error?: string;
                failedAt?: string;
                approvedAt?: string;
                updatedAt: string;
            };
            e10?: {
                status: Ns4E10Status;
                reportPath?: string;
                artifactPaths?: string[];
                repairStep?: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>;
                error?: string;
                failedAt?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                updatedAt: string;
            };
        };
        nextStep: Ns4NextStep;
        createdAt: string;
        updatedAt: string;
        /**
         * E9 audit: an E7 use case that did not become an operation. Only `degraded` is persisted at the
         * top level — a clean emit strips both fields so a prior-run `degraded` cannot come back.
         */
        useCases?: 'degraded';
        useCasesDropped?: {
            notEmitted: string[];
            approved: number;
            emitted: number;
            reasons?: Record<string, string>;
        };
        /** Recorded when `/fast` dispatches the next agent, so a re-entry of E10 does not send twice. */
        fastHandoff?: {
            to: string;
            message: string;
            at: string;
        };
    }
    export type Ns4ExistingAction = 'new' | 'resume-e1' | 'resume-e2' | 'resume-e3' | 'resume-e4' | 'resume-e5' | 'resume-e6' | 'resume-e7' | 'resume-e8' | 'resume-e9' | 'resume-e10' | 'resume-next' | 'collision';
    /** Steps a partial rebuild can start from. e1 is not one of them: restarting at e1 IS a total rebuild. */
    export type Ns4RebuildFrom = 'e2' | 'e3' | 'e4' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /** `/rebuild all` is its own mode: wipe l1/l2/l4 of the module, then regenerate from the stored prompt. */
    export type Ns4RebuildArg = Ns4RebuildFrom | 'all';
    export interface Ns4RebuildAllReport {
        at: string;
        deleted: {
            l1: number;
            l2: number;
            l4: number;
            l5: number;
        };
        sanitized: {
            projectJsonRemoved: number;
            configJsonRemoved: number;
        };
    }
    export interface Ns4Invocation {
        fast: boolean;
        /** Explicit regeneration intent. Never inferred from prose — prose only produces a graceful stop. */
        rebuild: boolean;
        /** Set by `/rebuild all` or `/rebuild <eN>`; empty means the existing total rebuild (l4/l5 only). */
        rebuildFrom: Ns4RebuildArg | '';
        /** Suppress the next-agent handoff. Independent of `/fast`; `/nochainlane` does not match. */
        nochain: boolean;
        prompt: string;
    }
    export function parseNs4Invocation(value: string): Ns4Invocation;
    /**
     * A prompt that ASKS for a rebuild in prose and names an existing module.
     *
     * The incident this exists for: `rebuild all criar um site chamado petShop , em …`. The module name sits
     * mid-sentence, so `resolveNs4ExistingModuleToken` (which requires the WHOLE prompt to be one token) read
     * it as a new module, E1 ran, and the existence backstop killed the task — the user asked to rebuild and
     * got a terminal error.
     *
     * BOTH signals are required. Scanning tokens for an existing module name on its own would hijack an
     * ordinary creation prompt that happens to mention one ("um módulo de agenda para o petShop"); demanding
     * an explicit rebuild word keeps every prompt without one canonicalized exactly as before. The outcome is
     * only ever a message teaching the flag — nothing is written or deleted on this path.
     *
     * The rebuild word may be a flag (`/rebuild`, `/regenerar`): the slash sits where a start-or-space
     * used to be required, so the canonical form never reached this helper.
     */
    export function detectNs4RebuildIntentModule(value: string, existingModules: ReadonlySet<string>): string;
    export function formatNs4MissingRebuildModuleMessage(existingModules: ReadonlySet<string>): string;
    export function createNs4E2Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E1Step(reviewRound?: number, adjustment?: string, previousReview?: unknown, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E2GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, coverageRepairAttempt: number, gateFeedback: string, stepTitle?: string, coverageIssueIds?: string[], policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E2CoverageRepairStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, coverageFeedback: string, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E2CoverageJudgeStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, judgeAttempt: number, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E3Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /**
     * One bounded structural repair for E3, mirroring the E2 gate repair: the model
     * sees the numbered gate findings plus the persisted invalid draft and returns a
     * complete corrected matrix through the same gate.
     */
    export function createNs4E3GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4RepairStep(moduleName: string, reviewRound: number, repairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4FinalizeStep(moduleName: string, reviewRound: number, dependsOn: string[], entityRepairRound?: number, planRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4RelationshipBindingStep(moduleName: string, reviewRound: number, bindingRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number): mls.msg.AIAgentStep;
    export function createNs4E5Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E6Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E7Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export type Ns4StepOwner = 'e1' | 'e2' | 'e3' | 'e4' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /**
     * The dispatch table, next to the factories that mint the plan ids it matches. The router and the
     * factories drifted apart once — a factory emitting `e8-workspaces-round-1` against a router that
     * only knew `e8-workspaces` — and the step died before reaching any agent, with no trace to read.
     * One table, one truth, and a test that walks every factory through it.
     */
    export function resolveNs4StepOwner(planId: string): Ns4StepOwner | '';
    /**
     * The E8 plan ids live in ONE place, next to the factories that mint them. The router matched a
     * hand-written pattern once and stopped seeing the real step: a plan id the factory emits and the
     * router does not recognize is a step that dies without ever reaching its agent.
     */
    export function ns4E8StepPlanId(reviewRound: number): string;
    export function ns4E8HubRepairPlanId(reviewRound: number, attempt: number): string;
    export function isNs4E8PlanId(planId: string): boolean;
    export function createNs4E8Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /** The one bounded repair E8 still schedules: the hub composition over its closed catalogue. */
    export function createNs4E8HubCompositionRepairStep(moduleName: string, reviewRound: number, compositionAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E9Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E10Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export const NS4_DEFAULT_TITLES: Record<Ns4PlanId, string>;
    export function formatNs4VisibleStepTitle(planId: Ns4PlanId, title: string): string;
    export function plainNs4StepTitle(title: string): string;
    /** Dynamic E4 children do not retain planning.planId; hook args are their stable dispatcher key. */
    export function resolveNs4DynamicWorker(value: unknown): 'e4' | 'e7' | 'e8' | '';
    export interface Ns4DynamicWorkerRequest {
        worker: 'e4' | 'e7' | 'e8' | '';
        args: string;
    }
    /**
     * collab-messages supplies the selector as hook args before a parallel prompt, but may omit those
     * args in the after-prompt callback while retaining the selector in step.prompt. Both callbacks must
     * resolve through the same ordered fallback or a valid entity payload reaches the root planner.
     */
    export function resolveNs4DynamicWorkerRequest(args: unknown, stepPrompt: unknown): Ns4DynamicWorkerRequest;
    export function normalizeNs4RootPlan(payload: unknown, sourcePrompt: string): Ns4RootPlan;
    export function buildNs4PlannedSteps(plan: Ns4RootPlan): mls.msg.AIAgentStep[];
    export function isNs4ModuleToken(value: string): boolean;
    export function normalizeNs4ModuleName(value: unknown, fallback?: string): string;
    export function resolveNs4ExistingModuleToken(value: string, existingModules: ReadonlySet<string>): string;
    export function normalizeNs4Clarification(value: unknown): Ns4Clarification;
    export function buildNs4ModuleArtifact(sourcePrompt: string, clarificationInput: unknown, approvedBy: Ns4ApprovedBy, now?: string, presentation?: Ns4Presentation): Ns4ModuleArtifact;
    export function normalizeNs4Languages(value: unknown, fallback?: string): string[];
    export function createNs4Pipeline(moduleNameInput: string, sourcePrompt: string, now?: string, presentation?: Ns4Presentation): Ns4PipelineState;
    export function markNs4E1Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, autoReason?: string, skippedDefaults?: {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
    }): Ns4PipelineState;
    export function markNs4FastHandoff(state: Ns4PipelineState, to: string, message: string, now?: string): Ns4PipelineState;
    export function markNs4E2Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E1Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E2Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    /** A changed approved E2 contract invalidates only downstream contracts derived from journeys. */
    export function markNs4E2ImpactStale(state: Ns4PipelineState, hasJourneyImpact: boolean, now?: string): Ns4PipelineState;
    export function markNs4ModuleE2Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, invalidateDownstream?: boolean, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E3Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E3WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E3Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E3Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE3Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E4WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E4Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE4Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E5Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E5WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E5Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E5Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE5Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E6Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E6WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E6Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E6Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE6Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E7Running(state: Ns4PipelineState, planPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E7Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E7Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE7Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E8Running(state: Ns4PipelineState, reviewRound?: number, skeletonPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E8Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E8Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE8Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function markNs4E9Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E9Failed(state: Ns4PipelineState, failure: unknown, origin?: 'skeleton' | 'compiler', now?: string): Ns4PipelineState;
    export function markNs4E9Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE9Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E10Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    /**
     * E10 failed on a defect of the pipeline, not of the product: nothing upstream is stale, because
     * nothing upstream is wrong. The module waits on a fixed pipeline and re-validates from E10.
     */
    export function markNs4E10PipelineDefect(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Failed(state: Ns4PipelineState, failure: unknown, repairStep: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10RuntimeFailed(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, now?: string, reportPath?: string, artifactPaths?: string[]): Ns4PipelineState;
    export function markNs4ModuleE10Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function resolveNs4ExistingAction(moduleExists: boolean, pipeline: unknown, moduleArtifactExists: boolean): Ns4ExistingAction;
    /**
     * Everything a TOTAL rebuild archives: the module's whole l4 and l5 trees.
     *
     * The whole folder, not a list of known artifacts — that is the point. A previous run leaves drafts,
     * pipeline traces (`pipeline/msgtask*.json`) and per-entity defs whose names came from ITS ontology; a
     * selective delete keeps whatever the new run happens not to overwrite, and the module ends up a mix of
     * two generations. l2 is NOT touched: it belongs to agentChangeFrontend, which has its own rebuild.
     *
     * PURE over a `mls.stor.files`-shaped map so the selection is testable without the platform.
     */
    export function listNs4RebuildDeletionKeys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** eN and every step after it. */
    export function ns4RebuildRange(from: Ns4RebuildFrom): Ns4RebuildFrom[];
    /**
     * Resets eN..e10 for a partial rebuild.
     *
     * The reset is EXPLICIT and stamped (`rebuiltFrom`/`rebuiltAt`), which is what keeps rule 11 intact: an
     * approved state is never regressed by a late callback, only by an intent the user typed. The step entries
     * are dropped rather than set to a status, because e2..e10 are optional and "absent" is exactly what
     * "not done yet" means in this pipeline.
     */
    export function resetNs4PipelineForRebuild(pipeline: Ns4PipelineState, from: Ns4RebuildFrom, rebuiltAt?: string): Ns4PipelineState;
    /**
     * Drops the rebuilt range from the permanent artifact's completedSteps.
     *
     * Without this the reset is undone silently: the invocation reconciles the pipeline from
     * `specStatus.completedSteps` whenever the artifact says approved and the file still exists, so the very
     * next invocation would re-mark e10 approved and answer "pipeline encerrado" to a second /rebuild e10.
     */
    export function clearNs4ModuleCompletedStepsFrom(artifact: Ns4ModuleArtifact, from: Ns4RebuildFrom): Ns4ModuleArtifact;
    export function isNs4Pipeline(value: unknown): value is Ns4PipelineState;
    export function humanizeNs4ModuleName(moduleName: string): string;
}
declare module "_102020_/l2/agentNewSolution/helpers/ns4Resolve" {
    export type Ns4ResolutionClass = 'A' | 'B' | 'C';
    export interface Ns4SystemDecision {
        decisionId: string;
        stage: string;
        question: string;
        chosen: string;
        alternatives: string[];
        decidedBy: 'system';
        findingRef: string;
        changeHint: string;
    }
    interface Ns4ResolutionFindingBase {
        decisionId?: string;
        findingRef: string;
        stage: string;
        question: string;
        alternatives: string[];
        changeHint: string;
    }
    export interface Ns4TypeAFinding extends Ns4ResolutionFindingBase {
        classification: 'A';
    }
    export interface Ns4TypeBFinding extends Ns4ResolutionFindingBase {
        classification: 'B';
        /** The behavior already implicit in the generated artifact. */
        defaultChoice: string;
    }
    export interface Ns4TypeCFinding<TArtifact> extends Ns4ResolutionFindingBase {
        classification: 'C';
        deterministicChoice: string;
        apply: (artifact: TArtifact) => TArtifact;
    }
    export type Ns4ResolutionFinding<TArtifact> = Ns4TypeAFinding | Ns4TypeBFinding | Ns4TypeCFinding<TArtifact>;
    export interface Ns4ResolutionResult<TArtifact> {
        artifact: TArtifact;
        systemDecisions: Ns4SystemDecision[];
        unresolved: Array<Ns4TypeAFinding>;
    }
    /**
     * The single NS4 semantic-resolution boundary. Type A remains unresolved,
     * Type B records the generator's existing choice, and Type C applies its
     * caller-supplied mechanical patch before recording the decision.
     */
    export function resolveNs4Findings<TArtifact>(artifact: TArtifact, findings: Array<Ns4ResolutionFinding<TArtifact>>): Ns4ResolutionResult<TArtifact>;
}
declare module "_102020_/l2/agentNewSolution/helpers/ns4Context" {
    /**
     * The single place where journey contexts are derived. E2 owns narrative, sequence, step kind and
     * step entity; nothing declares a context id, a cardinality or a provider. Every consumer (E7, E8,
     * E9) reads the same derivation so a context can never mean two things in two steps.
     */
    export type Ns4ContextStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export interface Ns4DerivedContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        idFieldRef?: string;
    }
    export interface Ns4DerivedStepContexts {
        journeyId: string;
        stepId: string;
        stepRef: string;
        kind: Ns4ContextStepKind;
        entity: string;
        /** True when the step introduces its own entity instead of operating on an existing record. */
        creates: boolean;
        requires: Ns4DerivedContext[];
        provides: Ns4DerivedContext[];
    }
    export interface Ns4DerivedContextGraph {
        catalog: Ns4DerivedContext[];
        steps: Ns4DerivedStepContexts[];
        byStepRef: Map<string, Ns4DerivedStepContexts>;
        entryByJourneyId: Map<string, Ns4DerivedContext[]>;
    }
    export interface Ns4ContextJourneyStep {
        stepId: string;
        kind: Ns4ContextStepKind;
        entity: string;
        targetProfile?: string;
    }
    export interface Ns4ContextJourney {
        journeyId: string;
        business: {
            actorRef: string;
            entry: {
                mode: string;
                preferredFromJourneyRef?: string;
            };
            steps: Ns4ContextJourneyStep[];
        };
    }
    export interface Ns4ContextEntity {
        entityId: string;
        ownership?: string;
        storage?: {
            target?: string;
            scope?: string;
            idField?: string;
        };
        fields?: Array<{
            fieldId: string;
        }>;
    }
    export interface Ns4ContextRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
    }
    export interface Ns4ContextSources {
        journeys: {
            journeys: Ns4ContextJourney[];
        };
        ontology: {
            entities: Ns4ContextEntity[];
            relationships: Ns4ContextRelationship[];
        };
        access?: {
            profiles: Array<{
                profileId: string;
                actorRefs: string[];
            }>;
        };
    }
    /** A context id is a pure function of its entity, so the catalog and the E9 store are entity-keyed. */
    export function ns4ContextIdOf(entity: string): string;
    /**
     * Inspect of entity X that still has no selected X, while a later step locates X, is a collection
     * summary (counts of the listing) — not getById of one record. Identity-free by construction.
     */
    export function isNs4CollectionInspect(steps: ReadonlyArray<{
        kind: string;
        entity: string;
    }>, index: number): boolean;
    /**
     * Platform-owned records are supplied by the runtime session, never selected by the user, so they
     * are not a coordination requirement of a business step.
     */
    export function isNs4PlatformOwnedEntity(entity: Ns4ContextEntity): boolean;
    export function deriveNs4Contexts(sources: Ns4ContextSources): Ns4DerivedContextGraph;
    /** Business objects the ontology must realize: exactly the entities the journeys operate on. */
    export function collectNs4JourneyEntities(journeys: {
        journeys: Ns4ContextJourney[];
    }): string[];
}
declare module "_102020_/l2/agentNewSolution/steps/e2/coverageSignals" {
    export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL: "moduleWithoutDecide";
    export const NS4_E2_JOURNEY_WITHOUT_PROCESS_SIGNAL: "journeyWithoutProcess";
    export interface Ns4E2StepKindHistogram {
        locate: number;
        inspect: number;
        act: number;
        decide: number;
        handoff: number;
    }
    export interface Ns4E2MechanicalCoverageFinding {
        signalId: typeof NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL;
    }
    export interface Ns4E2MechanicalCoverageReport {
        stepKindHistogram: Ns4E2StepKindHistogram;
        findings: Ns4E2MechanicalCoverageFinding[];
        /** Journeys that carry no process: pure capture or maintenance of one record catalogue. */
        captureOnlyJourneys: Array<{
            journeyId: string;
            entity: string;
        }>;
    }
    interface Ns4E2StepSource {
        journeys: Array<{
            journeyId?: unknown;
            business: {
                steps: Array<{
                    kind: unknown;
                    entity?: unknown;
                }>;
            };
        }>;
    }
    export function analyzeNs4E2MechanicalCoverage(source: Ns4E2StepSource): Ns4E2MechanicalCoverageReport;
    /**
     * A journey with no decision, no handoff and one single entity is the record catalogue of that
     * entity written as a flow. Tier 1 already owns that screen, so the module records the demotion as
     * a visible product choice instead of shipping the same catalogue twice.
     */
    export function ns4E2DemotionDecisionId(journeyId: string): string;
    export function isNs4E2DemotionDecisionId(decisionId: string): boolean;
}
declare module "_102020_/l2/agentNewSolution/steps/e2/contracts" {
    import type { Ns4SystemDecision } from "_102020_/l2/agentNewSolution/helpers/ns4Resolve";
    import { type Ns4DerivedContext } from "_102020_/l2/agentNewSolution/helpers/ns4Context";
    import { Ns4E2StepKindHistogram } from "_102020_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-v5";
    export const NS4_JOURNEY_INDEX_SCHEMA_VERSION: "2026-08-15-ns4-journey-index-v7";
    export const NS4_REALIZED_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-realized-v5";
    export const NS4_E2_IMPACT_REPORT_SCHEMA_VERSION: "2026-08-13-ns4-e2-impact-report-v2";
    export type Ns4JourneyEntryMode = 'coldStart' | 'contextRequired' | 'contextOrLookup' | 'eventDriven';
    export type Ns4JourneyStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export type Ns4FeaturePriority = 'now' | 'next' | 'later';
    /**
     * A step names what it does and to which business record. Everything about context — who provides
     * it, what it carries, how many — is derived by helpers/ns4Context.ts from this entity, the step
     * kind, the journey sequence and the approved ontology.
     */
    export interface Ns4JourneyStep {
        stepId: string;
        kind: Ns4JourneyStepKind;
        entity: string;
        title: string;
        description: string;
        featureRefs: string[];
        /** Only a handoff names the receiving E3 profile; it is the routing fact E9 compiles. */
        targetProfile?: string;
    }
    export interface Ns4JourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
        };
        steps: Ns4JourneyStep[];
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    /** Frozen shape of journeys written by flow versions before the context graph became derived. */
    export interface Ns4LegacyJourneyContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        description: string;
        stateRequirement?: string;
    }
    export interface Ns4LegacyJourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        prerequisites: Array<{
            journeyRef: string;
            reason: string;
            required: boolean;
            providesContext: string[];
        }>;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
            carries: Ns4LegacyJourneyContext[];
        };
        steps: Array<{
            stepId: string;
            kind: Ns4JourneyStepKind;
            intent: string;
            requiresContext: string[];
            providesContext: Ns4LegacyJourneyContext[];
            result: string;
            featureRefs: string[];
        }>;
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    export interface Ns4JourneyProposal {
        journeyId: string;
        business: Ns4JourneyBusiness;
        policyDecisions: Ns4PolicyDecision[];
    }
    /** A product choice made while generating a journey, before any human review. */
    export interface Ns4PolicyDecision {
        decisionId: string;
        question: string;
        chosen: string;
        alternatives: string[];
        /** Only the independent E2 judge may add this explanation. */
        impact?: string;
        relatedJourneyIds?: string[];
    }
    /** Durable audit record of the choice the reviewer approved. */
    export interface Ns4PolicyDecisionSelection {
        decisionId: string;
        generatedChoice: string;
        selectedChoice: string;
        selectedBy: 'human' | 'auto';
        selectedAt: string;
    }
    export interface Ns4E2Feature {
        featureId: string;
        title: string;
        priority: Ns4FeaturePriority;
        journeyStepRefs: string[];
    }
    export interface Ns4E2Review {
        planId: 'e2-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        journeys: Ns4JourneyProposal[];
        features: Ns4E2Feature[];
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4JourneyArtifactV5 extends Ns4JourneyProposal {
        schemaVersion: typeof NS4_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'pending';
            contexts: Record<string, never>;
        };
        realization: {
            status: 'pending';
            compiledFromBusinessHash: string;
            steps: never[];
            transitionRefs: never[];
        };
    }
    /** The derived context, plus the structural provenance E7 records for the compiled journey. */
    export interface Ns4JourneyResolvedContext extends Ns4DerivedContext {
        sourceRefs: string[];
        consumerStepRefs: string[];
    }
    export interface Ns4JourneyStepRealization {
        stepId: string;
        useCaseRefs: string[];
    }
    export interface Ns4JourneyArtifactV5Realized extends Omit<Ns4JourneyProposal, 'policyDecisions'> {
        schemaVersion: typeof NS4_REALIZED_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'compiled';
            contexts: Record<string, Ns4JourneyResolvedContext>;
        };
        realization: {
            status: 'compiled';
            compiledFromBusinessHash: string;
            steps: Ns4JourneyStepRealization[];
            transitionRefs: string[];
            realizationHash: string;
        };
    }
    /**
     * Compile-only compatibility for permanent artifacts written by previous flow versions. They are
     * never resumed or migrated; the union only keeps already-generated L4 modules type-safe.
     */
    export interface Ns4LegacyJourneyArtifact {
        schemaVersion: '2026-08-04-ns4-journey-v1' | '2026-08-09-ns4-journey-v2' | '2026-08-10-ns4-journey-v3' | '2026-08-10-ns4-journey-v4';
        journeyId: string;
        revision: number;
        business: Ns4LegacyJourneyBusiness | (Omit<Ns4LegacyJourneyBusiness, 'useRules'> & {
            businessRules: Array<{
                journeyRuleId: string;
                statement: string;
            }>;
        });
        policyDecisions?: Ns4PolicyDecision[];
        businessHash: string;
        resolution: {
            status: 'pending' | 'compiled';
            contexts: Record<string, unknown>;
        };
        realization: {
            status: 'pending' | 'compiled';
            compiledFromBusinessHash: string;
            steps: Array<{
                stepId: string;
                useCaseRefs: string[];
            }>;
            transitionRefs: string[];
            realizationHash?: string;
        };
    }
    export type Ns4JourneyArtifact = Ns4JourneyArtifactV5 | Ns4JourneyArtifactV5Realized | Ns4LegacyJourneyArtifact;
    /** A journey written by a previous flow version still declares its context graph; it is never compiled. */
    export function isNs4CurrentJourneyBusiness(value: Ns4JourneyArtifact['business']): value is Ns4JourneyBusiness;
    export interface Ns4JourneyIndex {
        schemaVersion: typeof NS4_JOURNEY_INDEX_SCHEMA_VERSION | '2026-08-14-ns4-journey-index-v6' | '2026-08-12-ns4-journey-index-v5' | '2026-08-10-ns4-journey-index-v4' | '2026-08-04-ns4-journey-index-v1' | '2026-08-10-ns4-journey-index-v3' | '2026-08-09-ns4-journey-index-v2';
        moduleName: string;
        approvedAt: string;
        approvedBy: 'human' | 'auto';
        journeys: Array<{
            journeyId: string;
            actorRef: string;
            title: string;
            goal: string;
            entryMode: Ns4JourneyEntryMode;
            businessHash: string;
            artifactPath: string;
            useCaseRefs?: string[];
        }>;
        features: Ns4E2Feature[];
        /**
         * The decisions themselves, next to the selections that answer them. This is their durable home:
         * the journey artifact carries a copy while E2 is still reviewing, and E7 rewrites the artifact as
         * realized-v5, which has no policyDecisions — everything read after E7 reads the index.
         */
        policyDecisions?: Ns4JourneyIndexPolicyDecision[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        systemDecisions?: Ns4SystemDecision[];
        realizationHash?: string;
    }
    /** A policy decision with the journey that owns it; the index is flat, journeys reference by id. */
    export interface Ns4JourneyIndexPolicyDecision extends Ns4PolicyDecision {
        journeyRef: string;
    }
    export interface Ns4E2ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E2Review;
        policyDecisionSelections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>;
    }
    export interface Ns4E2ImpactReport {
        schemaVersion: typeof NS4_E2_IMPACT_REPORT_SCHEMA_VERSION;
        moduleName: string;
        generatedAt: string;
        stepKindHistogram: Ns4E2StepKindHistogram;
        changes: Array<{
            journeyId: string;
            reason: 'hashDivergent' | 'journeyNew' | 'journeyRemoved';
        }>;
        affectedSteps: Array<'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e7-realization'>;
    }
    export function normalizeNs4E2Review(value: unknown, fallbackModule?: string): Ns4E2Review;
    export function buildNs4JourneyArtifacts(review: Ns4E2Review): Promise<Ns4JourneyArtifactV5[]>;
    export function buildNs4JourneyIndex(moduleName: string, review: Ns4E2Review, artifacts: Ns4JourneyArtifactV5[], artifactPaths: string[], approvedBy: 'human' | 'auto', approvedAt: string, policyDecisionSelections?: Ns4PolicyDecisionSelection[]): Ns4JourneyIndex;
    export function buildNs4PolicyDecisionSelections(review: Ns4E2Review, selectedChoices: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, selectedBy: 'human' | 'auto', selectedAt: string): Ns4PolicyDecisionSelection[];
    export function buildNs4E2ImpactReport(moduleName: string, previousIndex: Ns4JourneyIndex | null, artifacts: Array<Pick<Ns4JourneyArtifactV5, 'journeyId' | 'businessHash'>>, generatedAt: string, review: Pick<Ns4E2Review, 'journeys'>): Ns4E2ImpactReport;
    export function sha256Ns4(value: unknown): Promise<string>;
    export function stableNs4Stringify(value: unknown): string;
    /**
     * Turns a human-spaced or already technical business noun into the stable PascalCase id shared by
     * journeys and ontology entities. The transformation is intentionally lexical: it never translates
     * or substitutes a domain noun.
     */
    export function normalizeNs4BusinessObjectId(value: unknown): string;
    /**
     * A journey with no decision, no handoff and one single entity IS the record catalogue of that
     * entity. Tier 1 already owns that screen, so the module records the demotion as a visible product
     * choice at the E2 checkpoint instead of shipping the same catalogue twice. The decision is
     * deterministic: it is recomputed on every round and is never authored by the generator.
     */
    export function withNs4DemotionDecisions(journeys: Ns4JourneyProposal[], userLanguage: string): Ns4JourneyProposal[];
    /** The journeys the approved review demoted to the tier 1 record catalogue of their entity. */
    export function collectNs4DemotedJourneyIds(review: Pick<Ns4E2Review, 'journeys'>, selections?: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>): string[];
    /** Business objects that later ontology compilation must realize as entities or projections. */
    export function collectNs4RequiredJourneyBusinessObjects(review: Ns4E2Review): string[];
}
declare module "_102020_/l2/agentNewSolution/steps/e3/contracts" {
    export const NS4_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-09-ns4-access-matrix-v2";
    export const NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-10-ns4-access-matrix-v3";
    export const NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-13-ns4-access-matrix-v4";
    export type Ns4AccessProfileKind = 'internal' | 'external';
    export type Ns4AccessScopeMode = 'organization' | 'assigned' | 'own' | 'related' | 'public' | 'custom';
    export type Ns4DisclosureMode = 'fullRecord' | 'summaryOnly' | 'fieldsOnly' | 'aggregateOnly';
    export interface Ns4AccessProfile {
        profileId: string;
        title: string;
        kind: Ns4AccessProfileKind;
        description: string;
        actorRefs: string[];
        landingIntent: string;
    }
    export interface Ns4AccessAuthority {
        authorityRef: string;
        title: string;
        description: string;
        journeyStepRefs: string[];
        informationNeeds: string[];
    }
    export interface Ns4AccessGrant {
        profileRef: string;
        authorityRef: string;
        reason: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        useRules: string[];
    }
    export interface Ns4E3Review {
        planId: 'e3-access-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        changeSummary: string[];
    }
    export interface Ns4E3ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E3Review;
    }
    export interface Ns4AccessMatrixArtifactV2 {
        schemaVersion: typeof NS4_ACCESS_MATRIX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        accessHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromAccessHash: string;
            operationAuthorityRefs: never[];
        };
    }
    export interface Ns4AccessUseCaseAuthorityRef {
        useCaseId: string;
        authorityRef: string;
        journeyStepRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV3 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'useCasesCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: never[];
            realizationHash: string;
        };
    }
    export interface Ns4AccessOperationAuthorityRef {
        operationRef: string;
        route: string;
        workspaceId: string;
        functionId: string;
        useCaseId?: string;
        authorityRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV4 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'navigationCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: Ns4AccessOperationAuthorityRef[];
            realizationHash: string;
        };
    }
    /** Compile-only compatibility for already generated v1 L4 artifacts. */
    export interface Ns4AccessMatrixArtifactV1 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'grants'> {
        schemaVersion: '2026-08-05-ns4-access-matrix-v1';
        grants: Array<Omit<Ns4AccessGrant, 'useRules'> & {
            constraints: string[];
        }>;
    }
    export type Ns4AccessMatrixArtifact = Ns4AccessMatrixArtifactV4 | Ns4AccessMatrixArtifactV3 | Ns4AccessMatrixArtifactV2 | Ns4AccessMatrixArtifactV1;
    export function normalizeNs4E3Review(value: unknown, fallbackModule?: string): Ns4E3Review;
    export function buildNs4AccessMatrixArtifact(review: Ns4E3Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4AccessMatrixArtifactV2>;
}
declare module "_102020_/l2/agentNewSolution/steps/e4/contracts" {
    import { type Ns4SystemDecision } from "_102020_/l2/agentNewSolution/helpers/ns4Resolve";
    export const NS4_ONTOLOGY_SCHEMA_VERSION: "2026-08-11-ns4-ontology-v6";
    export type Ns4EntityKind = 'core' | 'event' | 'supporting' | 'mdm' | 'projection' | 'valueObject';
    /**
     * Is this entity a PARTY — a natural person or an organization?
     *
     * The question decides where the record lives, and it cannot be answered by a name heuristic (the run of
     * buildFlowFsm sent Client and Project to MDM but left FieldWorker — a person — as a module table, seeded,
     * duplicating the organization's own people). Declaring it makes the rule mechanical: a party is master
     * data of the organization, so `storage.target` must be `mdm`, and the gate says so instead of hoping the
     * prompt was read.
     */
    export type Ns4EntityParty = 'person' | 'organization' | 'none';
    export type Ns4EntityOwnership = 'moduleOwned' | 'external' | 'derived';
    export type Ns4DerivationOp = 'count' | 'sum' | 'min' | 'max' | 'first' | 'groupKey';
    /** One output field of a derived projection, computed from the source named by `derivation.from`. */
    export interface Ns4DerivationAggregate {
        fieldId: string;
        op: Ns4DerivationOp;
        /** Source-entity field when the op needs one (`sum`/`min`/`max`/`first`/`groupKey`). Absent for `count`. */
        sourceField?: string;
    }
    /**
     * How a derived projection is computed. OPTIONAL on the type so L4 written before this field keeps
     * compiling — nothing is ever migrated. The E4 gate requires it on every `kind: projection` +
     * `ownership: derived` this generator now produces.
     */
    export interface Ns4EntityDerivation {
        /** entityId of the persisted source; must exist in the same ontology. */
        from: string;
        /** Predicate on declared fields of the source (`status = valid`). Empty when unfiltered. */
        filter: string;
        /** One entry per output field of the projection. */
        aggregate: Ns4DerivationAggregate[];
    }
    export type Ns4ConstraintSource = 'database' | 'journey' | 'user' | 'inferred' | 'legacyCode';
    export type Ns4StorageTarget = 'mdm' | 'moduleDatabase' | 'derived' | 'external' | 'embedded';
    export type Ns4StorageScope = 'organization' | 'module' | 'platform' | 'none';
    export type Ns4RelationshipPersistenceMode = 'mdmRelationship' | 'moduleReference' | 'crossStoreReference' | 'derivedJoin' | 'externalReference' | 'embedded';
    export type Ns4RelationshipRealizationKind = 'fieldReference' | 'fieldCollection' | 'mdmRelationship' | 'derived' | 'externalReference' | 'embedded';
    export interface Ns4RelationshipEndpointBinding {
        entityId: string;
        fieldIds: string[];
    }
    /** Concrete implementation of one semantic edge using fields that already exist in E4 entities. */
    export interface Ns4RelationshipRealization {
        kind: Ns4RelationshipRealizationKind;
        ownerEntity: string;
        from: Ns4RelationshipEndpointBinding;
        to: Ns4RelationshipEndpointBinding;
        description: string;
    }
    export interface Ns4FieldConstraint {
        constraintId: string;
        kind: 'min' | 'max' | 'minLength' | 'maxLength' | 'pattern' | 'enum' | 'format' | 'unique' | 'custom';
        value: string;
        description: string;
        source: Ns4ConstraintSource;
    }
    /** Display text for one closed-domain code. Array-of-objects so the tool schema can stay additionalProperties:false. */
    export interface Ns4EnumLabel {
        code: string;
        label: string;
    }
    export interface Ns4OntologyField {
        fieldId: string;
        title: string;
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        required: boolean;
        description: string;
        constraints: Ns4FieldConstraint[];
        /**
         * The literal values of an enumerated field, derived from its enum constraint (or from the entity
         * lifecycle for a status field). It is what turns a decision into a closed selector on the page
         * instead of a free text box; the constraint stays as the human-readable rule.
         */
        enum?: string[];
        /**
         * User-language labels for `enum` codes. OPTIONAL on the type so L4 written before this field keeps
         * compiling — nothing is ever migrated. New E4 runs backfill any gap with a humanized code and a
         * non-blocking systemDecision; the model should still author the user's language.
         */
        enumLabels?: Ns4EnumLabel[];
    }
    export interface Ns4LifecyclePredicate {
        predicateId: string;
        description: string;
        stateIds: string[];
        source: Ns4ConstraintSource;
    }
    export interface Ns4OntologyEntity {
        entityId: string;
        title: string;
        description: string;
        kind: Ns4EntityKind;
        ownership: Ns4EntityOwnership;
        /**
         * A core entity with one fixed instance (a petition, an institutional page). OPTIONAL so L4
         * written before this field keeps compiling. E8 skips the record catalogue when it is present.
         */
        cardinality?: 'singleton';
        /**
         * Required by the gate for everything this generator now produces; OPTIONAL in the type so the L4
         * artifacts written before it (schema v6, no `party`) keep compiling — nothing is ever migrated.
         */
        party?: Ns4EntityParty;
        /**
         * Required by the gate when `kind === 'projection'` and `ownership === 'derived'`; OPTIONAL in the
         * type so L4 written before this field keeps compiling — nothing is ever migrated.
         */
        derivation?: Ns4EntityDerivation;
        sourceRefs: {
            journeyIds: string[];
            featureIds: string[];
            authorityRefs: string[];
        };
        fields: Ns4OntologyField[];
        lifecycleStates: string[];
        /** The lifecycle values as a literal union; mirrors lifecycleStates and is never a second truth. */
        statusEnum?: string[];
        /** User-language labels for `lifecycleStates`. OPTIONAL on the type; new E4 runs backfill a gap. */
        lifecycleLabels?: Ns4EnumLabel[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates: Ns4LifecyclePredicate[];
        useRules: string[];
        storage: {
            target: Ns4StorageTarget;
            scope: Ns4StorageScope;
            idField?: string;
            mdmType?: string;
            notes: string;
        };
    }
    export interface Ns4OntologyRelationship {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        description: string;
        persistence: {
            mode: Ns4RelationshipPersistenceMode;
        };
        /** Absent only in the compact overview; mandatory before review and permanent emission. */
        realization?: Ns4RelationshipRealization;
    }
    export type Ns4ResolvedOntologyRelationship = Ns4OntologyRelationship & {
        realization: Ns4RelationshipRealization;
    };
    export type Ns4OntologyEntityPlan = Omit<Ns4OntologyEntity, 'fields' | 'useRules'>;
    export interface Ns4E4PlanDraft {
        planId: 'e4-ontology-plan';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntityPlan[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
    }
    export interface Ns4E4EntityDraft {
        planId: 'e4-ontology-entity';
        moduleName: string;
        reviewRound: number;
        entityId: string;
        fields: Ns4OntologyField[];
        useRules: string[];
    }
    export interface Ns4E4RelationshipBinding {
        relationshipId: string;
        realization: Ns4RelationshipRealization;
    }
    export interface Ns4E4RelationshipBindingsDraft {
        planId: 'e4-relationship-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4RelationshipBinding[];
    }
    /** Binding-gate finding that the entity fan-out must repair — travels as a typed payload, not a loose string. */
    export interface Ns4E4EntityFeedback {
        entityId: string;
        feedback: string;
    }
    export interface Ns4E4Review {
        planId: 'e4-ontology-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntity[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
        /** Type C backfills (missing enum/lifecycle labels). Empty when the model authored every label. */
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4E4ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E4Review;
    }
    export interface Ns4OntologyEntityArtifactV5 extends Ns4OntologyEntity {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
    }
    /** Compile-only compatibility for already generated v3 L4 artifacts. */
    export interface Ns4OntologyEntityArtifactV4 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: '2026-08-09-ns4-ontology-v4';
    }
    export interface Ns4OntologyEntityArtifactV3 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion' | 'useRules'> {
        schemaVersion: '2026-08-08-ns4-ontology-v3';
        invariants: Array<{
            invariantId: string;
            description: string;
            source: Ns4ConstraintSource;
        }>;
    }
    export type Ns4OntologyEntityArtifact = Ns4OntologyEntityArtifactV5 | Ns4OntologyEntityArtifactV4 | Ns4OntologyEntityArtifactV3;
    interface Ns4OntologyIndexArtifactBase {
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        title: string;
        businessDomain: string;
        entities: Array<{
            entityId: string;
            title: string;
            kind: Ns4EntityKind;
            storage: Pick<Ns4OntologyEntity['storage'], 'target' | 'scope' | 'idField' | 'mdmType'>;
            definitionRef: string;
        }>;
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromOntologyHash: string;
        };
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4OntologyIndexArtifactV5 extends Ns4OntologyIndexArtifactBase {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        relationships: Ns4ResolvedOntologyRelationship[];
    }
    /** Compile-only compatibility for already generated v3/v4 L4 artifacts. */
    export interface Ns4OntologyIndexArtifactLegacy extends Ns4OntologyIndexArtifactBase {
        schemaVersion: '2026-08-09-ns4-ontology-v4' | '2026-08-08-ns4-ontology-v3';
        relationships: Ns4OntologyRelationship[];
    }
    export type Ns4OntologyIndexArtifact = Ns4OntologyIndexArtifactV5 | Ns4OntologyIndexArtifactLegacy;
    export function normalizeNs4E4Review(value: unknown, fallbackModule?: string): Ns4E4Review;
    /** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
    export function humanizeNs4EnumCode(code: string): string;
    export function normalizeNs4E4PlanDraft(value: unknown, fallbackModule?: string): Ns4E4PlanDraft;
    export function normalizeNs4E4EntityDraft(value: unknown, moduleName: string, reviewRound: number, entityId: string): Ns4E4EntityDraft;
    /**
     * Removes the derived literal union from fields before they are echoed back to an entity worker.
     * The union is a projection E4 adds for the consumers; the worker's strict tool schema forbids the
     * key, so showing it in a prompt would invite an invalid repair answer.
     */
    export function stripNs4DerivedFieldUnions<T extends {
        fields?: unknown;
    }>(value: T): T;
    export function stripNs4DerivedFieldUnions(value: Ns4OntologyField[]): Ns4OntologyField[];
    export function assembleNs4E4Review(plan: Ns4E4PlanDraft, details: Ns4E4EntityDraft[]): Ns4E4Review;
    export function normalizeNs4E4RelationshipBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4RelationshipBindingsDraft;
    export function applyNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft): Ns4E4Review;
    export function buildNs4OntologyArtifacts(review: Ns4E4Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<{
        entities: Ns4OntologyEntityArtifactV5[];
        index: Ns4OntologyIndexArtifactV5;
    }>;
}
declare module "_102020_/l2/agentNewSolution/steps/e5/contracts" {
    export const NS4_RULES_SCHEMA_VERSION: "2026-08-09-ns4-rules-v2";
    /** The permanent business-rule contract. Meaning lives here; consumers keep only the id. */
    export interface Ns4RuleDefinition {
        id: string;
        description: string;
    }
    export interface Ns4E5Review {
        planId: 'e5-rules-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        rules: Ns4RuleDefinition[];
        changeSummary: string[];
    }
    export interface Ns4E5ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E5Review;
    }
    export interface Ns4RulesArtifact {
        schemaVersion: typeof NS4_RULES_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        rules: Ns4RuleDefinition[];
        rulesHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromRulesHash: string;
        };
    }
    export function normalizeNs4E5Review(value: unknown, fallbackModule?: string): Ns4E5Review;
    export function buildNs4RulesArtifact(review: Ns4E5Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4RulesArtifact>;
}
declare module "_102020_/l2/agentNewSolution/steps/e6/contracts" {
    export const NS4_COMPOSITION_SCHEMA_VERSION: "2026-08-09-ns4-composition-v1";
    export type Ns4AdditionalCapabilityKind = 'horizontalModule' | 'plugin';
    export type Ns4AdditionalCapabilityDecision = 'include' | 'defer';
    export interface Ns4AdditionalCapability {
        id: string;
        kind: Ns4AdditionalCapabilityKind;
        title: string;
        purpose: string;
        decision: Ns4AdditionalCapabilityDecision;
    }
    export interface Ns4E6Review {
        planId: 'e6-composition-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        changeSummary: string[];
    }
    export interface Ns4E6ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E6Review;
    }
    export interface Ns4CompositionArtifact {
        schemaVersion: typeof NS4_COMPOSITION_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        compositionHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromCompositionHash: string;
        };
    }
    export function normalizeNs4E6Review(value: unknown, fallbackModule?: string): Ns4E6Review;
    export function buildNs4CompositionArtifact(review: Ns4E6Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4CompositionArtifact>;
}
declare module "_102020_/l2/agentNewSolution/steps/e7/reachability" {
    export interface Ns4ReachabilityTransition {
        fromStates: string[];
        toState: string;
    }
    /** The single E7 definition used by both workflow compilation and its post-resolution gate. */
    export function collectNs4ReachableWorkflowStates(initialState: string, transitions: Ns4ReachabilityTransition[]): Set<string>;
    /**
     * Shrinks unreachable states and their outgoing transitions until no new orphan target appears.
     * fromStates are alternatives, so a transition survives while at least one source remains.
     */
    export function shrinkNs4WorkflowToReachable<TTransition extends Ns4ReachabilityTransition>(initialState: string, sourceStates: string[], sourceTransitions: TTransition[]): {
        states: string[];
        transitions: TTransition[];
        removedStates: string[];
    };
}
declare module "_102020_/l2/agentNewSolution/steps/e7/contracts" {
    import type { Ns4E2Review, Ns4JourneyArtifact, Ns4JourneyArtifactV5Realized, Ns4JourneyIndex } from "_102020_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact, Ns4AccessMatrixArtifactV3 } from "_102020_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyField } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4SystemDecision } from "_102020_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4DerivedContextGraph } from "_102020_/l2/agentNewSolution/helpers/ns4Context";
    export const NS4_USE_CASE_DRAFT_VERSION: "2026-08-10-ns4-usecase-draft-minimal-v3";
    export const NS4_USE_CASE_SCHEMA_VERSION: "2026-08-10-ns4-usecase-v3";
    export const NS4_USE_CASE_INDEX_SCHEMA_VERSION: "2026-08-10-ns4-usecase-index-v3";
    export const NS4_WORKFLOW_SCHEMA_VERSION: "2026-08-11-ns4-workflow-v4";
    export const NS4_WORKFLOW_INDEX_SCHEMA_VERSION: "2026-08-12-ns4-workflow-index-v5";
    export type Ns4UseCaseKind = 'query' | 'command';
    export type Ns4UseCaseFieldType = Ns4OntologyField['type'];
    export interface Ns4E7SourceHashes {
        journeys: Array<{
            journeyId: string;
            businessHash: string;
        }>;
        ontologyHash: string;
        rulesHash: string;
    }
    export interface Ns4E7PlanUseCase {
        useCaseId: string;
        title: string;
        kind: Ns4UseCaseKind;
        compiledFrom: string[];
        contexts: {
            requires: string[];
            provides: string[];
        };
    }
    export interface Ns4E7PlanDraft {
        planId: 'e7-realization-plan';
        moduleName: string;
        userLanguage: string;
        useCases: Ns4E7PlanUseCase[];
        sourceHashes: Ns4E7SourceHashes;
    }
    export interface Ns4UseCaseFieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4UseCaseInput {
        inputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseOutput {
        outputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        contextId?: string;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseEntityAccess {
        entityId: string;
        fieldRefs: string[];
    }
    export interface Ns4UseCaseTransition {
        transitionId: string;
        entityRef: string;
        fromStates: string[];
        toState: string;
        useRules: string[];
    }
    export interface Ns4UseCaseError {
        errorId: string;
        description: string;
        when: string;
        useRules: string[];
    }
    export interface Ns4UseCaseDraft extends Ns4E7PlanUseCase {
        draftVersion: typeof NS4_USE_CASE_DRAFT_VERSION;
        planId: 'e7-usecase';
        moduleName: string;
        description: string;
        contexts: {
            requires: string[];
            provides: string[];
        };
        entityRefs: string[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
    }
    export interface Ns4UseCaseArtifactV3 extends Omit<Ns4UseCaseDraft, 'planId' | 'draftVersion' | 'transitions'> {
        schemaVersion: typeof NS4_USE_CASE_SCHEMA_VERSION;
        transitionRefs: string[];
        useCaseHash: string;
    }
    export interface Ns4UseCaseIndexArtifactV3 {
        schemaVersion: typeof NS4_USE_CASE_INDEX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowTransition extends Ns4UseCaseTransition {
        useCaseId?: string;
        trigger?: 'system';
    }
    /** Lifecycle facts are owned by E4 and copied mechanically into E7 workflows. */
    export interface Ns4WorkflowLifecycleDefinition {
        states: string[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
    }
    export interface Ns4WorkflowArtifactV2 {
        schemaVersion: typeof NS4_WORKFLOW_SCHEMA_VERSION;
        moduleName: string;
        workflowId: string;
        entityRef: string;
        initialState: string;
        terminalStates: string[];
        states: string[];
        transitions: Ns4WorkflowTransition[];
        workflowHash: string;
    }
    export interface Ns4WorkflowIndexArtifactV2 {
        schemaVersion: '2026-08-11-ns4-workflow-index-v4';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifactV3 extends Omit<Ns4WorkflowIndexArtifactV2, 'schemaVersion'> {
        schemaVersion: typeof NS4_WORKFLOW_INDEX_SCHEMA_VERSION;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4UseCaseArtifact extends Ns4E7PlanUseCase {
        schemaVersion: '2026-08-10-ns4-usecase-v2';
        moduleName: string;
        description: string;
        inputs: Ns4UseCaseInput[];
        outputs: Ns4UseCaseOutput[];
        reads: Ns4UseCaseEntityAccess[];
        writes: Ns4UseCaseEntityAccess[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
        errors: Ns4UseCaseError[];
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCaseHash: string;
        generatedAt: string;
    }
    export interface Ns4UseCaseIndexArtifact {
        schemaVersion: '2026-08-10-ns4-usecase-index-v2';
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-v1';
        moduleName: string;
        userLanguage: string;
        workflowId: string;
        entityRef: string;
        states: string[];
        transitions: Ns4WorkflowTransition[];
        sourceHashes: Ns4E7SourceHashes;
        workflowHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-index-v1';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    /** Contexts come from the derivation, never from the journey text: E7 copies no declared name. */
    export function buildNs4E7Plan(moduleName: string, userLanguage: string, journeys: Ns4E2Review, sourceHashes: Ns4E7SourceHashes, contexts: Ns4DerivedContextGraph): Ns4E7PlanDraft;
    export function normalizeNs4UseCaseDraft(value: unknown, plan: Ns4E7PlanDraft, useCaseId: string): Ns4UseCaseDraft;
    export function buildNs4UseCaseArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], generatedAt: string): Promise<{
        artifacts: Ns4UseCaseArtifactV3[];
        index: Ns4UseCaseIndexArtifactV3;
    }>;
    export function buildNs4WorkflowArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], ontologyLifecycles: Map<string, Ns4WorkflowLifecycleDefinition>, generatedAt: string): Promise<{
        artifacts: Ns4WorkflowArtifactV2[];
        index: Ns4WorkflowIndexArtifactV3;
    }>;
    export function buildNs4RealizedJourneyArtifact(source: Ns4JourneyArtifact, useCases: Ns4UseCaseArtifactV3[], derived: Ns4DerivedContextGraph): Promise<Ns4JourneyArtifactV5Realized>;
    export function buildNs4RealizedJourneyIndex(source: Ns4JourneyIndex, journeys: Ns4JourneyArtifactV5Realized[]): Promise<Ns4JourneyIndex>;
    export function buildNs4RealizedAccessArtifact(source: Ns4AccessMatrixArtifact, useCases: Ns4UseCaseArtifactV3[]): Promise<Ns4AccessMatrixArtifactV3>;
}
declare module "_102020_/l2/agentNewSolution/steps/e8/model" {
    /**
     * The E8 workspace model: every screen of the module, in the shape E9 transposes into the classic
     * L4 format without taking a single decision of its own.
     *
     * A screen is a place: the record catalogue of an entity (tier 1), an approved journey that is
     * itself a place (tier 2: distinct actor, eventDriven/contextRequired, or more than one entity),
     * the hub of the dominant anchor when it has related lists or projection tiles (tier 3),
     * or a content page (`contentPage`) when E1 names an informative/institutional/public-campaign
     * page. A journey of the same actor on an entity the catalogue already shows is hosted there
     * (`hostedStepRefs`); it is not another kind of page.
     */
    import type { Ns4SystemDecision } from "_102020_/l2/agentNewSolution/helpers/ns4Resolve";
    export const NS4_E8_MODEL_VERSION: "2026-08-14-ns4-e8-model-v1";
    export type Ns4WorkspaceTier = 'recordCatalogue' | 'journey' | 'hub' | 'projection' | 'contentPage';
    /** Organisms of type `content` use these roles; they exist only on a `contentPage`. */
    export type Ns4E8ContentRole = 'hero' | 'richText' | 'imageSet' | 'ctaLink';
    /**
     * The only origins a page can render by, in the vocabulary the frontend actually reads from an
     * operation input: userInput is a form field, selectedEntity is a picker over a query on the page,
     * routeParam comes from the URL, and the rest is resolved at runtime and never rendered.
     */
    export type Ns4E8InputSource = 'userInput' | 'selectedEntity' | 'routeParam' | 'actorSession' | 'systemDefault';
    /**
     * The record-owner handle: `ownerId` / `ownerUserId` / `customerId` / `clientId`, or a field
     * ending in `OwnerId`. Not every person FK — `assignedUserId` is a choice the actor makes.
     */
    export function isNs4OwnerHandleField(fieldId: string): boolean;
    export type Ns4E8AccessPatternKind = 'list' | 'getById' | 'create' | 'update' | 'delete' | 'transition' | 'commandInput';
    export interface Ns4E8FieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4E8Input {
        inputId: string;
        fieldRef: Ns4E8FieldRef;
        source: Ns4E8InputSource;
        required: boolean;
        description: string;
        /** The literal union of an enumerated field, carried from the approved ontology. */
        enumValues?: string[];
        /** Present when the input is not the borrowed fieldRef's type (`page`/`pageSize` are numbers). */
        type?: 'number' | 'boolean' | 'string';
    }
    /**
     * One operation of the module. A journey step compiles into the E7 use case it already owns; a
     * record catalogue synthesizes its five operations from the ontology (list, getById, create,
     * update, and delete or the mdm inactivate/reactivate pair), because E7 only compiles journeys
     * and a catalogue is not a journey. getById is emitted even when no page consumes it.
     */
    /**
     * Master-data semantics of one operation. Master data is referenced by other
     * records, so an mdm catalogue deactivates instead of deleting.
     *
     * It is ONE optional block on purpose. The backend generator reads this artifact
     * as JSON and its accessPattern vocabulary is a closed set, so the lifecycle pair
     * keeps `kind: 'update'` — a command that mutates one identified record, which the
     * consumer already understands — and the meaning travels here. A consumer that
     * ignores the block behaves exactly as before.
     */
    export interface Ns4E8MdmSemantics {
        /** The command replaces a hard delete: route it to the MDM record lifecycle. */
        lifecycle?: 'inactivate' | 'reactivate';
        /** Optional request flag on a list: absent means only active records. */
        activeFilterInput?: 'includeInactive';
        /**
         * Response member carrying the situation. Derived from the MDM record lifecycle,
         * so it is NOT an ontology field and deliberately has no field ref: the ontology
         * declares no `active` field and the model must not invent one.
         */
        situationOutput?: 'active';
    }
    export interface Ns4E8Operation {
        operationId: string;
        title: string;
        kind: 'query' | 'command';
        entityRef: string;
        entityRefs: string[];
        accessPattern: {
            kind: Ns4E8AccessPatternKind;
            pagination?: 'optional';
        };
        inputs: Ns4E8Input[];
        outputRefs: string[];
        useRules: string[];
        transitionRefs: string[];
        story: string[];
        /** Present when the operation is an approved E7 use case; absent when the catalogue derived it. */
        useCaseId?: string;
        /** Present only on a catalogue operation of an entity whose storage.target is mdm. */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4E8BffCall {
        bffId: string;
        kind: 'query' | 'command';
        operationId: string;
        outputKind: 'object' | 'list' | 'paginated';
        entityRef: string;
        /**
         * Which LOCAL call feeds each input of this one. Operations are shared and calls are per workspace,
         * so "where the user picks this record from" is a property of the call, never of the operation.
         * Without it the screen knows an id must be chosen and not which query to choose it from.
         */
        inputSources?: Array<{
            inputId: string;
            bffId: string;
        }>;
    }
    export type Ns4E8OrganismRole = 'primarySurface' | 'detailPanel' | 'filterControl' | 'contextualAction' | Ns4E8ContentRole;
    export interface Ns4E8Organism {
        role: Ns4E8OrganismRole;
        /** Present only on a content organism (hero/richText/imageSet/ctaLink). Never on a data-bound surface. */
        type?: 'content';
        dataSource?: string;
        action?: string;
        /** A picker is a query rendered to choose the record another call consumes. summary is counts of that list, not a row. */
        usage?: 'picker' | 'summary';
        /** Query bffId whose optional list inputs (search/sort) this filterControl drives. */
        attachTo?: string;
    }
    export interface Ns4E8Section {
        sectionId: string;
        intent: string;
        organisms: Ns4E8Organism[];
    }
    export interface Ns4E8ModelWorkspace {
        workspaceId: string;
        tier: Ns4WorkspaceTier;
        title: string;
        purpose: string;
        /** Classic workspace kind: operation, workflow, landing or record. */
        kind: 'operation' | 'workflow' | 'landing' | 'record';
        entity: string;
        workflowId?: string;
        actors: string[];
        profileRefs: string[];
        featureRefs: string[];
        hostedStepRefs: string[];
        journeyRef?: string;
        categoryRef: string;
        bffCalls: Ns4E8BffCall[];
        sections: Ns4E8Section[];
        /** Only a hub carries the closed catalogue its composition call may order and name. */
        hubCatalogue?: Ns4E8HubCatalogue;
        /** Workspaces this one links to; the site map turns them into navigation edges. */
        navigation?: Ns4E8NavigationTarget[];
    }
    export interface Ns4E8HubCatalogueItem {
        itemId: string;
        kind: 'projectionTile' | 'relatedList' | 'action' | 'pending';
        label: string;
        entityRef: string;
        /** The workspace the item belongs to; never invented by the composition call. */
        targetRef: string;
        /**
         * For an item the hub READS: the operation behind it. Operations are shared across the module and
         * calls are per workspace, so a tile becomes a local call of the hub over the same operation — an
         * organism only ever consumes a call of its own workspace.
         */
        sourceOperationId?: string;
        sourceBffId?: string;
        /** The shape the source call declares; a list read as an object would project a single record. */
        sourceOutputKind?: 'object' | 'list' | 'paginated';
        score: number;
    }
    /**
     * A journey reached from the hub is NAVIGATION, not an embedded command: it leaves the sections and
     * travels to the site map, carrying the prominence and order the composition chose.
     */
    export interface Ns4E8NavigationTarget {
        targetWorkspaceId: string;
        label: string;
        prominence: 'primary' | 'contextual';
        order: number;
    }
    export interface Ns4E8HubCatalogue {
        anchorEntity: string;
        items: Ns4E8HubCatalogueItem[];
    }
    export interface Ns4E8HubComposition {
        workspaceId: string;
        title: string;
        /** Catalogue item ids, in display order. Never a new id. */
        tileOrder: string[];
        primaryActionIds: string[];
        labels: Array<{
            itemId: string;
            label: string;
        }>;
        menuGroups: Array<{
            groupId: string;
            label: string;
            itemIds: string[];
        }>;
    }
    export interface Ns4E8MenuEntry {
        workspaceId: string;
        label: string;
        featureRef: string;
        tier: Ns4WorkspaceTier;
        profileRefs: string[];
    }
    export interface Ns4E8Model {
        planId: 'e8-workspace-model';
        schemaVersion: typeof NS4_E8_MODEL_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        hubEntity: string;
        workspaces: Ns4E8ModelWorkspace[];
        operations: Ns4E8Operation[];
        /** The menu lists places only: catalogues, hubs, projections and content pages. A journey is never a menu item. */
        menu: Ns4E8MenuEntry[];
        landings: Array<{
            profileRef: string;
            workspaceId: string;
        }>;
        systemDecisions: Ns4SystemDecision[];
        modelHash?: string;
    }
}
declare module "_102020_/l2/agentNewSolution/steps/e9/classic" {
    /**
     * E9 is a transpiler. It takes no screen decision: every workspace, call, section and operation was
     * already decided by E8. What lives here is the shape the consumers read — the classic L4 format
     * that agentChangeBackend and agentChangeFrontend already parse today.
     *
     * The one thing that must be exactly right is the `from` path of a projected field,
     * `"<operationId>.<inputId>"`, because both consumers trace an input's origin and an enumerated
     * field's literal union back through it (cbContracts.resolveBffProjection and
     * cfeL4Contract.bffCallCommandShape).
     */
    import type { Ns4E4Review } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4E8Input, Ns4E8MdmSemantics, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation } from "_102020_/l2/agentNewSolution/steps/e8/model";
    export const NS4_CLASSIC_WORKSPACE_VERSION: "2026-08-14-ns4-classic-workspace-v6";
    export interface Ns4ClassicField {
        name: string;
        from: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: Ns4ClassicField[];
        };
    }
    export interface Ns4ClassicBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: Array<{
            operationId: string;
        }>;
        input: Array<{
            name: string;
            from: string;
            required?: boolean;
            source: string;
            sourceRef?: string;
            type: string;
            enumValues?: string[];
        }>;
        output: {
            kind: 'object' | 'list' | 'paginated';
            fields: Ns4ClassicField[];
        };
        route: string;
    }
    export interface Ns4ClassicWorkspace {
        workspaceId: string;
        title: string;
        actors: string[];
        kind: string;
        entity: string;
        workflowId?: string;
        bffCalls: Ns4ClassicBffCall[];
        sections: Array<{
            sectionId: string;
            intent: string;
            organisms: Array<Record<string, string>>;
        }>;
        operationIds: string[];
        purpose: string;
        presentation: {
            categoryRef: string;
            confidence: number;
            classificationNote: string;
        };
        sliceHash: string;
    }
    export interface Ns4ClassicOperation {
        operationId: string;
        title: string;
        actors: string[];
        entity: string;
        kind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        story: {
            actor: string;
            goal: string;
            steps: string[];
            outcome: string;
        };
        accessPattern: {
            kind: string;
            description: string;
            entity: string;
            keyField: string;
            pagination: string;
            selection: string;
            output: string[];
        };
        outputShape: {
            kind: 'object' | 'list' | 'paginated';
            fields: Array<{
                name: string;
                type: string;
                required: boolean;
                fieldRef?: string;
                item?: {
                    fields: Array<{
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }>;
                };
            }>;
        };
        inputs: Array<{
            inputId: string;
            fieldRef: string;
            required: boolean;
            source: string;
            description: string;
            enumValues?: string[];
            type?: string;
        }>;
        pageId: string;
        commandName: string;
        bffName: string;
        /**
         * Carried verbatim from the model when the operation is a master-data catalogue
         * operation. It is what lets the backend generator route the lifecycle pair to
         * the MDM facade and keep the list active-only. Optional, so a consumer that
         * ignores it is unaffected.
         */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4ClassicSiteMap {
        moduleName: string;
        note: string;
        workspaces: Array<{
            workspaceId: string;
            title: string;
            actors: string[];
            kind: string;
            entity: string;
            operationIds: string[];
            purpose: string;
        }>;
        landings: Array<{
            actorId: string;
            workspaceId: string;
            reason: string;
        }>;
        navigationEdges: Array<{
            from: string;
            to: string;
            operationId: string;
            description: string;
            prominence?: 'primary' | 'contextual';
            order?: number;
        }>;
        workspaceIds: string[];
    }
    /** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
    export function ns4ClassicFrom(operationId: string, member: string): string;
    export function transposeNs4ClassicOperation(model: Ns4E8Model, operation: Ns4E8Operation, ontology: Ns4E4Review): Ns4ClassicOperation;
    export function transposeNs4ClassicWorkspace(model: Ns4E8Model, workspace: Ns4E8ModelWorkspace, operations: Map<string, Ns4E8Operation>, ontology: Ns4E4Review, sliceHash: string): Ns4ClassicWorkspace;
    /** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
    export function buildNs4ClassicContractSource(args: {
        moduleName: string;
        workspaceId: string;
        call: Ns4ClassicBffCall;
        fileRef: string;
        sourceRef: string;
    }): string;
    export function buildNs4ClassicSiteMap(model: Ns4E8Model, classic: Ns4ClassicWorkspace[]): Ns4ClassicSiteMap;
    /** Declared collection name on the wire — never the generic `items`. */
    export function collectionFieldName(entityId: string): string;
    export interface Ns4ClassicL4 {
        workspaces: Ns4ClassicWorkspace[];
        operations: Ns4ClassicOperation[];
        contracts: Array<{
            workspaceId: string;
            bffId: string;
            route: string;
            source: string;
        }>;
        siteMap: Ns4ClassicSiteMap;
    }
    /** The whole transposition: what E9 writes to L4 from an approved E8 model. */
    export function compileNs4ClassicL4(model: Ns4E8Model, ontology: Ns4E4Review): Promise<Ns4ClassicL4>;
    export type Ns4ClassicInput = Ns4E8Input;
}
declare module "_102020_/l2/agentNewSolution/steps/e10/contracts" {
    import { type Ns4JourneyIndex, type Ns4PolicyDecisionSelection } from "_102020_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4OntologyIndexArtifact } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102020_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4UseCaseIndexArtifactV3, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102020_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102020_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E2Review } from "_102020_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102020_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102020_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4E8Model } from "_102020_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4ClassicL4 } from "_102020_/l2/agentNewSolution/steps/e9/classic";
    export const NS4_E10_VALIDATION_REPORT_VERSION: "2026-08-15-ns4-e10-validation-report-v2";
    export const NS4_L5_TODO_FRONTEND_VERSION: "2026-08-13-ns4-todo-frontend-v1";
    export const NS4_L5_TODO_BACKEND_VERSION: "2026-08-13-ns4-todo-backend-v1";
    export const NS4_L5_PROCESS_VERSION: "2026-08-13-ns4-process-v1";
    export const NS4_E10_MENU_LIMIT: 7;
    export type Ns4E10RepairStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler';
    /** E10 validates the approved E8 model against the classic L4 that E9 actually wrote to disk. */
    export interface Ns4E10Sources {
        moduleName: string;
        userLanguage: string;
        journeys: Ns4E2Review;
        journeyIndex: Ns4JourneyIndex;
        ontology: Ns4E4Review;
        ontologyIndex: Ns4OntologyIndexArtifact;
        rules: Ns4RulesArtifact;
        access: Ns4AccessMatrixArtifact;
        useCases: Ns4UseCaseArtifactV3[];
        useCaseIndex: Ns4UseCaseIndexArtifactV3;
        workflows: Ns4WorkflowArtifactV2[];
        workflowIndex: Ns4WorkflowIndexArtifactV2 | Ns4WorkflowIndexArtifactV3;
        model: Ns4E8Model;
        /** What E9 emitted, read back from L4: the staleness check compares it to a fresh compilation. */
        saved: Ns4ClassicL4;
    }
    export interface Ns4E10Issue {
        code: string;
        path: string;
        message: string;
        repairStep?: Ns4E10RepairStep;
    }
    export interface Ns4E10CheckSummary {
        checkId: 'A1-resolution' | 'A2-journeys' | 'A3-decisions' | 'A4-disclosure' | 'A5-fsm' | 'A6-staleness' | 'A7-warnings' | 'A8-dormant-commands';
        status: 'passed' | 'failed' | 'reported';
        errorCount: number;
        warningCount: number;
        registrarCount: number;
    }
    export interface Ns4L5NavigationItem {
        id: string;
        label: string;
        href: string;
        description: string;
        actors: string[];
        workspaceId: string;
        scenarioId: string;
        sectionId: string;
        hub?: string;
    }
    export interface Ns4L5HeaderLink {
        id: string;
        label: string;
        href: string;
        actors: string[];
        manageable: true;
        hub?: string;
    }
    export interface Ns4L5ModuleNavigation {
        moduleId: string;
        basePath: string;
        userLanguage: string;
        navigation: Ns4L5NavigationItem[];
        headerLinks: Ns4L5HeaderLink[];
    }
    export interface Ns4E10ValidationReport {
        schemaVersion: typeof NS4_E10_VALIDATION_REPORT_VERSION;
        moduleName: string;
        userLanguage: string;
        finalStatus: 'passed' | 'failed';
        checks: Ns4E10CheckSummary[];
        errors: Ns4E10Issue[];
        warnings: Ns4E10Issue[];
        registrars: Ns4E10Issue[];
        policyDecisions: Ns4PolicyDecisionSelection[];
        systemDecisions: Ns4SystemDecision[];
        repairStep?: Ns4E10RepairStep;
        /**
         * The failure is a defect of the pipeline itself, not of the product: no step can repair it, so
         * nothing is marked stale and the module waits for a fixed pipeline instead of re-running whole.
         */
        pipelineDefect?: true;
        sourceHashes: {
            journeys: Array<{
                journeyId: string;
                businessHash: string;
            }>;
            accessHash: string;
            ontologyHash: string;
            rulesHash: string;
        };
        counts: {
            journeys: number;
            workspaces: number;
            operations: number;
            contracts: number;
            decisions: number;
        };
        menuPreview: Ns4L5ModuleNavigation;
        reportHash: string;
    }
    /**
     * e10 always EMITS 'toCreate', but the todo file is the ledger the downstream agents own: changeBackend
     * and changeFrontend flip each owner to 'inProgress' and 'done' in place, keeping the `satisfies` the
     * generator wrote. Pinning the literal made the artifact stop type-checking as soon as work progressed —
     * 264 TS2322 in one module's todoFrontend. The type describes the file, so it carries the whole lifecycle.
     */
    export type Ns4L5OwnerStatus = 'toCreate' | 'inProgress' | 'done';
    export interface Ns4L5FrontendOwner {
        ownerType: 'workspace' | 'contract';
        ownerId: string;
        workspaceId: string;
        statusFrontend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5BackendOwner {
        ownerType: 'useCase';
        ownerId: string;
        statusBackend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5TodoFrontendArtifact {
        schemaVersion: typeof NS4_L5_TODO_FRONTEND_VERSION;
        layer: 'frontend';
        moduleName: string;
        owners: Ns4L5FrontendOwner[];
    }
    export interface Ns4L5TodoBackendArtifact {
        schemaVersion: typeof NS4_L5_TODO_BACKEND_VERSION;
        layer: 'backend';
        moduleName: string;
        owners: Ns4L5BackendOwner[];
    }
    export interface Ns4L5ProcessArtifact {
        schemaVersion: typeof NS4_L5_PROCESS_VERSION;
        moduleName: string;
        sourceHashes: Ns4E10ValidationReport['sourceHashes'];
        counts: Ns4E10ValidationReport['counts'];
        validation: {
            status: 'passed';
            reportPath: string;
            reportHash: string;
            warningCount: number;
            registrarCount: number;
        };
        next: {
            frontend: 'todoFrontend';
            backend: 'todoBackend';
        };
        processHash: string;
    }
    export interface Ns4E10Delivery {
        config: Record<string, unknown>;
        moduleNavigation: Ns4L5ModuleNavigation;
        todoFrontend: Ns4L5TodoFrontendArtifact;
        todoBackend: Ns4L5TodoBackendArtifact;
        process: Ns4L5ProcessArtifact;
    }
    /**
     * The L5 menu preview. The frontend rebuilds navigation as E8 `model.menu` ∩ materialized pages
     * (nodejsSaveConfigJson.ts), with `/<module>/<workspaceId>` as the href — this mirrors that
     * derivation so the report shows the menu the module will actually have.
     */
    export function compileNs4L5ModuleNavigation(sources: Ns4E10Sources): Ns4L5ModuleNavigation;
    export function compileNs4E10Delivery(sources: Ns4E10Sources, report: Ns4E10ValidationReport, existingConfig: unknown, projectId: number): Promise<Ns4E10Delivery>;
    export function mergeNs4L5Config(existing: unknown, projectId: number, moduleNavigation: Ns4L5ModuleNavigation): Record<string, unknown>;
}
declare module "_102020_/l2/agentNewSolution/steps/e8/contracts" {
    import type { Ns4E2Review, Ns4PolicyDecisionSelection } from "_102020_/l2/agentNewSolution/steps/e2/contracts";
    import { type Ns4DerivedContext } from "_102020_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4E3Review } from "_102020_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102020_/l2/agentNewSolution/steps/e7/contracts";
    export interface Ns4E8HubScore {
        entityRef: string;
        score: number;
        anchoredJourneyCount: number;
        requiredRelationshipCount: number;
        projectionCount: number;
        locateUseCaseCount: number;
    }
    /** A workspace context is exactly the derived journey context; E8 never invents another shape. */
    export type Ns4WorkspaceContext = Ns4DerivedContext;
    /**
     * The E1 prose a contentPage may quote into organisms. Detection itself is structural
     * (public external grant + singleton read) — this blob is copy, not the door.
     */
    export interface Ns4E8ModuleSignals {
        title: string;
        purpose: string;
        mainGoal?: string;
        expectedOutcomes?: Array<{
            outcomeId?: string;
            title: string;
            description: string;
        }>;
        inScope?: string[];
        outOfScope?: string[];
        boundaries?: string;
    }
    /** The approved contracts every E8 derivation reads. */
    export interface Ns4E8Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        useCases: Ns4UseCaseArtifactV3[];
        workflows: Ns4WorkflowArtifactV2[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        module?: Ns4E8ModuleSignals;
    }
    export interface Ns4E8Edge {
        from: string;
        to: string;
        carries: string[];
        preferredFromJourneyRef?: string;
    }
    export function deriveE8HubScore(sources: Ns4E8Sources, derived?: import("/_102020_/l2/agentNewSolution/helpers/ns4Context.js").Ns4DerivedContextGraph): Ns4E8HubScore[];
    export function isPlatformOwnedEntity(entity: Ns4E4Review['entities'][number]): boolean;
    /**
     * Compile-only compatibility for workspaces written by the previous E8 model (runs 38-44). They are
     * never read or migrated — the union exists so already-generated L4 folders keep type-checking.
     */
    export interface Ns4WorkspaceArtifact {
        schemaVersion: string;
        moduleName: string;
        workspaceId: string;
        kind: string;
        title: string;
        description: string;
        anchorEntity?: string;
        profileRefs: string[];
        pageContext: Array<Record<string, unknown>>;
        scenarios: Array<Record<string, unknown>>;
        viewCall: {
            uses: Array<Record<string, unknown>>;
        };
        commands: string[];
        invalidations: Array<{
            useCaseId: string;
            sliceIds: string[];
        }>;
        skeletonHash: string;
        workspaceHash: string;
    }
    export interface Ns4WorkspaceIndex {
        schemaVersion: string;
        moduleName: string;
        userLanguage: string;
        workspaces: Array<Record<string, unknown>>;
        hubs: Array<Record<string, unknown>>;
        menu: Record<string, unknown>;
        skeletonHash: string;
        systemDecisions: Array<Record<string, unknown>>;
        approvedBy: string;
        approvedAt: string;
    }
}
declare module "_102020_/l2/agentNewSolution/types" {
    import type { Ns4ModuleArtifact } from "_102020_/l2/agentNewSolution/helpers/ns4Core";
    import type { Ns4JourneyArtifact, Ns4JourneyIndex } from "_102020_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102020_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102020_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4CompositionArtifact } from "_102020_/l2/agentNewSolution/steps/e6/contracts";
    import type { Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102020_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact } from "_102020_/l2/agentNewSolution/steps/e10/contracts";
    export type { Ns4ApprovedBy, Ns4CompletedStepId, Ns4E1Status, Ns4E2Status, Ns4E3Status, Ns4E4Status, Ns4E5Status, Ns4E6Status, Ns4E7Status, Ns4E8Status, Ns4E9Status, Ns4E10Status, Ns4ModuleArtifact, Ns4NextStep, Ns4PipelineState, Ns4Presentation, } from "_102020_/l2/agentNewSolution/helpers/ns4Core";
    export type { Ns4E2Feature, Ns4E2Review, Ns4E2ReviewEvent, Ns4FeaturePriority, Ns4JourneyArtifact, Ns4JourneyBusiness, Ns4JourneyEntryMode, Ns4JourneyIndex, Ns4JourneyProposal, Ns4JourneyStep, Ns4JourneyStepKind, Ns4LegacyJourneyArtifact, Ns4LegacyJourneyBusiness, Ns4LegacyJourneyContext, Ns4PolicyDecision, Ns4PolicyDecisionSelection, } from "_102020_/l2/agentNewSolution/steps/e2/contracts";
    export type { Ns4AccessAuthority, Ns4AccessMatrixArtifactV4, Ns4AccessOperationAuthorityRef, Ns4AccessGrant, Ns4AccessMatrixArtifact, Ns4AccessProfile, Ns4AccessProfileKind, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review, Ns4E3ReviewEvent, } from "_102020_/l2/agentNewSolution/steps/e3/contracts";
    export type { Ns4ConstraintSource, Ns4DerivationAggregate, Ns4DerivationOp, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBinding, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4ReviewEvent, Ns4EntityDerivation, Ns4EntityKind, Ns4EntityOwnership, Ns4FieldConstraint, Ns4LifecyclePredicate, Ns4OntologyEntity, Ns4OntologyEntityArtifact, Ns4OntologyEntityPlan, Ns4OntologyField, Ns4OntologyIndexArtifact, Ns4OntologyRelationship, Ns4RelationshipEndpointBinding, Ns4RelationshipPersistenceMode, Ns4RelationshipRealization, Ns4RelationshipRealizationKind, Ns4ResolvedOntologyRelationship, Ns4StorageScope, Ns4StorageTarget, } from "_102020_/l2/agentNewSolution/steps/e4/contracts";
    export type { Ns4E5Review, Ns4E5ReviewEvent, Ns4RuleDefinition, Ns4RulesArtifact, } from "_102020_/l2/agentNewSolution/steps/e5/contracts";
    export type { Ns4AdditionalCapability, Ns4AdditionalCapabilityDecision, Ns4AdditionalCapabilityKind, Ns4CompositionArtifact, Ns4E6Review, Ns4E6ReviewEvent, } from "_102020_/l2/agentNewSolution/steps/e6/contracts";
    export type { Ns4E7PlanDraft, Ns4E7PlanUseCase, Ns4E7SourceHashes, Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseDraft, Ns4UseCaseEntityAccess, Ns4UseCaseError, Ns4UseCaseFieldRef, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4UseCaseInput, Ns4UseCaseKind, Ns4UseCaseOutput, Ns4UseCaseTransition, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4WorkflowTransition, } from "_102020_/l2/agentNewSolution/steps/e7/contracts";
    export type { Ns4E8Edge, Ns4E8HubScore, Ns4E8ModuleSignals, Ns4E8Sources, Ns4WorkspaceArtifact, Ns4WorkspaceContext, Ns4WorkspaceIndex, } from "_102020_/l2/agentNewSolution/steps/e8/contracts";
    export type { Ns4E8BffCall, Ns4E8HubCatalogue, Ns4E8HubCatalogueItem, Ns4E8HubComposition, Ns4E8Input, Ns4E8InputSource, Ns4E8MenuEntry, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation, Ns4E8Organism, Ns4E8Section, Ns4WorkspaceTier, } from "_102020_/l2/agentNewSolution/steps/e8/model";
    export type { Ns4ClassicBffCall, Ns4ClassicL4, Ns4ClassicOperation, Ns4ClassicSiteMap, Ns4ClassicWorkspace, } from "_102020_/l2/agentNewSolution/steps/e9/classic";
    export type { Ns4E10CheckSummary, Ns4E10Delivery, Ns4E10Issue, Ns4E10RepairStep, Ns4E10ValidationReport, Ns4L5BackendOwner, Ns4L5FrontendOwner, Ns4L5HeaderLink, Ns4L5ModuleNavigation, Ns4L5NavigationItem, Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact, } from "_102020_/l2/agentNewSolution/steps/e10/contracts";
    export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES: readonly ["Ns4ModuleArtifact", "Ns4JourneyArtifact", "Ns4JourneyIndex", "Ns4AccessMatrixArtifact", "Ns4OntologyEntityArtifact", "Ns4OntologyIndexArtifact", "Ns4RulesArtifact", "Ns4CompositionArtifact", "Ns4UseCaseArtifact", "Ns4UseCaseArtifactV3", "Ns4UseCaseIndexArtifact", "Ns4UseCaseIndexArtifactV3", "Ns4WorkflowArtifact", "Ns4WorkflowArtifactV2", "Ns4WorkflowIndexArtifact", "Ns4WorkflowIndexArtifactV2", "Ns4WorkflowIndexArtifactV3", "Ns4L5TodoFrontendArtifact", "Ns4L5TodoBackendArtifact", "Ns4L5ProcessArtifact"];
    export type Ns4PermanentArtifactTypeName = typeof NS4_PERMANENT_ARTIFACT_TYPE_NAMES[number];
    export interface Ns4PermanentArtifactByType {
        Ns4ModuleArtifact: Ns4ModuleArtifact;
        Ns4JourneyArtifact: Ns4JourneyArtifact;
        Ns4JourneyIndex: Ns4JourneyIndex;
        Ns4AccessMatrixArtifact: Ns4AccessMatrixArtifact;
        Ns4OntologyEntityArtifact: Ns4OntologyEntityArtifact;
        Ns4OntologyIndexArtifact: Ns4OntologyIndexArtifact;
        Ns4RulesArtifact: Ns4RulesArtifact;
        Ns4CompositionArtifact: Ns4CompositionArtifact;
        Ns4UseCaseArtifact: Ns4UseCaseArtifact;
        Ns4UseCaseArtifactV3: Ns4UseCaseArtifactV3;
        Ns4UseCaseIndexArtifact: Ns4UseCaseIndexArtifact;
        Ns4UseCaseIndexArtifactV3: Ns4UseCaseIndexArtifactV3;
        Ns4WorkflowArtifact: Ns4WorkflowArtifact;
        Ns4WorkflowArtifactV2: Ns4WorkflowArtifactV2;
        Ns4WorkflowIndexArtifact: Ns4WorkflowIndexArtifact;
        Ns4WorkflowIndexArtifactV2: Ns4WorkflowIndexArtifactV2;
        Ns4WorkflowIndexArtifactV3: Ns4WorkflowIndexArtifactV3;
        Ns4L5TodoFrontendArtifact: Ns4L5TodoFrontendArtifact;
        Ns4L5TodoBackendArtifact: Ns4L5TodoBackendArtifact;
        Ns4L5ProcessArtifact: Ns4L5ProcessArtifact;
    }
}
declare module "_102047_/l4/controleChamados/module.defs" {
    export const controleChamadosModule: {
        readonly schemaVersion: "2026-08-06-ns4-module-v4";
        readonly presentation: {
            readonly userLanguage: "pt-BR";
            readonly stepTitles: {
                readonly "e1-clarification": "Defina os detalhes";
                readonly "e1-compile": "Revise o resumo";
                readonly "e2-journeys": "Veja as jornadas";
                readonly "e3-access-matrix": "Confira os acessos";
                readonly "e4-ontology": "Explore os conceitos";
                readonly "e5-rules": "Valide as regras";
                readonly "e6-behaviors": "Revise módulos e plugins";
                readonly "e7-realization": "Acompanhe a construção";
                readonly "e8-workspaces": "Organize os espaços";
                readonly "e9-navigation-compiler": "Confira a navegação";
                readonly "e10-validation": "Valide a solução";
            };
        };
        readonly module: {
            readonly moduleName: "controleChamados";
            readonly title: "Controle de Chamados";
            readonly purpose: "Permitir que o atendente registre, acompanhe, comente e encerre chamados com título, descrição e status.";
            readonly languages: ["pt-BR"];
        };
        readonly designContext: {
            readonly initialPrompt: "criar um site chamado controleChamados , em portugues. cada chamado tem titulo, descricao e status (aberto ou fechado). o atendente registra o chamado, escreve comentarios no chamado, e depois fecha o chamado. um unico perfil de acesso: atendente.";
            readonly clarification: {
                readonly mainActors: "Atendente";
                readonly mainGoal: "Registrar, acompanhar e encerrar chamados com título, descrição, status e comentários.";
                readonly boundaries: "in: Cadastro de chamados com título, descrição e status (aberto ou fechado); in: Consulta de chamados; in: Registro de comentários no chamado; in: Fechamento do chamado pelo atendente; in: Único ator de negócio: atendente; out: Outros perfis ou atores de acesso além do atendente; out: Funcionalidades não relacionadas ao controle de chamados; out: Integrações com sistemas externos";
            };
        };
        readonly reviewPolicy: {
            readonly mode: "automatic";
        };
        readonly solutionStrategy: {
            readonly mode: "newSolution";
            readonly rationale: "A solicitação pede a criação de um site novo, sem sistema legado, preservação de banco existente ou migração de dados.";
            readonly databaseChangePolicy: "new";
        };
        readonly businessScope: {
            readonly mainGoal: "Registrar, acompanhar e encerrar chamados com título, descrição, status e comentários.";
            readonly actors: [{
                readonly actorId: "atendente";
                readonly title: "Atendente";
                readonly kind: "internal";
                readonly expectedOutcome: "Registrar chamados, escrever comentários e fechar chamados.";
            }];
            readonly expectedOutcomes: [{
                readonly outcomeId: "chamadoRegistrado";
                readonly title: "Chamado registrado";
                readonly description: "O atendente cria o chamado com título, descrição e status aberto.";
            }, {
                readonly outcomeId: "chamadoComentado";
                readonly title: "Comentários no chamado";
                readonly description: "O atendente registra comentários no chamado durante o atendimento.";
            }, {
                readonly outcomeId: "chamadoEncerrado";
                readonly title: "Chamado fechado";
                readonly description: "O atendente altera o status do chamado para fechado ao concluir o atendimento.";
            }];
            readonly inScope: ["Cadastro de chamados com título, descrição e status (aberto ou fechado)", "Consulta de chamados", "Registro de comentários no chamado", "Fechamento do chamado pelo atendente", "Único ator de negócio: atendente"];
            readonly outOfScope: ["Outros perfis ou atores de acesso além do atendente", "Funcionalidades não relacionadas ao controle de chamados", "Integrações com sistemas externos"];
        };
        readonly localization: {
            readonly productLanguages: ["pt-BR"];
            readonly defaultLanguage: "pt-BR";
            readonly defaultLocale: "";
            readonly currency: "";
            readonly timeZone: "";
            readonly primaryMarket: "";
        };
        readonly declaredConstraints: {
            readonly mandatoryIntegrations: [];
            readonly regulatoryNotes: "";
            readonly criticalNotes: "";
        };
        readonly specStatus: {
            readonly flowId: "agentNewSolution";
            readonly flowVersion: "2026-08-14-ns4-flow-v40";
            readonly state: "complete";
            readonly artifactCompleteness: "full";
            readonly completedSteps: [{
                readonly stepId: "e1";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:51:41.474Z";
            }, {
                readonly stepId: "e2-journeys";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:53:41.206Z";
            }, {
                readonly stepId: "e3-access-matrix";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:54:03.994Z";
            }, {
                readonly stepId: "e4-ontology";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:55:28.916Z";
            }, {
                readonly stepId: "e5-rules";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:55:34.793Z";
            }, {
                readonly stepId: "e6-behaviors";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:55:40.636Z";
            }, {
                readonly stepId: "e7-realization";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:55:53.516Z";
            }, {
                readonly stepId: "e8-workspaces";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:56:10.827Z";
            }, {
                readonly stepId: "e9-navigation-compiler";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:56:11.111Z";
            }, {
                readonly stepId: "e10-validation";
                readonly status: "approved";
                readonly approvedBy: "auto";
                readonly approvedAt: "2026-09-02T12:56:11.376Z";
            }];
            readonly nextStep: "complete";
            readonly updatedAt: "2026-09-02T12:56:11.376Z";
        };
    };
    export type ControleChamadosModuleType = typeof controleChamadosModule;
    export default controleChamadosModule;
}
declare module "_102047_/l4/controleChamados/siteMap.defs" {
    export const controleChamadosSiteMap: {
        readonly moduleName: "controleChamados";
        readonly note: "Site map (permanent page index) — workspaces, landings and advisory edges. Detail (sections/organisms/bffCalls) lives per-workspace under workspaces/.";
        readonly workspaces: readonly [{
            readonly workspaceId: "commentOpenTicket";
            readonly title: "Registrar comentário em chamado aberto";
            readonly actors: readonly ["atendente"];
            readonly kind: "operation";
            readonly entity: "TicketComment";
            readonly operationIds: readonly ["locateTicket", "recordComment"];
            readonly purpose: "Documentar o andamento do atendimento em um chamado aberto.";
        }, {
            readonly workspaceId: "ticketCatalogue";
            readonly title: "Chamado";
            readonly actors: readonly ["atendente"];
            readonly kind: "operation";
            readonly entity: "Ticket";
            readonly operationIds: readonly ["createTicket", "decideClosure", "deleteTicket", "getTicket", "listTicket", "locateTicket", "updateTicket"];
            readonly purpose: "Cadastro de Chamado.";
        }, {
            readonly workspaceId: "ticketCommentCatalogue";
            readonly title: "Comentário do chamado";
            readonly actors: readonly ["atendente"];
            readonly kind: "operation";
            readonly entity: "TicketComment";
            readonly operationIds: readonly ["createTicketComment", "deleteTicketComment", "getTicketComment", "listTicket", "listTicketComment", "updateTicketComment"];
            readonly purpose: "Cadastro de Comentário do chamado.";
        }, {
            readonly workspaceId: "ticketHub";
            readonly title: "Chamado";
            readonly actors: readonly ["atendente"];
            readonly kind: "landing";
            readonly entity: "Ticket";
            readonly operationIds: readonly ["listTicket", "listTicketComment"];
            readonly purpose: "Painel de Chamado.";
        }];
        readonly landings: readonly [{
            readonly actorId: "atendente";
            readonly workspaceId: "ticketHub";
            readonly reason: "Painel de Chamado.";
        }];
        readonly navigationEdges: readonly [{
            readonly from: "ticketHub";
            readonly to: "commentOpenTicket";
            readonly operationId: "";
            readonly description: "Registrar comentário em chamado aberto";
            readonly prominence: "primary";
            readonly order: 0;
        }, {
            readonly from: "ticketHub";
            readonly to: "ticketCommentCatalogue";
            readonly operationId: "";
            readonly description: "Comentário do chamado";
        }];
        readonly workspaceIds: readonly ["commentOpenTicket", "ticketCatalogue", "ticketCommentCatalogue", "ticketHub"];
    };
    export default controleChamadosSiteMap;
}
declare module "_102047_/l4/controleChamados/workspace-model.defs" {
    export const controleChamadosWorkspaceModel: {
        readonly planId: "e8-workspace-model";
        readonly schemaVersion: "2026-08-14-ns4-e8-model-v1";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly title: "Workspaces";
        readonly reviewRound: 1;
        readonly hubEntity: "Ticket";
        readonly workspaces: readonly [{
            readonly workspaceId: "commentOpenTicket";
            readonly tier: "journey";
            readonly title: "Registrar comentário em chamado aberto";
            readonly purpose: "Documentar o andamento do atendimento em um chamado aberto.";
            readonly kind: "operation";
            readonly entity: "TicketComment";
            readonly actors: readonly ["atendente"];
            readonly profileRefs: readonly ["atendente"];
            readonly featureRefs: readonly ["ticketCommenting"];
            readonly hostedStepRefs: readonly ["commentOpenTicket.locateTicket", "commentOpenTicket.recordComment"];
            readonly journeyRef: "commentOpenTicket";
            readonly categoryRef: "processWizard";
            readonly bffCalls: readonly [{
                readonly bffId: "qryLocateTicket";
                readonly kind: "query";
                readonly operationId: "locateTicket";
                readonly outputKind: "paginated";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "cmdRecordComment";
                readonly kind: "command";
                readonly operationId: "recordComment";
                readonly outputKind: "object";
                readonly entityRef: "TicketComment";
            }];
            readonly sections: readonly [{
                readonly sectionId: "locateTicket";
                readonly intent: "Um chamado aberto é selecionado a partir da Lista de chamados para acompanhamento.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly dataSource: "qryLocateTicket";
                    readonly usage: "picker";
                }];
            }, {
                readonly sectionId: "recordComment";
                readonly intent: "Um comentário fica registrado no histórico do chamado.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly action: "cmdRecordComment";
                }];
            }];
        }, {
            readonly workspaceId: "ticketCatalogue";
            readonly tier: "recordCatalogue";
            readonly title: "Chamado";
            readonly purpose: "Cadastro de Chamado.";
            readonly kind: "operation";
            readonly entity: "Ticket";
            readonly actors: readonly ["atendente"];
            readonly profileRefs: readonly ["atendente"];
            readonly featureRefs: readonly ["ticketClosure"];
            readonly hostedStepRefs: readonly ["closeOpenTicket.locateTicket", "closeOpenTicket.decideClosure"];
            readonly categoryRef: "entityRecordManagement";
            readonly bffCalls: readonly [{
                readonly bffId: "qryListTicket";
                readonly kind: "query";
                readonly operationId: "listTicket";
                readonly outputKind: "paginated";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "cmdCreateTicket";
                readonly kind: "command";
                readonly operationId: "createTicket";
                readonly outputKind: "object";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "cmdUpdateTicket";
                readonly kind: "command";
                readonly operationId: "updateTicket";
                readonly outputKind: "object";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "cmdDeleteTicket";
                readonly kind: "command";
                readonly operationId: "deleteTicket";
                readonly outputKind: "object";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "qryGetTicket";
                readonly kind: "query";
                readonly operationId: "getTicket";
                readonly outputKind: "object";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "qryLocateTicket";
                readonly kind: "query";
                readonly operationId: "locateTicket";
                readonly outputKind: "paginated";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "cmdDecideClosure";
                readonly kind: "command";
                readonly operationId: "decideClosure";
                readonly outputKind: "object";
                readonly entityRef: "Ticket";
            }];
            readonly sections: readonly [{
                readonly sectionId: "recordList";
                readonly intent: "Localizar Chamado.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly dataSource: "qryListTicket";
                }, {
                    readonly role: "filterControl";
                    readonly attachTo: "qryListTicket";
                }, {
                    readonly role: "contextualAction";
                    readonly action: "cmdDeleteTicket";
                }];
            }, {
                readonly sectionId: "recordForm";
                readonly intent: "Criar ou corrigir Chamado.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly action: "cmdCreateTicket";
                }, {
                    readonly role: "contextualAction";
                    readonly action: "cmdUpdateTicket";
                }];
            }, {
                readonly sectionId: "decideClosure";
                readonly intent: "O chamado passa a ter status fechado.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly action: "cmdDecideClosure";
                }];
            }];
        }, {
            readonly workspaceId: "ticketCommentCatalogue";
            readonly tier: "recordCatalogue";
            readonly title: "Comentário do chamado";
            readonly purpose: "Cadastro de Comentário do chamado.";
            readonly kind: "operation";
            readonly entity: "TicketComment";
            readonly actors: readonly ["atendente"];
            readonly profileRefs: readonly ["atendente"];
            readonly featureRefs: readonly [];
            readonly hostedStepRefs: readonly [];
            readonly categoryRef: "entityRecordManagement";
            readonly bffCalls: readonly [{
                readonly bffId: "qryListTicketComment";
                readonly kind: "query";
                readonly operationId: "listTicketComment";
                readonly outputKind: "paginated";
                readonly entityRef: "TicketComment";
            }, {
                readonly bffId: "cmdCreateTicketComment";
                readonly kind: "command";
                readonly operationId: "createTicketComment";
                readonly outputKind: "object";
                readonly entityRef: "TicketComment";
                readonly inputSources: readonly [{
                    readonly inputId: "ticketId";
                    readonly bffId: "qryTicketPicker";
                }];
            }, {
                readonly bffId: "cmdUpdateTicketComment";
                readonly kind: "command";
                readonly operationId: "updateTicketComment";
                readonly outputKind: "object";
                readonly entityRef: "TicketComment";
                readonly inputSources: readonly [{
                    readonly inputId: "ticketId";
                    readonly bffId: "qryTicketPicker";
                }];
            }, {
                readonly bffId: "cmdDeleteTicketComment";
                readonly kind: "command";
                readonly operationId: "deleteTicketComment";
                readonly outputKind: "object";
                readonly entityRef: "TicketComment";
            }, {
                readonly bffId: "qryGetTicketComment";
                readonly kind: "query";
                readonly operationId: "getTicketComment";
                readonly outputKind: "object";
                readonly entityRef: "TicketComment";
            }, {
                readonly bffId: "qryTicketPicker";
                readonly kind: "query";
                readonly operationId: "listTicket";
                readonly outputKind: "paginated";
                readonly entityRef: "Ticket";
            }];
            readonly sections: readonly [{
                readonly sectionId: "recordList";
                readonly intent: "Localizar Comentário do chamado.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly dataSource: "qryListTicketComment";
                }, {
                    readonly role: "contextualAction";
                    readonly action: "cmdDeleteTicketComment";
                }];
            }, {
                readonly sectionId: "recordForm";
                readonly intent: "Criar ou corrigir Comentário do chamado.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly action: "cmdCreateTicketComment";
                }, {
                    readonly role: "contextualAction";
                    readonly action: "cmdUpdateTicketComment";
                }, {
                    readonly role: "filterControl";
                    readonly dataSource: "qryTicketPicker";
                    readonly usage: "picker";
                }];
            }];
        }, {
            readonly workspaceId: "ticketHub";
            readonly tier: "hub";
            readonly title: "Chamado";
            readonly purpose: "Painel de Chamado.";
            readonly kind: "landing";
            readonly entity: "Ticket";
            readonly actors: readonly ["atendente"];
            readonly profileRefs: readonly ["atendente"];
            readonly featureRefs: readonly [];
            readonly hostedStepRefs: readonly [];
            readonly categoryRef: "dashboardCommandCenter";
            readonly bffCalls: readonly [{
                readonly bffId: "qryListTicket";
                readonly kind: "query";
                readonly operationId: "listTicket";
                readonly outputKind: "paginated";
                readonly entityRef: "Ticket";
            }, {
                readonly bffId: "qryListTicketComment";
                readonly kind: "query";
                readonly operationId: "listTicketComment";
                readonly outputKind: "paginated";
                readonly entityRef: "TicketComment";
            }];
            readonly sections: readonly [{
                readonly sectionId: "collection";
                readonly intent: "Carteira e busca.";
                readonly organisms: readonly [{
                    readonly role: "primarySurface";
                    readonly dataSource: "qryListTicket";
                }];
            }, {
                readonly sectionId: "record";
                readonly intent: "Registro selecionado e o que gira em volta dele.";
                readonly organisms: readonly [{
                    readonly role: "detailPanel";
                    readonly dataSource: "qryListTicketComment";
                }];
            }];
            readonly hubCatalogue: {
                readonly anchorEntity: "Ticket";
                readonly items: readonly [{
                    readonly itemId: "actionCommentOpenTicket";
                    readonly kind: "action";
                    readonly label: "Registrar comentário em chamado aberto";
                    readonly entityRef: "TicketComment";
                    readonly targetRef: "commentOpenTicket";
                    readonly score: 2;
                }, {
                    readonly itemId: "relatedTicketComment";
                    readonly kind: "relatedList";
                    readonly label: "Comentário do chamado";
                    readonly entityRef: "TicketComment";
                    readonly targetRef: "ticketCommentCatalogue";
                    readonly sourceOperationId: "listTicketComment";
                    readonly sourceBffId: "qryListTicketComment";
                    readonly sourceOutputKind: "paginated";
                    readonly score: 2;
                }];
            };
            readonly navigation: readonly [{
                readonly targetWorkspaceId: "commentOpenTicket";
                readonly label: "Registrar comentário em chamado aberto";
                readonly prominence: "primary";
                readonly order: 0;
            }];
        }];
        readonly operations: readonly [{
            readonly operationId: "listTicket";
            readonly title: "Listar Chamado";
            readonly kind: "query";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly accessPattern: {
                readonly kind: "list";
                readonly pagination: "optional";
            };
            readonly inputs: readonly [{
                readonly inputId: "search";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "title";
                };
                readonly source: "userInput";
                readonly required: false;
                readonly description: "Buscar por Título.";
            }, {
                readonly inputId: "sortBy";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "status";
                };
                readonly source: "userInput";
                readonly required: false;
                readonly enumValues: readonly ["status"];
                readonly description: "Campo de ordenação da listagem.";
            }, {
                readonly inputId: "sortOrder";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "status";
                };
                readonly source: "userInput";
                readonly required: false;
                readonly enumValues: readonly ["asc", "desc"];
                readonly description: "Direção da ordenação.";
            }];
            readonly outputRefs: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Encontrar o registro."];
        }, {
            readonly operationId: "createTicket";
            readonly title: "Criar Chamado";
            readonly kind: "command";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly accessPattern: {
                readonly kind: "create";
            };
            readonly inputs: readonly [{
                readonly inputId: "title";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "title";
                };
                readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                readonly source: "userInput";
                readonly required: true;
            }, {
                readonly inputId: "description";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "description";
                };
                readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                readonly source: "userInput";
                readonly required: true;
            }, {
                readonly inputId: "status";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "status";
                };
                readonly description: "Situação atual do chamado durante o atendimento.";
                readonly enumValues: readonly ["open", "closed"];
                readonly source: "systemDefault";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["Ticket.ticketId"];
            readonly useRules: readonly ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Informar os dados do novo registro."];
        }, {
            readonly operationId: "updateTicket";
            readonly title: "Atualizar Chamado";
            readonly kind: "command";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly accessPattern: {
                readonly kind: "update";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "ticketId";
                };
                readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                readonly source: "selectedEntity";
                readonly required: true;
            }, {
                readonly inputId: "title";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "title";
                };
                readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
                readonly source: "userInput";
                readonly required: true;
            }, {
                readonly inputId: "description";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "description";
                };
                readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
                readonly source: "userInput";
                readonly required: true;
            }, {
                readonly inputId: "status";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "status";
                };
                readonly description: "Situação atual do chamado durante o atendimento.";
                readonly enumValues: readonly ["open", "closed"];
                readonly source: "systemDefault";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["Ticket.ticketId"];
            readonly useRules: readonly ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Corrigir os dados do registro escolhido."];
        }, {
            readonly kind: "command";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly inputs: readonly [{
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "ticketId";
                };
                readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                readonly source: "selectedEntity";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["Ticket.ticketId"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly operationId: "deleteTicket";
            readonly title: "Excluir Chamado";
            readonly accessPattern: {
                readonly kind: "delete";
            };
            readonly story: readonly ["Remover o registro escolhido."];
        }, {
            readonly operationId: "getTicket";
            readonly title: "Obter Chamado";
            readonly kind: "query";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly accessPattern: {
                readonly kind: "getById";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "ticketId";
                };
                readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
                readonly source: "selectedEntity";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Ler o registro pelo identificador."];
        }, {
            readonly operationId: "listTicketComment";
            readonly title: "Listar Comentário do chamado";
            readonly kind: "query";
            readonly entityRef: "TicketComment";
            readonly entityRefs: readonly ["TicketComment"];
            readonly accessPattern: {
                readonly kind: "list";
                readonly pagination: "optional";
            };
            readonly inputs: readonly [];
            readonly outputRefs: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Encontrar o registro."];
        }, {
            readonly operationId: "createTicketComment";
            readonly title: "Criar Comentário do chamado";
            readonly kind: "command";
            readonly entityRef: "TicketComment";
            readonly entityRefs: readonly ["Ticket", "TicketComment"];
            readonly accessPattern: {
                readonly kind: "create";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "ticketId";
                };
                readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
                readonly source: "selectedEntity";
                readonly required: true;
            }, {
                readonly inputId: "commentText";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "commentText";
                };
                readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                readonly source: "userInput";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["TicketComment.ticketCommentId"];
            readonly useRules: readonly ["onlyOpenTicketCanReceiveComment"];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Informar os dados do novo registro."];
        }, {
            readonly operationId: "updateTicketComment";
            readonly title: "Atualizar Comentário do chamado";
            readonly kind: "command";
            readonly entityRef: "TicketComment";
            readonly entityRefs: readonly ["Ticket", "TicketComment"];
            readonly accessPattern: {
                readonly kind: "update";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketCommentId";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "ticketCommentId";
                };
                readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                readonly source: "selectedEntity";
                readonly required: true;
            }, {
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "ticketId";
                };
                readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
                readonly source: "selectedEntity";
                readonly required: true;
            }, {
                readonly inputId: "commentText";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "commentText";
                };
                readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
                readonly source: "userInput";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["TicketComment.ticketCommentId"];
            readonly useRules: readonly ["onlyOpenTicketCanReceiveComment"];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Corrigir os dados do registro escolhido."];
        }, {
            readonly kind: "command";
            readonly entityRef: "TicketComment";
            readonly entityRefs: readonly ["TicketComment"];
            readonly inputs: readonly [{
                readonly inputId: "ticketCommentId";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "ticketCommentId";
                };
                readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                readonly source: "selectedEntity";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["TicketComment.ticketCommentId"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly operationId: "deleteTicketComment";
            readonly title: "Excluir Comentário do chamado";
            readonly accessPattern: {
                readonly kind: "delete";
            };
            readonly story: readonly ["Remover o registro escolhido."];
        }, {
            readonly operationId: "getTicketComment";
            readonly title: "Obter Comentário do chamado";
            readonly kind: "query";
            readonly entityRef: "TicketComment";
            readonly entityRefs: readonly ["TicketComment"];
            readonly accessPattern: {
                readonly kind: "getById";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketCommentId";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "ticketCommentId";
                };
                readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
                readonly source: "selectedEntity";
                readonly required: true;
            }];
            readonly outputRefs: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Ler o registro pelo identificador."];
        }, {
            readonly operationId: "locateTicket";
            readonly title: "Localizar o chamado aberto";
            readonly kind: "query";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly accessPattern: {
                readonly kind: "list";
                readonly pagination: "optional";
            };
            readonly inputs: readonly [];
            readonly outputRefs: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
            readonly useRules: readonly [];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Localizar o chamado aberto", "Um chamado aberto é selecionado a partir da Lista de chamados para encerramento."];
            readonly useCaseId: "locateTicket";
        }, {
            readonly operationId: "recordComment";
            readonly title: "Registrar comentário";
            readonly kind: "command";
            readonly entityRef: "TicketComment";
            readonly entityRefs: readonly ["Ticket", "TicketComment"];
            readonly accessPattern: {
                readonly kind: "commandInput";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "ticketId";
                };
                readonly source: "routeParam";
                readonly required: true;
                readonly description: "Chamado";
            }, {
                readonly inputId: "commentText";
                readonly fieldRef: {
                    readonly entityId: "TicketComment";
                    readonly fieldId: "commentText";
                };
                readonly source: "userInput";
                readonly required: true;
                readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
            }];
            readonly outputRefs: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
            readonly useRules: readonly ["onlyOpenTicketCanReceiveComment"];
            readonly transitionRefs: readonly [];
            readonly story: readonly ["Registrar comentário", "Um comentário fica registrado no histórico do chamado."];
            readonly useCaseId: "recordComment";
        }, {
            readonly operationId: "decideClosure";
            readonly title: "Confirmar o fechamento do chamado";
            readonly kind: "command";
            readonly entityRef: "Ticket";
            readonly entityRefs: readonly ["Ticket"];
            readonly accessPattern: {
                readonly kind: "transition";
            };
            readonly inputs: readonly [{
                readonly inputId: "ticketId";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "ticketId";
                };
                readonly source: "routeParam";
                readonly required: true;
                readonly description: "Chamado";
            }, {
                readonly inputId: "status";
                readonly fieldRef: {
                    readonly entityId: "Ticket";
                    readonly fieldId: "status";
                };
                readonly source: "userInput";
                readonly required: true;
                readonly description: "Decisão tomada.";
                readonly enumValues: readonly ["closed"];
            }];
            readonly outputRefs: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
            readonly useRules: readonly ["onlyOpenTicketCanBeClosed"];
            readonly transitionRefs: readonly ["closeTicket"];
            readonly story: readonly ["Confirmar o fechamento do chamado", "O chamado passa a ter status fechado."];
            readonly useCaseId: "decideClosure";
        }];
        readonly menu: readonly [{
            readonly workspaceId: "ticketCatalogue";
            readonly label: "Chamado";
            readonly featureRef: "ticketClosure";
            readonly tier: "recordCatalogue";
            readonly profileRefs: readonly ["atendente"];
        }, {
            readonly workspaceId: "ticketCommentCatalogue";
            readonly label: "Comentário do chamado";
            readonly featureRef: "";
            readonly tier: "recordCatalogue";
            readonly profileRefs: readonly ["atendente"];
        }, {
            readonly workspaceId: "ticketHub";
            readonly label: "Chamado";
            readonly featureRef: "";
            readonly tier: "hub";
            readonly profileRefs: readonly ["atendente"];
        }];
        readonly landings: readonly [{
            readonly profileRef: "atendente";
            readonly workspaceId: "ticketHub";
        }];
        readonly systemDecisions: readonly [{
            readonly decisionId: "hubCompositionTicketHub";
            readonly stage: "e8-workspaces";
            readonly question: "A composição proposta para o painel de Chamado não respeitou o catálogo; usar a ordem padrão?";
            readonly chosen: "keepDerivedComposition";
            readonly alternatives: readonly ["keepDerivedComposition", "reviewDashboardComposition"];
            readonly decidedBy: "system";
            readonly findingRef: "NS4_E8_HUB_COMPOSITION:ticketHub";
            readonly changeHint: "Revisar a ordem e os destaques do painel de Chamado no próximo round.";
        }];
    };
    export default controleChamadosWorkspaceModel;
}
declare module "_102047_/l4/controleChamados/access/access-matrix.defs" {
    export const controleChamadosAccessMatrix: {
        readonly schemaVersion: "2026-08-10-ns4-access-matrix-v3";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly title: "Matriz de acesso";
        readonly profiles: [{
            readonly profileId: "atendente";
            readonly title: "Atendente";
            readonly kind: "internal";
            readonly description: "Profissional responsável por registrar, consultar, comentar e encerrar chamados.";
            readonly actorRefs: ["atendente"];
            readonly landingIntent: "Acessar a lista de chamados para registrar novos atendimentos e acompanhar os existentes.";
        }];
        readonly authorities: [{
            readonly authorityRef: "tickets:read";
            readonly title: "Consultar chamados e histórico";
            readonly description: "Permite localizar e consultar os dados, o status e o histórico de comentários dos chamados da organização.";
            readonly journeyStepRefs: ["commentOpenTicket.locateTicket", "closeOpenTicket.locateTicket", "consultTicket.locateTicket", "consultTicket.inspectTicket"];
            readonly informationNeeds: ["Dados do chamado: título, descrição e status", "Histórico de comentários associado ao chamado"];
        }, {
            readonly authorityRef: "tickets:manage";
            readonly title: "Registrar e conduzir chamados";
            readonly description: "Permite criar chamados, registrar comentários em chamados abertos e fechar chamados abertos.";
            readonly journeyStepRefs: ["registerTicket.createTicket", "commentOpenTicket.recordComment", "closeOpenTicket.decideClosure"];
            readonly informationNeeds: [];
        }];
        readonly grants: [{
            readonly profileRef: "atendente";
            readonly authorityRef: "tickets:read";
            readonly reason: "O atendente precisa localizar chamados e acompanhar suas informações e comentários para realizar o atendimento.";
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todos os chamados pertencentes à organização ativa.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Disponibiliza os dados completos do chamado e seu histórico de comentários necessários ao acompanhamento.";
                readonly allowedInformation: [];
                readonly deniedInformation: [];
            };
            readonly useRules: [];
        }, {
            readonly profileRef: "atendente";
            readonly authorityRef: "tickets:manage";
            readonly reason: "O atendente é o único perfil responsável por iniciar, atualizar o histórico e concluir os chamados da organização.";
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Todos os chamados pertencentes à organização ativa.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite acessar os dados completos do chamado estritamente para registrá-lo, comentar seu andamento ou fechá-lo.";
                readonly allowedInformation: [];
                readonly deniedInformation: [];
            };
            readonly useRules: ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
        }];
        readonly accessHash: "sha256:03668099f53ef20645623a13d5c51a48a8c15b9bc3bbe3bc50833957bbe3b35f";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-02T12:54:03.994Z";
        readonly realization: {
            readonly status: "useCasesCompiled";
            readonly compiledFromAccessHash: "sha256:03668099f53ef20645623a13d5c51a48a8c15b9bc3bbe3bc50833957bbe3b35f";
            readonly useCaseAuthorityRefs: [{
                readonly useCaseId: "createTicket";
                readonly authorityRef: "tickets:manage";
                readonly journeyStepRefs: ["registerTicket.createTicket"];
            }, {
                readonly useCaseId: "decideClosure";
                readonly authorityRef: "tickets:manage";
                readonly journeyStepRefs: ["closeOpenTicket.decideClosure"];
            }, {
                readonly useCaseId: "inspectTicket";
                readonly authorityRef: "tickets:read";
                readonly journeyStepRefs: ["consultTicket.inspectTicket"];
            }, {
                readonly useCaseId: "locateTicket";
                readonly authorityRef: "tickets:read";
                readonly journeyStepRefs: ["closeOpenTicket.locateTicket", "commentOpenTicket.locateTicket", "consultTicket.locateTicket"];
            }, {
                readonly useCaseId: "recordComment";
                readonly authorityRef: "tickets:manage";
                readonly journeyStepRefs: ["commentOpenTicket.recordComment"];
            }];
            readonly operationAuthorityRefs: [];
            readonly realizationHash: "sha256:4d822e2ae4e63b4d18fc6dd661d8f9a94eaf74b2d76679e5f526bddbfda0fb75";
        };
    };
    export type ControleChamadosAccessMatrixType = typeof controleChamadosAccessMatrix;
    export default controleChamadosAccessMatrix;
}
declare module "_102047_/l4/controleChamados/composition/additional-capabilities.defs" {
    export const controleChamadosAdditionalCapabilities: {
        readonly schemaVersion: "2026-08-09-ns4-composition-v1";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly analysisSummary: "O módulo pode ser realizado sem componentes adicionais. O contrato aprovado não exige integrações externas nem capacidades horizontais além das fornecidas pela plataforma.";
        readonly recommendations: [];
        readonly compositionHash: "sha256:c486a3e30ab3e671a42850218ec8f0dc1b1f42d49cf10eb61afbda866dc72e3a";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-02T12:55:40.636Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromCompositionHash: "sha256:c486a3e30ab3e671a42850218ec8f0dc1b1f42d49cf10eb61afbda866dc72e3a";
        };
    };
    export type ControleChamadosAdditionalCapabilitiesType = typeof controleChamadosAdditionalCapabilities;
    export default controleChamadosAdditionalCapabilities;
}
declare module "_102047_/l4/controleChamados/contracts/commentOpenTicket--cmdRecordComment.defs" {
    export interface CmdRecordCommentInput {
        ticketId: string;
        commentText: string;
    }
    export interface CmdRecordCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdRecordCommentRoute: "controleChamados.commentOpenTicket.cmdRecordComment";
}
declare module "_102047_/l4/controleChamados/contracts/commentOpenTicket--qryLocateTicket.defs" {
    export interface QryLocateTicketInput {
    }
    export interface QryLocateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const qryLocateTicketRoute: "controleChamados.commentOpenTicket.qryLocateTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdCreateTicket.defs" {
    export interface CmdCreateTicketInput {
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export interface CmdCreateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const cmdCreateTicketRoute: "controleChamados.ticketCatalogue.cmdCreateTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdDecideClosure.defs" {
    export interface CmdDecideClosureInput {
        ticketId: string;
        status: 'closed';
    }
    export interface CmdDecideClosureOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const cmdDecideClosureRoute: "controleChamados.ticketCatalogue.cmdDecideClosure";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdDeleteTicket.defs" {
    export interface CmdDeleteTicketInput {
        ticketId: string;
    }
    export interface CmdDeleteTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const cmdDeleteTicketRoute: "controleChamados.ticketCatalogue.cmdDeleteTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--cmdUpdateTicket.defs" {
    export interface CmdUpdateTicketInput {
        ticketId: string;
        title: string;
        description: string;
        status: 'open' | 'closed';
    }
    export interface CmdUpdateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const cmdUpdateTicketRoute: "controleChamados.ticketCatalogue.cmdUpdateTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--qryGetTicket.defs" {
    export interface QryGetTicketInput {
        ticketId: string;
    }
    export interface QryGetTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const qryGetTicketRoute: "controleChamados.ticketCatalogue.qryGetTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--qryListTicket.defs" {
    export interface QryListTicketInput {
        search?: string;
        sortBy?: 'status';
        sortOrder?: 'asc' | 'desc';
    }
    export interface QryListTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const qryListTicketRoute: "controleChamados.ticketCatalogue.qryListTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCatalogue--qryLocateTicket.defs" {
    export interface QryLocateTicketInput {
    }
    export interface QryLocateTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const qryLocateTicketRoute: "controleChamados.ticketCatalogue.qryLocateTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--cmdCreateTicketComment.defs" {
    export interface CmdCreateTicketCommentInput {
        ticketId: string;
        commentText: string;
    }
    export interface CmdCreateTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdCreateTicketCommentRoute: "controleChamados.ticketCommentCatalogue.cmdCreateTicketComment";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--cmdDeleteTicketComment.defs" {
    export interface CmdDeleteTicketCommentInput {
        ticketCommentId: string;
    }
    export interface CmdDeleteTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdDeleteTicketCommentRoute: "controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--cmdUpdateTicketComment.defs" {
    export interface CmdUpdateTicketCommentInput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export interface CmdUpdateTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const cmdUpdateTicketCommentRoute: "controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--qryGetTicketComment.defs" {
    export interface QryGetTicketCommentInput {
        ticketCommentId: string;
    }
    export interface QryGetTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const qryGetTicketCommentRoute: "controleChamados.ticketCommentCatalogue.qryGetTicketComment";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--qryListTicketComment.defs" {
    export interface QryListTicketCommentInput {
    }
    export interface QryListTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const qryListTicketCommentRoute: "controleChamados.ticketCommentCatalogue.qryListTicketComment";
}
declare module "_102047_/l4/controleChamados/contracts/ticketCommentCatalogue--qryTicketPicker.defs" {
    export interface QryTicketPickerInput {
        search?: string;
        sortBy?: 'status';
        sortOrder?: 'asc' | 'desc';
    }
    export interface QryTicketPickerOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const qryTicketPickerRoute: "controleChamados.ticketCommentCatalogue.qryTicketPicker";
}
declare module "_102047_/l4/controleChamados/contracts/ticketHub--qryListTicket.defs" {
    export interface QryListTicketInput {
        search?: string;
        sortBy?: 'status';
        sortOrder?: 'asc' | 'desc';
    }
    export interface QryListTicketOutput {
        ticketId: string;
        title: string;
        description: string;
        status: string;
    }
    export const qryListTicketRoute: "controleChamados.ticketHub.qryListTicket";
}
declare module "_102047_/l4/controleChamados/contracts/ticketHub--qryListTicketComment.defs" {
    export interface QryListTicketCommentInput {
    }
    export interface QryListTicketCommentOutput {
        ticketCommentId: string;
        ticketId: string;
        commentText: string;
    }
    export const qryListTicketCommentRoute: "controleChamados.ticketHub.qryListTicketComment";
}
declare module "_102047_/l4/controleChamados/journeys/closeOpenTicket.defs" {
    export const closeOpenTicketJourney: {
        readonly schemaVersion: "2026-08-14-ns4-journey-realized-v5";
        readonly journeyId: "closeOpenTicket";
        readonly revision: 1;
        readonly business: {
            readonly actorRef: "atendente";
            readonly title: "Fechar chamado aberto";
            readonly goal: "Encerrar um chamado quando o atendimento estiver concluído.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateTicket";
                readonly kind: "locate";
                readonly entity: "Ticket";
                readonly title: "Localizar o chamado aberto";
                readonly description: "Um chamado aberto é selecionado a partir da Lista de chamados para encerramento.";
                readonly featureRefs: ["ticketClosure"];
            }, {
                readonly stepId: "decideClosure";
                readonly kind: "decide";
                readonly entity: "Ticket";
                readonly title: "Confirmar o fechamento do chamado";
                readonly description: "O chamado passa a ter status fechado.";
                readonly featureRefs: ["ticketClosure"];
            }];
            readonly outcome: {
                readonly statement: "O chamado é encerrado e deixa de aceitar novos comentários.";
                readonly evidence: ["O status do chamado está fechado.", "O histórico do chamado permanece disponível para consulta."];
            };
            readonly useRules: ["onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
        };
        readonly businessHash: "sha256:59a221f329e03b3d9664759d9ade26252066313814e79d983a82e7fb299aba3e";
        readonly resolution: {
            readonly status: "compiled";
            readonly contexts: {
                readonly selectedTicket: {
                    readonly contextId: "selectedTicket";
                    readonly businessObject: "Ticket";
                    readonly cardinality: "one";
                    readonly required: true;
                    readonly idFieldRef: "ticketId";
                    readonly sourceRefs: ["closeOpenTicket.decideClosure", "closeOpenTicket.entry", "closeOpenTicket.locateTicket"];
                    readonly consumerStepRefs: ["closeOpenTicket.decideClosure"];
                };
            };
        };
        readonly realization: {
            readonly status: "compiled";
            readonly compiledFromBusinessHash: "sha256:59a221f329e03b3d9664759d9ade26252066313814e79d983a82e7fb299aba3e";
            readonly steps: [{
                readonly stepId: "locateTicket";
                readonly useCaseRefs: ["locateTicket"];
            }, {
                readonly stepId: "decideClosure";
                readonly useCaseRefs: ["decideClosure"];
            }];
            readonly transitionRefs: ["closeTicket"];
            readonly realizationHash: "sha256:9c8107bff769bb1091226a48e72089cf4b02f8e140b0bf01ebe463301f27b842";
        };
    };
    export type CloseOpenTicketJourneyType = typeof closeOpenTicketJourney;
    export default closeOpenTicketJourney;
}
declare module "_102047_/l4/controleChamados/journeys/commentOpenTicket.defs" {
    export const commentOpenTicketJourney: {
        readonly schemaVersion: "2026-08-14-ns4-journey-realized-v5";
        readonly journeyId: "commentOpenTicket";
        readonly revision: 1;
        readonly business: {
            readonly actorRef: "atendente";
            readonly title: "Registrar comentário em chamado aberto";
            readonly goal: "Documentar o andamento do atendimento em um chamado aberto.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateTicket";
                readonly kind: "locate";
                readonly entity: "Ticket";
                readonly title: "Localizar o chamado aberto";
                readonly description: "Um chamado aberto é selecionado a partir da Lista de chamados para acompanhamento.";
                readonly featureRefs: ["ticketCommenting"];
            }, {
                readonly stepId: "recordComment";
                readonly kind: "act";
                readonly entity: "TicketComment";
                readonly title: "Registrar comentário";
                readonly description: "Um comentário fica registrado no histórico do chamado.";
                readonly featureRefs: ["ticketCommenting"];
            }];
            readonly outcome: {
                readonly statement: "O histórico do chamado passa a registrar uma atualização do atendimento.";
                readonly evidence: ["O comentário está associado ao chamado selecionado.", "O comentário pode ser consultado no histórico do chamado."];
            };
            readonly useRules: ["onlyOpenTicketCanReceiveComment"];
        };
        readonly businessHash: "sha256:496a92da9d280e9db4975401bd6575e57c703078ff53ed3fe4a1383c62164363";
        readonly resolution: {
            readonly status: "compiled";
            readonly contexts: {
                readonly selectedTicket: {
                    readonly contextId: "selectedTicket";
                    readonly businessObject: "Ticket";
                    readonly cardinality: "one";
                    readonly required: true;
                    readonly idFieldRef: "ticketId";
                    readonly sourceRefs: ["commentOpenTicket.entry", "commentOpenTicket.locateTicket"];
                    readonly consumerStepRefs: ["commentOpenTicket.recordComment"];
                };
                readonly selectedTicketComment: {
                    readonly contextId: "selectedTicketComment";
                    readonly businessObject: "TicketComment";
                    readonly cardinality: "one";
                    readonly required: true;
                    readonly idFieldRef: "ticketCommentId";
                    readonly sourceRefs: ["commentOpenTicket.recordComment"];
                    readonly consumerStepRefs: [];
                };
            };
        };
        readonly realization: {
            readonly status: "compiled";
            readonly compiledFromBusinessHash: "sha256:496a92da9d280e9db4975401bd6575e57c703078ff53ed3fe4a1383c62164363";
            readonly steps: [{
                readonly stepId: "locateTicket";
                readonly useCaseRefs: ["locateTicket"];
            }, {
                readonly stepId: "recordComment";
                readonly useCaseRefs: ["recordComment"];
            }];
            readonly transitionRefs: [];
            readonly realizationHash: "sha256:77f9f7cd35b279df81ae1658429277273afd878e7f265312f5e4428719268dc1";
        };
    };
    export type CommentOpenTicketJourneyType = typeof commentOpenTicketJourney;
    export default commentOpenTicketJourney;
}
declare module "_102047_/l4/controleChamados/journeys/consultTicket.defs" {
    export const consultTicketJourney: {
        readonly schemaVersion: "2026-08-14-ns4-journey-realized-v5";
        readonly journeyId: "consultTicket";
        readonly revision: 1;
        readonly business: {
            readonly actorRef: "atendente";
            readonly title: "Consultar chamados";
            readonly goal: "Acompanhar as informações e o histórico de um chamado.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "locateTicket";
                readonly kind: "locate";
                readonly entity: "Ticket";
                readonly title: "Localizar chamado na Lista de chamados";
                readonly description: "O atendente localiza um chamado na Lista de chamados, que é a fonte de consulta dos chamados registrados.";
                readonly featureRefs: ["ticketConsultation"];
            }, {
                readonly stepId: "inspectTicket";
                readonly kind: "act";
                readonly entity: "Ticket";
                readonly title: "Consultar informações e histórico do chamado";
                readonly description: "O atendente inspeciona o título, a descrição, o status e o histórico de comentários do chamado localizado.";
                readonly featureRefs: ["ticketConsultation"];
            }];
            readonly outcome: {
                readonly statement: "As informações do chamado ficam disponíveis para acompanhamento.";
                readonly evidence: ["O título, a descrição e o status do chamado podem ser consultados.", "O histórico de comentários do chamado pode ser consultado."];
            };
            readonly useRules: [];
        };
        readonly businessHash: "sha256:28f65c7aea1dbed9d07c2e278d447809cbf29f4800e00f70af45cd0dcfcca8ce";
        readonly resolution: {
            readonly status: "compiled";
            readonly contexts: {
                readonly selectedTicket: {
                    readonly contextId: "selectedTicket";
                    readonly businessObject: "Ticket";
                    readonly cardinality: "one";
                    readonly required: true;
                    readonly idFieldRef: "ticketId";
                    readonly sourceRefs: ["consultTicket.inspectTicket", "consultTicket.locateTicket"];
                    readonly consumerStepRefs: ["consultTicket.inspectTicket"];
                };
            };
        };
        readonly realization: {
            readonly status: "compiled";
            readonly compiledFromBusinessHash: "sha256:28f65c7aea1dbed9d07c2e278d447809cbf29f4800e00f70af45cd0dcfcca8ce";
            readonly steps: [{
                readonly stepId: "locateTicket";
                readonly useCaseRefs: ["locateTicket"];
            }, {
                readonly stepId: "inspectTicket";
                readonly useCaseRefs: ["inspectTicket"];
            }];
            readonly transitionRefs: [];
            readonly realizationHash: "sha256:3520e5211adc13e514ce66f362ca1a6b692976cb8b65d8888c38717c3a051c30";
        };
    };
    export type ConsultTicketJourneyType = typeof consultTicketJourney;
    export default consultTicketJourney;
}
declare module "_102047_/l4/controleChamados/journeys/index.defs" {
    export const controleChamadosJourneyIndex: {
        readonly schemaVersion: "2026-08-15-ns4-journey-index-v7";
        readonly moduleName: "controleChamados";
        readonly approvedAt: "2026-09-02T12:53:41.206Z";
        readonly approvedBy: "auto";
        readonly journeys: [{
            readonly journeyId: "commentOpenTicket";
            readonly actorRef: "atendente";
            readonly title: "Registrar comentário em chamado aberto";
            readonly goal: "Documentar o andamento do atendimento em um chamado aberto.";
            readonly entryMode: "contextOrLookup";
            readonly businessHash: "sha256:496a92da9d280e9db4975401bd6575e57c703078ff53ed3fe4a1383c62164363";
            readonly artifactPath: "l4/controleChamados/journeys/commentOpenTicket.defs.ts";
            readonly useCaseRefs: ["locateTicket", "recordComment"];
        }, {
            readonly journeyId: "closeOpenTicket";
            readonly actorRef: "atendente";
            readonly title: "Fechar chamado aberto";
            readonly goal: "Encerrar um chamado quando o atendimento estiver concluído.";
            readonly entryMode: "contextOrLookup";
            readonly businessHash: "sha256:59a221f329e03b3d9664759d9ade26252066313814e79d983a82e7fb299aba3e";
            readonly artifactPath: "l4/controleChamados/journeys/closeOpenTicket.defs.ts";
            readonly useCaseRefs: ["decideClosure", "locateTicket"];
        }, {
            readonly journeyId: "registerTicket";
            readonly actorRef: "atendente";
            readonly title: "Registrar chamado";
            readonly goal: "Criar um novo chamado para iniciar o atendimento.";
            readonly entryMode: "coldStart";
            readonly businessHash: "sha256:fec1c17f3843924c7160eaf9b48ec99cecc163ce2a415c7f4c18385d34c79120";
            readonly artifactPath: "l4/controleChamados/journeys/registerTicket.defs.ts";
            readonly useCaseRefs: ["createTicket"];
        }, {
            readonly journeyId: "consultTicket";
            readonly actorRef: "atendente";
            readonly title: "Consultar chamados";
            readonly goal: "Acompanhar as informações e o histórico de um chamado.";
            readonly entryMode: "coldStart";
            readonly businessHash: "sha256:28f65c7aea1dbed9d07c2e278d447809cbf29f4800e00f70af45cd0dcfcca8ce";
            readonly artifactPath: "l4/controleChamados/journeys/consultTicket.defs.ts";
            readonly useCaseRefs: ["inspectTicket", "locateTicket"];
        }];
        readonly features: [{
            readonly featureId: "ticketCommenting";
            readonly title: "Comentários em chamados";
            readonly priority: "now";
            readonly journeyStepRefs: ["commentOpenTicket.locateTicket", "commentOpenTicket.recordComment"];
        }, {
            readonly featureId: "ticketClosure";
            readonly title: "Fechamento de chamados";
            readonly priority: "now";
            readonly journeyStepRefs: ["closeOpenTicket.locateTicket", "closeOpenTicket.decideClosure"];
        }, {
            readonly featureId: "ticketRegistration";
            readonly title: "Cadastro de chamados";
            readonly priority: "now";
            readonly journeyStepRefs: ["registerTicket.createTicket"];
        }, {
            readonly featureId: "ticketConsultation";
            readonly title: "Consulta de chamados";
            readonly priority: "now";
            readonly journeyStepRefs: ["consultTicket.locateTicket", "consultTicket.inspectTicket"];
        }];
        readonly policyDecisions: [{
            readonly decisionId: "commentAfterTicketClosurePolicy";
            readonly question: "Comentários podem ser registrados depois que um chamado é fechado?";
            readonly chosen: "Comentários só podem ser registrados enquanto o chamado estiver aberto.";
            readonly alternatives: ["Permitir comentários também em chamados fechados"];
            readonly journeyRef: "commentOpenTicket";
        }, {
            readonly decisionId: "ticketClosureRequirementPolicy";
            readonly question: "O que é necessário para fechar um chamado aberto?";
            readonly chosen: "O atendente pode fechar o chamado quando concluir o atendimento, sem exigir um comentário final.";
            readonly alternatives: ["Exigir pelo menos um comentário antes do fechamento", "Exigir um comentário final no momento do fechamento"];
            readonly journeyRef: "closeOpenTicket";
        }, {
            readonly decisionId: "ticketReopeningPolicy";
            readonly question: "Um chamado fechado pode voltar a ser aberto?";
            readonly chosen: "O fechamento é definitivo; chamados fechados não são reabertos.";
            readonly alternatives: ["Permitir que o atendente reabra um chamado fechado"];
            readonly journeyRef: "closeOpenTicket";
        }, {
            readonly decisionId: "demoteRegisterTicketToRecordCatalogue";
            readonly question: "Registrar chamado não tem decisão nem repasse: vira a tela de cadastro padrão de Ticket?";
            readonly chosen: "Tela de cadastro padrão de Ticket";
            readonly alternatives: ["Tela de cadastro padrão de Ticket", "Manter Registrar chamado como jornada própria"];
            readonly journeyRef: "registerTicket";
        }, {
            readonly decisionId: "demoteConsultTicketToRecordCatalogue";
            readonly question: "Consultar chamados não tem decisão nem repasse: vira a tela de cadastro padrão de Ticket?";
            readonly chosen: "Tela de cadastro padrão de Ticket";
            readonly alternatives: ["Tela de cadastro padrão de Ticket", "Manter Consultar chamados como jornada própria"];
            readonly journeyRef: "consultTicket";
        }];
        readonly policyDecisionSelections: [{
            readonly decisionId: "commentAfterTicketClosurePolicy";
            readonly generatedChoice: "Comentários só podem ser registrados enquanto o chamado estiver aberto.";
            readonly selectedChoice: "Comentários só podem ser registrados enquanto o chamado estiver aberto.";
            readonly selectedBy: "auto";
            readonly selectedAt: "2026-09-02T12:53:41.206Z";
        }, {
            readonly decisionId: "ticketClosureRequirementPolicy";
            readonly generatedChoice: "O atendente pode fechar o chamado quando concluir o atendimento, sem exigir um comentário final.";
            readonly selectedChoice: "O atendente pode fechar o chamado quando concluir o atendimento, sem exigir um comentário final.";
            readonly selectedBy: "auto";
            readonly selectedAt: "2026-09-02T12:53:41.206Z";
        }, {
            readonly decisionId: "ticketReopeningPolicy";
            readonly generatedChoice: "O fechamento é definitivo; chamados fechados não são reabertos.";
            readonly selectedChoice: "O fechamento é definitivo; chamados fechados não são reabertos.";
            readonly selectedBy: "auto";
            readonly selectedAt: "2026-09-02T12:53:41.206Z";
        }, {
            readonly decisionId: "demoteRegisterTicketToRecordCatalogue";
            readonly generatedChoice: "Tela de cadastro padrão de Ticket";
            readonly selectedChoice: "Tela de cadastro padrão de Ticket";
            readonly selectedBy: "auto";
            readonly selectedAt: "2026-09-02T12:53:41.206Z";
        }, {
            readonly decisionId: "demoteConsultTicketToRecordCatalogue";
            readonly generatedChoice: "Tela de cadastro padrão de Ticket";
            readonly selectedChoice: "Tela de cadastro padrão de Ticket";
            readonly selectedBy: "auto";
            readonly selectedAt: "2026-09-02T12:53:41.206Z";
        }];
        readonly systemDecisions: [];
        readonly realizationHash: "sha256:fb1c49acf37e739bef2ba30a9d6c791b4d31255872ff61c2823ea8d087f796b5";
    };
    export type ControleChamadosJourneyIndexType = typeof controleChamadosJourneyIndex;
    export default controleChamadosJourneyIndex;
}
declare module "_102047_/l4/controleChamados/journeys/registerTicket.defs" {
    export const registerTicketJourney: {
        readonly schemaVersion: "2026-08-14-ns4-journey-realized-v5";
        readonly journeyId: "registerTicket";
        readonly revision: 1;
        readonly business: {
            readonly actorRef: "atendente";
            readonly title: "Registrar chamado";
            readonly goal: "Criar um novo chamado para iniciar o atendimento.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "createTicket";
                readonly kind: "act";
                readonly entity: "Ticket";
                readonly title: "Registrar os dados do chamado";
                readonly description: "O atendente informa título e descrição, e cria o chamado com status aberto.";
                readonly featureRefs: ["ticketRegistration"];
            }];
            readonly outcome: {
                readonly statement: "Um novo chamado aberto fica disponível para acompanhamento.";
                readonly evidence: ["O chamado possui título e descrição registrados.", "O status inicial do chamado está aberto.", "O novo chamado está disponível na Lista de chamados."];
            };
            readonly useRules: [];
        };
        readonly businessHash: "sha256:fec1c17f3843924c7160eaf9b48ec99cecc163ce2a415c7f4c18385d34c79120";
        readonly resolution: {
            readonly status: "compiled";
            readonly contexts: {
                readonly selectedTicket: {
                    readonly contextId: "selectedTicket";
                    readonly businessObject: "Ticket";
                    readonly cardinality: "one";
                    readonly required: true;
                    readonly idFieldRef: "ticketId";
                    readonly sourceRefs: ["registerTicket.createTicket"];
                    readonly consumerStepRefs: [];
                };
            };
        };
        readonly realization: {
            readonly status: "compiled";
            readonly compiledFromBusinessHash: "sha256:fec1c17f3843924c7160eaf9b48ec99cecc163ce2a415c7f4c18385d34c79120";
            readonly steps: [{
                readonly stepId: "createTicket";
                readonly useCaseRefs: ["createTicket"];
            }];
            readonly transitionRefs: [];
            readonly realizationHash: "sha256:cf4753ec98f4f4fc1f8b9bbcce3e958dc16a9ea64073960cfa8fd25bd027f2e3";
        };
    };
    export type RegisterTicketJourneyType = typeof registerTicketJourney;
    export default registerTicketJourney;
}
declare module "_102047_/l4/controleChamados/ontology/Ticket.defs" {
    export const controleChamadosEntityTicket: {
        readonly schemaVersion: "2026-08-11-ns4-ontology-v6";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly solutionMode: "new";
        readonly entityId: "Ticket";
        readonly title: "Chamado";
        readonly description: "Registro operacional de uma solicitação de atendimento, com título, descrição, status e histórico de comentários.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly party: "none";
        readonly sourceRefs: {
            readonly journeyIds: ["registerTicket", "consultTicket", "commentOpenTicket", "closeOpenTicket"];
            readonly featureIds: ["ticketRegistration", "ticketConsultation", "ticketCommenting", "ticketClosure"];
            readonly authorityRefs: ["tickets:read", "tickets:manage"];
        };
        readonly fields: [{
            readonly fieldId: "ticketId";
            readonly title: "Identificador do chamado";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
            readonly constraints: [{
                readonly constraintId: "uniqueTicketId";
                readonly kind: "unique";
                readonly value: "true";
                readonly description: "Cada chamado possui um identificador estável e exclusivo.";
                readonly source: "inferred";
            }];
        }, {
            readonly fieldId: "title";
            readonly title: "Título";
            readonly type: "string";
            readonly required: true;
            readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
            readonly constraints: [];
        }, {
            readonly fieldId: "description";
            readonly title: "Descrição";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
            readonly constraints: [];
        }, {
            readonly fieldId: "status";
            readonly title: "Status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Situação atual do chamado durante o atendimento.";
            readonly constraints: [{
                readonly constraintId: "ticketStatusEnum";
                readonly kind: "enum";
                readonly value: "[\"open\",\"closed\"]";
                readonly description: "Estados permitidos para o ciclo de vida do chamado.";
                readonly source: "journey";
            }];
            readonly enum: ["open", "closed"];
        }];
        readonly lifecycleStates: ["open", "closed"];
        readonly statusEnum: ["open", "closed"];
        readonly lifecycleLabels: [{
            readonly code: "open";
            readonly label: "Aberto";
        }, {
            readonly code: "closed";
            readonly label: "Fechado";
        }];
        readonly initialState: "open";
        readonly terminalStates: ["closed"];
        readonly lifecyclePredicates: [{
            readonly predicateId: "commentableTicket";
            readonly description: "Um chamado pode receber comentários somente enquanto estiver aberto.";
            readonly stateIds: ["open"];
            readonly source: "journey";
        }, {
            readonly predicateId: "closableTicket";
            readonly description: "Um chamado pode ser fechado somente enquanto estiver aberto.";
            readonly stateIds: ["open"];
            readonly source: "journey";
        }, {
            readonly predicateId: "closedTicket";
            readonly description: "Um chamado fechado está encerrado definitivamente e não pode voltar ao estado aberto.";
            readonly stateIds: ["closed"];
            readonly source: "journey";
        }];
        readonly useRules: ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "ticketId";
            readonly notes: "Chamado é um registro operacional transacional da organização e seu status não deve compor cadastro mestre.";
        };
        readonly ontologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-02T12:55:28.916Z";
    };
    export type ControleChamadosEntityTicketType = typeof controleChamadosEntityTicket;
    export default controleChamadosEntityTicket;
}
declare module "_102047_/l4/controleChamados/ontology/TicketComment.defs" {
    export const controleChamadosEntityTicketComment: {
        readonly schemaVersion: "2026-08-11-ns4-ontology-v6";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly solutionMode: "new";
        readonly entityId: "TicketComment";
        readonly title: "Comentário do chamado";
        readonly description: "Registro histórico de uma atualização escrita pelo atendente em um chamado aberto.";
        readonly kind: "core";
        readonly ownership: "moduleOwned";
        readonly party: "none";
        readonly sourceRefs: {
            readonly journeyIds: ["commentOpenTicket", "consultTicket"];
            readonly featureIds: ["ticketCommenting", "ticketConsultation"];
            readonly authorityRefs: ["tickets:read", "tickets:manage"];
        };
        readonly fields: [{
            readonly fieldId: "ticketCommentId";
            readonly title: "Identificador do comentário";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
            readonly constraints: [{
                readonly constraintId: "uniqueTicketCommentId";
                readonly kind: "unique";
                readonly value: "true";
                readonly description: "Cada comentário possui um identificador estável e exclusivo.";
                readonly source: "inferred";
            }];
        }, {
            readonly fieldId: "ticketId";
            readonly title: "Chamado";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
            readonly constraints: [];
        }, {
            readonly fieldId: "commentText";
            readonly title: "Comentário";
            readonly type: "text";
            readonly required: true;
            readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
            readonly constraints: [{
                readonly constraintId: "commentTextMinLength";
                readonly kind: "minLength";
                readonly value: "1";
                readonly description: "O comentário deve conter uma atualização escrita pelo atendente.";
                readonly source: "journey";
            }];
        }];
        readonly lifecycleStates: [];
        readonly lifecyclePredicates: [];
        readonly useRules: ["onlyOpenTicketCanReceiveComment"];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "ticketCommentId";
            readonly notes: "Comentário é um evento operacional persistido no histórico do chamado. A autoria é associada à identidade do atendente disponível no diretório e na auditoria da plataforma, sem duplicar usuários neste módulo.";
        };
        readonly ontologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-02T12:55:28.916Z";
    };
    export type ControleChamadosEntityTicketCommentType = typeof controleChamadosEntityTicketComment;
    export default controleChamadosEntityTicketComment;
}
declare module "_102047_/l4/controleChamados/ontology/index.defs" {
    export const controleChamadosOntologyIndex: {
        readonly schemaVersion: "2026-08-11-ns4-ontology-v6";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly solutionMode: "new";
        readonly title: "Ontologia de negócio";
        readonly businessDomain: "Controle de chamados e acompanhamento de atendimento";
        readonly entities: [{
            readonly entityId: "Ticket";
            readonly title: "Chamado";
            readonly kind: "core";
            readonly storage: {
                readonly target: "moduleDatabase";
                readonly scope: "module";
                readonly idField: "ticketId";
            };
            readonly definitionRef: "l4/controleChamados/ontology/Ticket.defs.ts";
        }, {
            readonly entityId: "TicketComment";
            readonly title: "Comentário do chamado";
            readonly kind: "core";
            readonly storage: {
                readonly target: "moduleDatabase";
                readonly scope: "module";
                readonly idField: "ticketCommentId";
            };
            readonly definitionRef: "l4/controleChamados/ontology/TicketComment.defs.ts";
        }];
        readonly relationships: [{
            readonly relationshipId: "ticketCommentBelongsToTicket";
            readonly fromEntity: "TicketComment";
            readonly toEntity: "Ticket";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada comentário pertence a um único chamado, mantendo seu histórico vinculado ao chamado selecionado.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "TicketComment";
                readonly from: {
                    readonly entityId: "TicketComment";
                    readonly fieldIds: ["ticketId"];
                };
                readonly to: {
                    readonly entityId: "Ticket";
                    readonly fieldIds: ["ticketId"];
                };
                readonly description: "TicketComment.ticketId obrigatório referencia Ticket.ticketId, vinculando cada comentário ao chamado.";
            };
        }];
        readonly ontologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-02T12:55:28.916Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromOntologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
        };
    };
    export type ControleChamadosOntologyIndexType = typeof controleChamadosOntologyIndex;
    export default controleChamadosOntologyIndex;
}
declare module "_102047_/l4/controleChamados/operations/createTicket.defs" {
    export const operationCreateTicket: {
        readonly operationId: "createTicket";
        readonly title: "Criar Chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "create";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly ["Ticket"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Criar Chamado";
            readonly steps: readonly ["Informar os dados do novo registro."];
            readonly outcome: "Informar os dados do novo registro.";
        };
        readonly accessPattern: {
            readonly kind: "create";
            readonly description: "Criar Chamado";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "title";
            readonly fieldRef: "Ticket.title";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
        }, {
            readonly inputId: "description";
            readonly fieldRef: "Ticket.description";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
        }, {
            readonly inputId: "status";
            readonly fieldRef: "Ticket.status";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Situação atual do chamado durante o atendimento.";
            readonly enumValues: readonly ["open", "closed"];
        }];
        readonly pageId: "ticketCatalogue";
        readonly commandName: "cmdCreateTicket";
        readonly bffName: "cmdCreateTicket";
    };
    export default operationCreateTicket;
}
declare module "_102047_/l4/controleChamados/operations/createTicketComment.defs" {
    export const operationCreateTicketComment: {
        readonly operationId: "createTicketComment";
        readonly title: "Criar Comentário do chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "TicketComment";
        readonly kind: "create";
        readonly reads: readonly ["Ticket", "TicketComment"];
        readonly writes: readonly ["TicketComment"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Criar Comentário do chamado";
            readonly steps: readonly ["Informar os dados do novo registro."];
            readonly outcome: "Informar os dados do novo registro.";
        };
        readonly accessPattern: {
            readonly kind: "create";
            readonly description: "Criar Comentário do chamado";
            readonly entity: "TicketComment";
            readonly keyField: "TicketComment.ticketCommentId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketCommentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketCommentId";
            }, {
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketId";
            }, {
                readonly name: "commentText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.commentText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketId";
            readonly fieldRef: "TicketComment.ticketId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
        }, {
            readonly inputId: "commentText";
            readonly fieldRef: "TicketComment.commentText";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
        }];
        readonly pageId: "ticketCommentCatalogue";
        readonly commandName: "cmdCreateTicketComment";
        readonly bffName: "cmdCreateTicketComment";
    };
    export default operationCreateTicketComment;
}
declare module "_102047_/l4/controleChamados/operations/decideClosure.defs" {
    export const operationDecideClosure: {
        readonly operationId: "decideClosure";
        readonly title: "Confirmar o fechamento do chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "transition";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly ["Ticket"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanBeClosed"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Confirmar o fechamento do chamado";
            readonly steps: readonly ["Confirmar o fechamento do chamado", "O chamado passa a ter status fechado."];
            readonly outcome: "O chamado passa a ter status fechado.";
        };
        readonly accessPattern: {
            readonly kind: "transition";
            readonly description: "Confirmar o fechamento do chamado";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketId";
            readonly fieldRef: "Ticket.ticketId";
            readonly required: true;
            readonly source: "routeParam";
            readonly description: "Chamado";
        }, {
            readonly inputId: "status";
            readonly fieldRef: "Ticket.status";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Decisão tomada.";
            readonly enumValues: readonly ["closed"];
        }];
        readonly pageId: "ticketCatalogue";
        readonly commandName: "cmdDecideClosure";
        readonly bffName: "cmdDecideClosure";
    };
    export default operationDecideClosure;
}
declare module "_102047_/l4/controleChamados/operations/deleteTicket.defs" {
    export const operationDeleteTicket: {
        readonly operationId: "deleteTicket";
        readonly title: "Excluir Chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "delete";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly ["Ticket"];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Excluir Chamado";
            readonly steps: readonly ["Remover o registro escolhido."];
            readonly outcome: "Remover o registro escolhido.";
        };
        readonly accessPattern: {
            readonly kind: "delete";
            readonly description: "Excluir Chamado";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketId";
            readonly fieldRef: "Ticket.ticketId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
        }];
        readonly pageId: "ticketCatalogue";
        readonly commandName: "cmdDeleteTicket";
        readonly bffName: "cmdDeleteTicket";
    };
    export default operationDeleteTicket;
}
declare module "_102047_/l4/controleChamados/operations/deleteTicketComment.defs" {
    export const operationDeleteTicketComment: {
        readonly operationId: "deleteTicketComment";
        readonly title: "Excluir Comentário do chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "TicketComment";
        readonly kind: "delete";
        readonly reads: readonly ["TicketComment"];
        readonly writes: readonly ["TicketComment"];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Excluir Comentário do chamado";
            readonly steps: readonly ["Remover o registro escolhido."];
            readonly outcome: "Remover o registro escolhido.";
        };
        readonly accessPattern: {
            readonly kind: "delete";
            readonly description: "Excluir Comentário do chamado";
            readonly entity: "TicketComment";
            readonly keyField: "TicketComment.ticketCommentId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketCommentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketCommentId";
            }, {
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketId";
            }, {
                readonly name: "commentText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.commentText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketCommentId";
            readonly fieldRef: "TicketComment.ticketCommentId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
        }];
        readonly pageId: "ticketCommentCatalogue";
        readonly commandName: "cmdDeleteTicketComment";
        readonly bffName: "cmdDeleteTicketComment";
    };
    export default operationDeleteTicketComment;
}
declare module "_102047_/l4/controleChamados/operations/getTicket.defs" {
    export const operationGetTicket: {
        readonly operationId: "getTicket";
        readonly title: "Obter Chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "query";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Obter Chamado";
            readonly steps: readonly ["Ler o registro pelo identificador."];
            readonly outcome: "Ler o registro pelo identificador.";
        };
        readonly accessPattern: {
            readonly kind: "getById";
            readonly description: "Obter Chamado";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketId";
            readonly fieldRef: "Ticket.ticketId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
        }];
        readonly pageId: "ticketCatalogue";
        readonly commandName: "qryGetTicket";
        readonly bffName: "qryGetTicket";
    };
    export default operationGetTicket;
}
declare module "_102047_/l4/controleChamados/operations/getTicketComment.defs" {
    export const operationGetTicketComment: {
        readonly operationId: "getTicketComment";
        readonly title: "Obter Comentário do chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "TicketComment";
        readonly kind: "query";
        readonly reads: readonly ["TicketComment"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Obter Comentário do chamado";
            readonly steps: readonly ["Ler o registro pelo identificador."];
            readonly outcome: "Ler o registro pelo identificador.";
        };
        readonly accessPattern: {
            readonly kind: "getById";
            readonly description: "Obter Comentário do chamado";
            readonly entity: "TicketComment";
            readonly keyField: "TicketComment.ticketCommentId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketCommentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketCommentId";
            }, {
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketId";
            }, {
                readonly name: "commentText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.commentText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketCommentId";
            readonly fieldRef: "TicketComment.ticketCommentId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
        }];
        readonly pageId: "ticketCommentCatalogue";
        readonly commandName: "qryGetTicketComment";
        readonly bffName: "qryGetTicketComment";
    };
    export default operationGetTicketComment;
}
declare module "_102047_/l4/controleChamados/operations/listTicket.defs" {
    export const operationListTicket: {
        readonly operationId: "listTicket";
        readonly title: "Listar Chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "query";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Listar Chamado";
            readonly steps: readonly ["Encontrar o registro."];
            readonly outcome: "Encontrar o registro.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly description: "Listar Chamado";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "search";
            readonly fieldRef: "Ticket.title";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Buscar por Título.";
        }, {
            readonly inputId: "sortBy";
            readonly fieldRef: "Ticket.status";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Campo de ordenação da listagem.";
            readonly enumValues: readonly ["status"];
        }, {
            readonly inputId: "sortOrder";
            readonly fieldRef: "Ticket.status";
            readonly required: false;
            readonly source: "userInput";
            readonly description: "Direção da ordenação.";
            readonly enumValues: readonly ["asc", "desc"];
        }];
        readonly pageId: "ticketCatalogue";
        readonly commandName: "qryListTicket";
        readonly bffName: "qryListTicket";
    };
    export default operationListTicket;
}
declare module "_102047_/l4/controleChamados/operations/listTicketComment.defs" {
    export const operationListTicketComment: {
        readonly operationId: "listTicketComment";
        readonly title: "Listar Comentário do chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "TicketComment";
        readonly kind: "query";
        readonly reads: readonly ["TicketComment"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Listar Comentário do chamado";
            readonly steps: readonly ["Encontrar o registro."];
            readonly outcome: "Encontrar o registro.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly description: "Listar Comentário do chamado";
            readonly entity: "TicketComment";
            readonly keyField: "TicketComment.ticketCommentId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "ticketCommentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketCommentId";
            }, {
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketId";
            }, {
                readonly name: "commentText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.commentText";
            }];
        };
        readonly inputs: readonly [];
        readonly pageId: "ticketCommentCatalogue";
        readonly commandName: "qryListTicketComment";
        readonly bffName: "qryListTicketComment";
    };
    export default operationListTicketComment;
}
declare module "_102047_/l4/controleChamados/operations/locateTicket.defs" {
    export const operationLocateTicket: {
        readonly operationId: "locateTicket";
        readonly title: "Localizar o chamado aberto";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "query";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly [];
        readonly rulesApplied: readonly [];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Localizar o chamado aberto";
            readonly steps: readonly ["Localizar o chamado aberto", "Um chamado aberto é selecionado a partir da Lista de chamados para encerramento."];
            readonly outcome: "Um chamado aberto é selecionado a partir da Lista de chamados para encerramento.";
        };
        readonly accessPattern: {
            readonly kind: "list";
            readonly description: "Localizar o chamado aberto";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "single";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "list";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [];
        readonly pageId: "commentOpenTicket";
        readonly commandName: "qryLocateTicket";
        readonly bffName: "qryLocateTicket";
    };
    export default operationLocateTicket;
}
declare module "_102047_/l4/controleChamados/operations/recordComment.defs" {
    export const operationRecordComment: {
        readonly operationId: "recordComment";
        readonly title: "Registrar comentário";
        readonly actors: readonly ["atendente"];
        readonly entity: "TicketComment";
        readonly kind: "commandInput";
        readonly reads: readonly ["Ticket", "TicketComment"];
        readonly writes: readonly ["TicketComment"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Registrar comentário";
            readonly steps: readonly ["Registrar comentário", "Um comentário fica registrado no histórico do chamado."];
            readonly outcome: "Um comentário fica registrado no histórico do chamado.";
        };
        readonly accessPattern: {
            readonly kind: "commandInput";
            readonly description: "Registrar comentário";
            readonly entity: "TicketComment";
            readonly keyField: "TicketComment.ticketCommentId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketCommentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketCommentId";
            }, {
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketId";
            }, {
                readonly name: "commentText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.commentText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketId";
            readonly fieldRef: "Ticket.ticketId";
            readonly required: true;
            readonly source: "routeParam";
            readonly description: "Chamado";
        }, {
            readonly inputId: "commentText";
            readonly fieldRef: "TicketComment.commentText";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
        }];
        readonly pageId: "commentOpenTicket";
        readonly commandName: "cmdRecordComment";
        readonly bffName: "cmdRecordComment";
    };
    export default operationRecordComment;
}
declare module "_102047_/l4/controleChamados/operations/updateTicket.defs" {
    export const operationUpdateTicket: {
        readonly operationId: "updateTicket";
        readonly title: "Atualizar Chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "Ticket";
        readonly kind: "update";
        readonly reads: readonly ["Ticket"];
        readonly writes: readonly ["Ticket"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment", "onlyOpenTicketCanBeClosed", "closedTicketCannotBeReopened"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Atualizar Chamado";
            readonly steps: readonly ["Corrigir os dados do registro escolhido."];
            readonly outcome: "Corrigir os dados do registro escolhido.";
        };
        readonly accessPattern: {
            readonly kind: "update";
            readonly description: "Atualizar Chamado";
            readonly entity: "Ticket";
            readonly keyField: "Ticket.ticketId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["Ticket.ticketId", "Ticket.title", "Ticket.description", "Ticket.status"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.ticketId";
            }, {
                readonly name: "title";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.title";
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.description";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "Ticket.status";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketId";
            readonly fieldRef: "Ticket.ticketId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador estável do chamado, usado para vinculá-lo aos comentários e aos fluxos de atendimento.";
        }, {
            readonly inputId: "title";
            readonly fieldRef: "Ticket.title";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Título que identifica resumidamente a solicitação de atendimento.";
        }, {
            readonly inputId: "description";
            readonly fieldRef: "Ticket.description";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Descrição detalhada da solicitação de atendimento registrada no chamado.";
        }, {
            readonly inputId: "status";
            readonly fieldRef: "Ticket.status";
            readonly required: true;
            readonly source: "systemDefault";
            readonly description: "Situação atual do chamado durante o atendimento.";
            readonly enumValues: readonly ["open", "closed"];
        }];
        readonly pageId: "ticketCatalogue";
        readonly commandName: "cmdUpdateTicket";
        readonly bffName: "cmdUpdateTicket";
    };
    export default operationUpdateTicket;
}
declare module "_102047_/l4/controleChamados/operations/updateTicketComment.defs" {
    export const operationUpdateTicketComment: {
        readonly operationId: "updateTicketComment";
        readonly title: "Atualizar Comentário do chamado";
        readonly actors: readonly ["atendente"];
        readonly entity: "TicketComment";
        readonly kind: "update";
        readonly reads: readonly ["Ticket", "TicketComment"];
        readonly writes: readonly ["TicketComment"];
        readonly rulesApplied: readonly ["onlyOpenTicketCanReceiveComment"];
        readonly story: {
            readonly actor: "atendente";
            readonly goal: "Atualizar Comentário do chamado";
            readonly steps: readonly ["Corrigir os dados do registro escolhido."];
            readonly outcome: "Corrigir os dados do registro escolhido.";
        };
        readonly accessPattern: {
            readonly kind: "update";
            readonly description: "Atualizar Comentário do chamado";
            readonly entity: "TicketComment";
            readonly keyField: "TicketComment.ticketCommentId";
            readonly pagination: "none";
            readonly selection: "none";
            readonly output: readonly ["TicketComment.ticketCommentId", "TicketComment.ticketId", "TicketComment.commentText"];
        };
        readonly outputShape: {
            readonly kind: "object";
            readonly fields: readonly [{
                readonly name: "ticketCommentId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketCommentId";
            }, {
                readonly name: "ticketId";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.ticketId";
            }, {
                readonly name: "commentText";
                readonly type: "string";
                readonly required: true;
                readonly fieldRef: "TicketComment.commentText";
            }];
        };
        readonly inputs: readonly [{
            readonly inputId: "ticketCommentId";
            readonly fieldRef: "TicketComment.ticketCommentId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Identificador estável do comentário, usado para referenciá-lo no histórico do chamado.";
        }, {
            readonly inputId: "ticketId";
            readonly fieldRef: "TicketComment.ticketId";
            readonly required: true;
            readonly source: "selectedEntity";
            readonly description: "Chamado selecionado ao qual este comentário pertence e em cujo histórico será exibido.";
        }, {
            readonly inputId: "commentText";
            readonly fieldRef: "TicketComment.commentText";
            readonly required: true;
            readonly source: "userInput";
            readonly description: "Atualização do atendimento registrada pelo atendente no histórico do chamado.";
        }];
        readonly pageId: "ticketCommentCatalogue";
        readonly commandName: "cmdUpdateTicketComment";
        readonly bffName: "cmdUpdateTicketComment";
    };
    export default operationUpdateTicketComment;
}
declare module "_102047_/l4/controleChamados/rules/rules.defs" {
    export const controleChamadosRules: {
        readonly schemaVersion: "2026-08-09-ns4-rules-v2";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly rules: [{
            readonly id: "closedTicketCannotBeReopened";
            readonly description: "Um chamado fechado é encerrado definitivamente e não pode voltar ao status aberto.";
        }, {
            readonly id: "onlyOpenTicketCanBeClosed";
            readonly description: "Somente um chamado com status aberto pode ser fechado.";
        }, {
            readonly id: "onlyOpenTicketCanReceiveComment";
            readonly description: "Somente um chamado com status aberto pode receber comentários.";
        }];
        readonly rulesHash: "sha256:b6356c46bee687ee1f1aa2d750e415392b3de005047b3fe236224feab6242529";
        readonly approvedBy: "auto";
        readonly approvedAt: "2026-09-02T12:55:34.793Z";
        readonly realization: {
            readonly status: "pending";
            readonly compiledFromRulesHash: "sha256:b6356c46bee687ee1f1aa2d750e415392b3de005047b3fe236224feab6242529";
        };
    };
    export type ControleChamadosRulesType = typeof controleChamadosRules;
    export default controleChamadosRules;
}
declare module "_102047_/l4/controleChamados/usecases/createTicket.defs" {
    export const createTicketUseCase: {
        readonly schemaVersion: "2026-08-10-ns4-usecase-v3";
        readonly moduleName: "controleChamados";
        readonly useCaseId: "createTicket";
        readonly title: "Registrar os dados do chamado";
        readonly kind: "command";
        readonly compiledFrom: ["registerTicket.createTicket"];
        readonly description: "Registra um chamado com título e descrição, iniciando-o com status aberto.";
        readonly contexts: {
            readonly requires: [];
            readonly provides: ["selectedTicket"];
        };
        readonly entityRefs: ["Ticket"];
        readonly useRules: [];
        readonly transitionRefs: [];
        readonly useCaseHash: "sha256:349119b3b7c62ec3a84ac030108473f9447db64a3af8595b043ad6670f35013e";
    };
    export type CreateTicketUseCaseType = typeof createTicketUseCase;
    export default createTicketUseCase;
}
declare module "_102047_/l4/controleChamados/usecases/decideClosure.defs" {
    export const decideClosureUseCase: {
        readonly schemaVersion: "2026-08-10-ns4-usecase-v3";
        readonly moduleName: "controleChamados";
        readonly useCaseId: "decideClosure";
        readonly title: "Confirmar o fechamento do chamado";
        readonly kind: "command";
        readonly compiledFrom: ["closeOpenTicket.decideClosure"];
        readonly description: "Confirma o fechamento de um chamado aberto.";
        readonly contexts: {
            readonly requires: ["selectedTicket"];
            readonly provides: ["selectedTicket"];
        };
        readonly entityRefs: ["Ticket"];
        readonly useRules: ["onlyOpenTicketCanBeClosed"];
        readonly transitionRefs: ["closeTicket"];
        readonly useCaseHash: "sha256:ccffc522c34fe9145b4ba8ffbbe76b6c2c21edf94ca88998f17633e94e852c5e";
    };
    export type DecideClosureUseCaseType = typeof decideClosureUseCase;
    export default decideClosureUseCase;
}
declare module "_102047_/l4/controleChamados/usecases/index.defs" {
    export const controleChamadosUseCaseIndex: {
        readonly schemaVersion: "2026-08-10-ns4-usecase-index-v3";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly sourceHashes: {
            readonly journeys: [{
                readonly journeyId: "commentOpenTicket";
                readonly businessHash: "sha256:496a92da9d280e9db4975401bd6575e57c703078ff53ed3fe4a1383c62164363";
            }, {
                readonly journeyId: "closeOpenTicket";
                readonly businessHash: "sha256:59a221f329e03b3d9664759d9ade26252066313814e79d983a82e7fb299aba3e";
            }, {
                readonly journeyId: "registerTicket";
                readonly businessHash: "sha256:fec1c17f3843924c7160eaf9b48ec99cecc163ce2a415c7f4c18385d34c79120";
            }, {
                readonly journeyId: "consultTicket";
                readonly businessHash: "sha256:28f65c7aea1dbed9d07c2e278d447809cbf29f4800e00f70af45cd0dcfcca8ce";
            }];
            readonly ontologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
            readonly rulesHash: "sha256:b6356c46bee687ee1f1aa2d750e415392b3de005047b3fe236224feab6242529";
        };
        readonly useCases: [{
            readonly useCaseId: "createTicket";
            readonly title: "Registrar os dados do chamado";
            readonly kind: "command";
            readonly compiledFrom: ["registerTicket.createTicket"];
            readonly useCaseHash: "sha256:349119b3b7c62ec3a84ac030108473f9447db64a3af8595b043ad6670f35013e";
            readonly artifactPath: "l4/controleChamados/usecases/createTicket.defs.ts";
        }, {
            readonly useCaseId: "decideClosure";
            readonly title: "Confirmar o fechamento do chamado";
            readonly kind: "command";
            readonly compiledFrom: ["closeOpenTicket.decideClosure"];
            readonly useCaseHash: "sha256:ccffc522c34fe9145b4ba8ffbbe76b6c2c21edf94ca88998f17633e94e852c5e";
            readonly artifactPath: "l4/controleChamados/usecases/decideClosure.defs.ts";
        }, {
            readonly useCaseId: "inspectTicket";
            readonly title: "Consultar informações e histórico do chamado";
            readonly kind: "command";
            readonly compiledFrom: ["consultTicket.inspectTicket"];
            readonly useCaseHash: "sha256:76d3254e8fac81c69a2f973caace12ec233578cfd0944f38c6e4c43541d95c1f";
            readonly artifactPath: "l4/controleChamados/usecases/inspectTicket.defs.ts";
        }, {
            readonly useCaseId: "locateTicket";
            readonly title: "Localizar o chamado aberto";
            readonly kind: "query";
            readonly compiledFrom: ["closeOpenTicket.locateTicket", "commentOpenTicket.locateTicket", "consultTicket.locateTicket"];
            readonly useCaseHash: "sha256:23dbe6fecdc23416a6c699043a61a643029a904cb33c05dc36d76d4363f97d80";
            readonly artifactPath: "l4/controleChamados/usecases/locateTicket.defs.ts";
        }, {
            readonly useCaseId: "recordComment";
            readonly title: "Registrar comentário";
            readonly kind: "command";
            readonly compiledFrom: ["commentOpenTicket.recordComment"];
            readonly useCaseHash: "sha256:d657ea9d78e877857748609e5f3a7dd814302afbe4b8ec5c615648d23cefb7c6";
            readonly artifactPath: "l4/controleChamados/usecases/recordComment.defs.ts";
        }];
        readonly realizationHash: "sha256:c04bd703428ac5be860ec897e7fe71f34604760cffd5e79b7546feaae111448a";
        readonly generatedAt: "2026-09-02T12:55:53.516Z";
    };
    export type ControleChamadosUseCaseIndexType = typeof controleChamadosUseCaseIndex;
    export default controleChamadosUseCaseIndex;
}
declare module "_102047_/l4/controleChamados/usecases/inspectTicket.defs" {
    export const inspectTicketUseCase: {
        readonly schemaVersion: "2026-08-10-ns4-usecase-v3";
        readonly moduleName: "controleChamados";
        readonly useCaseId: "inspectTicket";
        readonly title: "Consultar informações e histórico do chamado";
        readonly kind: "command";
        readonly compiledFrom: ["consultTicket.inspectTicket"];
        readonly description: "Consulta as informações do chamado selecionado e seu histórico de comentários.";
        readonly contexts: {
            readonly requires: ["selectedTicket"];
            readonly provides: ["selectedTicket"];
        };
        readonly entityRefs: ["Ticket", "TicketComment"];
        readonly useRules: [];
        readonly transitionRefs: [];
        readonly useCaseHash: "sha256:76d3254e8fac81c69a2f973caace12ec233578cfd0944f38c6e4c43541d95c1f";
    };
    export type InspectTicketUseCaseType = typeof inspectTicketUseCase;
    export default inspectTicketUseCase;
}
declare module "_102047_/l4/controleChamados/usecases/locateTicket.defs" {
    export const locateTicketUseCase: {
        readonly schemaVersion: "2026-08-10-ns4-usecase-v3";
        readonly moduleName: "controleChamados";
        readonly useCaseId: "locateTicket";
        readonly title: "Localizar o chamado aberto";
        readonly kind: "query";
        readonly compiledFrom: ["closeOpenTicket.locateTicket", "commentOpenTicket.locateTicket", "consultTicket.locateTicket"];
        readonly description: "Localiza um chamado e o disponibiliza como chamado selecionado.";
        readonly contexts: {
            readonly requires: [];
            readonly provides: ["selectedTicket"];
        };
        readonly entityRefs: ["Ticket"];
        readonly useRules: [];
        readonly transitionRefs: [];
        readonly useCaseHash: "sha256:23dbe6fecdc23416a6c699043a61a643029a904cb33c05dc36d76d4363f97d80";
    };
    export type LocateTicketUseCaseType = typeof locateTicketUseCase;
    export default locateTicketUseCase;
}
declare module "_102047_/l4/controleChamados/usecases/recordComment.defs" {
    export const recordCommentUseCase: {
        readonly schemaVersion: "2026-08-10-ns4-usecase-v3";
        readonly moduleName: "controleChamados";
        readonly useCaseId: "recordComment";
        readonly title: "Registrar comentário";
        readonly kind: "command";
        readonly compiledFrom: ["commentOpenTicket.recordComment"];
        readonly description: "Registra um comentário no histórico do chamado selecionado quando ele está aberto.";
        readonly contexts: {
            readonly requires: ["selectedTicket"];
            readonly provides: ["selectedTicketComment"];
        };
        readonly entityRefs: ["Ticket", "TicketComment"];
        readonly useRules: ["onlyOpenTicketCanReceiveComment"];
        readonly transitionRefs: [];
        readonly useCaseHash: "sha256:d657ea9d78e877857748609e5f3a7dd814302afbe4b8ec5c615648d23cefb7c6";
    };
    export type RecordCommentUseCaseType = typeof recordCommentUseCase;
    export default recordCommentUseCase;
}
declare module "_102047_/l4/controleChamados/workflows/index.defs" {
    export const controleChamadosWorkflowIndex: {
        readonly schemaVersion: "2026-08-12-ns4-workflow-index-v5";
        readonly moduleName: "controleChamados";
        readonly userLanguage: "pt-BR";
        readonly workflows: [{
            readonly workflowId: "ticketLifecycle";
            readonly entityRef: "Ticket";
            readonly workflowHash: "sha256:9ba7fe670b4f9613f58d4fce53ec2293f9ffb0c1f9ba71606d4fc3501f3a4eb6";
            readonly artifactPath: "l4/controleChamados/workflows/ticketLifecycle.defs.ts";
        }];
        readonly sourceHashes: {
            readonly journeys: [{
                readonly journeyId: "commentOpenTicket";
                readonly businessHash: "sha256:496a92da9d280e9db4975401bd6575e57c703078ff53ed3fe4a1383c62164363";
            }, {
                readonly journeyId: "closeOpenTicket";
                readonly businessHash: "sha256:59a221f329e03b3d9664759d9ade26252066313814e79d983a82e7fb299aba3e";
            }, {
                readonly journeyId: "registerTicket";
                readonly businessHash: "sha256:fec1c17f3843924c7160eaf9b48ec99cecc163ce2a415c7f4c18385d34c79120";
            }, {
                readonly journeyId: "consultTicket";
                readonly businessHash: "sha256:28f65c7aea1dbed9d07c2e278d447809cbf29f4800e00f70af45cd0dcfcca8ce";
            }];
            readonly ontologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
            readonly rulesHash: "sha256:b6356c46bee687ee1f1aa2d750e415392b3de005047b3fe236224feab6242529";
        };
        readonly realizationHash: "sha256:15edd3b7d4642515eb1e23fa854af6ade476167ef6ea73fc13b0f552830d084e";
        readonly generatedAt: "2026-09-02T12:55:53.516Z";
        readonly systemDecisions: [];
    };
    export type ControleChamadosWorkflowIndexType = typeof controleChamadosWorkflowIndex;
    export default controleChamadosWorkflowIndex;
}
declare module "_102047_/l4/controleChamados/workflows/ticketLifecycle.defs" {
    export const ticketLifecycleWorkflow: {
        readonly schemaVersion: "2026-08-11-ns4-workflow-v4";
        readonly moduleName: "controleChamados";
        readonly workflowId: "ticketLifecycle";
        readonly entityRef: "Ticket";
        readonly initialState: "open";
        readonly terminalStates: ["closed"];
        readonly states: ["open", "closed"];
        readonly transitions: [{
            readonly transitionId: "closeTicket";
            readonly entityRef: "Ticket";
            readonly fromStates: ["open"];
            readonly toState: "closed";
            readonly useRules: ["onlyOpenTicketCanBeClosed"];
            readonly useCaseId: "decideClosure";
        }];
        readonly workflowHash: "sha256:9ba7fe670b4f9613f58d4fce53ec2293f9ffb0c1f9ba71606d4fc3501f3a4eb6";
    };
    export type TicketLifecycleWorkflowType = typeof ticketLifecycleWorkflow;
    export default ticketLifecycleWorkflow;
}
declare module "_102047_/l4/controleChamados/workspaces/commentOpenTicket.defs" {
    export const commentOpenTicketWorkspace: {
        readonly workspaceId: "commentOpenTicket";
        readonly title: "Registrar comentário em chamado aberto";
        readonly actors: readonly ["atendente"];
        readonly kind: "operation";
        readonly entity: "TicketComment";
        readonly bffCalls: readonly [{
            readonly bffId: "qryLocateTicket";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locateTicket";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "locateTicket.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "locateTicket.$items.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "locateTicket.$items.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "locateTicket.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.commentOpenTicket.qryLocateTicket";
        }, {
            readonly bffId: "cmdRecordComment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "recordComment";
            }];
            readonly input: readonly [{
                readonly name: "ticketId";
                readonly from: "recordComment.ticketId";
                readonly required: true;
                readonly source: "routeParam";
                readonly type: "string";
            }, {
                readonly name: "commentText";
                readonly from: "recordComment.commentText";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "recordComment.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "recordComment.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "recordComment.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.commentOpenTicket.cmdRecordComment";
        }];
        readonly sections: readonly [{
            readonly sectionId: "locateTicket";
            readonly intent: "Um chamado aberto é selecionado a partir da Lista de chamados para acompanhamento.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryLocateTicket";
                readonly usage: "picker";
            }];
        }, {
            readonly sectionId: "recordComment";
            readonly intent: "Um comentário fica registrado no histórico do chamado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdRecordComment";
            }];
        }];
        readonly operationIds: readonly ["locateTicket", "recordComment"];
        readonly purpose: "Documentar o andamento do atendimento em um chamado aberto.";
        readonly presentation: {
            readonly categoryRef: "processWizard";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the journey tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:2fca13e1";
    };
    export default commentOpenTicketWorkspace;
}
declare module "_102047_/l4/controleChamados/workspaces/ticketCatalogue.defs" {
    export const ticketCatalogueWorkspace: {
        readonly workspaceId: "ticketCatalogue";
        readonly title: "Chamado";
        readonly actors: readonly ["atendente"];
        readonly kind: "operation";
        readonly entity: "Ticket";
        readonly bffCalls: readonly [{
            readonly bffId: "qryListTicket";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listTicket";
            }];
            readonly input: readonly [{
                readonly name: "search";
                readonly from: "listTicket.search";
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "sortBy";
                readonly from: "listTicket.sortBy";
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["status"];
            }, {
                readonly name: "sortOrder";
                readonly from: "listTicket.sortOrder";
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["asc", "desc"];
            }];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "listTicket.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "listTicket.$items.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "listTicket.$items.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "listTicket.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.qryListTicket";
        }, {
            readonly bffId: "cmdCreateTicket";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "createTicket";
            }];
            readonly input: readonly [{
                readonly name: "title";
                readonly from: "createTicket.title";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "description";
                readonly from: "createTicket.description";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly from: "createTicket.status";
                readonly required: true;
                readonly source: "systemDefault";
                readonly type: "string";
                readonly enumValues: readonly ["open", "closed"];
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "createTicket.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "createTicket.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "createTicket.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "createTicket.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.cmdCreateTicket";
        }, {
            readonly bffId: "cmdUpdateTicket";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "updateTicket";
            }];
            readonly input: readonly [{
                readonly name: "ticketId";
                readonly from: "updateTicket.ticketId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }, {
                readonly name: "title";
                readonly from: "updateTicket.title";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "description";
                readonly from: "updateTicket.description";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly from: "updateTicket.status";
                readonly required: true;
                readonly source: "systemDefault";
                readonly type: "string";
                readonly enumValues: readonly ["open", "closed"];
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "updateTicket.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "updateTicket.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "updateTicket.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "updateTicket.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.cmdUpdateTicket";
        }, {
            readonly bffId: "cmdDeleteTicket";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "deleteTicket";
            }];
            readonly input: readonly [{
                readonly name: "ticketId";
                readonly from: "deleteTicket.ticketId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "deleteTicket.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "deleteTicket.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "deleteTicket.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "deleteTicket.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.cmdDeleteTicket";
        }, {
            readonly bffId: "qryGetTicket";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "getTicket";
            }];
            readonly input: readonly [{
                readonly name: "ticketId";
                readonly from: "getTicket.ticketId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "getTicket.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "getTicket.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "getTicket.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "getTicket.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.qryGetTicket";
        }, {
            readonly bffId: "qryLocateTicket";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "locateTicket";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "locateTicket.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "locateTicket.$items.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "locateTicket.$items.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "locateTicket.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.qryLocateTicket";
        }, {
            readonly bffId: "cmdDecideClosure";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "decideClosure";
            }];
            readonly input: readonly [{
                readonly name: "ticketId";
                readonly from: "decideClosure.ticketId";
                readonly required: true;
                readonly source: "routeParam";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly from: "decideClosure.status";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["closed"];
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "decideClosure.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "decideClosure.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "decideClosure.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "decideClosure.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCatalogue.cmdDecideClosure";
        }];
        readonly sections: readonly [{
            readonly sectionId: "recordList";
            readonly intent: "Localizar Chamado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryListTicket";
            }, {
                readonly role: "filterControl";
                readonly attachTo: "qryListTicket";
            }, {
                readonly role: "contextualAction";
                readonly action: "cmdDeleteTicket";
            }];
        }, {
            readonly sectionId: "recordForm";
            readonly intent: "Criar ou corrigir Chamado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdCreateTicket";
            }, {
                readonly role: "contextualAction";
                readonly action: "cmdUpdateTicket";
            }];
        }, {
            readonly sectionId: "decideClosure";
            readonly intent: "O chamado passa a ter status fechado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdDecideClosure";
            }];
        }];
        readonly operationIds: readonly ["createTicket", "decideClosure", "deleteTicket", "getTicket", "listTicket", "locateTicket", "updateTicket"];
        readonly purpose: "Cadastro de Chamado.";
        readonly presentation: {
            readonly categoryRef: "entityRecordManagement";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the recordCatalogue tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:72aa9a44";
    };
    export default ticketCatalogueWorkspace;
}
declare module "_102047_/l4/controleChamados/workspaces/ticketCommentCatalogue.defs" {
    export const ticketCommentCatalogueWorkspace: {
        readonly workspaceId: "ticketCommentCatalogue";
        readonly title: "Comentário do chamado";
        readonly actors: readonly ["atendente"];
        readonly kind: "operation";
        readonly entity: "TicketComment";
        readonly bffCalls: readonly [{
            readonly bffId: "qryListTicketComment";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listTicketComment";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "listTicketComment.$items.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "listTicketComment.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "listTicketComment.$items.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCommentCatalogue.qryListTicketComment";
        }, {
            readonly bffId: "cmdCreateTicketComment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "createTicketComment";
            }];
            readonly input: readonly [{
                readonly name: "ticketId";
                readonly from: "createTicketComment.ticketId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryTicketPicker";
                readonly type: "string";
            }, {
                readonly name: "commentText";
                readonly from: "createTicketComment.commentText";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "createTicketComment.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "createTicketComment.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "createTicketComment.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCommentCatalogue.cmdCreateTicketComment";
        }, {
            readonly bffId: "cmdUpdateTicketComment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "updateTicketComment";
            }];
            readonly input: readonly [{
                readonly name: "ticketCommentId";
                readonly from: "updateTicketComment.ticketCommentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }, {
                readonly name: "ticketId";
                readonly from: "updateTicketComment.ticketId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly sourceRef: "qryTicketPicker";
                readonly type: "string";
            }, {
                readonly name: "commentText";
                readonly from: "updateTicketComment.commentText";
                readonly required: true;
                readonly source: "userInput";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "updateTicketComment.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "updateTicketComment.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "updateTicketComment.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment";
        }, {
            readonly bffId: "cmdDeleteTicketComment";
            readonly kind: "command";
            readonly uses: readonly [{
                readonly operationId: "deleteTicketComment";
            }];
            readonly input: readonly [{
                readonly name: "ticketCommentId";
                readonly from: "deleteTicketComment.ticketCommentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "deleteTicketComment.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "deleteTicketComment.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "deleteTicketComment.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment";
        }, {
            readonly bffId: "qryGetTicketComment";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "getTicketComment";
            }];
            readonly input: readonly [{
                readonly name: "ticketCommentId";
                readonly from: "getTicketComment.ticketCommentId";
                readonly required: true;
                readonly source: "selectedEntity";
                readonly type: "string";
            }];
            readonly output: {
                readonly kind: "object";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "getTicketComment.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "getTicketComment.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "getTicketComment.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCommentCatalogue.qryGetTicketComment";
        }, {
            readonly bffId: "qryTicketPicker";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listTicket";
            }];
            readonly input: readonly [{
                readonly name: "search";
                readonly from: "listTicket.search";
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "sortBy";
                readonly from: "listTicket.sortBy";
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["status"];
            }, {
                readonly name: "sortOrder";
                readonly from: "listTicket.sortOrder";
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["asc", "desc"];
            }];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "listTicket.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "listTicket.$items.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "listTicket.$items.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "listTicket.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketCommentCatalogue.qryTicketPicker";
        }];
        readonly sections: readonly [{
            readonly sectionId: "recordList";
            readonly intent: "Localizar Comentário do chamado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryListTicketComment";
            }, {
                readonly role: "contextualAction";
                readonly action: "cmdDeleteTicketComment";
            }];
        }, {
            readonly sectionId: "recordForm";
            readonly intent: "Criar ou corrigir Comentário do chamado.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly action: "cmdCreateTicketComment";
            }, {
                readonly role: "contextualAction";
                readonly action: "cmdUpdateTicketComment";
            }, {
                readonly role: "filterControl";
                readonly dataSource: "qryTicketPicker";
                readonly usage: "picker";
            }];
        }];
        readonly operationIds: readonly ["createTicketComment", "deleteTicketComment", "getTicketComment", "listTicket", "listTicketComment", "updateTicketComment"];
        readonly purpose: "Cadastro de Comentário do chamado.";
        readonly presentation: {
            readonly categoryRef: "entityRecordManagement";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the recordCatalogue tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:50cf1325";
    };
    export default ticketCommentCatalogueWorkspace;
}
declare module "_102047_/l4/controleChamados/workspaces/ticketHub.defs" {
    export const ticketHubWorkspace: {
        readonly workspaceId: "ticketHub";
        readonly title: "Chamado";
        readonly actors: readonly ["atendente"];
        readonly kind: "landing";
        readonly entity: "Ticket";
        readonly bffCalls: readonly [{
            readonly bffId: "qryListTicket";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listTicket";
            }];
            readonly input: readonly [{
                readonly name: "search";
                readonly from: "listTicket.search";
                readonly source: "userInput";
                readonly type: "string";
            }, {
                readonly name: "sortBy";
                readonly from: "listTicket.sortBy";
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["status"];
            }, {
                readonly name: "sortOrder";
                readonly from: "listTicket.sortOrder";
                readonly source: "userInput";
                readonly type: "string";
                readonly enumValues: readonly ["asc", "desc"];
            }];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketId";
                    readonly from: "listTicket.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "title";
                    readonly from: "listTicket.$items.title";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly from: "listTicket.$items.description";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly from: "listTicket.$items.status";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketHub.qryListTicket";
        }, {
            readonly bffId: "qryListTicketComment";
            readonly kind: "query";
            readonly uses: readonly [{
                readonly operationId: "listTicketComment";
            }];
            readonly input: readonly [];
            readonly output: {
                readonly kind: "list";
                readonly fields: readonly [{
                    readonly name: "ticketCommentId";
                    readonly from: "listTicketComment.$items.ticketCommentId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "ticketId";
                    readonly from: "listTicketComment.$items.ticketId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "commentText";
                    readonly from: "listTicketComment.$items.commentText";
                    readonly type: "string";
                    readonly required: true;
                }];
            };
            readonly route: "controleChamados.ticketHub.qryListTicketComment";
        }];
        readonly sections: readonly [{
            readonly sectionId: "collection";
            readonly intent: "Carteira e busca.";
            readonly organisms: readonly [{
                readonly role: "primarySurface";
                readonly dataSource: "qryListTicket";
            }];
        }, {
            readonly sectionId: "record";
            readonly intent: "Registro selecionado e o que gira em volta dele.";
            readonly organisms: readonly [{
                readonly role: "detailPanel";
                readonly dataSource: "qryListTicketComment";
            }];
        }];
        readonly operationIds: readonly ["listTicket", "listTicketComment"];
        readonly purpose: "Painel de Chamado.";
        readonly presentation: {
            readonly categoryRef: "dashboardCommandCenter";
            readonly confidence: 10;
            readonly classificationNote: "Derived from the hub tier of the approved E8 model; the category is structural, not a guess.";
        };
        readonly sliceHash: "sha256:1333cf38";
    };
    export default ticketHubWorkspace;
}
declare module "_102047_/l5/controleChamados/process.defs" {
    export const controleChamadosProcess: {
        readonly schemaVersion: "2026-08-13-ns4-process-v1";
        readonly moduleName: "controleChamados";
        readonly sourceHashes: {
            readonly journeys: [{
                readonly journeyId: "closeOpenTicket";
                readonly businessHash: "sha256:59a221f329e03b3d9664759d9ade26252066313814e79d983a82e7fb299aba3e";
            }, {
                readonly journeyId: "commentOpenTicket";
                readonly businessHash: "sha256:496a92da9d280e9db4975401bd6575e57c703078ff53ed3fe4a1383c62164363";
            }, {
                readonly journeyId: "consultTicket";
                readonly businessHash: "sha256:28f65c7aea1dbed9d07c2e278d447809cbf29f4800e00f70af45cd0dcfcca8ce";
            }, {
                readonly journeyId: "registerTicket";
                readonly businessHash: "sha256:fec1c17f3843924c7160eaf9b48ec99cecc163ce2a415c7f4c18385d34c79120";
            }];
            readonly accessHash: "sha256:03668099f53ef20645623a13d5c51a48a8c15b9bc3bbe3bc50833957bbe3b35f";
            readonly ontologyHash: "sha256:563cf2c2d6bfb3cca7f9abda33d56065755c6df6b2e5dba2880f51bb37e1787a";
            readonly rulesHash: "sha256:b6356c46bee687ee1f1aa2d750e415392b3de005047b3fe236224feab6242529";
        };
        readonly counts: {
            readonly journeys: 4;
            readonly workspaces: 4;
            readonly operations: 13;
            readonly contracts: 17;
            readonly decisions: 6;
        };
        readonly validation: {
            readonly status: "passed";
            readonly reportPath: "l4/controleChamados/pipeline/e10-validation-report.json";
            readonly reportHash: "sha256:2c313fd73bb4274cf69fd5e0d512988d25446d4d9b5e46e9ae4f17afe2194143";
            readonly warningCount: 0;
            readonly registrarCount: 0;
        };
        readonly next: {
            readonly frontend: "todoFrontend";
            readonly backend: "todoBackend";
        };
        readonly processHash: "sha256:01d1b70a5c3da5c270134ac688ae7076e99150a720220911a57f610d719bbf80";
    };
    export type ControleChamadosProcessType = typeof controleChamadosProcess;
    export default controleChamadosProcess;
}
declare module "_102047_/l5/controleChamados/todoBackend.defs" {
    export const controleChamadosTodoBackend: {
        readonly schemaVersion: "2026-08-13-ns4-todo-backend-v1";
        readonly layer: "backend";
        readonly moduleName: "controleChamados";
        readonly owners: [{
            readonly ownerType: "useCase";
            readonly ownerId: "createTicket";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "createTicketComment";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "decideClosure";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "deleteTicket";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "deleteTicketComment";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "getTicket";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "getTicketComment";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "listTicket";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "listTicketComment";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "locateTicket";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "recordComment";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "updateTicket";
            readonly statusBackend: "done";
        }, {
            readonly ownerType: "useCase";
            readonly ownerId: "updateTicketComment";
            readonly statusBackend: "done";
        }];
    };
    export type ControleChamadosTodoBackendType = typeof controleChamadosTodoBackend;
    export default controleChamadosTodoBackend;
}
declare module "_102047_/l5/controleChamados/todoFrontend.defs" {
    export const controleChamadosTodoFrontend: {
        readonly schemaVersion: "2026-08-13-ns4-todo-frontend-v1";
        readonly layer: "frontend";
        readonly moduleName: "controleChamados";
        readonly owners: [{
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.commentOpenTicket.cmdRecordComment";
            readonly workspaceId: "commentOpenTicket";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.commentOpenTicket.qryLocateTicket";
            readonly workspaceId: "commentOpenTicket";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.cmdCreateTicket";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.cmdDecideClosure";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.cmdDeleteTicket";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.cmdUpdateTicket";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.qryGetTicket";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.qryListTicket";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCatalogue.qryLocateTicket";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCommentCatalogue.cmdCreateTicketComment";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCommentCatalogue.cmdDeleteTicketComment";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCommentCatalogue.cmdUpdateTicketComment";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCommentCatalogue.qryGetTicketComment";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCommentCatalogue.qryListTicketComment";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketCommentCatalogue.qryTicketPicker";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketHub.qryListTicket";
            readonly workspaceId: "ticketHub";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "contract";
            readonly ownerId: "controleChamados.ticketHub.qryListTicketComment";
            readonly workspaceId: "ticketHub";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "workspace";
            readonly ownerId: "commentOpenTicket";
            readonly workspaceId: "commentOpenTicket";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "workspace";
            readonly ownerId: "ticketCatalogue";
            readonly workspaceId: "ticketCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "workspace";
            readonly ownerId: "ticketCommentCatalogue";
            readonly workspaceId: "ticketCommentCatalogue";
            readonly statusFrontend: "done";
        }, {
            readonly ownerType: "workspace";
            readonly ownerId: "ticketHub";
            readonly workspaceId: "ticketHub";
            readonly statusFrontend: "done";
        }];
    };
    export type ControleChamadosTodoFrontendType = typeof controleChamadosTodoFrontend;
    export default controleChamadosTodoFrontend;
}

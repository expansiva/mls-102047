declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102047_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    /**
     * Design system do projeto — vocabulário de tokens POR PAPEL (role-based).
     * Este vocabulário é o padrão para novos projetos; só os VALORES mudam por marca.
     *
     * Regras de nomenclatura (color):
     *  - O nome diz onde o token é usado; nunca deduza pelo valor.
     *  - Pares bg/text andam juntos: quem usa button-primary-bg escreve o rótulo
     *    com button-primary-text; quem usa status-error-bg usa status-error-text;
     *    nav-bg com nav-text; tooltip-bg com tooltip-text. Vale para todo par
     *    <papel>-bg / <papel>-text.
     *  - Superfícies: page-bg (fundo da página) > surface-bg (cards, painéis,
     *    modais) > surface-alt-bg (linhas zebradas, hover de linha, skeleton,
     *    cabeçalhos de seção). Texto sobre superfícies: text-strong (títulos),
     *    text-default (corpo), text-muted (secundário/placeholder).
     *  - Navegação (sidebar/topbar): nav-bg + nav-text; item ativo usa
     *    nav-active-bg + nav-active-text.
     *  - Overlay de modal: overlay-backdrop-bg atrás, surface-bg no modal.
     *  - Gráficos: séries usam chart-series-1..6 SEMPRE nesta ordem fixa (a ordem
     *    é o mecanismo de segurança para daltonismo — nunca embaralhar nem gerar
     *    cores novas); textos e eixos usam os tokens text-*, nunca a cor da série;
     *    status-* são reservados a estado e nunca viram série de gráfico.
     *  - Todo token base de cor tem as variantes -hover, -focus e -disabled
     *    (em chart-series, -disabled é a série apagada pela legenda).
     *  - Modo noite: cada chave tem par com prefixo _dark- (mesmo nome). O
     *    compilador gera o bloco dark automaticamente; paginas usam so o nome base.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102047_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102034_/l1/mdm/defs/level1Types" {
    /**
     * Level-1 ontology artifacts emitted from this engine into l4/organization/ontology.
     * Agents read the generated defs; they do not re-parse these types.
     */
    /** Schema of the platform level-1 ontology defs. Bumped when the subtype set or field shape changes. */
    export const NS4_LEVEL1_SCHEMA_VERSION: "ns4-level1-v2";
    /** Closed platform subtype set. Grows only on a platform release, never per module. */
    export const NS4_LEVEL1_SUBTYPE_VALUES: readonly ["Person", "Company", "Product", "Service", "Location", "AssetGeneric", "AssetVehicle", "AssetProperty", "AssetEquipment", "Animal", "BankAccount", "Document", "ContactChannel"];
    export type Ns4Level1Subtype = typeof NS4_LEVEL1_SUBTYPE_VALUES[number];
    export interface Ns4Level1Field {
        fieldId: string;
        type: string;
        required: boolean;
    }
    export interface Ns4Level1RelationshipRef {
        type: string;
        from: readonly string[];
        to: readonly string[];
        bidirectional: boolean;
    }
    export interface Ns4Level1AllowedRelationship {
        type: string;
        as: 'from' | 'to' | 'both';
        otherSubtypes: readonly string[];
    }
    export interface Ns4Level1EntityArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtype: string;
        identification: readonly Ns4Level1Field[];
        baseFields: readonly Ns4Level1Field[];
        allowedRelationships: readonly Ns4Level1AllowedRelationship[];
        compactRelationshipKeys: readonly string[];
    }
    export interface Ns4Level1IndexArtifact {
        schemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        level1SchemaVersion: typeof NS4_LEVEL1_SCHEMA_VERSION;
        subtypes: readonly Ns4Level1Subtype[];
        docTypes: readonly string[];
        mdmStatuses: readonly string[];
        relationshipTypes: readonly Ns4Level1RelationshipRef[];
    }
    export interface MdmPlatformService {
        service: string;
        table?: string;
        tables?: readonly string[];
        rows?: string;
        indexes?: readonly string[];
        operations?: readonly string[];
        useFor?: readonly string[];
        notFor?: readonly string[];
        catalog?: string;
        compactRefs?: string;
        storage?: string;
        rule?: string;
        pending?: readonly string[];
    }
    export interface MdmPlatformEvent {
        eventId: string;
        on: string;
    }
    export interface MdmPlatformCatalogArtifact {
        catalogVersion: string;
        layers: readonly {
            layer: string;
            owner: string;
            where: string;
            fields: readonly string[];
            note: string;
        }[];
        visibility: {
            rule: string;
            read: string;
            unrestricted: string;
            write: string;
        };
        identity: {
            who: string;
            whereThePersonExists: string;
            login: {
                storage: string;
                row: {
                    entityType: string;
                    entityId: string;
                    namespace: string;
                    tag: string;
                    module: string;
                };
                lookup: string;
                invariant: string;
                services?: readonly string[];
                pending: readonly string[];
            };
            otherIdentifiers: string;
            neverInModule: readonly string[];
        };
        roles: {
            meaning: string;
            tag: string;
            createOrAttach: readonly string[];
            ontologyRules: readonly string[];
            actorsAreNotRoles: string;
        };
        services: readonly MdmPlatformService[];
        lookups: readonly {
            lookup: string;
            cost: string;
        }[];
        invariants: readonly string[];
        /** Platform events a module may receive with `inbound.from: 'organization'`. No handler in alpha. */
        events?: readonly MdmPlatformEvent[];
    }
}
declare module "_102035_/l2/solution/types" {
    /** Schema ids for NS5 source artifacts. Bumped when a field is added or removed. */
    export const NS5_MODULE_SCHEMA_VERSION: "2026-09-10-ns5-module-v2";
    export const NS5_JOURNEY_SCHEMA_VERSION: "2026-09-10-ns5-journey-v1";
    export const NS5_ONTOLOGY_SCHEMA_VERSION: "2026-09-11-ns5-ontology-v2";
    export const NS5_RULES_SCHEMA_VERSION: "2026-09-10-ns5-rules-v1";
    export const NS5_WORKFLOWS_SCHEMA_VERSION: "2026-09-12-ns5-workflows-v2";
    export const NS5_ACCESS_SCHEMA_VERSION: "2026-09-12-ns5-access-v3";
    export const NS5_INTEGRATION_SCHEMA_VERSION: "2026-09-12-ns5-integration-v2";
    export const NS5_INTEGRATION_REQUEST_SCHEMA_VERSION: "2026-09-12-ns5-integration-request-v1";
    export const NS5_PIPELINE_SCHEMA_VERSION: "2026-09-10-ns5-pipeline-v1";
    export const NS5_STEP_IDS: readonly ["module10", "journeys20", "ontology30", "rules40", "workflows50", "access60", "integration70", "finalize80"];
    export type Ns5StepId = typeof NS5_STEP_IDS[number];
    export interface Ns5ModuleActor {
        /** journeys20 binds actorRef; access60 copies survivors onto access.defs.ts; finalize80 I3 checks coverage. */
        actorId: string;
        /** journeys20 drops inferred external without an exclusive step; integration70 treats system as a signal. */
        kind: 'internal' | 'external' | 'system';
        /** journeys20 removes inferred external without a private step; module10 only records the origin. */
        origin: 'named' | 'inferred';
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Planner / UI; no generator reads this as structure. */
        description: string;
    }
    export interface Ns5ModuleArtifact {
        /** Gate of module10; later steps refuse a different version. */
        schemaVersion: typeof NS5_MODULE_SCHEMA_VERSION;
        /** Folder name; every later step and the registry key off this. */
        moduleName: string;
        /** Planner / UI; no generator reads this as structure. */
        title: string;
        /** Phrases catalogue and later prompts write user-facing text in this language. */
        userLanguage: string;
        /** module10 gate; defaultLanguage must be in this list. */
        productLanguages: string[];
        /** Fallback language when a phrase is missing. */
        defaultLanguage: string;
        /** Resume and /rebuild all recover the original request from here. */
        sourcePrompt: string;
        /** Organization-wide aggregates; ontology30 writes this at the end of the fan-out. */
        details?: Record<string, Ns5OntologyDetail>;
    }
    export interface Ns5JourneyStep {
        /** Identity of the step; I6 names a handoff by this id. */
        stepId: string;
        /** journeys20 gate; finalize80 maps act/decide onto ontology transitions. */
        kind: 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
        /** ontology30 must declare this UpperCamel id; finalize80 checks it exists. */
        entity: string;
        /** ontology30 must declare each extra entity the step also changes. */
        affects?: string[];
        /**
         * Required on `kind: act`. `create` opens the record (or attaches, when mdm);
         * `transition` applies `transitionRef`; `update` writes fields without a state change.
         * Readers: I2, master backend, master frontend.
         */
        effect?: 'create' | 'update' | 'transition';
        /**
         * Required iff `effect === 'transition'`. Ontology `transitionId` of `entity` (lowerCamel).
         * Readers: I2, master backend, master frontend.
         */
        transitionRef?: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** workflows50 requires a process covering this handoff; must be an actorId. */
        handoffTo?: string;
    }
    export interface Ns5JourneyArtifact {
        /** Gate of journeys20. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Index order, workflows50.journeyRef. */
        journeyId: string;
        business: {
            /** Must be an actorId from the pipeline (then access.defs.ts). */
            actorRef: string;
            /** Planner / UI. */
            title: string;
            /** Planner / UI. */
            goal: string;
            entry: {
                /** journeys20 gate; no screen meaning. */
                mode: 'coldStart' | 'contextOrLookup' | 'fromNotification';
            };
            /** ontology30 collects entity names; finalize80 is the oracle for act/decide. */
            steps: Ns5JourneyStep[];
            outcome: {
                /** Planner / UI. */
                statement: string;
                /** Planner / UI. */
                evidence: string[];
            };
        };
        /** Staleness: journeys20 rewrite vs finalize80. */
        businessHash: string;
    }
    export interface Ns5SystemDecision {
        /** dropInferredActor<Actor> after journeys20. */
        decisionId: string;
        /** Mechanical choice. */
        chosen: string;
        /** Visible alternative; not offered as a widget. */
        alternatives: string[];
        decidedBy: 'system';
    }
    export interface Ns5JourneyIndexEntry {
        /** File name under journeys/. */
        journeyId: string;
        /** Must be an actorId that survived inferred-actor drop. */
        actorRef: string;
        /** Planner / UI. */
        title: string;
    }
    export interface Ns5JourneyIndexArtifact {
        /** Gate of journeys20; same version as each journey file. */
        schemaVersion: typeof NS5_JOURNEY_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Declaration order; ontology30 and access60 read this list. */
        journeys: Ns5JourneyIndexEntry[];
        /** journeys20 records dropInferredActor<Actor> here. */
        systemDecisions: Ns5SystemDecision[];
    }
    export interface Ns5OntologyDetail {
        /** Typed JSON column and screen formatting. */
        type: Ns5OntologyField['type'];
        /** Planner / UI; rules may cite details.<name>. */
        description: string;
    }
    export interface Ns5OntologyEnumValue {
        /** Stable English lowerCamel code; status.enum.value covers lifecycleStates[].state. */
        value: string;
        /** Screen select/badge label in userLanguage. */
        title: string;
    }
    export interface Ns5OntologyFieldConstraints {
        /** Inclusive lower bound; number, integer or money. */
        min?: number;
        /** Inclusive upper bound; number, integer or money. */
        max?: number;
        /** string or text only. */
        maxLength?: number;
        /** money or number only. */
        precision?: number;
    }
    export interface Ns5OntologyField {
        /** Grants and rules name Entidade.campo using this id. */
        fieldId: string;
        /** Planner / UI. */
        title: string;
        /** Backend storage and grant field resolution. */
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        /** Backend required-on-write; ontology30 gate. */
        required: boolean;
        /** Simple uniqueness; DDL unique index. Never the identity field. */
        unique?: boolean;
        /** Closed domain; value is the code, title is the screen label. */
        enum?: Ns5OntologyEnumValue[];
        /** Intrinsic to the type (day 1..31, percent 0..100). Never a business policy. */
        constraints?: Ns5OntologyFieldConstraints;
        /** Planner / UI. */
        description: string;
    }
    export interface Ns5OntologyEntityArtifact {
        /** Gate of ontology30. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / storage.mdmType prefix. */
        moduleName: string;
        /** File name, relationship endpoints, grant entityRefs. */
        entityId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** ontology30 gate vs storage.target; mdm has no lifecycle. */
        kind: 'core' | 'event' | 'supporting' | 'mdm' | 'valueObject';
        /** access60 own-anchor search; registry role inference. */
        party: 'person' | 'organization' | 'none';
        /** Required on kind mdm; must be a level-1 subtype. */
        mdmSubtype?: string;
        /** Resolvable field (own or level-1 identification/base). */
        displayField: string;
        /** Namespace-only on mdm; identity lives in storage.idField. */
        fields: Ns5OntologyField[];
        /** Composite uniqueness; fieldIds of this entity, never idField. finalize80 I9. */
        uniqueKeys?: string[][];
        /** Calculated values; typed JSON column; rules may cite details.<name>. */
        details?: Record<string, Ns5OntologyDetail>;
        /** finalize80 reachability; a screen may only request a declared transition. */
        lifecycleStates: Array<{
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        /** finalize80 maps journey act/decide onto these; ruleRefs cite rules.defs.ts. */
        transitions: Array<{
            transitionId: string;
            from: string[];
            to: string;
            by: string[] | 'system' | 'time';
            description: string;
            /** Optional citations; finalize80 I4 checks each id exists in rules.defs.ts. */
            ruleRefs?: string[];
        }>;
        storage: {
            /** Must match kind (mdm => mdm). */
            target: 'moduleDatabase' | 'mdm' | 'external';
            /** mdm is organization. */
            scope: string;
            /** Identity field; outside fields[] on mdm. */
            idField: string;
            /** '<mod>.<Entity>' on mdm, consumed by the registry. */
            mdmType?: string;
        };
        /** appendOnly entities have no lifecycle; E-like backends skip update/delete. */
        mutability?: 'appendOnly';
        /**
         * How this entity is written. Omitted = `journey` (an `act` writes it as `entity` or `affects`).
         * `crud` = reference catalog nobody creates in a journey (no lifecycle); master
         * frontend emits a data grid, master backend emits CRUD usecases.
         * `inbound` = created/updated by an integration inbound item; integration70 requires
         * a matching `inbound.writes` row. ontology30 normalize drops `crud`/`inbound` when
         * an act already writes the entity. ontology30 / access60 / finalize80 I10 I8.
         * Replaces `maintenance?: 'crud'` (ns5_31).
         */
        writer?: 'journey' | 'crud' | 'inbound';
    }
    export interface Ns5OntologyRelationship {
        /** Index identity. */
        relationshipId: string;
        /** Must be an entityId in this index. */
        fromEntity: string;
        /** Must be an entityId in this index. */
        toEntity: string;
        /** Structural type of the link. */
        type: string;
        /** Ontology screen edge label; master frontend. One sentence, userLanguage. */
        description: string;
        /** access60 own-anchor walk follows required edges. */
        required: boolean;
        persistence: {
            mode: 'moduleReference' | 'crossStoreReference' | 'mdmRelationship' | 'externalReference';
        };
        realization: {
            kind: string;
            ownerEntity: string;
            from: {
                entityId: string;
                fieldIds: string[];
            };
            to: {
                entityId: string;
                fieldIds: string[];
            };
        };
    }
    export interface Ns5OntologyIndexArtifact {
        /** Gate of ontology30 bindings. */
        schemaVersion: typeof NS5_ONTOLOGY_SCHEMA_VERSION;
        /** Folder / registry. */
        moduleName: string;
        /** Planner / UI. */
        businessDomain: string;
        /** Order of entity files; finalize80 coverage. */
        entities: string[];
        /** n15 field endpoints; access60 anchorPath. */
        relationships: Ns5OntologyRelationship[];
        /** ontology30: platform-service candidates (attachments/comments). Omitted when none. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5Rule {
        /** Cited by transitions.ruleRefs and later screens/endpoints. */
        ruleId: string;
        /** The only copy of the rule text. */
        description: string;
    }
    export interface Ns5RulesArtifact {
        /** Gate of rules40. */
        schemaVersion: typeof NS5_RULES_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Catalog of {ruleId, description}; I4 checks cited ruleRefs exist. */
        rules: Ns5Rule[];
    }
    export interface Ns5WorkflowTrigger {
        /** Gate: scheduled needs schedule, event needs event, manual needs actorRef. */
        kind: 'scheduled' | 'event' | 'manual';
        /** Required iff kind === 'scheduled'. Prose ("every month, day 1"). Backend job. */
        schedule?: string;
        /** Required iff kind === 'event'. '<Entity>.<transitionId>' of this module (inbound '<mod>.<eventId>' is ns5_31). */
        event?: string;
        /** Required iff kind === 'manual'. */
        actorRef?: string;
    }
    export interface Ns5WorkflowTask {
        /** Graph node id. Unique in the process. */
        taskId: string;
        /** Gate: no neutral value; every stage is one of these. */
        kind: 'human' | 'mechanical' | 'llm' | 'wait';
        /** Required on human. */
        actorRef?: string;
        /** Required on human. The journey the person runs, never a screen step. */
        journeyRef?: string;
        /** Required on mechanical|llm. Entity the stage acts on. */
        entityRef?: string;
        /** Required on mechanical|llm. Same form as act.effect (ns5_28). */
        effect?: 'create' | 'update' | 'transition';
        /** Required iff effect === 'transition'. Ontology transitionId; by is system or the actor. */
        transitionRef?: string;
        /** Acyclic unless a wait is on the cycle. */
        next: string[];
        /** Planner / UI. Wait: the pause (time or event) in prose. */
        description: string;
    }
    export interface Ns5WorkflowProcess {
        /** Index identity. */
        processId: string;
        /** Planner / UI. */
        title: string;
        /** Planner / UI. */
        description: string;
        /** How the process starts. Tela da Fase 2, harness, backend job. */
        trigger: Ns5WorkflowTrigger;
        /** finalize80 I6: every journey handoff appears as a human journeyRef. */
        tasks: Ns5WorkflowTask[];
    }
    export interface Ns5JourneyDecision {
        /** Must exist in the journey index. Tela da Fase 2 shows why a journey stayed out. */
        journeyId: string;
        /** One decision per journey in the same LLM call. */
        inProcess: boolean;
        /** Required iff inProcess. */
        processId?: string;
    }
    export interface Ns5WorkflowsArtifact {
        /** Gate of workflows50. Empty processes is valid. */
        schemaVersion: typeof NS5_WORKFLOWS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Orchestration only; not the entity FSM. */
        processes: Ns5WorkflowProcess[];
        /** One row per journey; the screen lists who is in a process. */
        journeyDecisions: Ns5JourneyDecision[];
        /** workflows50 normalize: dropped duplicate stages. */
        systemDecisions?: Ns5SystemDecision[];
    }
    export interface Ns5AccessDataScope {
        /** own|assigned|related require anchorEntity. Other modes drop it before the gate. */
        mode: 'own' | 'assigned' | 'related' | 'public' | 'organization' | 'custom';
        /** party:person entity reachable from each entityRef. The path is derived, not stored. */
        anchorEntity?: string;
        /** Prose for custom; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessDisclosure {
        /** fieldsOnly|summaryOnly require a proper (not the full resolvable set) allowedFields or deniedFields list. */
        mode: 'fullRecord' | 'fieldsOnly' | 'summaryOnly' | 'aggregateOnly';
        /** Entity.field the backend includes. */
        allowedFields?: string[];
        /** Entity.field the backend strips. */
        deniedFields?: string[];
        /** Prose; backend does not parse it. */
        description: string;
    }
    export interface Ns5AccessGrant {
        /** Index identity. Unique. */
        grantId: string;
        /** Must be an actorId from access.actors. */
        actorRef: string;
        /** Access matrix screen. */
        title: string;
        /** Access matrix screen. */
        description: string;
        /** Must be entityIds. */
        entityRefs: string[];
        dataScope: Ns5AccessDataScope;
        disclosure: Ns5AccessDisclosure;
    }
    export interface Ns5AccessArtifact {
        /** Gate of access60. */
        schemaVersion: typeof NS5_ACCESS_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** Copied from the pipeline (survivors of the journeys20 drop). The LLM does not rewrite this list. */
        actors: Ns5ModuleActor[];
        /** The grant is the capability. Backend applies scope and disclosure from these rows. */
        grants: Ns5AccessGrant[];
    }
    export interface Ns5IntegrationItem {
        /** Index identity. Unique across inbound and outbound. */
        id: string;
        /** Gate vs registry / plugin catalogue / platform events. */
        kind: 'moduleEndpoint' | 'event' | 'external';
        /** Inbound source: sibling module, `organization` (platform catalog), or external system. */
        from?: string;
        /** Outbound destination: sibling module, `any`, or external system. */
        to?: string;
        /** Event id this row receives (inbound) or publishes (outbound). Defaults to `id`. */
        event?: string;
        /**
         * Inbound: entities of this module the arrival creates/updates.
         * Counts as a writer (ontology30 WITHOUT_WRITER, access60, I10) and as `trigger.event`.
         */
        writes?: string[];
        /** Inbound: what the arrival does to `writes`. Required on inbound. */
        effect?: 'create' | 'update' | 'transition';
        /** Inbound, required iff `effect === 'transition'`. */
        transitionRef?: string;
        /**
         * Outbound: when this module publishes. `Entity.transitionId` or `Entity.create`.
         * Payload is the entity record at that moment (not declared in l4). I12 checks it exists.
         */
        on?: string;
        /** Planner / UI. Cites `inbound.id` when the rule maps a sibling payload. */
        description: string;
        /** Outbound (and inbound leftover): entity ids this row touches. */
        entityRefs: string[];
    }
    export interface Ns5IntegrationPlugin {
        /** Must be in the platform plugin catalogue. */
        pluginId: string;
        /** Planner / UI. */
        description: string;
        /** `journeyId.stepId` or `processId.taskId` that uses the plugin. I12. */
        usedBy: string[];
    }
    /** Queued request that a sibling (or a predicted module) publish an event. */
    export interface Ns5IntegrationRequestArtifact {
        schemaVersion: typeof NS5_INTEGRATION_REQUEST_SCHEMA_VERSION;
        requestedBy: string;
        eventId: string;
        on?: string;
        entityRefs: string[];
        description: string;
        status: 'requested';
        /** Organization inbox: the predicted module that should publish. */
        to?: string;
    }
    export interface Ns5IntegrationArtifact {
        /** Gate of integration70. Empty lists are valid. */
        schemaVersion: typeof NS5_INTEGRATION_SCHEMA_VERSION;
        /** Folder. */
        moduleName: string;
        /** What this module receives. */
        inbound: Ns5IntegrationItem[];
        /** What this module publishes. */
        outbound: Ns5IntegrationItem[];
        /** Platform plugins this module uses. */
        plugins: Ns5IntegrationPlugin[];
    }
    export type Ns5PipelineStatus = 'inProgress' | 'awaitingStep' | 'complete' | 'failed';
    /** Form change recorded on `pipeline.json` `steps.<step>`. Shape is step-specific. */
    export interface Ns5PipelineNormalization {
        kind: string;
        detail: string;
        entityId?: string;
        grantId?: string;
        journeyId?: string;
        stepId?: string;
        inboundId?: string;
    }
    export interface Ns5PipelineLiftedField {
        entityId: string;
        detail: string;
    }
    export interface Ns5PipelineStepState {
        /** Monotonic: approved is never overwritten by running/failed. */
        status: 'running' | 'approved' | 'failed';
        updatedAt: string;
        artifactPaths?: string[];
        error?: string;
        /** Set when /fast auto-approves; later steps and the supervisor read this. */
        autoReason?: string;
        /** journeys20: count of decide steps in the module. Zero is valid. */
        decideStepCount?: number;
        /** ontology30: entityIds no journey cites. Supporting/valueObject may be legitimate. */
        uncitedEntities?: string[];
        /**
         * ontology30: entity ids `liftNs5AggregateOnlyEntities` absorbed into `module.details`.
         * finalize80 I1 accepts a journey `entity`/`affects` that names one of these when
         * `module.details` still has the corresponding aggregate keys.
         */
        liftedAggregateEntities?: string[];
        /**
         * Form changes this step applied (pt→pt-BR, dropCrud, liftedFields, …).
         * Same records as the step draft `normalizations[]`. Fase 2 reads this.
         */
        normalizations?: Ns5PipelineNormalization[];
        /**
         * ontology30: extra fields discarded when a panel entity was lifted
         * (`normalizations[].kind === 'liftedFields'`).
         */
        liftedFields?: Ns5PipelineLiftedField[];
        /** module10: actors born by the step. Later steps read them via `readNs5Actors`. */
        actors?: Ns5ModuleActor[];
        /** journeys20: actorIds dropped as inferred-external without an exclusive step. */
        droppedActors?: string[];
        /** workflows50: true when processes is [] because no handoff, foreign-by, cross-actor decide, system/time transition or time/event phrase. */
        noProcessSignal?: boolean;
        /** integration70: true when inbound/outbound/plugins are [] because no system actor and no plugin-catalog term. */
        noIntegrationSignal?: boolean;
    }
    export interface Ns5Invocation {
        /** /fast skips reserved clarification anchors. */
        fast: boolean;
        /** /module value when given; module10 proposes lowerCamel otherwise. */
        module: string;
        /** /rebuild all of that module (l1/l2/l4/l5 trees plus l5 json / registry). */
        rebuildAll: boolean;
    }
    export interface Ns5RebuildAllReport {
        /** Display paths unlinked under l1/l2/l4/l5/<module>/. */
        deleted: string[];
        /** Display paths rewritten (l5 jsons and the organization registry). */
        edited: string[];
        at: string;
    }
    export interface Ns5PipelineState {
        /** Gate of the skeleton; later steps refuse a different version. */
        schemaVersion: typeof NS5_PIPELINE_SCHEMA_VERSION;
        /** Must be agentNewSolution5. */
        flowId: 'agentNewSolution5';
        /** Folder this pipeline belongs to. */
        moduleName: string;
        /** Supervisor reads awaitingStep when status is awaitingStep. */
        status: Ns5PipelineStatus;
        /** First unimplemented step id; supervisor proof for ns5_01. */
        awaitingStep?: Ns5StepId;
        /** Per-step checkpoint; empty at create. */
        steps: Partial<Record<Ns5StepId, Ns5PipelineStepState>>;
        /** Original user prompt after flags are stripped. */
        sourcePrompt: string;
        /** Flags used for this run. */
        invocation: Ns5Invocation;
        /** Set when this pipeline was created by /rebuild all. */
        rebuildAll?: Ns5RebuildAllReport;
        updatedAt: string;
    }
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102034_/l1/mdm/defs/level1Types";
}
declare module "_102047_/l4/agendaClinica/access.defs" {
    export const agendaClinicaAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "agendaClinica";
        readonly actors: [{
            readonly actorId: "recepcionista";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Recepcionista";
            readonly description: "Profissional da clínica que cadastra pacientes, agenda e confirma consultas e registra faltas.";
        }, {
            readonly actorId: "profissional";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Profissional";
            readonly description: "Médico ou terapeuta da clínica que consulta sua agenda diária e registra os atendimentos realizados.";
        }];
        readonly grants: [{
            readonly grantId: "gestaoAgendaRecepcionista";
            readonly actorRef: "recepcionista";
            readonly title: "Gestão de pacientes, profissionais e agenda";
            readonly description: "Permite cadastrar pacientes, manter o cadastro de profissionais e agendar, confirmar ou registrar faltas em consultas de toda a clínica, sem acesso às anotações de atendimento.";
            readonly entityRefs: ["Paciente", "Profissional", "Consulta"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os cadastros e as consultas de toda a clínica.";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Disponibiliza os dados necessários para cadastro e gestão da agenda, preservando a anotação clínica do atendimento.";
                readonly allowedFields: ["Paciente.id", "Profissional.id", "Consulta.id", "Consulta.pacienteId", "Consulta.profissionalId", "Consulta.scheduledAt", "Consulta.status"];
                readonly deniedFields: ["Consulta.attendanceNote"];
            };
        }, {
            readonly grantId: "agendaPropriaProfissional";
            readonly actorRef: "profissional";
            readonly title: "Agenda e atendimentos próprios";
            readonly description: "Permite consultar as próprias consultas agendadas e registrar o atendimento realizado com sua anotação.";
            readonly entityRefs: ["Consulta"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Abrange somente as consultas vinculadas ao profissional autenticado.";
                readonly anchorEntity: "Profissional";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Disponibiliza todos os campos da consulta vinculada ao próprio profissional, incluindo a anotação de atendimento.";
            };
        }];
    };
    export type AgendaClinicaAccessType = typeof agendaClinicaAccess;
    export default agendaClinicaAccess;
}
declare module "_102047_/l4/agendaClinica/integration.defs" {
    export const agendaClinicaIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "agendaClinica";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "consultaConfirmada";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "consultaConfirmada";
            readonly on: "Consulta.confirmarConsulta";
            readonly description: "Publica a confirmação da consulta para módulos interessados.";
            readonly entityRefs: ["Consulta"];
        }, {
            readonly id: "consultaComFaltaRegistrada";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "consultaComFaltaRegistrada";
            readonly on: "Consulta.registrarFalta";
            readonly description: "Publica o registro de falta do paciente para módulos interessados.";
            readonly entityRefs: ["Consulta"];
        }, {
            readonly id: "consultaAtendida";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "consultaAtendida";
            readonly on: "Consulta.registrarAtendimento";
            readonly description: "Publica a conclusão do atendimento para módulos interessados.";
            readonly entityRefs: ["Consulta"];
        }];
        readonly plugins: [];
    };
    export type AgendaClinicaIntegrationType = typeof agendaClinicaIntegration;
    export default agendaClinicaIntegration;
}
declare module "_102047_/l4/agendaClinica/module.defs" {
    export const agendaClinicaModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "agendaClinica";
        readonly title: "Agenda Clínica";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "criar o módulo agendaClinica em português. a clínica tem profissionais (médicos e terapeutas) e pacientes. a recepcionista cadastra pacientes, marca consultas para um profissional em data e hora, confirma por telefone, e registra falta quando o paciente não vem. o profissional vê só a própria agenda do dia e marca a consulta como atendida com uma anotação. não pode haver duas consultas do mesmo profissional no mesmo horário. dois perfis: recepcionista e profissional.";
    };
    export type AgendaClinicaModuleType = typeof agendaClinicaModule;
    export default agendaClinicaModule;
}
declare module "_102047_/l4/agendaClinica/rules.defs" {
    export const agendaClinicaRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "agendaClinica";
        readonly rules: [{
            readonly ruleId: "horarioProfissionalExclusivo";
            readonly description: "Não pode haver duas consultas para o mesmo profissional na mesma data e horário.";
        }, {
            readonly ruleId: "anotacaoObrigatoriaNoAtendimento";
            readonly description: "O registro de atendimento deve incluir uma anotação do atendimento.";
        }];
    };
    export type AgendaClinicaRulesType = typeof agendaClinicaRules;
    export default agendaClinicaRules;
}
declare module "_102047_/l4/agendaClinica/workflows.defs" {
    export const agendaClinicaWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "agendaClinica";
        readonly processes: [{
            readonly processId: "acompanharConsultaAgendada";
            readonly title: "Acompanhar consulta agendada";
            readonly description: "Coordena a confirmação da consulta e o atendimento pelo profissional no horário marcado.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "recepcionista";
            };
            readonly tasks: [{
                readonly taskId: "agendarConsulta";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "agendarConsulta";
                readonly next: ["confirmarConsultaPorTelefone"];
                readonly description: "A recepcionista agenda a consulta para o paciente com o profissional e horário definidos.";
            }, {
                readonly taskId: "confirmarConsultaPorTelefone";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "confirmarConsultaPorTelefone";
                readonly next: ["aguardarHorarioDaConsulta"];
                readonly description: "A recepcionista registra a confirmação telefônica da consulta agendada.";
            }, {
                readonly taskId: "aguardarHorarioDaConsulta";
                readonly kind: "wait";
                readonly next: ["consultarAgendaDiaria"];
                readonly description: "Aguarda o horário programado da consulta.";
            }, {
                readonly taskId: "consultarAgendaDiaria";
                readonly kind: "human";
                readonly actorRef: "profissional";
                readonly journeyRef: "consultarAgendaDiaria";
                readonly next: ["registrarAtendimento"];
                readonly description: "O profissional consulta a própria agenda do dia para preparar o atendimento.";
            }, {
                readonly taskId: "registrarAtendimento";
                readonly kind: "human";
                readonly actorRef: "profissional";
                readonly journeyRef: "registrarAtendimento";
                readonly next: [];
                readonly description: "O profissional registra o atendimento realizado e sua anotação.";
            }];
        }, {
            readonly processId: "registrarAusenciaEmConsulta";
            readonly title: "Registrar ausência em consulta";
            readonly description: "Registra a falta do paciente quando ele não comparece à consulta.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "recepcionista";
            };
            readonly tasks: [{
                readonly taskId: "registrarFaltaPaciente";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "registrarFaltaPaciente";
                readonly next: [];
                readonly description: "A recepcionista marca a consulta como falta do paciente após o não comparecimento.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "cadastrarPaciente";
            readonly inProcess: false;
        }, {
            readonly journeyId: "agendarConsulta";
            readonly inProcess: true;
            readonly processId: "acompanharConsultaAgendada";
        }, {
            readonly journeyId: "confirmarConsultaPorTelefone";
            readonly inProcess: true;
            readonly processId: "acompanharConsultaAgendada";
        }, {
            readonly journeyId: "registrarFaltaPaciente";
            readonly inProcess: true;
            readonly processId: "registrarAusenciaEmConsulta";
        }, {
            readonly journeyId: "consultarAgendaDiaria";
            readonly inProcess: true;
            readonly processId: "acompanharConsultaAgendada";
        }, {
            readonly journeyId: "registrarAtendimento";
            readonly inProcess: true;
            readonly processId: "acompanharConsultaAgendada";
        }];
    };
    export type AgendaClinicaWorkflowsType = typeof agendaClinicaWorkflows;
    export default agendaClinicaWorkflows;
}
declare module "_102047_/l4/agendaClinica/journeys/agendarConsulta.defs" {
    export const agendarConsultaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "agendarConsulta";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Agendar consulta";
            readonly goal: "Marcar uma consulta para um paciente com um profissional em data e horário disponíveis.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarPaciente";
                readonly kind: "locate";
                readonly entity: "Paciente";
                readonly title: "x";
                readonly description: "Localiza o paciente que receberá a consulta.";
            }, {
                readonly stepId: "localizarProfissional";
                readonly kind: "locate";
                readonly entity: "Profissional";
                readonly title: "x";
                readonly description: "Localiza o profissional que realizará a consulta.";
            }, {
                readonly stepId: "criarConsulta";
                readonly kind: "act";
                readonly entity: "Consulta";
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Registra a consulta com paciente, profissional, data e horário.";
            }];
            readonly outcome: {
                readonly statement: "A consulta fica agendada para o paciente e o profissional no horário informado.";
                readonly evidence: ["Consulta criada com data, horário, paciente e profissional.", "Horário do profissional passa a constar como ocupado."];
            };
        };
        readonly businessHash: "sha256:6799d2524c273213ff99272987c51f3fd9ac61dc388d0da06f8449f742856c26";
    };
    export type AgendarConsultaJourneyType = typeof agendarConsultaJourney;
    export default agendarConsultaJourney;
}
declare module "_102047_/l4/agendaClinica/journeys/cadastrarPaciente.defs" {
    export const cadastrarPacienteJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarPaciente";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Cadastrar paciente";
            readonly goal: "Registrar ou vincular o paciente para permitir seu atendimento na clínica.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "informarDadosPaciente";
                readonly kind: "act";
                readonly entity: "Paciente";
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Informa os dados cadastrais do paciente.";
            }];
            readonly outcome: {
                readonly statement: "O paciente fica cadastrado ou vinculado ao registro mestre existente.";
                readonly evidence: ["Registro de Paciente disponível para agendamento."];
            };
        };
        readonly businessHash: "sha256:56f79077b7ebd77e004786f5b826983d537ee6300ec9e1bfc5c4209c17e37929";
    };
    export type CadastrarPacienteJourneyType = typeof cadastrarPacienteJourney;
    export default cadastrarPacienteJourney;
}
declare module "_102047_/l4/agendaClinica/journeys/confirmarConsultaPorTelefone.defs" {
    export const confirmarConsultaPorTelefoneJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "confirmarConsultaPorTelefone";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Confirmar consulta por telefone";
            readonly goal: "Registrar a confirmação telefônica de uma consulta agendada.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarConsultaAgendada";
                readonly kind: "locate";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Localiza a consulta agendada para contato.";
            }, {
                readonly stepId: "inspecionarDadosDaConsulta";
                readonly kind: "inspect";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Confere os dados da consulta antes do contato telefônico.";
            }, {
                readonly stepId: "confirmarConsulta";
                readonly kind: "act";
                readonly entity: "Consulta";
                readonly effect: "transition";
                readonly transitionRef: "confirmarConsulta";
                readonly title: "x";
                readonly description: "Registra que o paciente confirmou a consulta por telefone.";
            }];
            readonly outcome: {
                readonly statement: "A consulta fica registrada como confirmada.";
                readonly evidence: ["Situação da consulta indica confirmação.", "Registro da consulta mostra a confirmação telefônica."];
            };
        };
        readonly businessHash: "sha256:4172afd9d3b870f9c2ff59752c98b18dddf6a822f373846d09d5397f8526616e";
    };
    export type ConfirmarConsultaPorTelefoneJourneyType = typeof confirmarConsultaPorTelefoneJourney;
    export default confirmarConsultaPorTelefoneJourney;
}
declare module "_102047_/l4/agendaClinica/journeys/consultarAgendaDiaria.defs" {
    export const consultarAgendaDiariaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "consultarAgendaDiaria";
        readonly business: {
            readonly actorRef: "profissional";
            readonly title: "Consultar agenda diária";
            readonly goal: "Visualizar as próprias consultas previstas para o dia.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarConsultasDoDia";
                readonly kind: "locate";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Localiza as consultas do próprio profissional para o dia.";
            }, {
                readonly stepId: "inspecionarAgendaDoDia";
                readonly kind: "inspect";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Consulta horários e dados dos pacientes da agenda diária.";
            }];
            readonly outcome: {
                readonly statement: "O profissional visualiza sua agenda diária.";
                readonly evidence: ["Lista de consultas do dia do profissional é apresentada com horários e pacientes."];
            };
        };
        readonly businessHash: "sha256:e508a925562d83d7e68262e702cfd6943b2ea74dd135a4c892547a926a8cf68e";
    };
    export type ConsultarAgendaDiariaJourneyType = typeof consultarAgendaDiariaJourney;
    export default consultarAgendaDiariaJourney;
}
declare module "_102047_/l4/agendaClinica/journeys/index.defs" {
    export const agendaClinicaJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "agendaClinica";
        readonly journeys: [{
            readonly journeyId: "cadastrarPaciente";
            readonly actorRef: "recepcionista";
            readonly title: "Cadastrar paciente";
        }, {
            readonly journeyId: "agendarConsulta";
            readonly actorRef: "recepcionista";
            readonly title: "Agendar consulta";
        }, {
            readonly journeyId: "confirmarConsultaPorTelefone";
            readonly actorRef: "recepcionista";
            readonly title: "Confirmar consulta por telefone";
        }, {
            readonly journeyId: "registrarFaltaPaciente";
            readonly actorRef: "recepcionista";
            readonly title: "Registrar falta do paciente";
        }, {
            readonly journeyId: "consultarAgendaDiaria";
            readonly actorRef: "profissional";
            readonly title: "Consultar agenda diária";
        }, {
            readonly journeyId: "registrarAtendimento";
            readonly actorRef: "profissional";
            readonly title: "Registrar atendimento realizado";
        }];
        readonly systemDecisions: [];
    };
    export type AgendaClinicaJourneyIndexType = typeof agendaClinicaJourneyIndex;
    export default agendaClinicaJourneyIndex;
}
declare module "_102047_/l4/agendaClinica/journeys/registrarAtendimento.defs" {
    export const registrarAtendimentoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarAtendimento";
        readonly business: {
            readonly actorRef: "profissional";
            readonly title: "Registrar atendimento realizado";
            readonly goal: "Marcar uma consulta como atendida e registrar uma anotação do atendimento.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarConsultaDaAgenda";
                readonly kind: "locate";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Localiza uma consulta da própria agenda.";
            }, {
                readonly stepId: "inspecionarConsulta";
                readonly kind: "inspect";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Confere os dados da consulta antes de concluir o atendimento.";
            }, {
                readonly stepId: "registrarAtendimentoRealizado";
                readonly kind: "act";
                readonly entity: "Consulta";
                readonly effect: "transition";
                readonly transitionRef: "registrarAtendimento";
                readonly title: "x";
                readonly description: "Marca a consulta como atendida e registra a anotação do atendimento.";
            }];
            readonly outcome: {
                readonly statement: "A consulta fica registrada como atendida com a anotação do profissional.";
                readonly evidence: ["Situação da consulta indica atendimento realizado.", "Anotação do atendimento está registrada na consulta."];
            };
        };
        readonly businessHash: "sha256:f4b141538e312c7e305b1dc0e259af89e509e35d60e80d682447516f9f08f2d7";
    };
    export type RegistrarAtendimentoJourneyType = typeof registrarAtendimentoJourney;
    export default registrarAtendimentoJourney;
}
declare module "_102047_/l4/agendaClinica/journeys/registrarFaltaPaciente.defs" {
    export const registrarFaltaPacienteJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarFaltaPaciente";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Registrar falta do paciente";
            readonly goal: "Registrar que o paciente não compareceu à consulta.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarConsultaDoPaciente";
                readonly kind: "locate";
                readonly entity: "Consulta";
                readonly title: "x";
                readonly description: "Localiza a consulta em que o paciente não compareceu.";
            }, {
                readonly stepId: "registrarFalta";
                readonly kind: "act";
                readonly entity: "Consulta";
                readonly effect: "transition";
                readonly transitionRef: "registrarFalta";
                readonly title: "x";
                readonly description: "Marca a consulta como falta do paciente.";
            }];
            readonly outcome: {
                readonly statement: "A ausência do paciente fica registrada na consulta.";
                readonly evidence: ["Situação da consulta indica falta.", "Consulta permanece disponível no histórico do paciente e do profissional."];
            };
        };
        readonly businessHash: "sha256:7bc5e90e6b1f478bb7841c1ee551d593c82221774efe834cb4605f2d4c7ef094";
    };
    export type RegistrarFaltaPacienteJourneyType = typeof registrarFaltaPacienteJourney;
    export default registrarFaltaPacienteJourney;
}
declare module "_102047_/l4/agendaClinica/ontology/Consulta.defs" {
    export const agendaClinicaEntityConsulta: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "agendaClinica";
        readonly entityId: "Consulta";
        readonly title: "Consulta";
        readonly description: "Agendamento de atendimento de um paciente com um profissional em data e horário determinados.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "scheduledAt";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da consulta.";
        }, {
            readonly fieldId: "pacienteId";
            readonly title: "Paciente";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao paciente para o qual a consulta foi agendada.";
        }, {
            readonly fieldId: "profissionalId";
            readonly title: "Profissional";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao profissional que realizará a consulta.";
        }, {
            readonly fieldId: "scheduledAt";
            readonly title: "Data e horário";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e horário agendados para a consulta.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "scheduled";
                readonly title: "Agendada";
            }, {
                readonly value: "confirmed";
                readonly title: "Confirmada";
            }, {
                readonly value: "missed";
                readonly title: "Falta registrada";
            }, {
                readonly value: "attended";
                readonly title: "Atendida";
            }];
            readonly description: "Situação atual da consulta.";
        }, {
            readonly fieldId: "attendanceNote";
            readonly title: "Anotação do atendimento";
            readonly type: "text";
            readonly required: false;
            readonly description: "Anotação registrada pelo profissional após o atendimento.";
        }];
        readonly uniqueKeys: [["profissionalId", "scheduledAt"]];
        readonly lifecycleStates: [{
            readonly state: "scheduled";
            readonly reachedBy: "actor";
        }, {
            readonly state: "confirmed";
            readonly reachedBy: "actor";
        }, {
            readonly state: "missed";
            readonly reachedBy: "actor";
        }, {
            readonly state: "attended";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "confirmarConsulta";
            readonly from: ["scheduled"];
            readonly to: "confirmed";
            readonly by: ["recepcionista"];
            readonly description: "Registra a confirmação telefônica da consulta pelo paciente.";
        }, {
            readonly transitionId: "registrarFalta";
            readonly from: ["scheduled", "confirmed"];
            readonly to: "missed";
            readonly by: ["recepcionista"];
            readonly description: "Registra que o paciente não compareceu à consulta.";
        }, {
            readonly transitionId: "registrarAtendimento";
            readonly from: ["scheduled", "confirmed"];
            readonly to: "attended";
            readonly by: ["profissional"];
            readonly description: "Registra a realização da consulta e a anotação do atendimento.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type AgendaClinicaEntityConsultaType = typeof agendaClinicaEntityConsulta;
    export default agendaClinicaEntityConsulta;
}
declare module "_102047_/l4/agendaClinica/ontology/Paciente.defs" {
    export const agendaClinicaEntityPaciente: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "agendaClinica";
        readonly entityId: "Paciente";
        readonly title: "Paciente";
        readonly description: "Pessoa cadastrada ou vinculada à clínica para receber consultas.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "agendaClinica.Paciente";
        };
    };
    export type AgendaClinicaEntityPacienteType = typeof agendaClinicaEntityPaciente;
    export default agendaClinicaEntityPaciente;
}
declare module "_102047_/l4/agendaClinica/ontology/Profissional.defs" {
    export const agendaClinicaEntityProfissional: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "agendaClinica";
        readonly entityId: "Profissional";
        readonly title: "Profissional";
        readonly description: "Médico ou terapeuta da clínica que realiza consultas e acessa a própria agenda.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "agendaClinica.Profissional";
        };
        readonly writer: "crud";
    };
    export type AgendaClinicaEntityProfissionalType = typeof agendaClinicaEntityProfissional;
    export default agendaClinicaEntityProfissional;
}
declare module "_102047_/l4/agendaClinica/ontology/index.defs" {
    export const agendaClinicaOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "agendaClinica";
        readonly businessDomain: "Agendamento e registro de consultas clínicas";
        readonly entities: ["Paciente", "Profissional", "Consulta"];
        readonly relationships: [{
            readonly relationshipId: "consultaPaciente";
            readonly fromEntity: "Consulta";
            readonly toEntity: "Paciente";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada consulta é agendada para um paciente.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Consulta";
                readonly from: {
                    readonly entityId: "Consulta";
                    readonly fieldIds: ["pacienteId"];
                };
                readonly to: {
                    readonly entityId: "Paciente";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "consultaProfissional";
            readonly fromEntity: "Consulta";
            readonly toEntity: "Profissional";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada consulta é realizada por um profissional.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Consulta";
                readonly from: {
                    readonly entityId: "Consulta";
                    readonly fieldIds: ["profissionalId"];
                };
                readonly to: {
                    readonly entityId: "Profissional";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type AgendaClinicaOntologyIndexType = typeof agendaClinicaOntologyIndex;
    export default agendaClinicaOntologyIndex;
}
declare module "_102047_/l4/comandaRestaurante/access.defs" {
    export const comandaRestauranteAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "comandaRestaurante";
        readonly actors: [{
            readonly actorId: "garcom";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Garçom";
            readonly description: "Profissional do restaurante que abre comandas para mesas, lança itens e cancela lançamentos realizados por engano enquanto a comanda está aberta.";
        }, {
            readonly actorId: "caixa";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Caixa";
            readonly description: "Profissional do restaurante que fecha comandas, aplica descontos opcionais, registra a forma de pagamento e libera a mesa.";
        }];
        readonly grants: [{
            readonly grantId: "garcomRecursosRestaurante";
            readonly actorRef: "garcom";
            readonly title: "Consultar mesas e cardápio";
            readonly description: "Permite ao garçom consultar todas as mesas do restaurante e os itens disponíveis no cardápio para abrir comandas e registrar pedidos.";
            readonly entityRefs: ["Mesa", "ItemCardapio"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Mesas e itens do cardápio de todo o restaurante.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Exibe todos os campos disponíveis de mesas e itens do cardápio.";
            };
        }, {
            readonly grantId: "garcomPropriasComandas";
            readonly actorRef: "garcom";
            readonly title: "Gerenciar próprias comandas";
            readonly description: "Permite ao garçom manter seu próprio cadastro funcional, abrir comandas vinculadas a ele, lançar itens e cancelar lançamentos de suas comandas abertas.";
            readonly entityRefs: ["Garcom", "Comanda", "ItemComanda"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Acesso ao cadastro do garçom autenticado e às comandas e lançamentos vinculados a ele.";
                readonly anchorEntity: "Garcom";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Exibe todos os campos disponíveis das próprias comandas e de seus lançamentos.";
            };
        }, {
            readonly grantId: "caixaFechamentoComandas";
            readonly actorRef: "caixa";
            readonly title: "Fechar comandas do restaurante";
            readonly description: "Permite ao caixa consultar mesas, comandas e lançamentos de todo o restaurante para registrar pagamento, aplicar desconto, encerrar a comanda e liberar a mesa.";
            readonly entityRefs: ["Mesa", "Comanda", "ItemComanda"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Comandas, lançamentos e mesas de todo o restaurante.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Exibe todos os campos disponíveis necessários para conferir e fechar as comandas.";
            };
        }];
    };
    export type ComandaRestauranteAccessType = typeof comandaRestauranteAccess;
    export default comandaRestauranteAccess;
}
declare module "_102047_/l4/comandaRestaurante/integration.defs" {
    export const comandaRestauranteIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "comandaRestaurante";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "comandaFechada";
            readonly kind: "event";
            readonly to: "controleEstoque";
            readonly event: "comandaFechada";
            readonly on: "Comanda.fecharComanda";
            readonly description: "Publica o fechamento da comanda, com os itens consumidos, para que o controle de estoque possa registrar a baixa correspondente.";
            readonly entityRefs: ["Comanda", "ItemComanda"];
        }];
        readonly plugins: [];
    };
    export type ComandaRestauranteIntegrationType = typeof comandaRestauranteIntegration;
    export default comandaRestauranteIntegration;
}
declare module "_102047_/l4/comandaRestaurante/module.defs" {
    export const comandaRestauranteModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "comandaRestaurante";
        readonly title: "Comanda de Restaurante";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "módulo comandaRestaurante, português. o restaurante tem mesas e um cardápio com itens e preços. o garçom abre uma comanda para uma mesa, lança itens (com quantidade e observação), e pode cancelar um item lançado por engano enquanto a comanda estiver aberta. o caixa fecha a comanda: vê o total, aplica desconto opcional, registra a forma de pagamento e a mesa fica livre. perfis: garçom e caixa.";
    };
    export type ComandaRestauranteModuleType = typeof comandaRestauranteModule;
    export default comandaRestauranteModule;
}
declare module "_102047_/l4/comandaRestaurante/rules.defs" {
    export const comandaRestauranteRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "comandaRestaurante";
        readonly rules: [{
            readonly ruleId: "mesaDeveEstarDisponivelParaAbrirComanda";
            readonly description: "Uma comanda só pode ser aberta para uma mesa disponível.";
        }, {
            readonly ruleId: "comandaDeveEstarAbertaParaLancamento";
            readonly description: "Um item do cardápio só pode ser lançado em uma comanda aberta.";
        }, {
            readonly ruleId: "comandaDeveEstarAbertaParaCancelarItem";
            readonly description: "Um lançamento de item só pode ser cancelado enquanto sua comanda estiver aberta.";
        }, {
            readonly ruleId: "formaDePagamentoDeveSerRegistradaParaFecharComanda";
            readonly description: "Uma comanda só pode ser fechada após o registro da forma de pagamento.";
        }, {
            readonly ruleId: "subtotalDoItemComanda";
            readonly description: "O subtotal de um lançamento de item é igual à sua quantidade multiplicada pelo preço unitário registrado.";
        }, {
            readonly ruleId: "subtotalDaComanda";
            readonly description: "O subtotal da comanda é igual à soma dos subtotais dos lançamentos não cancelados.";
        }, {
            readonly ruleId: "totalDaComanda";
            readonly description: "O total da comanda é igual ao seu subtotal menos o desconto aplicado, considerando desconto zero quando nenhum desconto for aplicado.";
        }];
    };
    export type ComandaRestauranteRulesType = typeof comandaRestauranteRules;
    export default comandaRestauranteRules;
}
declare module "_102047_/l4/comandaRestaurante/workflows.defs" {
    export const comandaRestauranteWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "comandaRestaurante";
        readonly processes: [];
        readonly journeyDecisions: [{
            readonly journeyId: "abrirComanda";
            readonly inProcess: false;
        }, {
            readonly journeyId: "lancarItemNaComanda";
            readonly inProcess: false;
        }, {
            readonly journeyId: "cancelarItemLancado";
            readonly inProcess: false;
        }, {
            readonly journeyId: "fecharComanda";
            readonly inProcess: false;
        }];
    };
    export type ComandaRestauranteWorkflowsType = typeof comandaRestauranteWorkflows;
    export default comandaRestauranteWorkflows;
}
declare module "_102047_/l4/comandaRestaurante/journeys/abrirComanda.defs" {
    export const abrirComandaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "abrirComanda";
        readonly business: {
            readonly actorRef: "garcom";
            readonly title: "Abrir comanda para uma mesa";
            readonly goal: "Iniciar uma comanda para uma mesa disponível.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarMesa";
                readonly kind: "locate";
                readonly entity: "Mesa";
                readonly title: "x";
                readonly description: "Localiza a mesa que receberá a comanda.";
            }, {
                readonly stepId: "inspecionarMesa";
                readonly kind: "inspect";
                readonly entity: "Mesa";
                readonly title: "x";
                readonly description: "Confirma que a mesa está disponível.";
            }, {
                readonly stepId: "criarComanda";
                readonly kind: "act";
                readonly entity: "Comanda";
                readonly affects: ["Mesa"];
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Abre uma comanda vinculada à mesa e a deixa ocupada.";
            }];
            readonly outcome: {
                readonly statement: "A comanda fica aberta para a mesa selecionada.";
                readonly evidence: ["Comanda criada e vinculada à mesa.", "Mesa identificada como ocupada."];
            };
        };
        readonly businessHash: "sha256:2829d350a65fa60859c7e2167b658e6240876990cae99fec884eed2ac3d72dad";
    };
    export type AbrirComandaJourneyType = typeof abrirComandaJourney;
    export default abrirComandaJourney;
}
declare module "_102047_/l4/comandaRestaurante/journeys/cancelarItemLancado.defs" {
    export const cancelarItemLancadoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cancelarItemLancado";
        readonly business: {
            readonly actorRef: "garcom";
            readonly title: "Cancelar item lançado por engano";
            readonly goal: "Cancelar um lançamento incorreto enquanto a comanda estiver aberta.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarComandaParaCancelamento";
                readonly kind: "locate";
                readonly entity: "Comanda";
                readonly title: "x";
                readonly description: "Localiza a comanda aberta que contém o lançamento incorreto.";
            }, {
                readonly stepId: "inspecionarLancamentos";
                readonly kind: "inspect";
                readonly entity: "ItemComanda";
                readonly title: "x";
                readonly description: "Identifica o item lançado por engano na comanda.";
            }, {
                readonly stepId: "cancelarLancamento";
                readonly kind: "act";
                readonly entity: "ItemComanda";
                readonly affects: ["Comanda"];
                readonly effect: "transition";
                readonly transitionRef: "cancelarItemComanda";
                readonly title: "x";
                readonly description: "Cancela o lançamento incorreto enquanto a comanda permanece aberta.";
            }];
            readonly outcome: {
                readonly statement: "O lançamento incorreto é cancelado e deixa de compor a comanda.";
                readonly evidence: ["Item da comanda identificado como cancelado.", "Total da comanda reflete a exclusão do lançamento cancelado."];
            };
        };
        readonly businessHash: "sha256:b9b486a4dd4639f4b6b019d2e416c3348e522f64576e37ca888a796dd0dae71e";
    };
    export type CancelarItemLancadoJourneyType = typeof cancelarItemLancadoJourney;
    export default cancelarItemLancadoJourney;
}
declare module "_102047_/l4/comandaRestaurante/journeys/fecharComanda.defs" {
    export const fecharComandaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "fecharComanda";
        readonly business: {
            readonly actorRef: "caixa";
            readonly title: "Fechar comanda e liberar mesa";
            readonly goal: "Receber o pagamento, encerrar a comanda e liberar a mesa.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarComandaParaFechamento";
                readonly kind: "locate";
                readonly entity: "Comanda";
                readonly title: "x";
                readonly description: "Localiza a comanda aberta apresentada para pagamento.";
            }, {
                readonly stepId: "inspecionarTotalDaComanda";
                readonly kind: "inspect";
                readonly entity: "Comanda";
                readonly title: "x";
                readonly description: "Consulta os itens lançados e o total da comanda.";
            }, {
                readonly stepId: "registrarDescontoEpagamento";
                readonly kind: "act";
                readonly entity: "Comanda";
                readonly effect: "update";
                readonly title: "x";
                readonly description: "Registra o desconto opcional e a forma de pagamento.";
            }, {
                readonly stepId: "encerrarComanda";
                readonly kind: "act";
                readonly entity: "Comanda";
                readonly affects: ["Mesa"];
                readonly effect: "transition";
                readonly transitionRef: "fecharComanda";
                readonly title: "x";
                readonly description: "Fecha a comanda paga e libera a mesa.";
            }];
            readonly outcome: {
                readonly statement: "A comanda é encerrada com o pagamento registrado e a mesa fica livre.";
                readonly evidence: ["Comanda registrada como fechada com total, desconto aplicado quando houver e forma de pagamento.", "Mesa vinculada à comanda está disponível."];
            };
        };
        readonly businessHash: "sha256:c39255d59a716428cb8b0bdff5d68050fef135a669288bd57b00b76707aa4895";
    };
    export type FecharComandaJourneyType = typeof fecharComandaJourney;
    export default fecharComandaJourney;
}
declare module "_102047_/l4/comandaRestaurante/journeys/index.defs" {
    export const comandaRestauranteJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "comandaRestaurante";
        readonly journeys: [{
            readonly journeyId: "abrirComanda";
            readonly actorRef: "garcom";
            readonly title: "Abrir comanda para uma mesa";
        }, {
            readonly journeyId: "lancarItemNaComanda";
            readonly actorRef: "garcom";
            readonly title: "Lançar item na comanda";
        }, {
            readonly journeyId: "cancelarItemLancado";
            readonly actorRef: "garcom";
            readonly title: "Cancelar item lançado por engano";
        }, {
            readonly journeyId: "fecharComanda";
            readonly actorRef: "caixa";
            readonly title: "Fechar comanda e liberar mesa";
        }];
        readonly systemDecisions: [];
    };
    export type ComandaRestauranteJourneyIndexType = typeof comandaRestauranteJourneyIndex;
    export default comandaRestauranteJourneyIndex;
}
declare module "_102047_/l4/comandaRestaurante/journeys/lancarItemNaComanda.defs" {
    export const lancarItemNaComandaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "lancarItemNaComanda";
        readonly business: {
            readonly actorRef: "garcom";
            readonly title: "Lançar item na comanda";
            readonly goal: "Adicionar um item do cardápio à comanda aberta de uma mesa.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarComandaAberta";
                readonly kind: "locate";
                readonly entity: "Comanda";
                readonly title: "x";
                readonly description: "Localiza a comanda aberta, usando a mesa ou a própria comanda.";
            }, {
                readonly stepId: "inspecionarComanda";
                readonly kind: "inspect";
                readonly entity: "Comanda";
                readonly title: "x";
                readonly description: "Confere a comanda aberta e seus lançamentos atuais.";
            }, {
                readonly stepId: "localizarItemDoCardapio";
                readonly kind: "locate";
                readonly entity: "ItemCardapio";
                readonly title: "x";
                readonly description: "Localiza o item solicitado no cardápio.";
            }, {
                readonly stepId: "criarLancamento";
                readonly kind: "act";
                readonly entity: "ItemComanda";
                readonly affects: ["Comanda", "ItemCardapio"];
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Lança o item com quantidade e observação na comanda aberta.";
            }];
            readonly outcome: {
                readonly statement: "O item solicitado é registrado na comanda aberta.";
                readonly evidence: ["Lançamento com item, quantidade e observação registrado na comanda.", "Comanda apresenta o novo lançamento."];
            };
        };
        readonly businessHash: "sha256:92cb85895a3d372c0bbbde9897ff23f26dcd141cc1c9ccf9228d061f68a25ba7";
    };
    export type LancarItemNaComandaJourneyType = typeof lancarItemNaComandaJourney;
    export default lancarItemNaComandaJourney;
}
declare module "_102047_/l4/comandaRestaurante/ontology/Comanda.defs" {
    export const comandaRestauranteEntityComanda: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "comandaRestaurante";
        readonly entityId: "Comanda";
        readonly title: "Comanda";
        readonly description: "Registro de consumo aberto para uma mesa, encerrado após o pagamento.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "number";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da comanda.";
        }, {
            readonly fieldId: "number";
            readonly title: "Número";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número sequencial de identificação da comanda.";
        }, {
            readonly fieldId: "mesaId";
            readonly title: "Mesa";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à mesa para a qual a comanda foi aberta.";
        }, {
            readonly fieldId: "garcomId";
            readonly title: "Garçom responsável";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao garçom que abriu a comanda.";
        }, {
            readonly fieldId: "discountAmount";
            readonly title: "Desconto";
            readonly type: "money";
            readonly required: false;
            readonly description: "Valor opcional de desconto aplicado no fechamento da comanda.";
        }, {
            readonly fieldId: "paymentMethod";
            readonly title: "Forma de pagamento";
            readonly type: "string";
            readonly required: false;
            readonly enum: [{
                readonly value: "cash";
                readonly title: "Dinheiro";
            }, {
                readonly value: "creditCard";
                readonly title: "Cartão de crédito";
            }, {
                readonly value: "debitCard";
                readonly title: "Cartão de débito";
            }, {
                readonly value: "pix";
                readonly title: "Pix";
            }];
            readonly description: "Forma de pagamento registrada ao fechar a comanda.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "open";
                readonly title: "Aberta";
            }, {
                readonly value: "closed";
                readonly title: "Fechada";
            }];
            readonly description: "Situação atual da comanda.";
        }];
        readonly details: {
            readonly subtotalAmount: {
                readonly type: "money";
                readonly description: "Soma dos itens ativos lançados na comanda antes do desconto.";
            };
            readonly totalAmount: {
                readonly type: "money";
                readonly description: "Valor total a pagar, calculado pelos itens ativos menos o desconto aplicado.";
            };
        };
        readonly lifecycleStates: [{
            readonly state: "open";
            readonly reachedBy: "actor";
        }, {
            readonly state: "closed";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "fecharComanda";
            readonly from: ["open"];
            readonly to: "closed";
            readonly by: ["caixa"];
            readonly description: "Fecha a comanda após registrar o desconto opcional e a forma de pagamento.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type ComandaRestauranteEntityComandaType = typeof comandaRestauranteEntityComanda;
    export default comandaRestauranteEntityComanda;
}
declare module "_102047_/l4/comandaRestaurante/ontology/Garcom.defs" {
    export const comandaRestauranteEntityGarcom: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "comandaRestaurante";
        readonly entityId: "Garcom";
        readonly title: "Garçom";
        readonly description: "Profissional do restaurante que abre comandas e registra lançamentos de itens.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "comandaRestaurante.Garcom";
        };
        readonly writer: "crud";
    };
    export type ComandaRestauranteEntityGarcomType = typeof comandaRestauranteEntityGarcom;
    export default comandaRestauranteEntityGarcom;
}
declare module "_102047_/l4/comandaRestaurante/ontology/ItemCardapio.defs" {
    export const comandaRestauranteEntityItemCardapio: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "comandaRestaurante";
        readonly entityId: "ItemCardapio";
        readonly title: "Item do cardápio";
        readonly description: "Produto oferecido no cardápio do restaurante, com informações comerciais específicas do cardápio.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "Product";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "preco";
            readonly title: "Preço";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda atual do item no cardápio.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "comandaRestaurante.ItemCardapio";
        };
    };
    export type ComandaRestauranteEntityItemCardapioType = typeof comandaRestauranteEntityItemCardapio;
    export default comandaRestauranteEntityItemCardapio;
}
declare module "_102047_/l4/comandaRestaurante/ontology/ItemComanda.defs" {
    export const comandaRestauranteEntityItemComanda: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "comandaRestaurante";
        readonly entityId: "ItemComanda";
        readonly title: "Item da comanda";
        readonly description: "Lançamento de um item do cardápio em uma comanda, com quantidade e observação.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "description";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do lançamento de item na comanda.";
        }, {
            readonly fieldId: "comandaId";
            readonly title: "Comanda";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à comanda à qual o lançamento pertence.";
        }, {
            readonly fieldId: "itemCardapioId";
            readonly title: "Item do cardápio";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao item do cardápio lançado na comanda.";
        }, {
            readonly fieldId: "description";
            readonly title: "Descrição";
            readonly type: "string";
            readonly required: true;
            readonly description: "Descrição do item do cardápio registrada no lançamento para identificação na comanda.";
        }, {
            readonly fieldId: "quantity";
            readonly title: "Quantidade";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 1;
            };
            readonly description: "Quantidade solicitada do item do cardápio.";
        }, {
            readonly fieldId: "unitPrice";
            readonly title: "Preço unitário";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço unitário do item no momento em que foi lançado na comanda.";
        }, {
            readonly fieldId: "observation";
            readonly title: "Observação";
            readonly type: "text";
            readonly required: false;
            readonly description: "Orientação ou observação informada para o preparo do item.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "lancado";
                readonly title: "Lançado";
            }, {
                readonly value: "cancelado";
                readonly title: "Cancelado";
            }];
            readonly description: "Situação atual do lançamento na comanda.";
        }];
        readonly details: {
            readonly subtotal: {
                readonly type: "money";
                readonly description: "Valor do lançamento calculado pela quantidade multiplicada pelo preço unitário, desconsiderado quando cancelado.";
            };
        };
        readonly lifecycleStates: [{
            readonly state: "lancado";
            readonly reachedBy: "actor";
        }, {
            readonly state: "cancelado";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "cancelarItemComanda";
            readonly from: ["lancado"];
            readonly to: "cancelado";
            readonly by: ["garcom"];
            readonly description: "Cancela um item lançado por engano enquanto a comanda permanece aberta.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type ComandaRestauranteEntityItemComandaType = typeof comandaRestauranteEntityItemComanda;
    export default comandaRestauranteEntityItemComanda;
}
declare module "_102047_/l4/comandaRestaurante/ontology/Mesa.defs" {
    export const comandaRestauranteEntityMesa: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "comandaRestaurante";
        readonly entityId: "Mesa";
        readonly title: "Mesa";
        readonly description: "Mesa física do restaurante disponível para receber comandas.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "AssetEquipment";
        readonly displayField: "name";
        readonly fields: [];
        readonly details: {
            readonly estaDisponivel: {
                readonly type: "boolean";
                readonly description: "Indica se a mesa está disponível para receber uma nova comanda, calculado a partir das comandas abertas.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "comandaRestaurante.Mesa";
        };
    };
    export type ComandaRestauranteEntityMesaType = typeof comandaRestauranteEntityMesa;
    export default comandaRestauranteEntityMesa;
}
declare module "_102047_/l4/comandaRestaurante/ontology/index.defs" {
    export const comandaRestauranteOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "comandaRestaurante";
        readonly businessDomain: "Operação de comandas, cardápio, mesas e pagamentos de restaurante.";
        readonly entities: ["Mesa", "ItemCardapio", "Garcom", "Comanda", "ItemComanda"];
        readonly relationships: [{
            readonly relationshipId: "comandaMesa";
            readonly fromEntity: "Comanda";
            readonly toEntity: "Mesa";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada comanda é aberta para uma mesa do restaurante.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Comanda";
                readonly from: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["mesaId"];
                };
                readonly to: {
                    readonly entityId: "Mesa";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "comandaGarcom";
            readonly fromEntity: "Comanda";
            readonly toEntity: "Garcom";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada comanda é aberta por um garçom responsável.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Comanda";
                readonly from: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["garcomId"];
                };
                readonly to: {
                    readonly entityId: "Garcom";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "itemComandaComanda";
            readonly fromEntity: "ItemComanda";
            readonly toEntity: "Comanda";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada item lançado pertence a uma comanda.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemComanda";
                readonly from: {
                    readonly entityId: "ItemComanda";
                    readonly fieldIds: ["comandaId"];
                };
                readonly to: {
                    readonly entityId: "Comanda";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "itemComandaItemCardapio";
            readonly fromEntity: "ItemComanda";
            readonly toEntity: "ItemCardapio";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada item lançado referencia um item do cardápio.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemComanda";
                readonly from: {
                    readonly entityId: "ItemComanda";
                    readonly fieldIds: ["itemCardapioId"];
                };
                readonly to: {
                    readonly entityId: "ItemCardapio";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type ComandaRestauranteOntologyIndexType = typeof comandaRestauranteOntologyIndex;
    export default comandaRestauranteOntologyIndex;
}
declare module "_102047_/l4/compras/access.defs" {
    export const comprasAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "compras";
        readonly actors: [{
            readonly actorId: "comprador";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Comprador";
            readonly description: "Profissional da organização que cadastra fornecedores e seus produtos, abre e envia pedidos de compra.";
        }, {
            readonly actorId: "gerenteCompras";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gerente de compras";
            readonly description: "Profissional da organização que aprova ou rejeita pedidos acima do valor limite e acompanha os indicadores de compras.";
        }, {
            readonly actorId: "almoxarife";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Almoxarife";
            readonly description: "Profissional da organização que registra o recebimento total ou parcial dos pedidos e a entrada dos produtos no estoque.";
        }];
        readonly grants: [{
            readonly grantId: "compradorGerenciaCompras";
            readonly actorRef: "comprador";
            readonly title: "Gerenciar fornecedores e pedidos de compra";
            readonly description: "Permite cadastrar ou vincular fornecedores, definir produtos e preços combinados e abrir ou enviar pedidos de compra da organização.";
            readonly entityRefs: ["Comprador", "Fornecedor", "Produto", "FornecimentoProduto", "PedidoCompra", "ItemPedidoCompra"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os cadastros comerciais e pedidos de compra de toda a organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite consultar todos os campos dos registros necessários para cadastrar fornecedores, condições comerciais e pedidos.";
            };
        }, {
            readonly grantId: "gerenteDecideEacompanhaPedidos";
            readonly actorRef: "gerenteCompras";
            readonly title: "Decidir e acompanhar pedidos de compra";
            readonly description: "Permite consultar pedidos, aprovar ou rejeitar os que exigem autorização e acompanhar indicadores de compras da organização.";
            readonly entityRefs: ["Fornecedor", "PedidoCompra", "ItemPedidoCompra"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange todos os fornecedores e pedidos de compra da organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite visualizar todos os campos dos fornecedores, pedidos e itens necessários para decisão e acompanhamento dos indicadores.";
            };
        }, {
            readonly grantId: "almoxarifeRegistraRecebimentos";
            readonly actorRef: "almoxarife";
            readonly title: "Registrar recebimentos de compras";
            readonly description: "Permite consultar pedidos e seus itens, registrar recebimentos totais ou parciais e identificar os produtos e posições de estoque de destino.";
            readonly entityRefs: ["Produto", "EstoqueProduto", "PedidoCompra", "ItemPedidoCompra", "RecebimentoCompra", "ItemRecebimentoCompra"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os pedidos, recebimentos e posições de estoque da organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite visualizar todos os campos necessários para conferir pedidos e registrar os recebimentos e entradas em estoque.";
            };
        }];
    };
    export type ComprasAccessType = typeof comprasAccess;
    export default comprasAccess;
}
declare module "_102047_/l4/compras/integration.defs" {
    export const comprasIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "compras";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "registrarRecebimentoParcial";
            readonly kind: "event";
            readonly to: "controleEstoque";
            readonly event: "registrarRecebimentoParcial";
            readonly on: "PedidoCompra.registrarRecebimentoParcial";
            readonly description: "Comunica ao módulo de controle de estoque o recebimento parcial do pedido para registrar a entrada das quantidades recebidas.";
            readonly entityRefs: ["PedidoCompra", "RecebimentoCompra", "ItemRecebimentoCompra"];
        }, {
            readonly id: "registrarRecebimentoTotal";
            readonly kind: "event";
            readonly to: "controleEstoque";
            readonly event: "registrarRecebimentoTotal";
            readonly on: "PedidoCompra.registrarRecebimentoTotal";
            readonly description: "Comunica ao módulo de controle de estoque o recebimento total do pedido para registrar a entrada dos produtos recebidos.";
            readonly entityRefs: ["PedidoCompra", "RecebimentoCompra", "ItemRecebimentoCompra"];
        }];
        readonly plugins: [];
    };
    export type ComprasIntegrationType = typeof comprasIntegration;
    export default comprasIntegration;
}
declare module "_102047_/l4/compras/module.defs" {
    export const comprasModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "compras";
        readonly title: "Compras";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "criar o módulo compras em português. a organização compra de fornecedores (empresas com CNPJ, razão social, contato). o comprador cadastra fornecedores e quais produtos cada um fornece, com preço combinado. o comprador abre um pedido de compra para um fornecedor com um ou mais produtos, quantidade e preço, e envia; o gerente de compras aprova ou rejeita pedidos acima de um valor limite. quando o pedido chega, o almoxarife registra o recebimento (total ou parcial) e isso dá entrada no estoque dos produtos recebidos. o gerente vê o painel de pedidos em aberto, atrasados e o total comprado por fornecedor no mês. perfis: comprador, gerente de compras e almoxarife.";
        readonly details: {
            readonly quantidadePedidosEmAberto: {
                readonly type: "integer";
                readonly description: "Quantidade calculada de pedidos de compra que permanecem em aberto.";
            };
            readonly quantidadePedidosAtrasados: {
                readonly type: "integer";
                readonly description: "Quantidade calculada de pedidos de compra em atraso.";
            };
            readonly totalCompradoPorFornecedorNoMes: {
                readonly type: "json";
                readonly description: "Totais calculados de compras do mês agrupados por fornecedor.";
            };
        };
    };
    export type ComprasModuleType = typeof comprasModule;
    export default comprasModule;
}
declare module "_102047_/l4/compras/rules.defs" {
    export const comprasRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "compras";
        readonly rules: [{
            readonly ruleId: "pedidoDeveTerAoMenosUmItem";
            readonly description: "Todo pedido de compra deve conter um ou mais itens de produto.";
        }, {
            readonly ruleId: "itensDevemCorresponderAoFornecimento";
            readonly description: "Cada item do pedido deve referenciar um produto fornecido pelo fornecedor do pedido e usar o preço comercial combinado.";
        }, {
            readonly ruleId: "valorTotalDoPedido";
            readonly description: "O valor total do pedido de compra deve ser calculado pela soma das quantidades dos itens multiplicadas por seus respectivos preços unitários.";
        }, {
            readonly ruleId: "aprovacaoAcimaDoValorLimite";
            readonly description: "Um pedido de compra cujo valor total seja superior ao valor limite deve ser aprovado ou rejeitado pelo gerente de compras antes de ser processado.";
        }, {
            readonly ruleId: "recebimentoNaoPodeExcederQuantidadePedida";
            readonly description: "A quantidade recebida acumulada de cada item do pedido não pode exceder a quantidade solicitada.";
        }, {
            readonly ruleId: "entradaDeEstoquePorRecebimento";
            readonly description: "Cada quantidade efetivamente recebida deve gerar entrada correspondente no estoque do produto.";
        }, {
            readonly ruleId: "pedidoAtrasado";
            readonly description: "Um pedido de compra deve ser considerado atrasado quando sua data prevista de entrega tiver passado e suas quantidades ainda não tiverem sido integralmente recebidas.";
        }, {
            readonly ruleId: "totalCompradoMensalPorFornecedor";
            readonly description: "O total comprado mensal por fornecedor deve ser calculado pela soma dos valores dos pedidos de compra do fornecedor no mês.";
        }];
    };
    export type ComprasRulesType = typeof comprasRules;
    export default comprasRules;
}
declare module "_102047_/l4/compras/workflows.defs" {
    export const comprasWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "compras";
        readonly processes: [{
            readonly processId: "submeterEProcessarPedidoCompra";
            readonly title: "Submeter e processar pedido de compra";
            readonly description: "Orquestra o envio do pedido pelo comprador e o seu encaminhamento automático ou para decisão gerencial conforme o valor.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "comprador";
            };
            readonly tasks: [{
                readonly taskId: "enviarPedidoParaProcessamento";
                readonly kind: "human";
                readonly actorRef: "comprador";
                readonly journeyRef: "abrirEenviarPedidoCompra";
                readonly next: ["liberarPedidoAbaixoDoLimite", "decidirPedidoAcimaDoLimite"];
                readonly description: "O comprador abre e envia o pedido, encaminhando os pedidos que exigem aprovação ao gerente de compras.";
            }, {
                readonly taskId: "liberarPedidoAbaixoDoLimite";
                readonly kind: "mechanical";
                readonly entityRef: "PedidoCompra";
                readonly effect: "transition";
                readonly transitionRef: "liberarPedidoSemAprovacao";
                readonly next: [];
                readonly description: "O sistema libera para processamento o pedido cujo valor não exige aprovação.";
            }, {
                readonly taskId: "decidirPedidoAcimaDoLimite";
                readonly kind: "human";
                readonly actorRef: "gerenteCompras";
                readonly journeyRef: "decidirPedidoAcimaDoLimite";
                readonly next: [];
                readonly description: "O gerente de compras aprova ou rejeita o pedido que exige autorização.";
            }];
        }, {
            readonly processId: "registrarEAtualizarRecebimento";
            readonly title: "Registrar e atualizar recebimento de pedido";
            readonly description: "Orquestra o registro do recebimento pelo almoxarife, a atualização do estoque e o status correspondente do pedido.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "almoxarife";
            };
            readonly tasks: [{
                readonly taskId: "registrarRecebimentoDoPedido";
                readonly kind: "human";
                readonly actorRef: "almoxarife";
                readonly journeyRef: "registrarRecebimentoDePedido";
                readonly next: ["atualizarEstoqueRecebido"];
                readonly description: "O almoxarife registra as quantidades recebidas, total ou parcialmente, para o pedido.";
            }, {
                readonly taskId: "atualizarEstoqueRecebido";
                readonly kind: "mechanical";
                readonly entityRef: "EstoqueProduto";
                readonly effect: "update";
                readonly next: ["marcarRecebimentoParcial"];
                readonly description: "O sistema atualiza o estoque dos produtos nas quantidades efetivamente recebidas.";
            }, {
                readonly taskId: "marcarRecebimentoParcial";
                readonly kind: "mechanical";
                readonly entityRef: "PedidoCompra";
                readonly effect: "transition";
                readonly transitionRef: "registrarRecebimentoParcial";
                readonly next: [];
                readonly description: "O sistema registra o pedido como parcialmente recebido quando ainda houver quantidades pendentes.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "cadastrarFornecedor";
            readonly inProcess: false;
        }, {
            readonly journeyId: "definirProdutosDoFornecedor";
            readonly inProcess: false;
        }, {
            readonly journeyId: "abrirEenviarPedidoCompra";
            readonly inProcess: true;
            readonly processId: "submeterEProcessarPedidoCompra";
        }, {
            readonly journeyId: "decidirPedidoAcimaDoLimite";
            readonly inProcess: true;
            readonly processId: "submeterEProcessarPedidoCompra";
        }, {
            readonly journeyId: "registrarRecebimentoDePedido";
            readonly inProcess: true;
            readonly processId: "registrarEAtualizarRecebimento";
        }, {
            readonly journeyId: "acompanharIndicadoresDeCompras";
            readonly inProcess: false;
        }];
        readonly systemDecisions: [{
            readonly decisionId: "dropDuplicateTaskMarcarRecebimentoTotal";
            readonly chosen: "drop";
            readonly alternatives: ["keep", "drop"];
            readonly decidedBy: "system";
        }];
    };
    export type ComprasWorkflowsType = typeof comprasWorkflows;
    export default comprasWorkflows;
}
declare module "_102047_/l4/compras/journeys/abrirEenviarPedidoCompra.defs" {
    export const abrirEenviarPedidoCompraJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "abrirEenviarPedidoCompra";
        readonly business: {
            readonly actorRef: "comprador";
            readonly title: "Abrir e enviar pedido de compra";
            readonly goal: "Criar um pedido para um fornecedor com os produtos, quantidades e preços acordados e enviá-lo.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarFornecedorDoPedido";
                readonly kind: "locate";
                readonly entity: "Fornecedor";
                readonly title: "x";
                readonly description: "Localiza o fornecedor para o qual o pedido será aberto.";
            }, {
                readonly stepId: "selecionarProdutosDoFornecedor";
                readonly kind: "locate";
                readonly entity: "FornecimentoProduto";
                readonly title: "x";
                readonly description: "Consulta os produtos e preços combinados disponíveis para o fornecedor.";
            }, {
                readonly stepId: "abrirPedido";
                readonly kind: "act";
                readonly entity: "PedidoCompra";
                readonly affects: ["Fornecedor", "Produto"];
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Cria o pedido com um ou mais produtos, suas quantidades e preços.";
            }, {
                readonly stepId: "enviarPedido";
                readonly kind: "act";
                readonly entity: "PedidoCompra";
                readonly effect: "transition";
                readonly transitionRef: "enviarPedido";
                readonly title: "x";
                readonly description: "Envia o pedido de compra para processamento.";
            }, {
                readonly stepId: "encaminharParaAprovacao";
                readonly kind: "handoff";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Encaminha ao gerente de compras os pedidos cujo valor exige aprovação.";
                readonly handoffTo: "gerenteCompras";
            }];
            readonly outcome: {
                readonly statement: "O pedido é enviado e, quando ultrapassa o valor limite, fica disponível para decisão do gerente de compras.";
                readonly evidence: ["Pedido de compra com fornecedor, itens, quantidades, preços e situação de envio registrada."];
            };
        };
        readonly businessHash: "sha256:561721ec07a3e2088e1ef2ff99b385f72b30a649621b3792a07ed535dfb7476e";
    };
    export type AbrirEenviarPedidoCompraJourneyType = typeof abrirEenviarPedidoCompraJourney;
    export default abrirEenviarPedidoCompraJourney;
}
declare module "_102047_/l4/compras/journeys/acompanharIndicadoresDeCompras.defs" {
    export const acompanharIndicadoresDeComprasJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharIndicadoresDeCompras";
        readonly business: {
            readonly actorRef: "gerenteCompras";
            readonly title: "Acompanhar indicadores de compras";
            readonly goal: "Acompanhar pedidos em aberto, atrasados e o total comprado por fornecedor no mês.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarPedidosParaPainel";
                readonly kind: "locate";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Consulta os pedidos em aberto e os pedidos atrasados no período.";
            }, {
                readonly stepId: "inspecionarIndicadores";
                readonly kind: "inspect";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Visualiza os indicadores de pedidos em aberto, atrasados e totais mensais comprados por fornecedor.";
            }];
            readonly outcome: {
                readonly statement: "O gerente acompanha a situação dos pedidos e o volume mensal comprado de cada fornecedor.";
                readonly evidence: ["Indicadores de pedidos em aberto e atrasados exibidos.", "Totais comprados por fornecedor no mês exibidos."];
            };
        };
        readonly businessHash: "sha256:dba27bd970d952670ddbdea2907a5153022c68b43be857f723256f67cd2a4a0c";
    };
    export type AcompanharIndicadoresDeComprasJourneyType = typeof acompanharIndicadoresDeComprasJourney;
    export default acompanharIndicadoresDeComprasJourney;
}
declare module "_102047_/l4/compras/journeys/cadastrarFornecedor.defs" {
    export const cadastrarFornecedorJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarFornecedor";
        readonly business: {
            readonly actorRef: "comprador";
            readonly title: "Cadastrar fornecedor";
            readonly goal: "Cadastrar ou vincular um fornecedor da organização a partir de seus dados empresariais.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "informarDadosFornecedor";
                readonly kind: "act";
                readonly entity: "Fornecedor";
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Informa CNPJ, razão social e contatos para criar ou vincular o cadastro mestre do fornecedor.";
            }];
            readonly outcome: {
                readonly statement: "O fornecedor fica disponível para ser utilizado nas compras da organização.";
                readonly evidence: ["Cadastro do fornecedor identificado pelo CNPJ, com razão social e contatos disponíveis."];
            };
        };
        readonly businessHash: "sha256:44edbdbaec2bd9cdadf04866fce22d2b96f3ecfecaeaf5c4e9e3263a632962b7";
    };
    export type CadastrarFornecedorJourneyType = typeof cadastrarFornecedorJourney;
    export default cadastrarFornecedorJourney;
}
declare module "_102047_/l4/compras/journeys/decidirPedidoAcimaDoLimite.defs" {
    export const decidirPedidoAcimaDoLimiteJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "decidirPedidoAcimaDoLimite";
        readonly business: {
            readonly actorRef: "gerenteCompras";
            readonly title: "Decidir pedido acima do limite";
            readonly goal: "Decidir pela aprovação ou rejeição de um pedido de compra que exige autorização.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "localizarPedidoPendente";
                readonly kind: "locate";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Abre o pedido indicado pela notificação ou o localiza entre os pedidos pendentes de aprovação.";
            }, {
                readonly stepId: "inspecionarPedido";
                readonly kind: "inspect";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Confere fornecedor, itens, quantidades, preços e valor total do pedido.";
            }, {
                readonly stepId: "decidirAprovacaoOuRejeicao";
                readonly kind: "decide";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Decide entre aprovar ou rejeitar o pedido.";
            }, {
                readonly stepId: "registrarDecisao";
                readonly kind: "act";
                readonly entity: "PedidoCompra";
                readonly effect: "transition";
                readonly transitionRef: "decidirPedido";
                readonly title: "x";
                readonly description: "Registra a aprovação ou a rejeição escolhida para o pedido.";
            }];
            readonly outcome: {
                readonly statement: "A decisão de aprovar ou rejeitar o pedido acima do limite é registrada.";
                readonly evidence: ["Situação de aprovação do pedido registrada como aprovada ou rejeitada."];
            };
        };
        readonly businessHash: "sha256:3b1a3bd7a18697437c74576d4a49775533aed317544715e1be1d99d4bece4dd9";
    };
    export type DecidirPedidoAcimaDoLimiteJourneyType = typeof decidirPedidoAcimaDoLimiteJourney;
    export default decidirPedidoAcimaDoLimiteJourney;
}
declare module "_102047_/l4/compras/journeys/definirProdutosDoFornecedor.defs" {
    export const definirProdutosDoFornecedorJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "definirProdutosDoFornecedor";
        readonly business: {
            readonly actorRef: "comprador";
            readonly title: "Definir produtos e preços do fornecedor";
            readonly goal: "Registrar os produtos fornecidos por um fornecedor e o preço comercial combinado.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarFornecedor";
                readonly kind: "locate";
                readonly entity: "Fornecedor";
                readonly title: "x";
                readonly description: "Localiza o fornecedor já selecionado ou o pesquisa pelo CNPJ ou razão social.";
            }, {
                readonly stepId: "localizarProdutos";
                readonly kind: "locate";
                readonly entity: "Produto";
                readonly title: "x";
                readonly description: "Localiza os produtos disponibilizados pelo fornecedor.";
            }, {
                readonly stepId: "registrarFornecimento";
                readonly kind: "act";
                readonly entity: "FornecimentoProduto";
                readonly affects: ["Fornecedor", "Produto"];
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Registra cada produto fornecido e seu preço combinado.";
            }];
            readonly outcome: {
                readonly statement: "Os produtos oferecidos pelo fornecedor e seus preços combinados ficam disponíveis para a abertura de pedidos.";
                readonly evidence: ["Relação de produtos do fornecedor com preços combinados registrada."];
            };
        };
        readonly businessHash: "sha256:87ced390553b4a46eea3cfd060f2af5a948515e2b393ebddaa72ca650dbdce38";
    };
    export type DefinirProdutosDoFornecedorJourneyType = typeof definirProdutosDoFornecedorJourney;
    export default definirProdutosDoFornecedorJourney;
}
declare module "_102047_/l4/compras/journeys/index.defs" {
    export const comprasJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "compras";
        readonly journeys: [{
            readonly journeyId: "cadastrarFornecedor";
            readonly actorRef: "comprador";
            readonly title: "Cadastrar fornecedor";
        }, {
            readonly journeyId: "definirProdutosDoFornecedor";
            readonly actorRef: "comprador";
            readonly title: "Definir produtos e preços do fornecedor";
        }, {
            readonly journeyId: "abrirEenviarPedidoCompra";
            readonly actorRef: "comprador";
            readonly title: "Abrir e enviar pedido de compra";
        }, {
            readonly journeyId: "decidirPedidoAcimaDoLimite";
            readonly actorRef: "gerenteCompras";
            readonly title: "Decidir pedido acima do limite";
        }, {
            readonly journeyId: "registrarRecebimentoDePedido";
            readonly actorRef: "almoxarife";
            readonly title: "Registrar recebimento de pedido";
        }, {
            readonly journeyId: "acompanharIndicadoresDeCompras";
            readonly actorRef: "gerenteCompras";
            readonly title: "Acompanhar indicadores de compras";
        }];
        readonly systemDecisions: [];
    };
    export type ComprasJourneyIndexType = typeof comprasJourneyIndex;
    export default comprasJourneyIndex;
}
declare module "_102047_/l4/compras/journeys/registrarRecebimentoDePedido.defs" {
    export const registrarRecebimentoDePedidoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarRecebimentoDePedido";
        readonly business: {
            readonly actorRef: "almoxarife";
            readonly title: "Registrar recebimento de pedido";
            readonly goal: "Registrar o recebimento total ou parcial de produtos de um pedido e dar entrada no estoque.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarPedidoParaRecebimento";
                readonly kind: "locate";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Abre o pedido recebido em contexto ou o localiza para conferência.";
            }, {
                readonly stepId: "inspecionarItensDoPedido";
                readonly kind: "inspect";
                readonly entity: "PedidoCompra";
                readonly title: "x";
                readonly description: "Confere os itens e as quantidades previstas no pedido.";
            }, {
                readonly stepId: "registrarRecebimento";
                readonly kind: "act";
                readonly entity: "RecebimentoCompra";
                readonly affects: ["PedidoCompra", "Produto", "EstoqueProduto"];
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Registra as quantidades efetivamente recebidas, total ou parcialmente, e a entrada correspondente no estoque.";
            }];
            readonly outcome: {
                readonly statement: "O recebimento é registrado e o estoque dos produtos recebidos é atualizado.";
                readonly evidence: ["Registro de recebimento com quantidades recebidas.", "Saldo de estoque dos produtos recebidos atualizado."];
            };
        };
        readonly businessHash: "sha256:bfdfbdffdf87c9f9e90ad1b66f3de8b5ebe1ebf125a1c01ac19b5e39604f5d9f";
    };
    export type RegistrarRecebimentoDePedidoJourneyType = typeof registrarRecebimentoDePedidoJourney;
    export default registrarRecebimentoDePedidoJourney;
}
declare module "_102047_/l4/compras/ontology/Comprador.defs" {
    export const comprasEntityComprador: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "Comprador";
        readonly title: "Comprador";
        readonly description: "Profissional da organização responsável por cadastrar fornecedores, definir seus produtos e preços e abrir pedidos de compra.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "compras.Comprador";
        };
        readonly writer: "crud";
    };
    export type ComprasEntityCompradorType = typeof comprasEntityComprador;
    export default comprasEntityComprador;
}
declare module "_102047_/l4/compras/ontology/EstoqueProduto.defs" {
    export const comprasEntityEstoqueProduto: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "EstoqueProduto";
        readonly title: "Estoque do produto";
        readonly description: "Posição de estoque do produto mantida pelo módulo de controle de estoque e atualizada a partir dos recebimentos.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador da posição de estoque na plataforma externa.";
        }, {
            readonly fieldId: "name";
            readonly title: "Nome";
            readonly type: "string";
            readonly required: true;
            readonly constraints: {
                readonly maxLength: 255;
            };
            readonly description: "Nome de exibição da posição de estoque do produto na plataforma externa.";
        }];
        readonly details: {
            readonly quantidadeDisponivel: {
                readonly type: "number";
                readonly description: "Quantidade disponível do produto na posição de estoque, calculada pela plataforma de estoque.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "external";
            readonly scope: "platform";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComprasEntityEstoqueProdutoType = typeof comprasEntityEstoqueProduto;
    export default comprasEntityEstoqueProduto;
}
declare module "_102047_/l4/compras/ontology/Fornecedor.defs" {
    export const comprasEntityFornecedor: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "Fornecedor";
        readonly title: "Fornecedor";
        readonly description: "Empresa fornecedora cadastrada ou vinculada pela organização para realizar compras.";
        readonly kind: "mdm";
        readonly party: "organization";
        readonly mdmSubtype: "Company";
        readonly displayField: "legalName";
        readonly fields: [];
        readonly details: {
            readonly totalCompradoNoMes: {
                readonly type: "money";
                readonly description: "Valor total dos pedidos de compra do fornecedor no mês corrente.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "compras.Fornecedor";
        };
    };
    export type ComprasEntityFornecedorType = typeof comprasEntityFornecedor;
    export default comprasEntityFornecedor;
}
declare module "_102047_/l4/compras/ontology/FornecimentoProduto.defs" {
    export const comprasEntityFornecimentoProduto: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "FornecimentoProduto";
        readonly title: "Fornecimento de produto";
        readonly description: "Condição comercial que registra um produto fornecido por um fornecedor e o preço combinado.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "produto";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do registro de fornecimento de produto.";
        }, {
            readonly fieldId: "fornecedor";
            readonly title: "Fornecedor";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à empresa fornecedora à qual a condição comercial pertence.";
        }, {
            readonly fieldId: "produto";
            readonly title: "Produto";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao produto fornecido sob esta condição comercial.";
        }, {
            readonly fieldId: "precoCombinado";
            readonly title: "Preço combinado";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço comercial acordado entre a organização e o fornecedor para o produto.";
        }];
        readonly uniqueKeys: [["fornecedor", "produto"]];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComprasEntityFornecimentoProdutoType = typeof comprasEntityFornecimentoProduto;
    export default comprasEntityFornecimentoProduto;
}
declare module "_102047_/l4/compras/ontology/ItemPedidoCompra.defs" {
    export const comprasEntityItemPedidoCompra: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "ItemPedidoCompra";
        readonly title: "Item do pedido de compra";
        readonly description: "Produto, quantidade e preço que compõem um pedido de compra.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "produto";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do pedido de compra.";
        }, {
            readonly fieldId: "pedidoCompra";
            readonly title: "Pedido de compra";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Pedido de compra ao qual este item pertence.";
        }, {
            readonly fieldId: "fornecimentoProduto";
            readonly title: "Condição de fornecimento";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Condição de fornecimento que define o preço de referência do produto.";
        }, {
            readonly fieldId: "produto";
            readonly title: "Produto";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Produto solicitado neste item do pedido de compra.";
        }, {
            readonly fieldId: "quantidade";
            readonly title: "Quantidade";
            readonly type: "number";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
            };
            readonly description: "Quantidade do produto solicitada no pedido.";
        }, {
            readonly fieldId: "precoUnitario";
            readonly title: "Preço unitário";
            readonly type: "money";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
                readonly precision: 2;
            };
            readonly description: "Preço unitário combinado para o produto neste pedido.";
        }];
        readonly details: {
            readonly valorTotal: {
                readonly type: "money";
                readonly description: "Valor total do item, calculado pela multiplicação da quantidade pelo preço unitário.";
            };
            readonly quantidadeRecebida: {
                readonly type: "number";
                readonly description: "Quantidade total já recebida para este item, calculada a partir dos recebimentos registrados.";
            };
            readonly quantidadePendente: {
                readonly type: "number";
                readonly description: "Quantidade ainda pendente de recebimento, calculada pela diferença entre a quantidade solicitada e a recebida.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComprasEntityItemPedidoCompraType = typeof comprasEntityItemPedidoCompra;
    export default comprasEntityItemPedidoCompra;
}
declare module "_102047_/l4/compras/ontology/ItemRecebimentoCompra.defs" {
    export const comprasEntityItemRecebimentoCompra: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "ItemRecebimentoCompra";
        readonly title: "Item do recebimento de compra";
        readonly description: "Quantidade efetivamente recebida de um item de pedido e destinada à entrada no estoque.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "produto";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item de recebimento de compra.";
        }, {
            readonly fieldId: "recebimentoCompraId";
            readonly title: "Recebimento de compra";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Recebimento de compra ao qual este item pertence.";
        }, {
            readonly fieldId: "itemPedidoCompraId";
            readonly title: "Item do pedido de compra";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Item do pedido de compra recebido nesta etapa.";
        }, {
            readonly fieldId: "produto";
            readonly title: "Produto";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Produto efetivamente recebido e destinado à entrada no estoque.";
        }, {
            readonly fieldId: "estoqueProdutoId";
            readonly title: "Posição de estoque";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Posição de estoque que recebe a entrada deste produto.";
        }, {
            readonly fieldId: "quantidadeRecebida";
            readonly title: "Quantidade recebida";
            readonly type: "number";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
                readonly precision: 3;
            };
            readonly description: "Quantidade do produto efetivamente recebida neste item.";
        }];
        readonly uniqueKeys: [["recebimentoCompraId", "itemPedidoCompraId"]];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComprasEntityItemRecebimentoCompraType = typeof comprasEntityItemRecebimentoCompra;
    export default comprasEntityItemRecebimentoCompra;
}
declare module "_102047_/l4/compras/ontology/PedidoCompra.defs" {
    export const comprasEntityPedidoCompra: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "PedidoCompra";
        readonly title: "Pedido de compra";
        readonly description: "Solicitação de compra aberta para um fornecedor, composta por produtos, quantidades e preços.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "numeroPedido";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido de compra.";
        }, {
            readonly fieldId: "numeroPedido";
            readonly title: "Número do pedido";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly constraints: {
                readonly maxLength: 50;
            };
            readonly description: "Número sequencial que identifica o pedido de compra.";
        }, {
            readonly fieldId: "fornecedorId";
            readonly title: "Fornecedor";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao fornecedor para o qual o pedido foi emitido.";
        }, {
            readonly fieldId: "dataEmissao";
            readonly title: "Data de emissão";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data em que o pedido de compra foi aberto.";
        }, {
            readonly fieldId: "dataPrevistaEntrega";
            readonly title: "Data prevista de entrega";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data prevista para a entrega dos produtos do pedido.";
        }, {
            readonly fieldId: "dataEnvio";
            readonly title: "Data de envio";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o pedido foi enviado para processamento.";
        }, {
            readonly fieldId: "situacaoAprovacao";
            readonly title: "Situação da aprovação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "notRequired";
                readonly title: "Não requerida";
            }, {
                readonly value: "pending";
                readonly title: "Pendente";
            }, {
                readonly value: "approved";
                readonly title: "Aprovada";
            }, {
                readonly value: "rejected";
                readonly title: "Rejeitada";
            }];
            readonly description: "Resultado ou pendência da aprovação do pedido conforme o valor limite.";
        }, {
            readonly fieldId: "status";
            readonly title: "Status";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "draft";
                readonly title: "Rascunho";
            }, {
                readonly value: "pendingApproval";
                readonly title: "Pendente de aprovação";
            }, {
                readonly value: "processed";
                readonly title: "Processado";
            }, {
                readonly value: "partiallyReceived";
                readonly title: "Parcialmente recebido";
            }, {
                readonly value: "received";
                readonly title: "Recebido";
            }];
            readonly description: "Etapa atual do processamento e recebimento do pedido de compra.";
        }];
        readonly details: {
            readonly valorTotal: {
                readonly type: "money";
                readonly description: "Soma dos valores dos itens do pedido conforme quantidades e preços registrados.";
            };
            readonly valorRecebido: {
                readonly type: "money";
                readonly description: "Soma dos valores correspondentes às quantidades já recebidas no pedido.";
            };
            readonly percentualRecebido: {
                readonly type: "number";
                readonly description: "Percentual das quantidades previstas no pedido que já foram recebidas.";
            };
            readonly estaAtrasado: {
                readonly type: "boolean";
                readonly description: "Indica se a data prevista de entrega foi ultrapassada antes do recebimento total.";
            };
        };
        readonly lifecycleStates: [{
            readonly state: "draft";
            readonly reachedBy: "actor";
        }, {
            readonly state: "pendingApproval";
            readonly reachedBy: "actor";
        }, {
            readonly state: "processed";
            readonly reachedBy: "actor";
        }, {
            readonly state: "partiallyReceived";
            readonly reachedBy: "command";
        }, {
            readonly state: "received";
            readonly reachedBy: "command";
        }];
        readonly transitions: [{
            readonly transitionId: "enviarPedido";
            readonly from: ["draft"];
            readonly to: "pendingApproval";
            readonly by: ["comprador"];
            readonly description: "Envia o pedido para avaliação da aprovação aplicável ao seu valor.";
        }, {
            readonly transitionId: "decidirPedido";
            readonly from: ["pendingApproval"];
            readonly to: "processed";
            readonly by: ["gerenteCompras"];
            readonly description: "Registra a decisão de aprovação ou rejeição do pedido, indicada na situação da aprovação.";
        }, {
            readonly transitionId: "liberarPedidoSemAprovacao";
            readonly from: ["pendingApproval"];
            readonly to: "processed";
            readonly by: "system";
            readonly description: "Processa o pedido que não exige aprovação gerencial conforme o valor limite.";
        }, {
            readonly transitionId: "registrarRecebimentoParcial";
            readonly from: ["processed", "partiallyReceived"];
            readonly to: "partiallyReceived";
            readonly by: "system";
            readonly description: "Atualiza o pedido após um recebimento que ainda não completa todas as quantidades previstas.";
        }, {
            readonly transitionId: "registrarRecebimentoTotal";
            readonly from: ["processed", "partiallyReceived"];
            readonly to: "received";
            readonly by: "system";
            readonly description: "Atualiza o pedido quando os recebimentos completam todas as quantidades previstas.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type ComprasEntityPedidoCompraType = typeof comprasEntityPedidoCompra;
    export default comprasEntityPedidoCompra;
}
declare module "_102047_/l4/compras/ontology/Produto.defs" {
    export const comprasEntityProduto: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "Produto";
        readonly title: "Produto";
        readonly description: "Produto mestre referenciado do módulo de controle de estoque para composição de fornecimentos, pedidos e recebimentos.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador do produto";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador do produto mestre no módulo de controle de estoque.";
        }, {
            readonly fieldId: "name";
            readonly title: "Nome do produto";
            readonly type: "string";
            readonly required: true;
            readonly constraints: {
                readonly maxLength: 255;
            };
            readonly description: "Nome de exibição do produto mestre referenciado para compor fornecimentos, pedidos e recebimentos.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "external";
            readonly scope: "platform";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComprasEntityProdutoType = typeof comprasEntityProduto;
    export default comprasEntityProduto;
}
declare module "_102047_/l4/compras/ontology/RecebimentoCompra.defs" {
    export const comprasEntityRecebimentoCompra: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly entityId: "RecebimentoCompra";
        readonly title: "Recebimento de compra";
        readonly description: "Registro do recebimento total ou parcial de um pedido de compra.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "numeroRecebimento";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do recebimento de compra.";
        }, {
            readonly fieldId: "numeroRecebimento";
            readonly title: "Número do recebimento";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número sequencial que identifica o recebimento de compra.";
        }, {
            readonly fieldId: "pedidoCompraId";
            readonly title: "Pedido de compra";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Pedido de compra ao qual este recebimento está vinculado.";
        }, {
            readonly fieldId: "dataRecebimento";
            readonly title: "Data de recebimento";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que os produtos foram efetivamente recebidos.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ComprasEntityRecebimentoCompraType = typeof comprasEntityRecebimentoCompra;
    export default comprasEntityRecebimentoCompra;
}
declare module "_102047_/l4/compras/ontology/index.defs" {
    export const comprasOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "compras";
        readonly businessDomain: "Gestão de compras, fornecedores, pedidos de compra e recebimentos de produtos.";
        readonly entities: ["Comprador", "Fornecedor", "Produto", "EstoqueProduto", "FornecimentoProduto", "PedidoCompra", "ItemPedidoCompra", "RecebimentoCompra", "ItemRecebimentoCompra"];
        readonly relationships: [{
            readonly relationshipId: "compradorGerenciaFornecedor";
            readonly fromEntity: "Comprador";
            readonly toEntity: "Fornecedor";
            readonly type: "manyToMany";
            readonly required: false;
            readonly description: "O comprador gerencia os fornecedores que cadastra e acompanha para a organização.";
            readonly persistence: {
                readonly mode: "mdmRelationship";
            };
            readonly realization: {
                readonly kind: "mdmRelationship";
                readonly ownerEntity: "Comprador";
                readonly from: {
                    readonly entityId: "Comprador";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "Fornecedor";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "fornecedorPossuiFornecimentos";
            readonly fromEntity: "Fornecedor";
            readonly toEntity: "FornecimentoProduto";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O fornecedor possui condições comerciais para os produtos que fornece.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "FornecimentoProduto";
                readonly from: {
                    readonly entityId: "Fornecedor";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "FornecimentoProduto";
                    readonly fieldIds: ["fornecedor"];
                };
            };
        }, {
            readonly relationshipId: "produtoPossuiFornecimentos";
            readonly fromEntity: "Produto";
            readonly toEntity: "FornecimentoProduto";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O produto pode ter condições comerciais registradas com diferentes fornecedores.";
            readonly persistence: {
                readonly mode: "externalReference";
            };
            readonly realization: {
                readonly kind: "externalReference";
                readonly ownerEntity: "FornecimentoProduto";
                readonly from: {
                    readonly entityId: "Produto";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "FornecimentoProduto";
                    readonly fieldIds: ["produto"];
                };
            };
        }, {
            readonly relationshipId: "fornecedorRecebePedidos";
            readonly fromEntity: "Fornecedor";
            readonly toEntity: "PedidoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O fornecedor recebe os pedidos de compra emitidos pela organização.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "PedidoCompra";
                readonly from: {
                    readonly entityId: "Fornecedor";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "PedidoCompra";
                    readonly fieldIds: ["fornecedorId"];
                };
            };
        }, {
            readonly relationshipId: "pedidoPossuiItens";
            readonly fromEntity: "PedidoCompra";
            readonly toEntity: "ItemPedidoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O pedido de compra é composto por um ou mais itens.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemPedidoCompra";
                readonly from: {
                    readonly entityId: "PedidoCompra";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ItemPedidoCompra";
                    readonly fieldIds: ["pedidoCompra"];
                };
            };
        }, {
            readonly relationshipId: "fornecimentoOriginaItensPedido";
            readonly fromEntity: "FornecimentoProduto";
            readonly toEntity: "ItemPedidoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "A condição de fornecimento define o produto e o preço de referência dos itens de pedido.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemPedidoCompra";
                readonly from: {
                    readonly entityId: "FornecimentoProduto";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ItemPedidoCompra";
                    readonly fieldIds: ["fornecimentoProduto"];
                };
            };
        }, {
            readonly relationshipId: "produtoComponeItensPedido";
            readonly fromEntity: "Produto";
            readonly toEntity: "ItemPedidoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O produto pode compor itens de diferentes pedidos de compra.";
            readonly persistence: {
                readonly mode: "externalReference";
            };
            readonly realization: {
                readonly kind: "externalReference";
                readonly ownerEntity: "ItemPedidoCompra";
                readonly from: {
                    readonly entityId: "Produto";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ItemPedidoCompra";
                    readonly fieldIds: ["produto"];
                };
            };
        }, {
            readonly relationshipId: "pedidoPossuiRecebimentos";
            readonly fromEntity: "PedidoCompra";
            readonly toEntity: "RecebimentoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O pedido de compra pode ter um ou mais recebimentos parciais ou totais.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "RecebimentoCompra";
                readonly from: {
                    readonly entityId: "PedidoCompra";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "RecebimentoCompra";
                    readonly fieldIds: ["pedidoCompraId"];
                };
            };
        }, {
            readonly relationshipId: "recebimentoPossuiItens";
            readonly fromEntity: "RecebimentoCompra";
            readonly toEntity: "ItemRecebimentoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O recebimento de compra registra as quantidades recebidas em seus itens.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemRecebimentoCompra";
                readonly from: {
                    readonly entityId: "RecebimentoCompra";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ItemRecebimentoCompra";
                    readonly fieldIds: ["recebimentoCompraId"];
                };
            };
        }, {
            readonly relationshipId: "itemPedidoPossuiRecebimentos";
            readonly fromEntity: "ItemPedidoCompra";
            readonly toEntity: "ItemRecebimentoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O item do pedido pode ser recebido em uma ou mais etapas.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ItemRecebimentoCompra";
                readonly from: {
                    readonly entityId: "ItemPedidoCompra";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ItemRecebimentoCompra";
                    readonly fieldIds: ["itemPedidoCompraId"];
                };
            };
        }, {
            readonly relationshipId: "produtoComponeItensRecebimento";
            readonly fromEntity: "Produto";
            readonly toEntity: "ItemRecebimentoCompra";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O produto recebido é identificado em cada item de recebimento.";
            readonly persistence: {
                readonly mode: "externalReference";
            };
            readonly realization: {
                readonly kind: "externalReference";
                readonly ownerEntity: "ItemRecebimentoCompra";
                readonly from: {
                    readonly entityId: "Produto";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ItemRecebimentoCompra";
                    readonly fieldIds: ["produto"];
                };
            };
        }, {
            readonly relationshipId: "itemRecebimentoAtualizaEstoque";
            readonly fromEntity: "ItemRecebimentoCompra";
            readonly toEntity: "EstoqueProduto";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "O item recebido gera a entrada na posição de estoque correspondente ao produto.";
            readonly persistence: {
                readonly mode: "externalReference";
            };
            readonly realization: {
                readonly kind: "externalReference";
                readonly ownerEntity: "ItemRecebimentoCompra";
                readonly from: {
                    readonly entityId: "ItemRecebimentoCompra";
                    readonly fieldIds: ["estoqueProdutoId"];
                };
                readonly to: {
                    readonly entityId: "EstoqueProduto";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type ComprasOntologyIndexType = typeof comprasOntologyIndex;
    export default comprasOntologyIndex;
}
declare module "_102047_/l4/controleEstoque/access.defs" {
    export const controleEstoqueAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "controleEstoque";
        readonly actors: [{
            readonly actorId: "estoquista";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Estoquista";
            readonly description: "Profissional responsável por operar o controle de estoque, registrando entradas e saídas de produtos.";
        }];
        readonly grants: [{
            readonly grantId: "operarEstoque";
            readonly actorRef: "estoquista";
            readonly title: "Operar controle de estoque";
            readonly description: "Permite ao estoquista cadastrar e acompanhar produtos de estoque, definir quantidades mínimas e registrar e consultar movimentações de entrada e saída.";
            readonly entityRefs: ["Produto", "MovimentacaoEstoque"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os produtos e as movimentações de estoque de toda a organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite visualizar todos os dados dos produtos controlados e das movimentações de estoque.";
            };
        }];
    };
    export type ControleEstoqueAccessType = typeof controleEstoqueAccess;
    export default controleEstoqueAccess;
}
declare module "_102047_/l4/controleEstoque/integration.defs" {
    export const controleEstoqueIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "controleEstoque";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "estoqueAbaixoDoMinimo";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "estoqueAbaixoDoMinimo";
            readonly on: "MovimentacaoEstoque.create";
            readonly description: "Publica um aviso para módulos interessados quando uma movimentação registrada deixar o saldo do produto abaixo do estoque mínimo.";
            readonly entityRefs: ["Produto", "MovimentacaoEstoque"];
        }];
        readonly plugins: [];
    };
    export type ControleEstoqueIntegrationType = typeof controleEstoqueIntegration;
    export default controleEstoqueIntegration;
}
declare module "_102047_/l4/controleEstoque/module.defs" {
    export const controleEstoqueModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "controleEstoque";
        readonly title: "Controle de estoque";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "controle de estoque: produtos, entradas e saídas, saldo atual por produto e aviso quando o saldo ficar abaixo do mínimo. movimentação não pode ser alterada depois de registrada. um perfil: estoquista.";
    };
    export type ControleEstoqueModuleType = typeof controleEstoqueModule;
    export default controleEstoqueModule;
}
declare module "_102047_/l4/controleEstoque/rules.defs" {
    export const controleEstoqueRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "controleEstoque";
        readonly rules: [{
            readonly ruleId: "quantidadeMinimaObrigatoria";
            readonly description: "Cada produto disponibilizado para controle de estoque deve ter uma quantidade mínima definida.";
        }, {
            readonly ruleId: "saldoAtualCalculadoPorMovimentacoes";
            readonly description: "O saldo atual de um produto deve corresponder às unidades registradas em entradas menos as unidades registradas em saídas.";
        }, {
            readonly ruleId: "avisoEstoqueBaixo";
            readonly description: "Deve haver aviso de estoque baixo quando o saldo atual de um produto ficar abaixo de sua quantidade mínima.";
        }, {
            readonly ruleId: "movimentacaoEstoqueImutavel";
            readonly description: "Uma movimentação de estoque não pode ser alterada depois de registrada.";
        }];
    };
    export type ControleEstoqueRulesType = typeof controleEstoqueRules;
    export default controleEstoqueRules;
}
declare module "_102047_/l4/controleEstoque/workflows.defs" {
    export const controleEstoqueWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "controleEstoque";
        readonly processes: [];
        readonly journeyDecisions: [{
            readonly journeyId: "cadastrarProdutoEstoque";
            readonly inProcess: false;
        }, {
            readonly journeyId: "atualizarQuantidadeMinima";
            readonly inProcess: false;
        }, {
            readonly journeyId: "registrarMovimentacaoEstoque";
            readonly inProcess: false;
        }, {
            readonly journeyId: "consultarSaldoProduto";
            readonly inProcess: false;
        }, {
            readonly journeyId: "tratarAvisoEstoqueBaixo";
            readonly inProcess: false;
        }];
    };
    export type ControleEstoqueWorkflowsType = typeof controleEstoqueWorkflows;
    export default controleEstoqueWorkflows;
}
declare module "_102047_/l4/controleEstoque/journeys/atualizarQuantidadeMinima.defs" {
    export const atualizarQuantidadeMinimaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "atualizarQuantidadeMinima";
        readonly business: {
            readonly actorRef: "estoquista";
            readonly title: "Atualizar quantidade mínima do produto";
            readonly goal: "Ajustar o nível mínimo usado para acompanhar a necessidade de reposição de um produto.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarProduto";
                readonly kind: "locate";
                readonly entity: "Produto";
                readonly title: "Localizar produto";
                readonly description: "Localizar o produto que terá a quantidade mínima ajustada.";
            }, {
                readonly stepId: "inspecionarEstoqueProduto";
                readonly kind: "inspect";
                readonly entity: "Produto";
                readonly title: "Consultar estoque do produto";
                readonly description: "Consultar o saldo atual e a quantidade mínima configurada para o produto.";
            }, {
                readonly stepId: "definirQuantidadeMinima";
                readonly kind: "act";
                readonly entity: "Produto";
                readonly effect: "update";
                readonly title: "Definir quantidade mínima";
                readonly description: "Atualizar a quantidade mínima do produto.";
            }];
            readonly outcome: {
                readonly statement: "A quantidade mínima do produto passa a orientar o aviso de estoque baixo.";
                readonly evidence: ["A nova quantidade mínima é exibida nos dados do produto."];
            };
        };
        readonly businessHash: "sha256:d9e38677f4d28bb4d907b665ef878c2c102fa730413c0cd2d9147edb189c02d6";
    };
    export type AtualizarQuantidadeMinimaJourneyType = typeof atualizarQuantidadeMinimaJourney;
    export default atualizarQuantidadeMinimaJourney;
}
declare module "_102047_/l4/controleEstoque/journeys/cadastrarProdutoEstoque.defs" {
    export const cadastrarProdutoEstoqueJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarProdutoEstoque";
        readonly business: {
            readonly actorRef: "estoquista";
            readonly title: "Cadastrar produto para controle de estoque";
            readonly goal: "Disponibilizar um produto no controle de estoque com sua quantidade mínima definida.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "informarProduto";
                readonly kind: "act";
                readonly entity: "Produto";
                readonly effect: "create";
                readonly title: "Cadastrar produto";
                readonly description: "Cadastrar ou vincular o produto ao controle de estoque e informar a quantidade mínima desejada.";
            }];
            readonly outcome: {
                readonly statement: "O produto fica disponível para movimentação e acompanhamento de estoque.";
                readonly evidence: ["O produto aparece no controle de estoque com a quantidade mínima registrada."];
            };
        };
        readonly businessHash: "sha256:20594ee8f13191707c177bf9a6a5938127d429cb6eac939e39ccf300ff3c0429";
    };
    export type CadastrarProdutoEstoqueJourneyType = typeof cadastrarProdutoEstoqueJourney;
    export default cadastrarProdutoEstoqueJourney;
}
declare module "_102047_/l4/controleEstoque/journeys/consultarSaldoProduto.defs" {
    export const consultarSaldoProdutoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "consultarSaldoProduto";
        readonly business: {
            readonly actorRef: "estoquista";
            readonly title: "Consultar saldo de produto";
            readonly goal: "Verificar o saldo atual e a situação de estoque de um produto.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarProdutoSaldo";
                readonly kind: "locate";
                readonly entity: "Produto";
                readonly title: "Localizar produto";
                readonly description: "Localizar o produto cujo estoque será consultado.";
            }, {
                readonly stepId: "inspecionarSaldoProduto";
                readonly kind: "inspect";
                readonly entity: "Produto";
                readonly title: "Consultar saldo do produto";
                readonly description: "Consultar o saldo atual, a quantidade mínima e a situação de estoque do produto.";
            }];
            readonly outcome: {
                readonly statement: "O estoquista conhece o saldo disponível e identifica se o produto está abaixo do mínimo.";
                readonly evidence: ["O saldo atual e a quantidade mínima são exibidos para o produto.", "A situação de estoque baixo é indicada quando o saldo está abaixo da quantidade mínima."];
            };
        };
        readonly businessHash: "sha256:1e9f59426697c4ef7fc5868f102a3d24e62f5990c2e03766499373b14bfcc138";
    };
    export type ConsultarSaldoProdutoJourneyType = typeof consultarSaldoProdutoJourney;
    export default consultarSaldoProdutoJourney;
}
declare module "_102047_/l4/controleEstoque/journeys/index.defs" {
    export const controleEstoqueJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "controleEstoque";
        readonly journeys: [{
            readonly journeyId: "cadastrarProdutoEstoque";
            readonly actorRef: "estoquista";
            readonly title: "Cadastrar produto para controle de estoque";
        }, {
            readonly journeyId: "atualizarQuantidadeMinima";
            readonly actorRef: "estoquista";
            readonly title: "Atualizar quantidade mínima do produto";
        }, {
            readonly journeyId: "registrarMovimentacaoEstoque";
            readonly actorRef: "estoquista";
            readonly title: "Registrar movimentação de estoque";
        }, {
            readonly journeyId: "consultarSaldoProduto";
            readonly actorRef: "estoquista";
            readonly title: "Consultar saldo de produto";
        }, {
            readonly journeyId: "tratarAvisoEstoqueBaixo";
            readonly actorRef: "estoquista";
            readonly title: "Verificar aviso de estoque baixo";
        }];
        readonly systemDecisions: [];
    };
    export type ControleEstoqueJourneyIndexType = typeof controleEstoqueJourneyIndex;
    export default controleEstoqueJourneyIndex;
}
declare module "_102047_/l4/controleEstoque/journeys/registrarMovimentacaoEstoque.defs" {
    export const registrarMovimentacaoEstoqueJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarMovimentacaoEstoque";
        readonly business: {
            readonly actorRef: "estoquista";
            readonly title: "Registrar movimentação de estoque";
            readonly goal: "Registrar uma entrada ou saída de unidades de um produto e manter seu saldo disponível atualizado.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarProdutoMovimentacao";
                readonly kind: "locate";
                readonly entity: "Produto";
                readonly title: "Localizar produto";
                readonly description: "Localizar o produto que receberá uma entrada ou terá unidades retiradas.";
            }, {
                readonly stepId: "inspecionarProdutoMovimentacao";
                readonly kind: "inspect";
                readonly entity: "Produto";
                readonly title: "Consultar produto";
                readonly description: "Consultar o saldo atual do produto antes do registro da movimentação.";
            }, {
                readonly stepId: "registrarMovimentacao";
                readonly kind: "act";
                readonly entity: "MovimentacaoEstoque";
                readonly affects: ["Produto"];
                readonly effect: "create";
                readonly title: "Registrar movimentação";
                readonly description: "Registrar a movimentação, informando se é entrada ou saída, o produto, a quantidade e os dados do registro.";
            }];
            readonly outcome: {
                readonly statement: "A movimentação fica registrada de forma imutável e o saldo do produto é atualizado conforme o tipo informado.";
                readonly evidence: ["Uma movimentação de entrada ou saída é exibida no histórico do produto.", "O saldo atual do produto aumenta para entradas e diminui para saídas pela quantidade registrada."];
            };
        };
        readonly businessHash: "sha256:38ddcf66d42e3c143d43f7bc3d342a73dd19f6906118877f1e452b5a92e8d2bf";
    };
    export type RegistrarMovimentacaoEstoqueJourneyType = typeof registrarMovimentacaoEstoqueJourney;
    export default registrarMovimentacaoEstoqueJourney;
}
declare module "_102047_/l4/controleEstoque/journeys/tratarAvisoEstoqueBaixo.defs" {
    export const tratarAvisoEstoqueBaixoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "tratarAvisoEstoqueBaixo";
        readonly business: {
            readonly actorRef: "estoquista";
            readonly title: "Verificar aviso de estoque baixo";
            readonly goal: "Identificar o produto que atingiu saldo abaixo do mínimo após receber um aviso.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "inspecionarProdutoEmAlerta";
                readonly kind: "inspect";
                readonly entity: "Produto";
                readonly title: "Consultar produto em alerta";
                readonly description: "Consultar o produto indicado no aviso, seu saldo atual e sua quantidade mínima.";
            }];
            readonly outcome: {
                readonly statement: "O estoquista identifica o produto que precisa de reposição.";
                readonly evidence: ["O produto do aviso exibe saldo atual abaixo da quantidade mínima.", "A situação de estoque baixo permanece visível na consulta do produto."];
            };
        };
        readonly businessHash: "sha256:9e2259b4627f2be6aa1b02298eccc60db9dce6634b91ba3067b15f0b53718e66";
    };
    export type TratarAvisoEstoqueBaixoJourneyType = typeof tratarAvisoEstoqueBaixoJourney;
    export default tratarAvisoEstoqueBaixoJourney;
}
declare module "_102047_/l4/controleEstoque/ontology/MovimentacaoEstoque.defs" {
    export const controleEstoqueEntityMovimentacaoEstoque: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "controleEstoque";
        readonly entityId: "MovimentacaoEstoque";
        readonly title: "Movimentação de estoque";
        readonly description: "Registro imutável de entrada ou saída de unidades de um produto no estoque.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "tipoMovimentacao";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da movimentação de estoque.";
        }, {
            readonly fieldId: "tipoMovimentacao";
            readonly title: "Tipo de movimentação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "entrada";
                readonly title: "Entrada";
            }, {
                readonly value: "saida";
                readonly title: "Saída";
            }];
            readonly description: "Indica se as unidades foram adicionadas ou retiradas do estoque.";
        }, {
            readonly fieldId: "produtoId";
            readonly title: "Produto";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao produto ao qual a movimentação se aplica.";
        }, {
            readonly fieldId: "quantidade";
            readonly title: "Quantidade";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 1;
            };
            readonly description: "Quantidade de unidades registrada na entrada ou saída.";
        }, {
            readonly fieldId: "dataMovimentacao";
            readonly title: "Data da movimentação";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a movimentação foi registrada.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ControleEstoqueEntityMovimentacaoEstoqueType = typeof controleEstoqueEntityMovimentacaoEstoque;
    export default controleEstoqueEntityMovimentacaoEstoque;
}
declare module "_102047_/l4/controleEstoque/ontology/Produto.defs" {
    export const controleEstoqueEntityProduto: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "controleEstoque";
        readonly entityId: "Produto";
        readonly title: "Produto em estoque";
        readonly description: "Produto disponibilizado para controle de estoque, com quantidade mínima definida para reposição.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "Product";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "quantidadeMinima";
            readonly title: "Quantidade mínima";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
            };
            readonly description: "Quantidade mínima de unidades que deve permanecer disponível para o produto.";
        }];
        readonly details: {
            readonly saldoAtual: {
                readonly type: "integer";
                readonly description: "Quantidade atual de unidades disponíveis do produto, calculada a partir das movimentações registradas.";
            };
            readonly estoqueBaixo: {
                readonly type: "boolean";
                readonly description: "Indica se o saldo atual do produto está abaixo da quantidade mínima configurada.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "controleEstoque.Produto";
        };
    };
    export type ControleEstoqueEntityProdutoType = typeof controleEstoqueEntityProduto;
    export default controleEstoqueEntityProduto;
}
declare module "_102047_/l4/controleEstoque/ontology/index.defs" {
    export const controleEstoqueOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "controleEstoque";
        readonly businessDomain: "Controle de estoque de produtos, movimentações de entrada e saída, saldo disponível e alerta de estoque baixo.";
        readonly entities: ["Produto", "MovimentacaoEstoque"];
        readonly relationships: [{
            readonly relationshipId: "movimentacaoEstoqueProduto";
            readonly fromEntity: "MovimentacaoEstoque";
            readonly toEntity: "Produto";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada movimentação de estoque registra a entrada ou saída de um produto.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "MovimentacaoEstoque";
                readonly from: {
                    readonly entityId: "MovimentacaoEstoque";
                    readonly fieldIds: ["produtoId"];
                };
                readonly to: {
                    readonly entityId: "Produto";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type ControleEstoqueOntologyIndexType = typeof controleEstoqueOntologyIndex;
    export default controleEstoqueOntologyIndex;
}
declare module "_102047_/l4/financeiro/access.defs" {
    export const financeiroAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "financeiro";
        readonly actors: [{
            readonly actorId: "caixa";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Caixa";
            readonly description: "Profissional da organização que recebe títulos, registra baixas parciais e estorna recebimentos no mesmo dia.";
        }, {
            readonly actorId: "gerenteFinanceiro";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gerente financeiro";
            readonly description: "Profissional da organização que acompanha os recebíveis, títulos vencidos e extratos por pagador.";
        }, {
            readonly actorId: "pagador";
            readonly kind: "external";
            readonly origin: "named";
            readonly title: "Pagador";
            readonly description: "Pessoa que acessa o portal para consultar seus títulos e recebimentos e pagar títulos em aberto com cartão.";
        }, {
            readonly actorId: "stripe";
            readonly kind: "system";
            readonly origin: "named";
            readonly title: "Stripe";
            readonly description: "Sistema externo utilizado para processar pagamentos com cartão.";
        }];
        readonly grants: [{
            readonly grantId: "caixaRecebimentos";
            readonly actorRef: "caixa";
            readonly title: "Operar recebimentos no caixa";
            readonly description: "Permite ao caixa consultar títulos da organização, registrar recebimentos parciais ou totais em dinheiro, Pix ou cartão e estornar recebimentos realizados no mesmo dia.";
            readonly entityRefs: ["TituloReceber", "Recebimento"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os títulos e recebimentos da organização necessários à operação do caixa.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O caixa pode consultar todos os dados dos títulos e recebimentos necessários para registrar, conferir e estornar baixas.";
            };
        }, {
            readonly grantId: "gerenteFinanceiroRecebiveis";
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Gerenciar recebíveis e extratos";
            readonly description: "Permite ao gerente financeiro acompanhar os recebíveis, consultar títulos vencidos e emitir extratos por pagador para toda a organização.";
            readonly entityRefs: ["TituloReceber", "Recebimento", "ExtratoPagador", "Pagador"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os pagadores, títulos, recebimentos e extratos da organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O gerente financeiro pode consultar todos os dados financeiros e os extratos necessários para análise e emissão.";
            };
        }, {
            readonly grantId: "pagadorMeusRecebiveis";
            readonly actorRef: "pagador";
            readonly title: "Consultar e pagar meus títulos";
            readonly description: "Permite ao pagador consultar somente seus próprios títulos e recebimentos e solicitar pagamento por cartão para títulos em aberto.";
            readonly entityRefs: ["TituloReceber", "Recebimento"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Abrange somente títulos vinculados ao pagador da sessão e os respectivos recebimentos.";
                readonly anchorEntity: "Pagador";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "O pagador vê os valores, vencimentos, situações e dados de seus recebimentos, sem referências internas de origem nem identificadores técnicos de processamento.";
                readonly allowedFields: ["TituloReceber.numeroTitulo", "TituloReceber.valorOriginal", "TituloReceber.vencimento", "TituloReceber.details.valorRecebido", "TituloReceber.details.saldoPendente", "TituloReceber.details.situacaoCobranca", "Recebimento.numeroRecebimento", "Recebimento.valor", "Recebimento.meioPagamento", "Recebimento.status", "Recebimento.recebidoEm", "Recebimento.estornadoEm"];
            };
        }, {
            readonly grantId: "stripeProcessarCartoes";
            readonly actorRef: "stripe";
            readonly title: "Processar cobranças por cartão";
            readonly description: "Permite à Stripe consultar solicitações de cartão encaminhadas para processamento e confirmar os respectivos recebimentos.";
            readonly entityRefs: ["TituloReceber", "Recebimento"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Abrange somente recebimentos por cartão vinculados ao pagador alcançado pelo título e os respectivos títulos.";
                readonly anchorEntity: "Pagador";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "A Stripe recebe somente os dados financeiros e técnicos indispensáveis para processar e confirmar cobranças por cartão.";
                readonly allowedFields: ["TituloReceber.id", "TituloReceber.numeroTitulo", "TituloReceber.valorOriginal", "TituloReceber.vencimento", "TituloReceber.details.valorRecebido", "TituloReceber.details.saldoPendente", "TituloReceber.details.situacaoCobranca", "Recebimento.id", "Recebimento.numeroRecebimento", "Recebimento.tituloReceberId", "Recebimento.valor", "Recebimento.meioPagamento", "Recebimento.status", "Recebimento.recebidoEm", "Recebimento.stripePaymentId"];
            };
        }];
    };
    export type FinanceiroAccessType = typeof financeiroAccess;
    export default financeiroAccess;
}
declare module "_102047_/l4/financeiro/module.defs" {
    export const financeiroModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "financeiro";
        readonly title: "Financeiro";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "criar o módulo financeiro em português. é o contas a receber da organização: toda cobrança nasce em outro módulo — a comanda fechada no restaurante, a mensalidade gerada na academia, a ordem de serviço entregue na assistência técnica — e aparece aqui como um título a receber com pagador, valor, vencimento e origem. o caixa recebe títulos (dinheiro, pix ou cartão via Stripe), pode dar baixa parcial e estornar um recebimento no mesmo dia. o gerente financeiro vê o painel de recebíveis por período e por origem, os títulos vencidos, e emite um extrato por pagador. o pagador acessa um portal e vê só os próprios títulos e recebimentos, e pode pagar um título em aberto com cartão. perfis: caixa, gerente financeiro e pagador.";
        readonly details: {
            readonly recebiveisPorPeriodoEorigem: {
                readonly type: "json";
                readonly description: "Indicadores calculados dos recebíveis da organização, agrupados por período e por origem.";
            };
        };
    };
    export type FinanceiroModuleType = typeof financeiroModule;
    export default financeiroModule;
}
declare module "_102047_/l4/financeiro/rules.defs" {
    export const financeiroRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "financeiro";
        readonly rules: [{
            readonly ruleId: "tituloDeveTerOrigemEmOutroModulo";
            readonly description: "Todo título a receber deve corresponder a uma cobrança gerada em outro módulo da organização.";
        }, {
            readonly ruleId: "saldoPendenteConsideraRecebimentosEestornos";
            readonly description: "O saldo pendente de um título deve corresponder ao valor original menos os recebimentos confirmados que não foram estornados.";
        }, {
            readonly ruleId: "tituloEmAbertoPossuiSaldoPendente";
            readonly description: "Um título a receber está em aberto quando seu saldo pendente é superior a zero.";
        }, {
            readonly ruleId: "cobrancaPorCartaoExigeTituloEmAberto";
            readonly description: "Uma cobrança por cartão só pode ser solicitada para um título a receber em aberto.";
        }, {
            readonly ruleId: "confirmacaoDeCartaoExigeProcessamento";
            readonly description: "Um recebimento por cartão só pode ser confirmado após o processamento da respectiva cobrança.";
        }, {
            readonly ruleId: "estornoSomenteNoMesmoDia";
            readonly description: "Um recebimento confirmado só pode ser estornado no mesmo dia em que foi confirmado.";
        }, {
            readonly ruleId: "tituloVencidoTemSaldoEprazoPassado";
            readonly description: "Um título a receber está vencido quando seu vencimento é anterior à data atual e possui saldo pendente.";
        }, {
            readonly ruleId: "extratoReuneRegistrosDoPagador";
            readonly description: "O extrato por pagador deve conter os títulos e os recebimentos associados ao pagador selecionado.";
        }];
    };
    export type FinanceiroRulesType = typeof financeiroRules;
    export default financeiroRules;
}
declare module "_102047_/l4/financeiro/workflows.defs" {
    export const financeiroWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "financeiro";
        readonly processes: [{
            readonly processId: "cobrancaCartaoNoCaixa";
            readonly title: "Cobrança por cartão no caixa";
            readonly description: "Orquestra a solicitação de cobrança por cartão iniciada pelo caixa e seu processamento pelo Stripe.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "caixa";
            };
            readonly tasks: [{
                readonly taskId: "iniciarCobranca";
                readonly kind: "human";
                readonly actorRef: "caixa";
                readonly journeyRef: "iniciarCobrancaPorCartaoNoCaixa";
                readonly next: ["confirmarPagamento"];
                readonly description: "O caixa registra e encaminha ao Stripe a solicitação de cobrança por cartão do título.";
            }, {
                readonly taskId: "confirmarPagamento";
                readonly kind: "mechanical";
                readonly actorRef: "stripe";
                readonly entityRef: "Recebimento";
                readonly effect: "transition";
                readonly transitionRef: "confirmarPagamentoComCartao";
                readonly next: [];
                readonly description: "O Stripe processa a cobrança encaminhada e confirma o pagamento por cartão.";
            }];
        }, {
            readonly processId: "pagamentoCartaoNoPortal";
            readonly title: "Pagamento por cartão no portal";
            readonly description: "Orquestra a solicitação de pagamento por cartão feita pelo pagador e seu processamento pelo Stripe.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "pagador";
            };
            readonly tasks: [{
                readonly taskId: "solicitarPagamento";
                readonly kind: "human";
                readonly actorRef: "pagador";
                readonly journeyRef: "pagarMeuTituloComCartao";
                readonly next: ["confirmarPagamento"];
                readonly description: "O pagador solicita e encaminha ao Stripe o pagamento por cartão de seu título em aberto.";
            }, {
                readonly taskId: "confirmarPagamento";
                readonly kind: "mechanical";
                readonly actorRef: "stripe";
                readonly entityRef: "Recebimento";
                readonly effect: "transition";
                readonly transitionRef: "confirmarPagamentoComCartao";
                readonly next: [];
                readonly description: "O Stripe processa a solicitação encaminhada e confirma o pagamento por cartão.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "registrarBaixaDeTitulo";
            readonly inProcess: false;
        }, {
            readonly journeyId: "iniciarCobrancaPorCartaoNoCaixa";
            readonly inProcess: true;
            readonly processId: "cobrancaCartaoNoCaixa";
        }, {
            readonly journeyId: "estornarRecebimentoDoMesmoDia";
            readonly inProcess: false;
        }, {
            readonly journeyId: "acompanharPainelDeRecebiveis";
            readonly inProcess: false;
        }, {
            readonly journeyId: "consultarTitulosVencidos";
            readonly inProcess: false;
        }, {
            readonly journeyId: "emitirExtratoPorPagador";
            readonly inProcess: false;
        }, {
            readonly journeyId: "consultarMeusTitulosErecebimentos";
            readonly inProcess: false;
        }, {
            readonly journeyId: "pagarMeuTituloComCartao";
            readonly inProcess: true;
            readonly processId: "pagamentoCartaoNoPortal";
        }, {
            readonly journeyId: "processarPagamentoPorCartao";
            readonly inProcess: false;
        }];
    };
    export type FinanceiroWorkflowsType = typeof financeiroWorkflows;
    export default financeiroWorkflows;
}
declare module "_102047_/l4/financeiro/journeys/acompanharPainelDeRecebiveis.defs" {
    export const acompanharPainelDeRecebiveisJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharPainelDeRecebiveis";
        readonly business: {
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Acompanhar painel de recebíveis";
            readonly goal: "Analisar os recebíveis da organização por período e por origem.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "inspecionarIndicadoresDeRecebiveis";
                readonly kind: "inspect";
                readonly entity: "TituloReceber";
                readonly title: "Inspecionar indicadores de recebíveis";
                readonly description: "Inspecionar os valores e a composição dos recebíveis por período e origem.";
            }];
            readonly outcome: {
                readonly statement: "O gerente financeiro visualiza a situação dos recebíveis no recorte solicitado.";
                readonly evidence: ["Indicadores de recebíveis exibidos para o período selecionado.", "Recebíveis identificados por origem."];
            };
        };
        readonly businessHash: "sha256:ba9c3c455fc9610dc72644d248a80666d3da9ee9cbc8a22d872d1f18a939731b";
    };
    export type AcompanharPainelDeRecebiveisJourneyType = typeof acompanharPainelDeRecebiveisJourney;
    export default acompanharPainelDeRecebiveisJourney;
}
declare module "_102047_/l4/financeiro/journeys/consultarMeusTitulosErecebimentos.defs" {
    export const consultarMeusTitulosErecebimentosJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "consultarMeusTitulosErecebimentos";
        readonly business: {
            readonly actorRef: "pagador";
            readonly title: "Consultar meus títulos e recebimentos";
            readonly goal: "Visualizar somente os próprios títulos a receber e recebimentos no portal.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarMeusTitulos";
                readonly kind: "locate";
                readonly entity: "TituloReceber";
                readonly title: "Localizar meus títulos";
                readonly description: "Localizar os títulos vinculados ao próprio pagador.";
            }, {
                readonly stepId: "inspecionarMeusTitulosErecebimentos";
                readonly kind: "inspect";
                readonly entity: "TituloReceber";
                readonly title: "Inspecionar meus títulos e recebimentos";
                readonly description: "Inspecionar valores, vencimentos, situação dos títulos e os recebimentos vinculados.";
            }];
            readonly outcome: {
                readonly statement: "O pagador visualiza seus títulos e seus recebimentos.";
                readonly evidence: ["Títulos vinculados ao pagador exibidos.", "Recebimentos do pagador disponíveis para consulta."];
            };
        };
        readonly businessHash: "sha256:6f467d376b9c5b24283913da4911285738717f271e37517012c095fc281ec9b0";
    };
    export type ConsultarMeusTitulosErecebimentosJourneyType = typeof consultarMeusTitulosErecebimentosJourney;
    export default consultarMeusTitulosErecebimentosJourney;
}
declare module "_102047_/l4/financeiro/journeys/consultarTitulosVencidos.defs" {
    export const consultarTitulosVencidosJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "consultarTitulosVencidos";
        readonly business: {
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Consultar títulos vencidos";
            readonly goal: "Identificar títulos a receber que estão vencidos.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarTitulosVencidos";
                readonly kind: "locate";
                readonly entity: "TituloReceber";
                readonly title: "Localizar títulos vencidos";
                readonly description: "Localizar títulos com vencimento passado e saldo pendente.";
            }, {
                readonly stepId: "inspecionarTitulosVencidos";
                readonly kind: "inspect";
                readonly entity: "TituloReceber";
                readonly title: "Inspecionar títulos vencidos";
                readonly description: "Inspecionar o pagador, o valor pendente, o vencimento e a origem de cada título vencido.";
            }];
            readonly outcome: {
                readonly statement: "Os títulos vencidos ficam disponíveis para acompanhamento financeiro.";
                readonly evidence: ["Lista de títulos vencidos apresentada.", "Dados de vencimento e saldo pendente visíveis."];
            };
        };
        readonly businessHash: "sha256:cf81b0dbc1e8ac2b6bb2f30437f3d9955a371fa2cfbe97b53817dbeda786554d";
    };
    export type ConsultarTitulosVencidosJourneyType = typeof consultarTitulosVencidosJourney;
    export default consultarTitulosVencidosJourney;
}
declare module "_102047_/l4/financeiro/journeys/emitirExtratoPorPagador.defs" {
    export const emitirExtratoPorPagadorJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "emitirExtratoPorPagador";
        readonly business: {
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Emitir extrato por pagador";
            readonly goal: "Obter o extrato de títulos e recebimentos de um pagador.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarPagador";
                readonly kind: "locate";
                readonly entity: "Pagador";
                readonly title: "Localizar pagador";
                readonly description: "Localizar o pagador para o qual será emitido o extrato.";
            }, {
                readonly stepId: "inspecionarExtratoDoPagador";
                readonly kind: "inspect";
                readonly entity: "Pagador";
                readonly title: "Inspecionar extrato do pagador";
                readonly description: "Inspecionar os títulos e os recebimentos associados ao pagador.";
            }, {
                readonly stepId: "emitirExtrato";
                readonly kind: "act";
                readonly entity: "ExtratoPagador";
                readonly effect: "create";
                readonly title: "Emitir extrato";
                readonly description: "Emitir o extrato com os títulos e recebimentos do pagador.";
            }];
            readonly outcome: {
                readonly statement: "O extrato do pagador é emitido.";
                readonly evidence: ["Extrato gerado para o pagador selecionado.", "Títulos e recebimentos incluídos no extrato."];
            };
        };
        readonly businessHash: "sha256:b4f4c730785f7afc079829e1789bdf00067413c81b3031963e26f1938e74f7c7";
    };
    export type EmitirExtratoPorPagadorJourneyType = typeof emitirExtratoPorPagadorJourney;
    export default emitirExtratoPorPagadorJourney;
}
declare module "_102047_/l4/financeiro/journeys/estornarRecebimentoDoMesmoDia.defs" {
    export const estornarRecebimentoDoMesmoDiaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "estornarRecebimentoDoMesmoDia";
        readonly business: {
            readonly actorRef: "caixa";
            readonly title: "Estornar recebimento do mesmo dia";
            readonly goal: "Cancelar um recebimento registrado no mesmo dia e recompor o saldo do título.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarRecebimentoDoDia";
                readonly kind: "locate";
                readonly entity: "Recebimento";
                readonly title: "Localizar recebimento do dia";
                readonly description: "Localizar o recebimento registrado no mesmo dia que será estornado.";
            }, {
                readonly stepId: "conferirRecebimentoEtitulo";
                readonly kind: "inspect";
                readonly entity: "Recebimento";
                readonly title: "Conferir recebimento e título";
                readonly description: "Conferir o recebimento e o título vinculado antes do estorno.";
            }, {
                readonly stepId: "estornarRecebimento";
                readonly kind: "act";
                readonly entity: "Recebimento";
                readonly affects: ["TituloReceber"];
                readonly effect: "transition";
                readonly transitionRef: "estornarRecebimento";
                readonly title: "Estornar recebimento";
                readonly description: "Estornar o recebimento registrado no mesmo dia.";
            }];
            readonly outcome: {
                readonly statement: "O recebimento é estornado e o saldo do título é recomposto.";
                readonly evidence: ["Recebimento identificado como estornado.", "Saldo do título atualizado após o estorno."];
            };
        };
        readonly businessHash: "sha256:d3111914db144f53e208f3165e090d83de215d9433d0bacdb2c1aea6144cf348";
    };
    export type EstornarRecebimentoDoMesmoDiaJourneyType = typeof estornarRecebimentoDoMesmoDiaJourney;
    export default estornarRecebimentoDoMesmoDiaJourney;
}
declare module "_102047_/l4/financeiro/journeys/index.defs" {
    export const financeiroJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "financeiro";
        readonly journeys: [{
            readonly journeyId: "registrarBaixaDeTitulo";
            readonly actorRef: "caixa";
            readonly title: "Registrar recebimento de título";
        }, {
            readonly journeyId: "iniciarCobrancaPorCartaoNoCaixa";
            readonly actorRef: "caixa";
            readonly title: "Cobrar título por cartão";
        }, {
            readonly journeyId: "estornarRecebimentoDoMesmoDia";
            readonly actorRef: "caixa";
            readonly title: "Estornar recebimento do mesmo dia";
        }, {
            readonly journeyId: "acompanharPainelDeRecebiveis";
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Acompanhar painel de recebíveis";
        }, {
            readonly journeyId: "consultarTitulosVencidos";
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Consultar títulos vencidos";
        }, {
            readonly journeyId: "emitirExtratoPorPagador";
            readonly actorRef: "gerenteFinanceiro";
            readonly title: "Emitir extrato por pagador";
        }, {
            readonly journeyId: "consultarMeusTitulosErecebimentos";
            readonly actorRef: "pagador";
            readonly title: "Consultar meus títulos e recebimentos";
        }, {
            readonly journeyId: "pagarMeuTituloComCartao";
            readonly actorRef: "pagador";
            readonly title: "Pagar meu título com cartão";
        }, {
            readonly journeyId: "processarPagamentoPorCartao";
            readonly actorRef: "stripe";
            readonly title: "Processar pagamento por cartão";
        }];
        readonly systemDecisions: [];
    };
    export type FinanceiroJourneyIndexType = typeof financeiroJourneyIndex;
    export default financeiroJourneyIndex;
}
declare module "_102047_/l4/financeiro/journeys/iniciarCobrancaPorCartaoNoCaixa.defs" {
    export const iniciarCobrancaPorCartaoNoCaixaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "iniciarCobrancaPorCartaoNoCaixa";
        readonly business: {
            readonly actorRef: "caixa";
            readonly title: "Cobrar título por cartão";
            readonly goal: "Iniciar no caixa o pagamento de um título em aberto por cartão.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarTituloParaCartao";
                readonly kind: "locate";
                readonly entity: "TituloReceber";
                readonly title: "Localizar título para cartão";
                readonly description: "Localizar o título em aberto que será cobrado por cartão.";
            }, {
                readonly stepId: "conferirDadosDaCobranca";
                readonly kind: "inspect";
                readonly entity: "TituloReceber";
                readonly title: "Conferir dados da cobrança";
                readonly description: "Conferir o pagador, o valor e o saldo do título antes de iniciar a cobrança.";
            }, {
                readonly stepId: "registrarSolicitacaoDeCartao";
                readonly kind: "act";
                readonly entity: "Recebimento";
                readonly affects: ["TituloReceber"];
                readonly effect: "create";
                readonly title: "Registrar solicitação de cartão";
                readonly description: "Registrar a solicitação de recebimento por cartão vinculada ao título.";
            }, {
                readonly stepId: "encaminharCobrancaParaStripe";
                readonly kind: "handoff";
                readonly entity: "Recebimento";
                readonly title: "Encaminhar cobrança para processamento";
                readonly description: "Encaminhar a cobrança por cartão para processamento.";
                readonly handoffTo: "stripe";
            }];
            readonly outcome: {
                readonly statement: "A cobrança por cartão é encaminhada para processamento.";
                readonly evidence: ["Solicitação de recebimento por cartão registrada.", "Cobrança encaminhada ao processador."];
            };
        };
        readonly businessHash: "sha256:15a80bafc3ca4f3b6e5da164047118ebc976718400a90fdf470299fe38a922ea";
    };
    export type IniciarCobrancaPorCartaoNoCaixaJourneyType = typeof iniciarCobrancaPorCartaoNoCaixaJourney;
    export default iniciarCobrancaPorCartaoNoCaixaJourney;
}
declare module "_102047_/l4/financeiro/journeys/pagarMeuTituloComCartao.defs" {
    export const pagarMeuTituloComCartaoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "pagarMeuTituloComCartao";
        readonly business: {
            readonly actorRef: "pagador";
            readonly title: "Pagar meu título com cartão";
            readonly goal: "Quitar um título próprio em aberto por cartão no portal.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarMeuTituloEmAberto";
                readonly kind: "locate";
                readonly entity: "TituloReceber";
                readonly title: "Localizar meu título em aberto";
                readonly description: "Localizar um título em aberto vinculado ao próprio pagador.";
            }, {
                readonly stepId: "conferirMeuTitulo";
                readonly kind: "inspect";
                readonly entity: "TituloReceber";
                readonly title: "Conferir meu título";
                readonly description: "Conferir o valor, o vencimento e o saldo do título antes do pagamento.";
            }, {
                readonly stepId: "solicitarPagamentoComCartao";
                readonly kind: "act";
                readonly entity: "Recebimento";
                readonly affects: ["TituloReceber"];
                readonly effect: "create";
                readonly title: "Solicitar pagamento com cartão";
                readonly description: "Solicitar o pagamento por cartão do título em aberto.";
            }, {
                readonly stepId: "encaminharPagamentoParaStripe";
                readonly kind: "handoff";
                readonly entity: "Recebimento";
                readonly title: "Encaminhar pagamento para processamento";
                readonly description: "Encaminhar a solicitação de pagamento por cartão para processamento.";
                readonly handoffTo: "stripe";
            }];
            readonly outcome: {
                readonly statement: "O pagamento por cartão é enviado para processamento.";
                readonly evidence: ["Solicitação de pagamento registrada.", "Cobrança encaminhada ao processador de cartão."];
            };
        };
        readonly businessHash: "sha256:81126e679978fe0a5283df16fafc56b7135eaa3551a3c29b2433d88a83468188";
    };
    export type PagarMeuTituloComCartaoJourneyType = typeof pagarMeuTituloComCartaoJourney;
    export default pagarMeuTituloComCartaoJourney;
}
declare module "_102047_/l4/financeiro/journeys/processarPagamentoPorCartao.defs" {
    export const processarPagamentoPorCartaoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "processarPagamentoPorCartao";
        readonly business: {
            readonly actorRef: "stripe";
            readonly title: "Processar pagamento por cartão";
            readonly goal: "Processar uma cobrança por cartão recebida do módulo financeiro.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "inspecionarSolicitacaoDeCartao";
                readonly kind: "inspect";
                readonly entity: "Recebimento";
                readonly title: "Inspecionar solicitação de cartão";
                readonly description: "Inspecionar a solicitação de recebimento por cartão encaminhada para processamento.";
            }, {
                readonly stepId: "confirmarPagamentoComCartao";
                readonly kind: "act";
                readonly entity: "Recebimento";
                readonly affects: ["TituloReceber"];
                readonly effect: "transition";
                readonly transitionRef: "confirmarPagamentoComCartao";
                readonly title: "Confirmar pagamento com cartão";
                readonly description: "Confirmar o pagamento por cartão processado.";
            }];
            readonly outcome: {
                readonly statement: "O pagamento por cartão confirmado é refletido no recebimento e no título.";
                readonly evidence: ["Recebimento confirmado por cartão.", "Saldo do título atualizado após a confirmação."];
            };
        };
        readonly businessHash: "sha256:ed9b9d02026c33bd58eab087f9c76f690b49abd31ca52b41bc59963324105a02";
    };
    export type ProcessarPagamentoPorCartaoJourneyType = typeof processarPagamentoPorCartaoJourney;
    export default processarPagamentoPorCartaoJourney;
}
declare module "_102047_/l4/financeiro/journeys/registrarBaixaDeTitulo.defs" {
    export const registrarBaixaDeTituloJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarBaixaDeTitulo";
        readonly business: {
            readonly actorRef: "caixa";
            readonly title: "Registrar recebimento de título";
            readonly goal: "Receber total ou parcialmente um título por dinheiro ou Pix.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarTituloEmAberto";
                readonly kind: "locate";
                readonly entity: "TituloReceber";
                readonly title: "Localizar título em aberto";
                readonly description: "Localizar o título em aberto que será recebido.";
            }, {
                readonly stepId: "conferirTitulo";
                readonly kind: "inspect";
                readonly entity: "TituloReceber";
                readonly title: "Conferir título";
                readonly description: "Conferir o pagador, o valor, o vencimento e o saldo pendente do título.";
            }, {
                readonly stepId: "registrarRecebimento";
                readonly kind: "act";
                readonly entity: "Recebimento";
                readonly affects: ["TituloReceber"];
                readonly effect: "create";
                readonly title: "Registrar recebimento";
                readonly description: "Registrar o valor recebido, inclusive em baixa parcial, e o meio de pagamento em dinheiro ou Pix.";
            }];
            readonly outcome: {
                readonly statement: "O recebimento é registrado e o saldo do título é atualizado.";
                readonly evidence: ["Comprovante de recebimento registrado.", "Saldo pendente do título atualizado."];
            };
        };
        readonly businessHash: "sha256:05fda5443e3d2a11fe326f8b92172c73b49377395d5f875a0f1070fe5140ed2d";
    };
    export type RegistrarBaixaDeTituloJourneyType = typeof registrarBaixaDeTituloJourney;
    export default registrarBaixaDeTituloJourney;
}
declare module "_102047_/l4/financeiro/ontology/ExtratoPagador.defs" {
    export const financeiroEntityExtratoPagador: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "financeiro";
        readonly entityId: "ExtratoPagador";
        readonly title: "Extrato do pagador";
        readonly description: "Extrato emitido para um pagador com os títulos e recebimentos considerados na emissão.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "numeroExtrato";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do extrato emitido.";
        }, {
            readonly fieldId: "numeroExtrato";
            readonly title: "Número do extrato";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número sequencial que identifica o extrato emitido.";
        }, {
            readonly fieldId: "pagadorId";
            readonly title: "Pagador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao pagador para o qual o extrato foi emitido.";
        }, {
            readonly fieldId: "emitidoEm";
            readonly title: "Emitido em";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de emissão do extrato.";
        }, {
            readonly fieldId: "titulosConsiderados";
            readonly title: "Títulos considerados";
            readonly type: "json";
            readonly required: true;
            readonly description: "Retrato dos títulos do pagador considerados na emissão do extrato.";
        }, {
            readonly fieldId: "recebimentosConsiderados";
            readonly title: "Recebimentos considerados";
            readonly type: "json";
            readonly required: true;
            readonly description: "Retrato dos recebimentos do pagador considerados na emissão do extrato.";
        }];
        readonly details: {
            readonly valorTotalTitulos: {
                readonly type: "money";
                readonly description: "Valor total dos títulos considerados no extrato.";
            };
            readonly valorTotalRecebido: {
                readonly type: "money";
                readonly description: "Valor total dos recebimentos considerados no extrato.";
            };
            readonly saldoEmAberto: {
                readonly type: "money";
                readonly description: "Saldo em aberto dos títulos considerados no momento da emissão.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type FinanceiroEntityExtratoPagadorType = typeof financeiroEntityExtratoPagador;
    export default financeiroEntityExtratoPagador;
}
declare module "_102047_/l4/financeiro/ontology/Pagador.defs" {
    export const financeiroEntityPagador: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "financeiro";
        readonly entityId: "Pagador";
        readonly title: "Pagador";
        readonly description: "Pessoa responsável por títulos a receber e que pode consultar e pagar os próprios títulos no portal.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "financeiro.Pagador";
        };
        readonly writer: "inbound";
    };
    export type FinanceiroEntityPagadorType = typeof financeiroEntityPagador;
    export default financeiroEntityPagador;
}
declare module "_102047_/l4/financeiro/ontology/Recebimento.defs" {
    export const financeiroEntityRecebimento: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "financeiro";
        readonly entityId: "Recebimento";
        readonly title: "Recebimento";
        readonly description: "Registro de uma solicitação ou confirmação de valor recebido para um título, por dinheiro, Pix ou cartão.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "numeroRecebimento";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do recebimento.";
        }, {
            readonly fieldId: "numeroRecebimento";
            readonly title: "Número do recebimento";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número sequencial que identifica o recebimento.";
        }, {
            readonly fieldId: "tituloReceberId";
            readonly title: "Título a receber";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Título a receber ao qual a solicitação, confirmação ou estorno está vinculado.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor recebido";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor da baixa ou da cobrança solicitada para o título.";
        }, {
            readonly fieldId: "meioPagamento";
            readonly title: "Meio de pagamento";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "dinheiro";
                readonly title: "Dinheiro";
            }, {
                readonly value: "pix";
                readonly title: "Pix";
            }, {
                readonly value: "cartao";
                readonly title: "Cartão";
            }];
            readonly description: "Meio utilizado ou solicitado para o recebimento.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "solicitado";
                readonly title: "Solicitado";
            }, {
                readonly value: "confirmado";
                readonly title: "Confirmado";
            }, {
                readonly value: "estornado";
                readonly title: "Estornado";
            }];
            readonly description: "Situação atual da solicitação ou confirmação de recebimento.";
        }, {
            readonly fieldId: "recebidoEm";
            readonly title: "Recebido em";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o recebimento foi confirmado.";
        }, {
            readonly fieldId: "stripePaymentId";
            readonly title: "Identificador do pagamento Stripe";
            readonly type: "string";
            readonly required: false;
            readonly description: "Identificador da cobrança processada pela Stripe quando o meio de pagamento for cartão.";
        }, {
            readonly fieldId: "estornadoEm";
            readonly title: "Estornado em";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora em que o recebimento foi estornado.";
        }];
        readonly lifecycleStates: [{
            readonly state: "solicitado";
            readonly reachedBy: "actor";
        }, {
            readonly state: "confirmado";
            readonly reachedBy: "actor";
        }, {
            readonly state: "estornado";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "confirmarPagamentoComCartao";
            readonly from: ["solicitado"];
            readonly to: "confirmado";
            readonly by: ["stripe"];
            readonly description: "Confirma o recebimento por cartão após o processamento da cobrança pela Stripe.";
        }, {
            readonly transitionId: "estornarRecebimento";
            readonly from: ["confirmado"];
            readonly to: "estornado";
            readonly by: ["caixa"];
            readonly description: "Estorna um recebimento confirmado e permite a recomposição do saldo do título.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type FinanceiroEntityRecebimentoType = typeof financeiroEntityRecebimento;
    export default financeiroEntityRecebimento;
}
declare module "_102047_/l4/financeiro/ontology/TituloReceber.defs" {
    export const financeiroEntityTituloReceber: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "financeiro";
        readonly entityId: "TituloReceber";
        readonly title: "Título a receber";
        readonly description: "Cobrança a receber originada em outro módulo da organização, com valor, vencimento, pagador e referência à origem.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "numeroTitulo";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do título a receber.";
        }, {
            readonly fieldId: "numeroTitulo";
            readonly title: "Número do título";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número sequencial que identifica o título a receber.";
        }, {
            readonly fieldId: "pagadorId";
            readonly title: "Pagador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao pagador responsável pelo título.";
        }, {
            readonly fieldId: "valorOriginal";
            readonly title: "Valor original";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor total originalmente cobrado no título.";
        }, {
            readonly fieldId: "vencimento";
            readonly title: "Vencimento";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data limite prevista para o pagamento do título.";
        }, {
            readonly fieldId: "origemModulo";
            readonly title: "Módulo de origem";
            readonly type: "string";
            readonly required: true;
            readonly description: "Identificador do módulo que gerou a cobrança.";
        }, {
            readonly fieldId: "origemReferencia";
            readonly title: "Referência da origem";
            readonly type: "string";
            readonly required: true;
            readonly description: "Identificador do registro de origem que gerou a cobrança.";
        }];
        readonly uniqueKeys: [["origemModulo", "origemReferencia"]];
        readonly details: {
            readonly valorRecebido: {
                readonly type: "money";
                readonly description: "Soma dos recebimentos confirmados e não estornados vinculados ao título.";
            };
            readonly saldoPendente: {
                readonly type: "money";
                readonly description: "Valor que ainda falta receber para quitar o título.";
            };
            readonly situacaoCobranca: {
                readonly type: "string";
                readonly description: "Situação calculada do título conforme saldo pendente, vencimento e recebimentos.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type FinanceiroEntityTituloReceberType = typeof financeiroEntityTituloReceber;
    export default financeiroEntityTituloReceber;
}
declare module "_102047_/l4/financeiro/ontology/index.defs" {
    export const financeiroOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "financeiro";
        readonly businessDomain: "Contas a receber da organização, incluindo títulos originados em outros módulos, recebimentos e consulta de extratos por pagador.";
        readonly entities: ["TituloReceber", "Recebimento", "ExtratoPagador", "Pagador"];
        readonly relationships: [{
            readonly relationshipId: "tituloTemPagador";
            readonly fromEntity: "TituloReceber";
            readonly toEntity: "Pagador";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada título a receber possui um pagador responsável.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "TituloReceber";
                readonly from: {
                    readonly entityId: "TituloReceber";
                    readonly fieldIds: ["pagadorId"];
                };
                readonly to: {
                    readonly entityId: "Pagador";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "recebimentoDoTitulo";
            readonly fromEntity: "Recebimento";
            readonly toEntity: "TituloReceber";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada recebimento registra uma solicitação, confirmação ou estorno relativo a um título a receber.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Recebimento";
                readonly from: {
                    readonly entityId: "Recebimento";
                    readonly fieldIds: ["tituloReceberId"];
                };
                readonly to: {
                    readonly entityId: "TituloReceber";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "extratoDoPagador";
            readonly fromEntity: "ExtratoPagador";
            readonly toEntity: "Pagador";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada extrato emitido pertence ao pagador consultado.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ExtratoPagador";
                readonly from: {
                    readonly entityId: "ExtratoPagador";
                    readonly fieldIds: ["pagadorId"];
                };
                readonly to: {
                    readonly entityId: "Pagador";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type FinanceiroOntologyIndexType = typeof financeiroOntologyIndex;
    export default financeiroOntologyIndex;
}
declare module "_102047_/l4/hiringPipeline/access.defs" {
    export const hiringPipelineAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "hiringPipeline";
        readonly actors: [{
            readonly actorId: "recruiter";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Recruiter";
            readonly description: "Internal staff member who opens job positions, registers candidates, and handles hiring pipeline activities other than offer and hiring decisions.";
        }, {
            readonly actorId: "hiringManager";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Hiring Manager";
            readonly description: "Internal manager responsible for deciding offers and hiring for job positions.";
        }];
        readonly grants: [{
            readonly grantId: "recruiterPipelineManagement";
            readonly actorRef: "recruiter";
            readonly title: "Manage hiring pipeline";
            readonly description: "Allows recruiters to open and review job positions, register candidates, create and advance applications, and record application rejections across the organization.";
            readonly entityRefs: ["JobPosition", "Candidate", "Application"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Applies to all hiring-pipeline records in the organization.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Recruiters may view complete job-position, candidate, and application records needed to manage the pipeline.";
            };
        }, {
            readonly grantId: "hiringManagerHiringDecisions";
            readonly actorRef: "hiringManager";
            readonly title: "Make hiring decisions";
            readonly description: "Allows hiring managers to review positions, candidates, and applications and to authorize offers and confirm hires across the organization.";
            readonly entityRefs: ["JobPosition", "Candidate", "Application"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Applies to all hiring-pipeline records in the organization.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Hiring managers may view complete job-position, candidate, and application records needed to make offer and hiring decisions.";
            };
        }];
    };
    export type HiringPipelineAccessType = typeof hiringPipelineAccess;
    export default hiringPipelineAccess;
}
declare module "_102047_/l4/hiringPipeline/integration.defs" {
    export const hiringPipelineIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "hiringPipeline";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "applicationAdvancedToInterview";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "advanceToInterview";
            readonly on: "Application.advanceToInterview";
            readonly description: "Publishes when an application advances to the interview stage.";
            readonly entityRefs: ["Application"];
        }, {
            readonly id: "applicationOfferIssued";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "issueOffer";
            readonly on: "Application.issueOffer";
            readonly description: "Publishes when an offer is issued for an application.";
            readonly entityRefs: ["Application"];
        }, {
            readonly id: "applicationMarkedHired";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "markHired";
            readonly on: "Application.markHired";
            readonly description: "Publishes when an application is marked as hired.";
            readonly entityRefs: ["Application"];
        }, {
            readonly id: "applicationRejected";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "rejectApplication";
            readonly on: "Application.rejectApplication";
            readonly description: "Publishes when an application is rejected, including its rejection reason.";
            readonly entityRefs: ["Application"];
        }];
        readonly plugins: [];
    };
    export type HiringPipelineIntegrationType = typeof hiringPipelineIntegration;
    export default hiringPipelineIntegration;
}
declare module "_102047_/l4/hiringPipeline/module.defs" {
    export const hiringPipelineModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "hiringPipeline";
        readonly title: "Hiring Pipeline";
        readonly userLanguage: "en";
        readonly productLanguages: ["en"];
        readonly defaultLanguage: "en";
        readonly sourcePrompt: "create the hiringPipeline module, in English. recruiters open job positions with title, department, description and headcount. candidates are registered with name, email, resume link and source. a candidate applies to a position and the application moves through stages: screening, interview, offer, then hired or rejected (with a reason). the hiring manager of the position decides offer and hired; the recruiter does everything else. a position closes automatically when its headcount is filled. profiles: recruiter and hiring manager.";
    };
    export type HiringPipelineModuleType = typeof hiringPipelineModule;
    export default hiringPipelineModule;
}
declare module "_102047_/l4/hiringPipeline/rules.defs" {
    export const hiringPipelineRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "hiringPipeline";
        readonly rules: [{
            readonly ruleId: "newApplicationStartsInScreening";
            readonly description: "A newly recorded application starts in the screening stage.";
        }, {
            readonly ruleId: "interviewRequiresScreening";
            readonly description: "An application may move to interview only from screening.";
        }, {
            readonly ruleId: "offerRequiresInterview";
            readonly description: "An application may move to offer only from interview.";
        }, {
            readonly ruleId: "hireRequiresOffer";
            readonly description: "An application may be marked hired only from offer.";
        }, {
            readonly ruleId: "hireRequiresRemainingHeadcount";
            readonly description: "An application may be marked hired only when its job position has remaining headcount.";
        }, {
            readonly ruleId: "rejectionRequiresActiveApplication";
            readonly description: "An application may be rejected only while it is in screening, interview, or offer.";
        }, {
            readonly ruleId: "rejectionReasonRequired";
            readonly description: "A rejected application must have a rejection reason.";
        }, {
            readonly ruleId: "applicationsRequireOpenPosition";
            readonly description: "An application may be recorded only for an open job position.";
        }, {
            readonly ruleId: "filledHeadcountCountsHiredApplications";
            readonly description: "A job position's filled headcount equals the number of its applications marked hired.";
        }, {
            readonly ruleId: "remainingHeadcountCalculation";
            readonly description: "A job position's remaining headcount equals its required headcount minus its filled headcount.";
        }, {
            readonly ruleId: "positionClosesWhenHeadcountFilled";
            readonly description: "A job position closes automatically when its filled headcount reaches its required headcount.";
        }];
    };
    export type HiringPipelineRulesType = typeof hiringPipelineRules;
    export default hiringPipelineRules;
}
declare module "_102047_/l4/hiringPipeline/workflows.defs" {
    export const hiringPipelineWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "hiringPipeline";
        readonly processes: [{
            readonly processId: "reviewInterviewForOffer";
            readonly title: "Review interviewed candidate for offer";
            readonly description: "Routes an interviewed application to the hiring manager for an offer decision.";
            readonly trigger: {
                readonly kind: "event";
                readonly event: "Application.advanceToInterview";
            };
            readonly tasks: [{
                readonly taskId: "issueOfferDecision";
                readonly kind: "human";
                readonly actorRef: "hiringManager";
                readonly journeyRef: "issueOffer";
                readonly next: [];
                readonly description: "The hiring manager reviews the interviewed application and decides whether to issue an offer.";
            }];
        }, {
            readonly processId: "confirmHireAndUpdatePosition";
            readonly title: "Confirm hire and update position capacity";
            readonly description: "Routes an offered application to the hiring manager and updates the associated position after a hire is recorded.";
            readonly trigger: {
                readonly kind: "event";
                readonly event: "Application.issueOffer";
            };
            readonly tasks: [{
                readonly taskId: "confirmHire";
                readonly kind: "human";
                readonly actorRef: "hiringManager";
                readonly journeyRef: "hireCandidate";
                readonly next: ["updatePositionCapacity"];
                readonly description: "The hiring manager confirms whether the offered candidate is hired.";
            }, {
                readonly taskId: "updatePositionCapacity";
                readonly kind: "mechanical";
                readonly entityRef: "JobPosition";
                readonly effect: "update";
                readonly next: [];
                readonly description: "Update the position's filled headcount and close the position when its required headcount is filled.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "openJobPosition";
            readonly inProcess: false;
        }, {
            readonly journeyId: "registerCandidate";
            readonly inProcess: false;
        }, {
            readonly journeyId: "startApplicationScreening";
            readonly inProcess: false;
        }, {
            readonly journeyId: "advanceApplicationToInterview";
            readonly inProcess: false;
        }, {
            readonly journeyId: "issueOffer";
            readonly inProcess: true;
            readonly processId: "reviewInterviewForOffer";
        }, {
            readonly journeyId: "hireCandidate";
            readonly inProcess: true;
            readonly processId: "confirmHireAndUpdatePosition";
        }, {
            readonly journeyId: "rejectApplication";
            readonly inProcess: false;
        }];
    };
    export type HiringPipelineWorkflowsType = typeof hiringPipelineWorkflows;
    export default hiringPipelineWorkflows;
}
declare module "_102047_/l4/hiringPipeline/journeys/advanceApplicationToInterview.defs" {
    export const advanceApplicationToInterviewJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "advanceApplicationToInterview";
        readonly business: {
            readonly actorRef: "recruiter";
            readonly title: "Advance an application to interview";
            readonly goal: "Move a screened application to the interview stage.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateApplication";
                readonly kind: "locate";
                readonly entity: "Application";
                readonly title: "Find the application.";
                readonly description: "Locate the application, or use the application already in context.";
            }, {
                readonly stepId: "inspectScreening";
                readonly kind: "inspect";
                readonly entity: "Application";
                readonly title: "Review screening details.";
                readonly description: "Inspect the application and its current screening stage.";
            }, {
                readonly stepId: "moveToInterview";
                readonly kind: "act";
                readonly entity: "Application";
                readonly effect: "transition";
                readonly transitionRef: "advanceToInterview";
                readonly title: "Move the application to interview.";
                readonly description: "Advance the application from screening to interview.";
            }];
            readonly outcome: {
                readonly statement: "The application is ready for the interview stage.";
                readonly evidence: ["The application shows the interview stage."];
            };
        };
        readonly businessHash: "sha256:3a3f768e869ef28e2d3a95f61415a4804b048a7434d3b0c2ed9197d21832b816";
    };
    export type AdvanceApplicationToInterviewJourneyType = typeof advanceApplicationToInterviewJourney;
    export default advanceApplicationToInterviewJourney;
}
declare module "_102047_/l4/hiringPipeline/journeys/hireCandidate.defs" {
    export const hireCandidateJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "hireCandidate";
        readonly business: {
            readonly actorRef: "hiringManager";
            readonly title: "Decide and record a hire";
            readonly goal: "Confirm that a candidate with an offer is hired.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateOfferApplication";
                readonly kind: "locate";
                readonly entity: "Application";
                readonly title: "Find the application with an offer.";
                readonly description: "Locate the application, or use the application already in context.";
            }, {
                readonly stepId: "inspectOfferApplication";
                readonly kind: "inspect";
                readonly entity: "Application";
                readonly title: "Review the offer application.";
                readonly description: "Inspect the candidate, job position, and offer-stage application.";
            }, {
                readonly stepId: "inspectPositionCapacity";
                readonly kind: "inspect";
                readonly entity: "JobPosition";
                readonly title: "Review position capacity.";
                readonly description: "Inspect the position's remaining headcount before confirming the hire.";
            }, {
                readonly stepId: "decideHire";
                readonly kind: "decide";
                readonly entity: "Application";
                readonly title: "Decide whether to hire the candidate.";
                readonly description: "Choose to confirm the candidate as hired.";
            }, {
                readonly stepId: "markHired";
                readonly kind: "act";
                readonly entity: "Application";
                readonly affects: ["JobPosition"];
                readonly effect: "transition";
                readonly transitionRef: "markHired";
                readonly title: "Record the hire.";
                readonly description: "Move the application from offer to hired and update the position's filled headcount.";
            }];
            readonly outcome: {
                readonly statement: "The candidate is recorded as hired, and the job position reflects the filled headcount.";
                readonly evidence: ["The application shows the hired stage.", "The job position's filled headcount reflects the hire.", "A position whose headcount is filled is closed automatically."];
            };
        };
        readonly businessHash: "sha256:c5858de30cd8c89fcddec2e9595acb709352b41d7126a07e0ce7f3b6c13a277b";
    };
    export type HireCandidateJourneyType = typeof hireCandidateJourney;
    export default hireCandidateJourney;
}
declare module "_102047_/l4/hiringPipeline/journeys/index.defs" {
    export const hiringPipelineJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "hiringPipeline";
        readonly journeys: [{
            readonly journeyId: "openJobPosition";
            readonly actorRef: "recruiter";
            readonly title: "Open a job position";
        }, {
            readonly journeyId: "registerCandidate";
            readonly actorRef: "recruiter";
            readonly title: "Register a candidate";
        }, {
            readonly journeyId: "startApplicationScreening";
            readonly actorRef: "recruiter";
            readonly title: "Start candidate screening";
        }, {
            readonly journeyId: "advanceApplicationToInterview";
            readonly actorRef: "recruiter";
            readonly title: "Advance an application to interview";
        }, {
            readonly journeyId: "issueOffer";
            readonly actorRef: "hiringManager";
            readonly title: "Decide and issue an offer";
        }, {
            readonly journeyId: "hireCandidate";
            readonly actorRef: "hiringManager";
            readonly title: "Decide and record a hire";
        }, {
            readonly journeyId: "rejectApplication";
            readonly actorRef: "recruiter";
            readonly title: "Reject an application";
        }];
        readonly systemDecisions: [];
    };
    export type HiringPipelineJourneyIndexType = typeof hiringPipelineJourneyIndex;
    export default hiringPipelineJourneyIndex;
}
declare module "_102047_/l4/hiringPipeline/journeys/issueOffer.defs" {
    export const issueOfferJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "issueOffer";
        readonly business: {
            readonly actorRef: "hiringManager";
            readonly title: "Decide and issue an offer";
            readonly goal: "Authorize an offer for an interviewed candidate.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateInterviewApplication";
                readonly kind: "locate";
                readonly entity: "Application";
                readonly title: "Find the interviewed application.";
                readonly description: "Locate the application, or use the application already in context.";
            }, {
                readonly stepId: "inspectApplication";
                readonly kind: "inspect";
                readonly entity: "Application";
                readonly title: "Review the application.";
                readonly description: "Inspect the candidate, job position, and interview-stage application.";
            }, {
                readonly stepId: "decideOffer";
                readonly kind: "decide";
                readonly entity: "Application";
                readonly title: "Decide whether to authorize an offer.";
                readonly description: "Choose to authorize an offer for the interviewed candidate.";
            }, {
                readonly stepId: "moveToOffer";
                readonly kind: "act";
                readonly entity: "Application";
                readonly effect: "transition";
                readonly transitionRef: "issueOffer";
                readonly title: "Issue the offer.";
                readonly description: "Move the application from interview to offer.";
            }];
            readonly outcome: {
                readonly statement: "The selected application has an authorized offer.";
                readonly evidence: ["The application shows the offer stage.", "The application remains linked to the candidate and job position."];
            };
        };
        readonly businessHash: "sha256:0e8ed208f84e85bd5fb24b4ab3f0f8a63add0c87059a89325545bab63f815d4b";
    };
    export type IssueOfferJourneyType = typeof issueOfferJourney;
    export default issueOfferJourney;
}
declare module "_102047_/l4/hiringPipeline/journeys/openJobPosition.defs" {
    export const openJobPositionJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "openJobPosition";
        readonly business: {
            readonly actorRef: "recruiter";
            readonly title: "Open a job position";
            readonly goal: "Create an open position with its hiring requirements.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "enterPositionDetails";
                readonly kind: "act";
                readonly entity: "JobPosition";
                readonly effect: "create";
                readonly title: "Enter the position title, department, description, and headcount.";
                readonly description: "Create the job position with its title, department, description, and required headcount.";
            }];
            readonly outcome: {
                readonly statement: "An open job position is available for candidate applications.";
                readonly evidence: ["The job position shows its title, department, description, and headcount.", "The job position is available in the hiring pipeline."];
            };
        };
        readonly businessHash: "sha256:d4dabe707059f458dea26e050c4ee82d13c0ec124291bf02d94244ef7951cabc";
    };
    export type OpenJobPositionJourneyType = typeof openJobPositionJourney;
    export default openJobPositionJourney;
}
declare module "_102047_/l4/hiringPipeline/journeys/registerCandidate.defs" {
    export const registerCandidateJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registerCandidate";
        readonly business: {
            readonly actorRef: "recruiter";
            readonly title: "Register a candidate";
            readonly goal: "Add a candidate to the hiring pipeline.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "captureCandidateDetails";
                readonly kind: "act";
                readonly entity: "Candidate";
                readonly effect: "create";
                readonly title: "Capture candidate details.";
                readonly description: "Register the candidate's name, email, resume link, and source.";
            }];
            readonly outcome: {
                readonly statement: "The candidate is available to be considered for job positions.";
                readonly evidence: ["The candidate record shows the name, email, resume link, and source."];
            };
        };
        readonly businessHash: "sha256:84d48c38dd2ebd84d6fd485164df286baba6c55f39694db7645b91df1736bf1e";
    };
    export type RegisterCandidateJourneyType = typeof registerCandidateJourney;
    export default registerCandidateJourney;
}
declare module "_102047_/l4/hiringPipeline/journeys/rejectApplication.defs" {
    export const rejectApplicationJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "rejectApplication";
        readonly business: {
            readonly actorRef: "recruiter";
            readonly title: "Reject an application";
            readonly goal: "Record that a candidate will not continue in the hiring pipeline.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateActiveApplication";
                readonly kind: "locate";
                readonly entity: "Application";
                readonly title: "Find the application.";
                readonly description: "Locate the active application, or use the application already in context.";
            }, {
                readonly stepId: "recordRejection";
                readonly kind: "act";
                readonly entity: "Application";
                readonly effect: "transition";
                readonly transitionRef: "rejectApplication";
                readonly title: "Record the rejection reason.";
                readonly description: "Move the application to rejected and record the reason for rejection.";
            }];
            readonly outcome: {
                readonly statement: "The application is rejected with a recorded reason.";
                readonly evidence: ["The application shows the rejected stage.", "The application includes a rejection reason."];
            };
        };
        readonly businessHash: "sha256:b5dac1ac03246dda1f2974ce96106dc3e432c4bcb466d558014ef566ff5d25f4";
    };
    export type RejectApplicationJourneyType = typeof rejectApplicationJourney;
    export default rejectApplicationJourney;
}
declare module "_102047_/l4/hiringPipeline/journeys/startApplicationScreening.defs" {
    export const startApplicationScreeningJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "startApplicationScreening";
        readonly business: {
            readonly actorRef: "recruiter";
            readonly title: "Start candidate screening";
            readonly goal: "Record a candidate's application for an open job position and begin screening.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "locateCandidate";
                readonly kind: "locate";
                readonly entity: "Candidate";
                readonly title: "Find the candidate.";
                readonly description: "Locate the registered candidate, or use the candidate already in context.";
            }, {
                readonly stepId: "locateOpenPosition";
                readonly kind: "locate";
                readonly entity: "JobPosition";
                readonly title: "Find the open position.";
                readonly description: "Locate the open job position for the application.";
            }, {
                readonly stepId: "createApplication";
                readonly kind: "act";
                readonly entity: "Application";
                readonly effect: "create";
                readonly title: "Create the application.";
                readonly description: "Record the candidate's application for the selected job position in screening.";
            }];
            readonly outcome: {
                readonly statement: "The candidate has an application in the screening stage for the job position.";
                readonly evidence: ["An application links the candidate and job position.", "The application shows the screening stage."];
            };
        };
        readonly businessHash: "sha256:e3b29d46b4de044aaba2fae8ad2b8a046ebaef5cfaf6256c436f67652ee2cf4a";
    };
    export type StartApplicationScreeningJourneyType = typeof startApplicationScreeningJourney;
    export default startApplicationScreeningJourney;
}
declare module "_102047_/l4/hiringPipeline/ontology/Application.defs" {
    export const hiringPipelineEntityApplication: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "hiringPipeline";
        readonly entityId: "Application";
        readonly title: "Application";
        readonly description: "A candidate's application for a job position, tracked through the hiring pipeline.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "id";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Application ID";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Unique identifier for the application.";
        }, {
            readonly fieldId: "candidateId";
            readonly title: "Candidate";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Reference to the candidate who submitted the application.";
        }, {
            readonly fieldId: "jobPositionId";
            readonly title: "Job Position";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Reference to the job position the candidate applied for.";
        }, {
            readonly fieldId: "status";
            readonly title: "Application Status";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "screening";
                readonly title: "Screening";
            }, {
                readonly value: "interview";
                readonly title: "Interview";
            }, {
                readonly value: "offer";
                readonly title: "Offer";
            }, {
                readonly value: "hired";
                readonly title: "Hired";
            }, {
                readonly value: "rejected";
                readonly title: "Rejected";
            }];
            readonly description: "Current stage of the application in the hiring pipeline.";
        }, {
            readonly fieldId: "rejectionReason";
            readonly title: "Rejection Reason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Reason recorded when the application is rejected.";
        }];
        readonly lifecycleStates: [{
            readonly state: "screening";
            readonly reachedBy: "actor";
        }, {
            readonly state: "interview";
            readonly reachedBy: "actor";
        }, {
            readonly state: "offer";
            readonly reachedBy: "actor";
        }, {
            readonly state: "hired";
            readonly reachedBy: "actor";
        }, {
            readonly state: "rejected";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "advanceToInterview";
            readonly from: ["screening"];
            readonly to: "interview";
            readonly by: ["recruiter"];
            readonly description: "Advance a screened application to the interview stage.";
        }, {
            readonly transitionId: "issueOffer";
            readonly from: ["interview"];
            readonly to: "offer";
            readonly by: ["hiringManager"];
            readonly description: "Authorize and issue an offer for an interviewed candidate.";
        }, {
            readonly transitionId: "markHired";
            readonly from: ["offer"];
            readonly to: "hired";
            readonly by: ["hiringManager"];
            readonly description: "Confirm that a candidate with an offer has been hired.";
        }, {
            readonly transitionId: "rejectApplication";
            readonly from: ["screening", "interview", "offer"];
            readonly to: "rejected";
            readonly by: ["recruiter"];
            readonly description: "Reject an active application and record the reason for rejection.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type HiringPipelineEntityApplicationType = typeof hiringPipelineEntityApplication;
    export default hiringPipelineEntityApplication;
}
declare module "_102047_/l4/hiringPipeline/ontology/Candidate.defs" {
    export const hiringPipelineEntityCandidate: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "hiringPipeline";
        readonly entityId: "Candidate";
        readonly title: "Candidate";
        readonly description: "A person registered as a candidate in the hiring pipeline.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "resumeLink";
            readonly title: "Resume Link";
            readonly type: "string";
            readonly required: true;
            readonly constraints: {
                readonly maxLength: 2048;
            };
            readonly description: "Link to the candidate's resume.";
        }, {
            readonly fieldId: "source";
            readonly title: "Source";
            readonly type: "string";
            readonly required: true;
            readonly constraints: {
                readonly maxLength: 255;
            };
            readonly description: "Source through which the candidate was identified.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "hiringPipeline.Candidate";
        };
    };
    export type HiringPipelineEntityCandidateType = typeof hiringPipelineEntityCandidate;
    export default hiringPipelineEntityCandidate;
}
declare module "_102047_/l4/hiringPipeline/ontology/JobPosition.defs" {
    export const hiringPipelineEntityJobPosition: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "hiringPipeline";
        readonly entityId: "JobPosition";
        readonly title: "Job Position";
        readonly description: "An open hiring position with its requirements and capacity for hires.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "title";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Job Position ID";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Unique identifier for the job position.";
        }, {
            readonly fieldId: "title";
            readonly title: "Title";
            readonly type: "string";
            readonly required: true;
            readonly description: "Title of the job position.";
        }, {
            readonly fieldId: "department";
            readonly title: "Department";
            readonly type: "string";
            readonly required: true;
            readonly description: "Department seeking to fill the position.";
        }, {
            readonly fieldId: "description";
            readonly title: "Description";
            readonly type: "text";
            readonly required: true;
            readonly description: "Description of the position and its hiring requirements.";
        }, {
            readonly fieldId: "headcount";
            readonly title: "Required Headcount";
            readonly type: "integer";
            readonly required: true;
            readonly description: "Number of candidates required for this position.";
        }];
        readonly details: {
            readonly filledHeadcount: {
                readonly type: "integer";
                readonly description: "Number of applications that have reached the hired stage for this position.";
            };
            readonly remainingHeadcount: {
                readonly type: "integer";
                readonly description: "Number of additional hires needed to fulfill the required headcount.";
            };
            readonly isHeadcountFilled: {
                readonly type: "boolean";
                readonly description: "Indicates whether the position's required headcount has been fulfilled.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type HiringPipelineEntityJobPositionType = typeof hiringPipelineEntityJobPosition;
    export default hiringPipelineEntityJobPosition;
}
declare module "_102047_/l4/hiringPipeline/ontology/index.defs" {
    export const hiringPipelineOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "hiringPipeline";
        readonly businessDomain: "Hiring pipeline management";
        readonly entities: ["JobPosition", "Candidate", "Application"];
        readonly relationships: [{
            readonly relationshipId: "candidateApplications";
            readonly fromEntity: "Candidate";
            readonly toEntity: "Application";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "A candidate submits one or more applications.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Application";
                readonly from: {
                    readonly entityId: "Candidate";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "Application";
                    readonly fieldIds: ["candidateId"];
                };
            };
        }, {
            readonly relationshipId: "jobPositionApplications";
            readonly fromEntity: "JobPosition";
            readonly toEntity: "Application";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "A job position receives one or more candidate applications.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Application";
                readonly from: {
                    readonly entityId: "JobPosition";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "Application";
                    readonly fieldIds: ["jobPositionId"];
                };
            };
        }];
    };
    export type HiringPipelineOntologyIndexType = typeof hiringPipelineOntologyIndex;
    export default hiringPipelineOntologyIndex;
}
declare module "_102047_/l4/inscricaoEvento/access.defs" {
    export const inscricaoEventoAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "inscricaoEvento";
        readonly actors: [{
            readonly actorId: "organizador";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Organizador";
            readonly description: "Pessoa da organização que cadastra, publica e acompanha eventos e inscrições.";
        }, {
            readonly actorId: "publico";
            readonly kind: "external";
            readonly origin: "named";
            readonly title: "Público";
            readonly description: "Pessoa que acessa a página pública de um evento para realizar ou cancelar sua inscrição.";
        }];
        readonly grants: [{
            readonly grantId: "organizadorGerenciaEventosEinscricoes";
            readonly actorRef: "organizador";
            readonly title: "Gerenciar eventos e inscrições";
            readonly description: "Permite cadastrar, publicar e acompanhar os eventos da organização, incluindo as inscrições e os participantes vinculados.";
            readonly entityRefs: ["Evento", "Inscricao", "Participante"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os eventos, inscrições e participantes de toda a organização.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite consultar todos os campos dos registros necessários para administrar eventos e inscrições.";
            };
        }, {
            readonly grantId: "publicoConsultaEgerenciaPropriaInscricao";
            readonly actorRef: "publico";
            readonly title: "Consultar e gerenciar a própria inscrição";
            readonly description: "Permite consultar os dados do evento relacionado e realizar ou cancelar apenas a própria inscrição.";
            readonly entityRefs: ["Evento", "Inscricao", "Participante"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Abrange somente a inscrição e o participante associados à pessoa identificada na sessão, bem como o evento dessa inscrição.";
                readonly anchorEntity: "Participante";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Exibe os dados de divulgação e disponibilidade do evento e os dados da própria inscrição, sem expor identificadores internos do evento.";
                readonly allowedFields: ["Evento.title", "Evento.description", "Evento.eventDate", "Evento.location", "Evento.capacity", "Evento.status", "Evento.details.occupiedSeats", "Evento.details.availableSeats", "Inscricao.id", "Inscricao.eventoId", "Inscricao.participanteId", "Inscricao.status", "Inscricao.registeredAt", "Participante.id"];
                readonly deniedFields: ["Evento.id"];
            };
        }];
    };
    export type InscricaoEventoAccessType = typeof inscricaoEventoAccess;
    export default inscricaoEventoAccess;
}
declare module "_102047_/l4/inscricaoEvento/integration.defs" {
    export const inscricaoEventoIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "inscricaoEvento";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "publicarEvento";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "publicarEvento";
            readonly on: "Evento.publicarEvento";
            readonly description: "Publica o evento para que outros módulos possam reagir à sua disponibilização pública.";
            readonly entityRefs: ["Evento"];
        }, {
            readonly id: "cancelarInscricao";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "cancelarInscricao";
            readonly on: "Inscricao.cancelarInscricao";
            readonly description: "Publica o cancelamento de uma inscrição para consumidores que acompanham a disponibilidade do evento.";
            readonly entityRefs: ["Inscricao", "Evento"];
        }, {
            readonly id: "promoverListaEspera";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "promoverListaEspera";
            readonly on: "Inscricao.promoverListaEspera";
            readonly description: "Publica a promoção de uma inscrição da lista de espera para uma vaga disponível.";
            readonly entityRefs: ["Inscricao", "Evento"];
        }];
        readonly plugins: [];
    };
    export type InscricaoEventoIntegrationType = typeof inscricaoEventoIntegration;
    export default inscricaoEventoIntegration;
}
declare module "_102047_/l4/inscricaoEvento/module.defs" {
    export const inscricaoEventoModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "inscricaoEvento";
        readonly title: "Inscrição em Eventos";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR", "en"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "módulo inscricaoEvento, em português e inglês. o organizador cadastra eventos com título, descrição, data, local e número de vagas, e publica. cada evento publicado tem uma página pública onde qualquer pessoa se inscreve com nome e e-mail; o mesmo e-mail só pode se inscrever uma vez por evento. quando as vagas acabam, novas inscrições entram em lista de espera na ordem de chegada; se um inscrito cancelar, o primeiro da lista de espera é promovido. o organizador vê os inscritos, o total de vagas ocupadas e baixa a lista em CSV. perfis: organizador e público.";
    };
    export type InscricaoEventoModuleType = typeof inscricaoEventoModule;
    export default inscricaoEventoModule;
}
declare module "_102047_/l4/inscricaoEvento/rules.defs" {
    export const inscricaoEventoRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "inscricaoEvento";
        readonly rules: [{
            readonly ruleId: "emailUnicoPorEvento";
            readonly description: "Um mesmo e-mail pode ter apenas uma inscrição em cada evento.";
        }, {
            readonly ruleId: "ocupacaoLimitadaAcapacidade";
            readonly description: "A quantidade de inscrições confirmadas de um evento não pode exceder sua capacidade.";
        }, {
            readonly ruleId: "inscricaoSemVagaEntraEmEspera";
            readonly description: "Uma inscrição criada quando não houver vagas disponíveis deve ficar na lista de espera.";
        }, {
            readonly ruleId: "listaEsperaPorOrdemDeChegada";
            readonly description: "As inscrições em lista de espera devem respeitar a ordem de registro.";
        }, {
            readonly ruleId: "promocaoAutomaticaDaListaEspera";
            readonly description: "Quando o cancelamento de uma inscrição confirmada liberar uma vaga, a primeira inscrição da lista de espera deve ser promovida para confirmada.";
        }, {
            readonly ruleId: "vagasOcupadasPorInscricoesConfirmadas";
            readonly description: "O total de vagas ocupadas de um evento corresponde à quantidade de inscrições confirmadas.";
        }, {
            readonly ruleId: "vagasDisponiveisPorCapacidade";
            readonly description: "A quantidade de vagas disponíveis de um evento corresponde à sua capacidade menos o total de vagas ocupadas.";
        }];
    };
    export type InscricaoEventoRulesType = typeof inscricaoEventoRules;
    export default inscricaoEventoRules;
}
declare module "_102047_/l4/inscricaoEvento/workflows.defs" {
    export const inscricaoEventoWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "inscricaoEvento";
        readonly processes: [{
            readonly processId: "promoverPrimeiroListaEspera";
            readonly title: "Promover participante da lista de espera";
            readonly description: "Promove automaticamente o primeiro participante elegível da lista de espera quando uma inscrição é cancelada e uma vaga é liberada.";
            readonly trigger: {
                readonly kind: "event";
                readonly event: "Inscricao.cancelarInscricao";
            };
            readonly tasks: [{
                readonly taskId: "promoverInscricaoEmEspera";
                readonly kind: "mechanical";
                readonly entityRef: "Inscricao";
                readonly effect: "transition";
                readonly transitionRef: "promoverListaEspera";
                readonly next: [];
                readonly description: "Promove o primeiro participante da lista de espera para confirmar sua inscrição quando houver vaga disponível.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "cadastrarEpublicarEvento";
            readonly inProcess: false;
        }, {
            readonly journeyId: "realizarInscricaoPublica";
            readonly inProcess: false;
        }, {
            readonly journeyId: "cancelarInscricao";
            readonly inProcess: false;
        }, {
            readonly journeyId: "acompanharInscricoesDoEvento";
            readonly inProcess: false;
        }];
    };
    export type InscricaoEventoWorkflowsType = typeof inscricaoEventoWorkflows;
    export default inscricaoEventoWorkflows;
}
declare module "_102047_/l4/inscricaoEvento/journeys/acompanharInscricoesDoEvento.defs" {
    export const acompanharInscricoesDoEventoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharInscricoesDoEvento";
        readonly business: {
            readonly actorRef: "organizador";
            readonly title: "Acompanhar inscritos e exportar lista";
            readonly goal: "Consultar os inscritos, as vagas ocupadas e baixar a lista do evento em CSV.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarEvento";
                readonly kind: "locate";
                readonly entity: "Evento";
                readonly title: "Localizar evento";
                readonly description: "Localiza o evento que deseja acompanhar.";
            }, {
                readonly stepId: "consultarOcupacaoDoEvento";
                readonly kind: "inspect";
                readonly entity: "Evento";
                readonly title: "Consultar ocupação do evento";
                readonly description: "Consulta o total de vagas ocupadas e a capacidade do evento.";
            }, {
                readonly stepId: "consultarEexportarInscricoes";
                readonly kind: "inspect";
                readonly entity: "Inscricao";
                readonly title: "Consultar e exportar inscritos";
                readonly description: "Consulta os inscritos e baixa a lista de inscrições do evento em formato CSV.";
            }];
            readonly outcome: {
                readonly statement: "O organizador acompanha a ocupação do evento e obtém a lista de inscritos em CSV.";
                readonly evidence: ["Total de vagas ocupadas exibido para o evento.", "Lista de inscrições do evento disponível para consulta.", "Arquivo CSV da lista de inscritos baixado."];
            };
        };
        readonly businessHash: "sha256:e54d7941eb27865a914d66efe155beb843076aa35ccbf40cc7eb34a926fbf3e5";
    };
    export type AcompanharInscricoesDoEventoJourneyType = typeof acompanharInscricoesDoEventoJourney;
    export default acompanharInscricoesDoEventoJourney;
}
declare module "_102047_/l4/inscricaoEvento/journeys/cadastrarEpublicarEvento.defs" {
    export const cadastrarEpublicarEventoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarEpublicarEvento";
        readonly business: {
            readonly actorRef: "organizador";
            readonly title: "Cadastrar e publicar evento";
            readonly goal: "Disponibilizar um evento com suas informações e capacidade para inscrição pública.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "criarEvento";
                readonly kind: "act";
                readonly entity: "Evento";
                readonly effect: "create";
                readonly title: "Criar evento";
                readonly description: "Cadastra o título, a descrição, a data, o local e o número de vagas do evento.";
            }, {
                readonly stepId: "publicarEvento";
                readonly kind: "act";
                readonly entity: "Evento";
                readonly effect: "transition";
                readonly transitionRef: "publicarEvento";
                readonly title: "Publicar evento";
                readonly description: "Publica o evento para disponibilizar sua página de inscrição pública.";
            }];
            readonly outcome: {
                readonly statement: "O evento fica publicado e disponível para receber inscrições.";
                readonly evidence: ["Evento publicado com título, descrição, data, local e número de vagas.", "Página pública de inscrição disponível para o evento."];
            };
        };
        readonly businessHash: "sha256:49b25d2dac280c5a3077c558a79f2acefaadc6f2829015f864a57d65a4f987b9";
    };
    export type CadastrarEpublicarEventoJourneyType = typeof cadastrarEpublicarEventoJourney;
    export default cadastrarEpublicarEventoJourney;
}
declare module "_102047_/l4/inscricaoEvento/journeys/cancelarInscricao.defs" {
    export const cancelarInscricaoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cancelarInscricao";
        readonly business: {
            readonly actorRef: "publico";
            readonly title: "Cancelar inscrição";
            readonly goal: "Cancelar a própria inscrição em um evento e liberar a vaga quando houver uma confirmação.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarInscricao";
                readonly kind: "locate";
                readonly entity: "Inscricao";
                readonly title: "Localizar inscrição";
                readonly description: "Localiza a própria inscrição do evento.";
            }, {
                readonly stepId: "consultarInscricao";
                readonly kind: "inspect";
                readonly entity: "Inscricao";
                readonly title: "Consultar inscrição";
                readonly description: "Confere os dados e a situação da inscrição antes do cancelamento.";
            }, {
                readonly stepId: "cancelarInscricao";
                readonly kind: "act";
                readonly entity: "Inscricao";
                readonly effect: "transition";
                readonly transitionRef: "cancelarInscricao";
                readonly title: "Cancelar inscrição";
                readonly description: "Cancela a inscrição; caso uma vaga seja liberada, o primeiro participante da lista de espera é promovido automaticamente.";
            }];
            readonly outcome: {
                readonly statement: "A inscrição é cancelada e uma eventual vaga liberada é destinada ao primeiro participante da lista de espera.";
                readonly evidence: ["Situação da inscrição alterada para cancelada.", "Próxima inscrição em lista de espera promovida quando aplicável."];
            };
        };
        readonly businessHash: "sha256:89447bf01d13332f5d9bd061692e3917620ec4f2283b9e9b7295a057215b3462";
    };
    export type CancelarInscricaoJourneyType = typeof cancelarInscricaoJourney;
    export default cancelarInscricaoJourney;
}
declare module "_102047_/l4/inscricaoEvento/journeys/index.defs" {
    export const inscricaoEventoJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "inscricaoEvento";
        readonly journeys: [{
            readonly journeyId: "cadastrarEpublicarEvento";
            readonly actorRef: "organizador";
            readonly title: "Cadastrar e publicar evento";
        }, {
            readonly journeyId: "realizarInscricaoPublica";
            readonly actorRef: "publico";
            readonly title: "Realizar inscrição em evento";
        }, {
            readonly journeyId: "cancelarInscricao";
            readonly actorRef: "publico";
            readonly title: "Cancelar inscrição";
        }, {
            readonly journeyId: "acompanharInscricoesDoEvento";
            readonly actorRef: "organizador";
            readonly title: "Acompanhar inscritos e exportar lista";
        }];
        readonly systemDecisions: [];
    };
    export type InscricaoEventoJourneyIndexType = typeof inscricaoEventoJourneyIndex;
    export default inscricaoEventoJourneyIndex;
}
declare module "_102047_/l4/inscricaoEvento/journeys/realizarInscricaoPublica.defs" {
    export const realizarInscricaoPublicaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "realizarInscricaoPublica";
        readonly business: {
            readonly actorRef: "publico";
            readonly title: "Realizar inscrição em evento";
            readonly goal: "Inscrever-se em um evento publicado usando nome e e-mail.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarEventoPublicado";
                readonly kind: "locate";
                readonly entity: "Evento";
                readonly title: "Localizar evento publicado";
                readonly description: "Acessa a página pública de um evento publicado.";
            }, {
                readonly stepId: "consultarEvento";
                readonly kind: "inspect";
                readonly entity: "Evento";
                readonly title: "Consultar informações do evento";
                readonly description: "Consulta os dados e a disponibilidade do evento antes de se inscrever.";
            }, {
                readonly stepId: "criarInscricao";
                readonly kind: "act";
                readonly entity: "Inscricao";
                readonly affects: ["Participante"];
                readonly effect: "create";
                readonly title: "Criar inscrição";
                readonly description: "Informa nome e e-mail para criar ou associar o participante e registrar sua inscrição; quando não houver vaga, a inscrição entra na lista de espera pela ordem de chegada.";
            }];
            readonly outcome: {
                readonly statement: "A inscrição é registrada como confirmada ou em lista de espera, conforme a disponibilidade.";
                readonly evidence: ["Inscrição vinculada ao evento e ao participante.", "Situação da inscrição indica confirmação ou lista de espera.", "Não existe mais de uma inscrição do mesmo e-mail para o mesmo evento."];
            };
        };
        readonly businessHash: "sha256:f7d82574aa448748791f2dee1f03840ef499e60b3570d0ded4b73c99851d1719";
    };
    export type RealizarInscricaoPublicaJourneyType = typeof realizarInscricaoPublicaJourney;
    export default realizarInscricaoPublicaJourney;
}
declare module "_102047_/l4/inscricaoEvento/ontology/Evento.defs" {
    export const inscricaoEventoEntityEvento: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "inscricaoEvento";
        readonly entityId: "Evento";
        readonly title: "Evento";
        readonly description: "Evento cadastrado pelo organizador, com informações, capacidade e publicação para inscrições públicas.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "title";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do evento.";
        }, {
            readonly fieldId: "title";
            readonly title: "Título";
            readonly type: "string";
            readonly required: true;
            readonly description: "Título de divulgação do evento.";
        }, {
            readonly fieldId: "description";
            readonly title: "Descrição";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descrição com as informações do evento.";
        }, {
            readonly fieldId: "eventDate";
            readonly title: "Data do evento";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data em que o evento será realizado.";
        }, {
            readonly fieldId: "location";
            readonly title: "Local";
            readonly type: "string";
            readonly required: true;
            readonly description: "Local de realização do evento.";
        }, {
            readonly fieldId: "capacity";
            readonly title: "Número de vagas";
            readonly type: "integer";
            readonly required: true;
            readonly description: "Quantidade de vagas disponíveis para inscrições confirmadas.";
        }, {
            readonly fieldId: "status";
            readonly title: "Status";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "draft";
                readonly title: "Rascunho";
            }, {
                readonly value: "published";
                readonly title: "Publicado";
            }];
            readonly description: "Situação de cadastro e publicação do evento.";
        }];
        readonly details: {
            readonly occupiedSeats: {
                readonly type: "integer";
                readonly description: "Total de vagas ocupadas por inscrições confirmadas no evento.";
            };
            readonly availableSeats: {
                readonly type: "integer";
                readonly description: "Quantidade de vagas ainda disponíveis para inscrições confirmadas no evento.";
            };
        };
        readonly lifecycleStates: [{
            readonly state: "draft";
            readonly reachedBy: "actor";
        }, {
            readonly state: "published";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "publicarEvento";
            readonly from: ["draft"];
            readonly to: "published";
            readonly by: ["organizador"];
            readonly description: "Publica o evento e disponibiliza sua página para inscrições públicas.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type InscricaoEventoEntityEventoType = typeof inscricaoEventoEntityEvento;
    export default inscricaoEventoEntityEvento;
}
declare module "_102047_/l4/inscricaoEvento/ontology/Inscricao.defs" {
    export const inscricaoEventoEntityInscricao: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "inscricaoEvento";
        readonly entityId: "Inscricao";
        readonly title: "Inscrição";
        readonly description: "Registro da participação de uma pessoa em um evento, incluindo sua situação de confirmação, espera ou cancelamento.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "id";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador da inscrição";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da inscrição.";
        }, {
            readonly fieldId: "eventoId";
            readonly title: "Evento";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao evento ao qual a pessoa se inscreveu.";
        }, {
            readonly fieldId: "participanteId";
            readonly title: "Participante";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao participante associado à inscrição.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "confirmed";
                readonly title: "Confirmada";
            }, {
                readonly value: "waitlisted";
                readonly title: "Em lista de espera";
            }, {
                readonly value: "cancelled";
                readonly title: "Cancelada";
            }];
            readonly description: "Situação atual da inscrição no evento.";
        }, {
            readonly fieldId: "registeredAt";
            readonly title: "Data e hora da inscrição";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a inscrição foi registrada, usada para ordenar a lista de espera.";
        }];
        readonly uniqueKeys: [["eventoId", "participanteId"]];
        readonly lifecycleStates: [{
            readonly state: "confirmed";
            readonly reachedBy: "actor";
        }, {
            readonly state: "waitlisted";
            readonly reachedBy: "actor";
        }, {
            readonly state: "cancelled";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "cancelarInscricao";
            readonly from: ["confirmed", "waitlisted"];
            readonly to: "cancelled";
            readonly by: ["publico"];
            readonly description: "Cancela a inscrição do participante no evento.";
        }, {
            readonly transitionId: "promoverListaEspera";
            readonly from: ["waitlisted"];
            readonly to: "confirmed";
            readonly by: "system";
            readonly description: "Promove automaticamente a primeira inscrição da lista de espera quando uma vaga é liberada.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type InscricaoEventoEntityInscricaoType = typeof inscricaoEventoEntityInscricao;
    export default inscricaoEventoEntityInscricao;
}
declare module "_102047_/l4/inscricaoEvento/ontology/Participante.defs" {
    export const inscricaoEventoEntityParticipante: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "inscricaoEvento";
        readonly entityId: "Participante";
        readonly title: "Participante";
        readonly description: "Pessoa inscrita ou em lista de espera para eventos deste módulo.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "inscricaoEvento.Participante";
        };
    };
    export type InscricaoEventoEntityParticipanteType = typeof inscricaoEventoEntityParticipante;
    export default inscricaoEventoEntityParticipante;
}
declare module "_102047_/l4/inscricaoEvento/ontology/index.defs" {
    export const inscricaoEventoOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "inscricaoEvento";
        readonly businessDomain: "Gestão de eventos publicados e inscrições públicas, incluindo lista de espera e cancelamentos.";
        readonly entities: ["Evento", "Inscricao", "Participante"];
        readonly relationships: [{
            readonly relationshipId: "eventoInscricoes";
            readonly fromEntity: "Evento";
            readonly toEntity: "Inscricao";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "Um evento possui as inscrições realizadas para sua participação.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Inscricao";
                readonly from: {
                    readonly entityId: "Evento";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "Inscricao";
                    readonly fieldIds: ["eventoId"];
                };
            };
        }, {
            readonly relationshipId: "participanteInscricoes";
            readonly fromEntity: "Participante";
            readonly toEntity: "Inscricao";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "Um participante pode possuir inscrições em eventos.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Inscricao";
                readonly from: {
                    readonly entityId: "Participante";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "Inscricao";
                    readonly fieldIds: ["participanteId"];
                };
            };
        }];
    };
    export type InscricaoEventoOntologyIndexType = typeof inscricaoEventoOntologyIndex;
    export default inscricaoEventoOntologyIndex;
}
declare module "_102047_/l4/locacaoEquipamentos/access.defs" {
    export const locacaoEquipamentosAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "locacaoEquipamentos";
        readonly actors: [{
            readonly actorId: "atendente";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Atendente";
            readonly description: "Profissional da locadora que cria contratos de locação e registra devoluções.";
        }, {
            readonly actorId: "gerente";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gerente";
            readonly description: "Responsável por acompanhar a disponibilidade, locações e manutenção dos equipamentos.";
        }];
        readonly grants: [{
            readonly grantId: "atendenteGerenciaLocacoes";
            readonly actorRef: "atendente";
            readonly title: "Gerenciar contratos de locação";
            readonly description: "Permite ao atendente localizar clientes e equipamentos, criar contratos e itens de locação, registrar devoluções e consultar os valores calculados da locação.";
            readonly entityRefs: ["Cliente", "Equipamento", "ContratoLocacao", "RentalItem"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os clientes, equipamentos, contratos e itens de locação da locadora.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite consultar todos os campos dos registros necessários para formalizar e encerrar locações.";
            };
        }, {
            readonly grantId: "atendenteConsultaCadastroProprio";
            readonly actorRef: "atendente";
            readonly title: "Consultar cadastro próprio de atendente";
            readonly description: "Permite ao atendente acessar seu próprio vínculo cadastral na locadora.";
            readonly entityRefs: ["Atendente"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Restringe o acesso ao registro de atendente vinculado à pessoa autenticada.";
                readonly anchorEntity: "Atendente";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite consultar integralmente o próprio registro de atendente.";
            };
        }, {
            readonly grantId: "gerenteAcompanhaEquipamentos";
            readonly actorRef: "gerente";
            readonly title: "Acompanhar situação dos equipamentos";
            readonly description: "Permite ao gerente localizar e consultar os equipamentos para acompanhar sua disponibilidade, locação ou manutenção.";
            readonly entityRefs: ["Equipamento"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange todos os equipamentos cadastrados pela locadora.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite consultar todos os dados cadastrais e a situação operacional dos equipamentos.";
            };
        }];
    };
    export type LocacaoEquipamentosAccessType = typeof locacaoEquipamentosAccess;
    export default locacaoEquipamentosAccess;
}
declare module "_102047_/l4/locacaoEquipamentos/integration.defs" {
    export const locacaoEquipamentosIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "registrarDevolucao";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "registrarDevolucao";
            readonly on: "ContratoLocacao.registrarDevolucao";
            readonly description: "Publica o registro de devolução do contrato, incluindo os itens locados, para módulos que precisem atualizar informações relacionadas aos equipamentos.";
            readonly entityRefs: ["ContratoLocacao", "RentalItem"];
        }];
        readonly plugins: [];
    };
    export type LocacaoEquipamentosIntegrationType = typeof locacaoEquipamentosIntegration;
    export default locacaoEquipamentosIntegration;
}
declare module "_102047_/l4/locacaoEquipamentos/module.defs" {
    export const locacaoEquipamentosModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly title: "Locação de Equipamentos";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "locacaoEquipamentos em português. locadora de equipamentos para construção. cada equipamento tem código, descrição, valor da diária e situação. o atendente cria um contrato de locação para um cliente com um ou mais equipamentos e período (data de retirada e data prevista de devolução); o mesmo equipamento não pode estar em dois contratos com períodos sobrepostos. na devolução registra a data real; se atrasou, o sistema calcula a multa (diária × dias de atraso × 1,5). o gerente vê quais equipamentos estão disponíveis, locados ou em manutenção. perfis: atendente e gerente.";
    };
    export type LocacaoEquipamentosModuleType = typeof locacaoEquipamentosModule;
    export default locacaoEquipamentosModule;
}
declare module "_102047_/l4/locacaoEquipamentos/rules.defs" {
    export const locacaoEquipamentosRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "locacaoEquipamentos";
        readonly rules: [{
            readonly ruleId: "equipmentRentalPeriodsMustNotOverlap";
            readonly description: "Um mesmo equipamento não pode constar em contratos de locação com períodos sobrepostos.";
        }, {
            readonly ruleId: "lateFeeCalculation";
            readonly description: "Quando a devolução ocorrer após a data prevista, a multa deve ser calculada como o valor da diária multiplicado pelos dias de atraso e por 1,5.";
        }];
    };
    export type LocacaoEquipamentosRulesType = typeof locacaoEquipamentosRules;
    export default locacaoEquipamentosRules;
}
declare module "_102047_/l4/locacaoEquipamentos/workflows.defs" {
    export const locacaoEquipamentosWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly processes: [];
        readonly journeyDecisions: [{
            readonly journeyId: "criarContratoLocacao";
            readonly inProcess: false;
        }, {
            readonly journeyId: "registrarDevolucao";
            readonly inProcess: false;
        }, {
            readonly journeyId: "acompanharSituacaoEquipamentos";
            readonly inProcess: false;
        }];
    };
    export type LocacaoEquipamentosWorkflowsType = typeof locacaoEquipamentosWorkflows;
    export default locacaoEquipamentosWorkflows;
}
declare module "_102047_/l4/locacaoEquipamentos/journeys/acompanharSituacaoEquipamentos.defs" {
    export const acompanharSituacaoEquipamentosJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharSituacaoEquipamentos";
        readonly business: {
            readonly actorRef: "gerente";
            readonly title: "Acompanhar situação dos equipamentos";
            readonly goal: "Visualizar quais equipamentos estão disponíveis, locados ou em manutenção.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarEquipamentos";
                readonly kind: "locate";
                readonly entity: "Equipamento";
                readonly title: "x";
                readonly description: "Localiza os equipamentos da locadora.";
            }, {
                readonly stepId: "inspecionarSituacoes";
                readonly kind: "inspect";
                readonly entity: "Equipamento";
                readonly title: "x";
                readonly description: "Consulta a situação de cada equipamento, identificando os disponíveis, locados e em manutenção.";
            }];
            readonly outcome: {
                readonly statement: "O gerente obtém a visão da disponibilidade e da situação operacional dos equipamentos.";
                readonly evidence: ["Lista de equipamentos com suas situações de disponível, locado ou em manutenção."];
            };
        };
        readonly businessHash: "sha256:f20dae9a0affca28e1ce7fa922ab9aac67ff30b21c977be9cf2379fe6717fb0a";
    };
    export type AcompanharSituacaoEquipamentosJourneyType = typeof acompanharSituacaoEquipamentosJourney;
    export default acompanharSituacaoEquipamentosJourney;
}
declare module "_102047_/l4/locacaoEquipamentos/journeys/criarContratoLocacao.defs" {
    export const criarContratoLocacaoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "criarContratoLocacao";
        readonly business: {
            readonly actorRef: "atendente";
            readonly title: "Criar contrato de locação";
            readonly goal: "Formalizar a locação de um cliente para um ou mais equipamentos em um período definido.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarCliente";
                readonly kind: "locate";
                readonly entity: "Cliente";
                readonly title: "x";
                readonly description: "Localiza o cliente para quem será feita a locação ou informa seus dados para criação ou vinculação.";
            }, {
                readonly stepId: "consultarEquipamentos";
                readonly kind: "locate";
                readonly entity: "Equipamento";
                readonly title: "x";
                readonly description: "Localiza os equipamentos solicitados para a locação.";
            }, {
                readonly stepId: "verificarEquipamentos";
                readonly kind: "inspect";
                readonly entity: "Equipamento";
                readonly title: "x";
                readonly description: "Confere a situação dos equipamentos e sua disponibilidade para as datas de retirada e devolução prevista.";
            }, {
                readonly stepId: "registrarContrato";
                readonly kind: "act";
                readonly entity: "ContratoLocacao";
                readonly affects: ["Cliente", "Equipamento"];
                readonly effect: "create";
                readonly title: "x";
                readonly description: "Cria o contrato com o cliente, os equipamentos, a data de retirada e a data prevista de devolução.";
            }];
            readonly outcome: {
                readonly statement: "O contrato de locação é registrado para os equipamentos disponíveis no período solicitado.";
                readonly evidence: ["Contrato de locação criado com cliente, equipamentos e período de locação.", "Equipamentos vinculados ao contrato passam a constar como locados para o período registrado."];
            };
        };
        readonly businessHash: "sha256:a8e12be4223a6ab77910233bdd0520e657517fb2a1cc1731da2e415481cd13b9";
    };
    export type CriarContratoLocacaoJourneyType = typeof criarContratoLocacaoJourney;
    export default criarContratoLocacaoJourney;
}
declare module "_102047_/l4/locacaoEquipamentos/journeys/index.defs" {
    export const locacaoEquipamentosJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "locacaoEquipamentos";
        readonly journeys: [{
            readonly journeyId: "criarContratoLocacao";
            readonly actorRef: "atendente";
            readonly title: "Criar contrato de locação";
        }, {
            readonly journeyId: "registrarDevolucao";
            readonly actorRef: "atendente";
            readonly title: "Registrar devolução de equipamentos";
        }, {
            readonly journeyId: "acompanharSituacaoEquipamentos";
            readonly actorRef: "gerente";
            readonly title: "Acompanhar situação dos equipamentos";
        }];
        readonly systemDecisions: [];
    };
    export type LocacaoEquipamentosJourneyIndexType = typeof locacaoEquipamentosJourneyIndex;
    export default locacaoEquipamentosJourneyIndex;
}
declare module "_102047_/l4/locacaoEquipamentos/journeys/registrarDevolucao.defs" {
    export const registrarDevolucaoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarDevolucao";
        readonly business: {
            readonly actorRef: "atendente";
            readonly title: "Registrar devolução de equipamentos";
            readonly goal: "Registrar a devolução efetiva e concluir a locação, incluindo a multa por atraso quando aplicável.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarContrato";
                readonly kind: "locate";
                readonly entity: "ContratoLocacao";
                readonly title: "x";
                readonly description: "Localiza o contrato em aberto, caso ele não esteja previamente em contexto.";
            }, {
                readonly stepId: "conferirContrato";
                readonly kind: "inspect";
                readonly entity: "ContratoLocacao";
                readonly title: "x";
                readonly description: "Confere os equipamentos locados e a data prevista de devolução.";
            }, {
                readonly stepId: "registrarDevolucaoReal";
                readonly kind: "act";
                readonly entity: "ContratoLocacao";
                readonly affects: ["Equipamento"];
                readonly effect: "transition";
                readonly transitionRef: "registrarDevolucao";
                readonly title: "x";
                readonly description: "Registra a data real de devolução, conclui o contrato e torna os equipamentos devolvidos disponíveis conforme sua situação.";
            }, {
                readonly stepId: "consultarMultaCalculada";
                readonly kind: "inspect";
                readonly entity: "ContratoLocacao";
                readonly title: "x";
                readonly description: "Consulta a multa calculada quando a devolução ocorreu após a data prevista.";
            }];
            readonly outcome: {
                readonly statement: "A devolução é registrada e a multa por atraso, quando houver, fica disponível no contrato.";
                readonly evidence: ["Contrato marcado como devolvido com a data real de devolução.", "Multa exibida no contrato quando houver dias de atraso.", "Equipamentos devolvidos deixam de constar como locados."];
            };
        };
        readonly businessHash: "sha256:5c8eceb98d96a9dbf6b273f31fb176d4ac3b2e34a0dc0690192fe52f03cf9a07";
    };
    export type RegistrarDevolucaoJourneyType = typeof registrarDevolucaoJourney;
    export default registrarDevolucaoJourney;
}
declare module "_102047_/l4/locacaoEquipamentos/ontology/Atendente.defs" {
    export const locacaoEquipamentosEntityAtendente: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly entityId: "Atendente";
        readonly title: "Atendente";
        readonly description: "Profissional da locadora responsável pelos contratos que cria e pelas devoluções que registra.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "locacaoEquipamentos.Atendente";
        };
        readonly writer: "crud";
    };
    export type LocacaoEquipamentosEntityAtendenteType = typeof locacaoEquipamentosEntityAtendente;
    export default locacaoEquipamentosEntityAtendente;
}
declare module "_102047_/l4/locacaoEquipamentos/ontology/Cliente.defs" {
    export const locacaoEquipamentosEntityCliente: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly entityId: "Cliente";
        readonly title: "Cliente";
        readonly description: "Pessoa cadastrada como cliente da locadora e vinculada aos seus contratos de locação.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "locacaoEquipamentos.Cliente";
        };
    };
    export type LocacaoEquipamentosEntityClienteType = typeof locacaoEquipamentosEntityCliente;
    export default locacaoEquipamentosEntityCliente;
}
declare module "_102047_/l4/locacaoEquipamentos/ontology/ContratoLocacao.defs" {
    export const locacaoEquipamentosEntityContratoLocacao: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly entityId: "ContratoLocacao";
        readonly title: "Contrato de locação";
        readonly description: "Registro da locação de equipamentos para um cliente, com período previsto e encerramento por devolução.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "contractNumber";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do contrato de locação.";
        }, {
            readonly fieldId: "contractNumber";
            readonly title: "Número do contrato";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número sequencial que identifica o contrato de locação.";
        }, {
            readonly fieldId: "clienteId";
            readonly title: "Cliente";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao cliente titular do contrato de locação.";
        }, {
            readonly fieldId: "atendenteId";
            readonly title: "Atendente responsável";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao atendente responsável pela criação do contrato.";
        }, {
            readonly fieldId: "pickupDate";
            readonly title: "Data de retirada";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data prevista para retirada dos equipamentos locados.";
        }, {
            readonly fieldId: "expectedReturnDate";
            readonly title: "Data prevista de devolução";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data prevista para devolução dos equipamentos.";
        }, {
            readonly fieldId: "actualReturnDate";
            readonly title: "Data real de devolução";
            readonly type: "date";
            readonly required: false;
            readonly description: "Data em que os equipamentos foram efetivamente devolvidos.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação do contrato";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "open";
                readonly title: "Em aberto";
            }, {
                readonly value: "completed";
                readonly title: "Concluído";
            }];
            readonly description: "Situação atual do contrato de locação.";
        }];
        readonly details: {
            readonly lateDays: {
                readonly type: "integer";
                readonly description: "Quantidade de dias de atraso calculada a partir das datas prevista e real de devolução.";
            };
            readonly lateFee: {
                readonly type: "money";
                readonly description: "Multa calculada pela soma das diárias dos itens multiplicada pelos dias de atraso e por 1,5.";
            };
        };
        readonly lifecycleStates: [{
            readonly state: "open";
            readonly reachedBy: "actor";
        }, {
            readonly state: "completed";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "registrarDevolucao";
            readonly from: ["open"];
            readonly to: "completed";
            readonly by: ["atendente"];
            readonly description: "Registra a data real de devolução e conclui o contrato de locação.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type LocacaoEquipamentosEntityContratoLocacaoType = typeof locacaoEquipamentosEntityContratoLocacao;
    export default locacaoEquipamentosEntityContratoLocacao;
}
declare module "_102047_/l4/locacaoEquipamentos/ontology/Equipamento.defs" {
    export const locacaoEquipamentosEntityEquipamento: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly entityId: "Equipamento";
        readonly title: "Equipamento";
        readonly description: "Equipamento de construção disponibilizado para locação, com situação operacional acompanhada pela locadora.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "AssetEquipment";
        readonly displayField: "name";
        readonly fields: [{
            readonly fieldId: "rentalCode";
            readonly title: "Código do equipamento";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly constraints: {
                readonly maxLength: 100;
            };
            readonly description: "Código interno usado pela locadora para identificar o equipamento.";
        }, {
            readonly fieldId: "dailyRate";
            readonly title: "Valor da diária";
            readonly type: "money";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
                readonly precision: 2;
            };
            readonly description: "Valor cobrado por dia de locação do equipamento.";
        }, {
            readonly fieldId: "operationalSituation";
            readonly title: "Situação operacional";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "available";
                readonly title: "Disponível";
            }, {
                readonly value: "rented";
                readonly title: "Locado";
            }, {
                readonly value: "maintenance";
                readonly title: "Em manutenção";
            }];
            readonly description: "Situação operacional atual do equipamento para fins de locação.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "locacaoEquipamentos.Equipamento";
        };
    };
    export type LocacaoEquipamentosEntityEquipamentoType = typeof locacaoEquipamentosEntityEquipamento;
    export default locacaoEquipamentosEntityEquipamento;
}
declare module "_102047_/l4/locacaoEquipamentos/ontology/RentalItem.defs" {
    export const locacaoEquipamentosEntityRentalItem: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly entityId: "RentalItem";
        readonly title: "Item de locação";
        readonly description: "Item de um contrato que identifica o equipamento reservado para o período de locação.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "equipment";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item de locação.";
        }, {
            readonly fieldId: "rentalContract";
            readonly title: "Contrato de locação";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Contrato de locação ao qual este item pertence.";
        }, {
            readonly fieldId: "equipment";
            readonly title: "Equipamento";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Equipamento específico reservado neste item de locação.";
        }, {
            readonly fieldId: "dailyRate";
            readonly title: "Valor da diária contratada";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor diário do equipamento registrado no momento da inclusão no contrato.";
        }];
        readonly uniqueKeys: [["rentalContract", "equipment"]];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type LocacaoEquipamentosEntityRentalItemType = typeof locacaoEquipamentosEntityRentalItem;
    export default locacaoEquipamentosEntityRentalItem;
}
declare module "_102047_/l4/locacaoEquipamentos/ontology/index.defs" {
    export const locacaoEquipamentosOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "locacaoEquipamentos";
        readonly businessDomain: "Locação de equipamentos para construção, incluindo contratos, devoluções e acompanhamento da situação dos equipamentos.";
        readonly entities: ["Cliente", "Equipamento", "Atendente", "ContratoLocacao", "RentalItem"];
        readonly relationships: [{
            readonly relationshipId: "clientHasRentalContracts";
            readonly fromEntity: "Cliente";
            readonly toEntity: "ContratoLocacao";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O cliente é titular dos contratos de locação realizados em seu nome.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ContratoLocacao";
                readonly from: {
                    readonly entityId: "Cliente";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ContratoLocacao";
                    readonly fieldIds: ["clienteId"];
                };
            };
        }, {
            readonly relationshipId: "attendantCreatesRentalContracts";
            readonly fromEntity: "Atendente";
            readonly toEntity: "ContratoLocacao";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O atendente é responsável pelos contratos de locação que cria.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "ContratoLocacao";
                readonly from: {
                    readonly entityId: "Atendente";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "ContratoLocacao";
                    readonly fieldIds: ["atendenteId"];
                };
            };
        }, {
            readonly relationshipId: "rentalContractIncludesItems";
            readonly fromEntity: "ContratoLocacao";
            readonly toEntity: "RentalItem";
            readonly type: "oneToMany";
            readonly required: true;
            readonly description: "O contrato de locação contém um ou mais itens de locação.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "RentalItem";
                readonly from: {
                    readonly entityId: "ContratoLocacao";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "RentalItem";
                    readonly fieldIds: ["rentalContract"];
                };
            };
        }, {
            readonly relationshipId: "rentalItemReservesEquipment";
            readonly fromEntity: "RentalItem";
            readonly toEntity: "Equipamento";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "O item de locação reserva um equipamento específico para o contrato.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "RentalItem";
                readonly from: {
                    readonly entityId: "RentalItem";
                    readonly fieldIds: ["equipment"];
                };
                readonly to: {
                    readonly entityId: "Equipamento";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type LocacaoEquipamentosOntologyIndexType = typeof locacaoEquipamentosOntologyIndex;
    export default locacaoEquipamentosOntologyIndex;
}
declare module "_102047_/l4/manutencaoFrota/access.defs" {
    export const manutencaoFrotaAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "manutencaoFrota";
        readonly actors: [{
            readonly actorId: "motorista";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Motorista";
            readonly description: "Motorista da transportadora que registra abastecimentos dos veículos atribuídos a ele.";
        }, {
            readonly actorId: "gestorFrota";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gestor de frota";
            readonly description: "Responsável pela gestão da frota, pelos planos preventivos e pelas ordens de manutenção.";
        }];
        readonly grants: [{
            readonly grantId: "gestaoCompletaFrota";
            readonly actorRef: "gestorFrota";
            readonly title: "Gestão completa da frota";
            readonly description: "Permite ao gestor cadastrar e consultar os cadastros da frota, planos preventivos, abastecimentos e ordens de manutenção de toda a organização.";
            readonly entityRefs: ["Motorista", "Oficina", "Veiculo", "Abastecimento", "PlanoManutencao", "OrdemManutencao"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Abrange os registros de toda a transportadora.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite acesso a todos os campos dos registros abrangidos pela gestão da frota.";
            };
        }, {
            readonly grantId: "veiculosAtribuidosMotorista";
            readonly actorRef: "motorista";
            readonly title: "Consulta dos veículos atribuídos";
            readonly description: "Permite ao motorista consultar os veículos que estão atribuídos a ele para condução e registro de abastecimento.";
            readonly entityRefs: ["Veiculo"];
            readonly dataScope: {
                readonly mode: "assigned";
                readonly description: "Abrange somente veículos cuja atribuição aponta diretamente para o motorista da sessão.";
                readonly anchorEntity: "Motorista";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite consultar integralmente os dados dos veículos atribuídos ao motorista.";
            };
        }, {
            readonly grantId: "abastecimentosPropriosMotorista";
            readonly actorRef: "motorista";
            readonly title: "Registro dos próprios abastecimentos";
            readonly description: "Permite ao motorista registrar e consultar os abastecimentos realizados por ele nos veículos atribuídos.";
            readonly entityRefs: ["Abastecimento"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Abrange somente abastecimentos vinculados ao motorista da sessão.";
                readonly anchorEntity: "Motorista";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Permite acesso integral aos registros de abastecimento do próprio motorista.";
            };
        }];
    };
    export type ManutencaoFrotaAccessType = typeof manutencaoFrotaAccess;
    export default manutencaoFrotaAccess;
}
declare module "_102047_/l4/manutencaoFrota/integration.defs" {
    export const manutencaoFrotaIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "manutencaoFrota";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "preventivaVencida";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "preventivaVencida";
            readonly on: "Abastecimento.create";
            readonly description: "Publica um aviso para módulos interessados quando o registro de abastecimento indicar que um veículo ultrapassou a quilometragem prevista para a manutenção preventiva.";
            readonly entityRefs: ["Abastecimento", "Veiculo", "PlanoManutencao"];
        }];
        readonly plugins: [];
    };
    export type ManutencaoFrotaIntegrationType = typeof manutencaoFrotaIntegration;
    export default manutencaoFrotaIntegration;
}
declare module "_102047_/l4/manutencaoFrota/module.defs" {
    export const manutencaoFrotaModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "manutencaoFrota";
        readonly title: "Manutenção de Frota";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "manutencaoFrota, português. transportadora com veículos (placa, modelo, ano, quilometragem atual). o motorista registra abastecimentos (data, litros, valor, km no painel) do veículo que dirige e só vê os veículos atribuídos a ele. o gestor de frota cadastra planos de manutenção preventiva por veículo (a cada N km ou a cada N meses) e abre ordens de manutenção quando o plano vence ou quando há defeito; a ordem tem oficina, descrição, custo e datas de entrada e saída. o sistema avisa quando um veículo passou do km previsto para a próxima preventiva. perfis: motorista e gestor.";
    };
    export type ManutencaoFrotaModuleType = typeof manutencaoFrotaModule;
    export default manutencaoFrotaModule;
}
declare module "_102047_/l4/manutencaoFrota/rules.defs" {
    export const manutencaoFrotaRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "manutencaoFrota";
        readonly rules: [{
            readonly ruleId: "atualizarQuilometragemPorAbastecimento";
            readonly description: "Ao registrar um abastecimento, a quilometragem atual do veículo deve ser atualizada para a quilometragem informada no painel.";
        }, {
            readonly ruleId: "exigirCriterioPreventivo";
            readonly description: "Todo plano de manutenção preventiva deve definir um intervalo por quilometragem, por meses ou por ambos.";
        }, {
            readonly ruleId: "calcularProximaQuilometragemPreventiva";
            readonly description: "Quando o plano definir intervalo por quilometragem, a próxima quilometragem prevista deve ser a quilometragem de referência acrescida desse intervalo.";
        }, {
            readonly ruleId: "calcularProximaDataPreventiva";
            readonly description: "Quando o plano definir intervalo por meses, a próxima data prevista deve ser a data de referência acrescida desse intervalo.";
        }, {
            readonly ruleId: "identificarPreventivaVencidaPorQuilometragem";
            readonly description: "A manutenção preventiva deve ser considerada vencida quando a quilometragem atual do veículo ultrapassar a próxima quilometragem prevista do plano.";
        }, {
            readonly ruleId: "avisarPreventivaVencidaPorQuilometragem";
            readonly description: "O sistema deve avisar quando a manutenção preventiva de um veículo for considerada vencida por quilometragem.";
        }];
    };
    export type ManutencaoFrotaRulesType = typeof manutencaoFrotaRules;
    export default manutencaoFrotaRules;
}
declare module "_102047_/l4/manutencaoFrota/workflows.defs" {
    export const manutencaoFrotaWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "manutencaoFrota";
        readonly processes: [{
            readonly processId: "notificarPreventivaVencida";
            readonly title: "Notificar preventiva vencida";
            readonly description: "Verifica planos preventivos vencidos por quilometragem e encaminha a abertura da ordem de manutenção.";
            readonly trigger: {
                readonly kind: "scheduled";
                readonly schedule: "Quando um veículo ultrapassar a quilometragem prevista para a próxima manutenção preventiva.";
            };
            readonly tasks: [{
                readonly taskId: "identificarPlanoVencido";
                readonly kind: "mechanical";
                readonly entityRef: "PlanoManutencao";
                readonly effect: "update";
                readonly next: ["abrirOrdemPreventiva"];
                readonly description: "Identifica o plano preventivo cuja quilometragem prevista foi ultrapassada e registra o aviso ao gestor de frota.";
            }, {
                readonly taskId: "abrirOrdemPreventiva";
                readonly kind: "human";
                readonly actorRef: "gestorFrota";
                readonly journeyRef: "abrirOrdemPorPreventivaVencida";
                readonly next: [];
                readonly description: "O gestor de frota analisa o aviso e abre a ordem de manutenção preventiva para o veículo.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "cadastrarVeiculo";
            readonly inProcess: false;
        }, {
            readonly journeyId: "registrarAbastecimento";
            readonly inProcess: false;
        }, {
            readonly journeyId: "cadastrarPlanoPreventivo";
            readonly inProcess: false;
        }, {
            readonly journeyId: "abrirOrdemPorPreventivaVencida";
            readonly inProcess: true;
            readonly processId: "notificarPreventivaVencida";
        }, {
            readonly journeyId: "abrirOrdemPorDefeito";
            readonly inProcess: false;
        }, {
            readonly journeyId: "registrarConclusaoManutencao";
            readonly inProcess: false;
        }];
    };
    export type ManutencaoFrotaWorkflowsType = typeof manutencaoFrotaWorkflows;
    export default manutencaoFrotaWorkflows;
}
declare module "_102047_/l4/manutencaoFrota/journeys/abrirOrdemPorDefeito.defs" {
    export const abrirOrdemPorDefeitoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "abrirOrdemPorDefeito";
        readonly business: {
            readonly actorRef: "gestorFrota";
            readonly title: "Abrir ordem por defeito";
            readonly goal: "Registrar o encaminhamento de um veículo com defeito para manutenção.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarVeiculoComDefeito";
                readonly kind: "locate";
                readonly entity: "Veiculo";
                readonly title: "Localizar veículo com defeito";
                readonly description: "Localiza o veículo que apresentou defeito.";
            }, {
                readonly stepId: "inspecionarVeiculoComDefeito";
                readonly kind: "inspect";
                readonly entity: "Veiculo";
                readonly title: "Conferir veículo";
                readonly description: "Confere a identificação e a quilometragem do veículo antes da abertura da ordem.";
            }, {
                readonly stepId: "abrirOrdemCorretiva";
                readonly kind: "act";
                readonly entity: "OrdemManutencao";
                readonly effect: "create";
                readonly title: "Abrir ordem de manutenção corretiva";
                readonly description: "Registra a oficina, a descrição do defeito ou serviço e a data de entrada.";
            }];
            readonly outcome: {
                readonly statement: "Uma ordem de manutenção é aberta para tratar o defeito informado.";
                readonly evidence: ["Ordem vinculada ao veículo com oficina, descrição e data de entrada.", "Registro da manutenção identificado como decorrente de defeito."];
            };
        };
        readonly businessHash: "sha256:e93874ab548268f7476f982a0d0d16fd575cd0630807d586d4ae860e07b1e08a";
    };
    export type AbrirOrdemPorDefeitoJourneyType = typeof abrirOrdemPorDefeitoJourney;
    export default abrirOrdemPorDefeitoJourney;
}
declare module "_102047_/l4/manutencaoFrota/journeys/abrirOrdemPorPreventivaVencida.defs" {
    export const abrirOrdemPorPreventivaVencidaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "abrirOrdemPorPreventivaVencida";
        readonly business: {
            readonly actorRef: "gestorFrota";
            readonly title: "Abrir ordem para preventiva vencida";
            readonly goal: "Encaminhar um veículo para manutenção ao receber o aviso de preventiva vencida.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "inspecionarPlanoAvisado";
                readonly kind: "inspect";
                readonly entity: "PlanoManutencao";
                readonly title: "Consultar plano avisado";
                readonly description: "Verifica o plano cuja quilometragem prevista para a preventiva foi ultrapassada.";
            }, {
                readonly stepId: "inspecionarVeiculo";
                readonly kind: "inspect";
                readonly entity: "Veiculo";
                readonly title: "Consultar veículo";
                readonly description: "Confere o veículo e sua quilometragem atual antes de encaminhá-lo à manutenção.";
            }, {
                readonly stepId: "abrirOrdemPreventiva";
                readonly kind: "act";
                readonly entity: "OrdemManutencao";
                readonly effect: "create";
                readonly title: "Abrir ordem de manutenção preventiva";
                readonly description: "Registra a oficina, a descrição do serviço e a data de entrada do veículo.";
            }];
            readonly outcome: {
                readonly statement: "Uma ordem de manutenção preventiva é aberta para o veículo avisado.";
                readonly evidence: ["Ordem vinculada ao veículo e ao plano preventivo vencido.", "Ordem com oficina, descrição e data de entrada registradas."];
            };
        };
        readonly businessHash: "sha256:123797b5034fd54ac2eead98bf75c1e1f2207abe1c71502c6c81c3073c579124";
    };
    export type AbrirOrdemPorPreventivaVencidaJourneyType = typeof abrirOrdemPorPreventivaVencidaJourney;
    export default abrirOrdemPorPreventivaVencidaJourney;
}
declare module "_102047_/l4/manutencaoFrota/journeys/cadastrarPlanoPreventivo.defs" {
    export const cadastrarPlanoPreventivoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarPlanoPreventivo";
        readonly business: {
            readonly actorRef: "gestorFrota";
            readonly title: "Cadastrar plano de manutenção preventiva";
            readonly goal: "Definir quando a manutenção preventiva de um veículo deve ser realizada.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarVeiculo";
                readonly kind: "locate";
                readonly entity: "Veiculo";
                readonly title: "Localizar veículo";
                readonly description: "Localiza o veículo que receberá o plano preventivo.";
            }, {
                readonly stepId: "inspecionarDadosVeiculo";
                readonly kind: "inspect";
                readonly entity: "Veiculo";
                readonly title: "Conferir dados do veículo";
                readonly description: "Confere a identificação e a quilometragem atual do veículo.";
            }, {
                readonly stepId: "registrarPlanoPreventivo";
                readonly kind: "act";
                readonly entity: "PlanoManutencao";
                readonly effect: "create";
                readonly title: "Registrar plano preventivo";
                readonly description: "Define o intervalo da preventiva por quilometragem, por meses ou pelos dois critérios.";
            }];
            readonly outcome: {
                readonly statement: "O veículo passa a ter um plano de manutenção preventiva acompanhado pela frota.";
                readonly evidence: ["Plano vinculado ao veículo com intervalo em quilômetros e/ou meses.", "Próxima preventiva calculada a partir dos critérios registrados."];
            };
        };
        readonly businessHash: "sha256:417d8c129b6a0c3a8b42c45023031852431d8f0f83d04bfd867a7c6d45ab4a02";
    };
    export type CadastrarPlanoPreventivoJourneyType = typeof cadastrarPlanoPreventivoJourney;
    export default cadastrarPlanoPreventivoJourney;
}
declare module "_102047_/l4/manutencaoFrota/journeys/cadastrarVeiculo.defs" {
    export const cadastrarVeiculoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarVeiculo";
        readonly business: {
            readonly actorRef: "gestorFrota";
            readonly title: "Cadastrar veículo na frota";
            readonly goal: "Disponibilizar um veículo identificado para atribuição e gestão de manutenção.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "registrarVeiculo";
                readonly kind: "act";
                readonly entity: "Veiculo";
                readonly effect: "create";
                readonly title: "Registrar os dados do veículo";
                readonly description: "Informa placa, modelo, ano e quilometragem atual do veículo.";
            }];
            readonly outcome: {
                readonly statement: "O veículo fica cadastrado para uso na gestão da frota.";
                readonly evidence: ["Veículo identificado pela placa e com modelo, ano e quilometragem atual registrados."];
            };
        };
        readonly businessHash: "sha256:27547deac1d2b1613364af5297f759260647b9148c526940c525dc7c64bbfe90";
    };
    export type CadastrarVeiculoJourneyType = typeof cadastrarVeiculoJourney;
    export default cadastrarVeiculoJourney;
}
declare module "_102047_/l4/manutencaoFrota/journeys/index.defs" {
    export const manutencaoFrotaJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "manutencaoFrota";
        readonly journeys: [{
            readonly journeyId: "cadastrarVeiculo";
            readonly actorRef: "gestorFrota";
            readonly title: "Cadastrar veículo na frota";
        }, {
            readonly journeyId: "registrarAbastecimento";
            readonly actorRef: "motorista";
            readonly title: "Registrar abastecimento do veículo atribuído";
        }, {
            readonly journeyId: "cadastrarPlanoPreventivo";
            readonly actorRef: "gestorFrota";
            readonly title: "Cadastrar plano de manutenção preventiva";
        }, {
            readonly journeyId: "abrirOrdemPorPreventivaVencida";
            readonly actorRef: "gestorFrota";
            readonly title: "Abrir ordem para preventiva vencida";
        }, {
            readonly journeyId: "abrirOrdemPorDefeito";
            readonly actorRef: "gestorFrota";
            readonly title: "Abrir ordem por defeito";
        }, {
            readonly journeyId: "registrarConclusaoManutencao";
            readonly actorRef: "gestorFrota";
            readonly title: "Registrar conclusão de manutenção";
        }];
        readonly systemDecisions: [];
    };
    export type ManutencaoFrotaJourneyIndexType = typeof manutencaoFrotaJourneyIndex;
    export default manutencaoFrotaJourneyIndex;
}
declare module "_102047_/l4/manutencaoFrota/journeys/registrarAbastecimento.defs" {
    export const registrarAbastecimentoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarAbastecimento";
        readonly business: {
            readonly actorRef: "motorista";
            readonly title: "Registrar abastecimento do veículo atribuído";
            readonly goal: "Registrar o consumo e atualizar a quilometragem do veículo que dirige.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarVeiculoAtribuido";
                readonly kind: "locate";
                readonly entity: "Veiculo";
                readonly title: "Localizar veículo atribuído";
                readonly description: "Localiza um dos veículos atribuídos ao motorista.";
            }, {
                readonly stepId: "inspecionarQuilometragem";
                readonly kind: "inspect";
                readonly entity: "Veiculo";
                readonly title: "Conferir veículo e quilometragem";
                readonly description: "Confere a identificação do veículo e a quilometragem atualmente registrada.";
            }, {
                readonly stepId: "registrarAbastecimento";
                readonly kind: "act";
                readonly entity: "Abastecimento";
                readonly affects: ["Veiculo"];
                readonly effect: "create";
                readonly title: "Registrar abastecimento";
                readonly description: "Informa data, litros, valor e quilometragem exibida no painel.";
            }];
            readonly outcome: {
                readonly statement: "O abastecimento é registrado no veículo atribuído e sua quilometragem é atualizada.";
                readonly evidence: ["Registro de abastecimento com data, litros, valor e km no painel.", "Quilometragem atual do veículo compatível com o km informado no abastecimento."];
            };
        };
        readonly businessHash: "sha256:50a0c44f47c60636fe0700cd669154b6b1fc02de0109a7da7a9ba4be7a19ff8d";
    };
    export type RegistrarAbastecimentoJourneyType = typeof registrarAbastecimentoJourney;
    export default registrarAbastecimentoJourney;
}
declare module "_102047_/l4/manutencaoFrota/journeys/registrarConclusaoManutencao.defs" {
    export const registrarConclusaoManutencaoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarConclusaoManutencao";
        readonly business: {
            readonly actorRef: "gestorFrota";
            readonly title: "Registrar conclusão de manutenção";
            readonly goal: "Completar os dados de uma ordem após o serviço realizado.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdemAberta";
                readonly kind: "locate";
                readonly entity: "OrdemManutencao";
                readonly title: "Localizar ordem de manutenção";
                readonly description: "Localiza a ordem referente ao serviço concluído.";
            }, {
                readonly stepId: "inspecionarOrdem";
                readonly kind: "inspect";
                readonly entity: "OrdemManutencao";
                readonly title: "Conferir ordem";
                readonly description: "Confere o veículo, a oficina, a descrição e os dados já registrados na ordem.";
            }, {
                readonly stepId: "registrarDadosConclusao";
                readonly kind: "act";
                readonly entity: "OrdemManutencao";
                readonly effect: "update";
                readonly title: "Registrar conclusão do serviço";
                readonly description: "Informa o custo e a data de saída do veículo da oficina.";
            }];
            readonly outcome: {
                readonly statement: "A ordem passa a registrar os dados finais da manutenção realizada.";
                readonly evidence: ["Ordem com custo e data de saída preenchidos.", "Histórico da ordem preserva oficina, descrição e período de manutenção."];
            };
        };
        readonly businessHash: "sha256:6a9051cd7b43e6a77a30102eb4779c4b7cb30457210a98a916fbf6677995ecfb";
    };
    export type RegistrarConclusaoManutencaoJourneyType = typeof registrarConclusaoManutencaoJourney;
    export default registrarConclusaoManutencaoJourney;
}
declare module "_102047_/l4/manutencaoFrota/ontology/Abastecimento.defs" {
    export const manutencaoFrotaEntityAbastecimento: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly entityId: "Abastecimento";
        readonly title: "Abastecimento";
        readonly description: "Registro do abastecimento realizado em um veículo por um motorista.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "data";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do registro de abastecimento.";
        }, {
            readonly fieldId: "data";
            readonly title: "Data do abastecimento";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data em que o abastecimento foi realizado.";
        }, {
            readonly fieldId: "litros";
            readonly title: "Litros abastecidos";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade de litros abastecidos no veículo.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor do abastecimento";
            readonly type: "money";
            readonly required: true;
            readonly constraints: {
                readonly precision: 2;
            };
            readonly description: "Valor total pago pelo abastecimento.";
        }, {
            readonly fieldId: "quilometragemPainel";
            readonly title: "Quilometragem no painel";
            readonly type: "integer";
            readonly required: true;
            readonly description: "Quilometragem exibida no painel do veículo no momento do abastecimento.";
        }, {
            readonly fieldId: "veiculoId";
            readonly title: "Veículo";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao veículo da frota que recebeu o abastecimento.";
        }, {
            readonly fieldId: "motoristaId";
            readonly title: "Motorista";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao motorista que registrou o abastecimento.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ManutencaoFrotaEntityAbastecimentoType = typeof manutencaoFrotaEntityAbastecimento;
    export default manutencaoFrotaEntityAbastecimento;
}
declare module "_102047_/l4/manutencaoFrota/ontology/Motorista.defs" {
    export const manutencaoFrotaEntityMotorista: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly entityId: "Motorista";
        readonly title: "Motorista";
        readonly description: "Papel de motorista da transportadora, usado para registrar quem realizou abastecimentos e quais veículos lhe estão atribuídos.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "manutencaoFrota.Motorista";
        };
        readonly writer: "crud";
    };
    export type ManutencaoFrotaEntityMotoristaType = typeof manutencaoFrotaEntityMotorista;
    export default manutencaoFrotaEntityMotorista;
}
declare module "_102047_/l4/manutencaoFrota/ontology/Oficina.defs" {
    export const manutencaoFrotaEntityOficina: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly entityId: "Oficina";
        readonly title: "Oficina";
        readonly description: "Empresa prestadora de serviços de manutenção utilizada nas ordens de manutenção.";
        readonly kind: "mdm";
        readonly party: "organization";
        readonly mdmSubtype: "Company";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "manutencaoFrota.Oficina";
        };
        readonly writer: "crud";
    };
    export type ManutencaoFrotaEntityOficinaType = typeof manutencaoFrotaEntityOficina;
    export default manutencaoFrotaEntityOficina;
}
declare module "_102047_/l4/manutencaoFrota/ontology/OrdemManutencao.defs" {
    export const manutencaoFrotaEntityOrdemManutencao: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly entityId: "OrdemManutencao";
        readonly title: "Ordem de manutenção";
        readonly description: "Registro do encaminhamento de um veículo para manutenção preventiva ou corretiva e da conclusão do serviço.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "descricao";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da ordem de manutenção.";
        }, {
            readonly fieldId: "veiculoId";
            readonly title: "Veículo";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao veículo encaminhado para manutenção.";
        }, {
            readonly fieldId: "planoManutencaoId";
            readonly title: "Plano de manutenção";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao plano preventivo que motivou a abertura da ordem, quando aplicável.";
        }, {
            readonly fieldId: "oficinaId";
            readonly title: "Oficina";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à oficina responsável pela execução do serviço.";
        }, {
            readonly fieldId: "descricao";
            readonly title: "Descrição";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descrição do defeito identificado ou do serviço de manutenção solicitado.";
        }, {
            readonly fieldId: "dataEntrada";
            readonly title: "Data de entrada";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data em que o veículo foi encaminhado à oficina.";
        }, {
            readonly fieldId: "custo";
            readonly title: "Custo";
            readonly type: "money";
            readonly required: false;
            readonly description: "Custo informado para o serviço de manutenção concluído.";
        }, {
            readonly fieldId: "dataSaida";
            readonly title: "Data de saída";
            readonly type: "date";
            readonly required: false;
            readonly description: "Data em que o veículo foi liberado pela oficina.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ManutencaoFrotaEntityOrdemManutencaoType = typeof manutencaoFrotaEntityOrdemManutencao;
    export default manutencaoFrotaEntityOrdemManutencao;
}
declare module "_102047_/l4/manutencaoFrota/ontology/PlanoManutencao.defs" {
    export const manutencaoFrotaEntityPlanoManutencao: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly entityId: "PlanoManutencao";
        readonly title: "Plano de manutenção";
        readonly description: "Definição da periodicidade de manutenção preventiva de um veículo por quilometragem, meses ou ambos.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "id";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do plano de manutenção preventiva.";
        }, {
            readonly fieldId: "veiculoId";
            readonly title: "Veículo";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao veículo ao qual este plano preventivo se aplica.";
        }, {
            readonly fieldId: "intervaloQuilometragem";
            readonly title: "Intervalo em quilômetros";
            readonly type: "integer";
            readonly required: false;
            readonly constraints: {
                readonly min: 1;
            };
            readonly description: "Quantidade de quilômetros entre as manutenções preventivas quando o critério por quilometragem for utilizado.";
        }, {
            readonly fieldId: "intervaloMeses";
            readonly title: "Intervalo em meses";
            readonly type: "integer";
            readonly required: false;
            readonly constraints: {
                readonly min: 1;
            };
            readonly description: "Quantidade de meses entre as manutenções preventivas quando o critério por tempo for utilizado.";
        }, {
            readonly fieldId: "quilometragemReferencia";
            readonly title: "Quilometragem de referência";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
            };
            readonly description: "Quilometragem do veículo usada como base para calcular a próxima preventiva por distância.";
        }, {
            readonly fieldId: "dataReferencia";
            readonly title: "Data de referência";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data usada como base para calcular a próxima preventiva por tempo.";
        }];
        readonly details: {
            readonly proximaQuilometragemPrevista: {
                readonly type: "integer";
                readonly description: "Quilometragem calculada em que a próxima manutenção preventiva deve ser realizada.";
            };
            readonly proximaDataPrevista: {
                readonly type: "date";
                readonly description: "Data calculada em que a próxima manutenção preventiva deve ser realizada pelo critério de tempo.";
            };
            readonly preventivaVencida: {
                readonly type: "boolean";
                readonly description: "Indica se a quilometragem atual do veículo já ultrapassou a quilometragem prevista para a preventiva.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type ManutencaoFrotaEntityPlanoManutencaoType = typeof manutencaoFrotaEntityPlanoManutencao;
    export default manutencaoFrotaEntityPlanoManutencao;
}
declare module "_102047_/l4/manutencaoFrota/ontology/Veiculo.defs" {
    export const manutencaoFrotaEntityVeiculo: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly entityId: "Veiculo";
        readonly title: "Veículo";
        readonly description: "Veículo da frota identificado e acompanhado para abastecimentos e manutenções.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "AssetVehicle";
        readonly displayField: "plate";
        readonly fields: [{
            readonly fieldId: "currentMileage";
            readonly title: "Quilometragem atual";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
            };
            readonly description: "Quilometragem atualmente registrada para o veículo.";
        }, {
            readonly fieldId: "motoristaId";
            readonly title: "Motorista atribuído";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao motorista atualmente atribuído para conduzir o veículo.";
        }];
        readonly details: {
            readonly preventiveMaintenanceOverdue: {
                readonly type: "boolean";
                readonly description: "Indica se algum plano preventivo do veículo ultrapassou a quilometragem prevista para manutenção.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "manutencaoFrota.Veiculo";
        };
    };
    export type ManutencaoFrotaEntityVeiculoType = typeof manutencaoFrotaEntityVeiculo;
    export default manutencaoFrotaEntityVeiculo;
}
declare module "_102047_/l4/manutencaoFrota/ontology/index.defs" {
    export const manutencaoFrotaOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "manutencaoFrota";
        readonly businessDomain: "Gestão de abastecimentos, manutenção preventiva e ordens de manutenção da frota de uma transportadora.";
        readonly entities: ["Abastecimento", "Motorista", "Oficina", "Veiculo", "PlanoManutencao", "OrdemManutencao"];
        readonly relationships: [{
            readonly relationshipId: "veiculoMotoristaAtribuido";
            readonly fromEntity: "Veiculo";
            readonly toEntity: "Motorista";
            readonly type: "manyToOne";
            readonly required: false;
            readonly description: "O veículo pode estar atribuído a um motorista responsável por conduzi-lo.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Veiculo";
                readonly from: {
                    readonly entityId: "Veiculo";
                    readonly fieldIds: ["motoristaId"];
                };
                readonly to: {
                    readonly entityId: "Motorista";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "abastecimentoVeiculo";
            readonly fromEntity: "Abastecimento";
            readonly toEntity: "Veiculo";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "O abastecimento é registrado para um veículo da frota.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Abastecimento";
                readonly from: {
                    readonly entityId: "Abastecimento";
                    readonly fieldIds: ["veiculoId"];
                };
                readonly to: {
                    readonly entityId: "Veiculo";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "abastecimentoMotorista";
            readonly fromEntity: "Abastecimento";
            readonly toEntity: "Motorista";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "O abastecimento é registrado pelo motorista que realizou o lançamento.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Abastecimento";
                readonly from: {
                    readonly entityId: "Abastecimento";
                    readonly fieldIds: ["motoristaId"];
                };
                readonly to: {
                    readonly entityId: "Motorista";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "planoManutencaoVeiculo";
            readonly fromEntity: "PlanoManutencao";
            readonly toEntity: "Veiculo";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "O plano preventivo define a manutenção de um veículo específico.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "PlanoManutencao";
                readonly from: {
                    readonly entityId: "PlanoManutencao";
                    readonly fieldIds: ["veiculoId"];
                };
                readonly to: {
                    readonly entityId: "Veiculo";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordemManutencaoVeiculo";
            readonly fromEntity: "OrdemManutencao";
            readonly toEntity: "Veiculo";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "A ordem de manutenção encaminha um veículo para serviço.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdemManutencao";
                readonly from: {
                    readonly entityId: "OrdemManutencao";
                    readonly fieldIds: ["veiculoId"];
                };
                readonly to: {
                    readonly entityId: "Veiculo";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordemManutencaoPlano";
            readonly fromEntity: "OrdemManutencao";
            readonly toEntity: "PlanoManutencao";
            readonly type: "manyToOne";
            readonly required: false;
            readonly description: "A ordem pode ser aberta em decorrência do vencimento de um plano preventivo.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdemManutencao";
                readonly from: {
                    readonly entityId: "OrdemManutencao";
                    readonly fieldIds: ["planoManutencaoId"];
                };
                readonly to: {
                    readonly entityId: "PlanoManutencao";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "ordemManutencaoOficina";
            readonly fromEntity: "OrdemManutencao";
            readonly toEntity: "Oficina";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "A ordem de manutenção é executada por uma oficina.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdemManutencao";
                readonly from: {
                    readonly entityId: "OrdemManutencao";
                    readonly fieldIds: ["oficinaId"];
                };
                readonly to: {
                    readonly entityId: "Oficina";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type ManutencaoFrotaOntologyIndexType = typeof manutencaoFrotaOntologyIndex;
    export default manutencaoFrotaOntologyIndex;
}
declare module "_102047_/l4/mensalidadesAcademia/access.defs" {
    export const mensalidadesAcademiaAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "mensalidadesAcademia";
        readonly actors: [{
            readonly actorId: "recepcao";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Recepção";
            readonly description: "Profissional da academia que matricula alunos em planos e registra pagamentos de mensalidades.";
        }, {
            readonly actorId: "gerencia";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gerência";
            readonly description: "Profissional da academia que gera mensalidades mensais e acompanha indicadores financeiros e de alunos.";
        }, {
            readonly actorId: "aluno";
            readonly kind: "external";
            readonly origin: "inferred";
            readonly title: "Aluno";
            readonly description: "Pessoa matriculada na academia que pode cancelar a própria matrícula.";
        }];
        readonly grants: [{
            readonly grantId: "gerenciaPlanosEmensalidades";
            readonly actorRef: "gerencia";
            readonly title: "Gerenciar planos e mensalidades";
            readonly description: "Permite cadastrar e atualizar planos, gerar mensalidades e acompanhar as cobranças e indicadores da academia.";
            readonly entityRefs: ["Plano", "Matricula", "Mensalidade"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "A gerência acessa os planos, matrículas e mensalidades de toda a academia.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "A gerência visualiza todos os dados dos planos, matrículas e mensalidades necessários à gestão financeira.";
            };
        }, {
            readonly grantId: "recepcaoMatriculasEpagamentos";
            readonly actorRef: "recepcao";
            readonly title: "Registrar matrículas e pagamentos";
            readonly description: "Permite cadastrar ou vincular alunos, realizar matrículas e consultar mensalidades para registrar seus pagamentos.";
            readonly entityRefs: ["Aluno", "Plano", "Matricula", "Mensalidade", "Pagamento"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "A recepção acessa os cadastros, planos, matrículas, mensalidades e pagamentos de toda a academia para atendimento.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "A recepção visualiza todos os dados necessários para matricular alunos e registrar pagamentos.";
            };
        }, {
            readonly grantId: "alunoCancelarPropriaMatricula";
            readonly actorRef: "aluno";
            readonly title: "Consultar e cancelar minha matrícula";
            readonly description: "Permite ao aluno consultar e encerrar exclusivamente a própria matrícula ativa.";
            readonly entityRefs: ["Matricula"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "O aluno acessa somente matrículas vinculadas ao seu próprio cadastro de aluno autenticado.";
                readonly anchorEntity: "Aluno";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "O aluno visualiza todos os dados da própria matrícula necessários para consultar sua vigência e solicitar o cancelamento.";
            };
        }];
    };
    export type MensalidadesAcademiaAccessType = typeof mensalidadesAcademiaAccess;
    export default mensalidadesAcademiaAccess;
}
declare module "_102047_/l4/mensalidadesAcademia/integration.defs" {
    export const mensalidadesAcademiaIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "matriculaCancelada";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "matriculaCancelada";
            readonly on: "Matricula.cancelarMatricula";
            readonly description: "Informa a outros módulos que a matrícula do aluno foi cancelada, encerrando a geração de mensalidades futuras.";
            readonly entityRefs: ["Matricula"];
        }];
        readonly plugins: [];
    };
    export type MensalidadesAcademiaIntegrationType = typeof mensalidadesAcademiaIntegration;
    export default mensalidadesAcademiaIntegration;
}
declare module "_102047_/l4/mensalidadesAcademia/module.defs" {
    export const mensalidadesAcademiaModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly title: "Mensalidades da Academia";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "criar mensalidadesAcademia em português. academia com alunos e planos (mensal, trimestral, anual, com valor e dia de vencimento). a recepção matricula o aluno em um plano a partir de uma data. todo mês a gerência gera as mensalidades do mês para todos os alunos ativos, uma por aluno, com valor do plano e vencimento. a recepção registra pagamentos (data, valor, forma). mensalidade não paga após o vencimento fica vencida; aluno com duas mensalidades vencidas fica bloqueado e não pode entrar até regularizar. a gerência vê um painel com total a receber no mês, total recebido, quantidade de alunos ativos, bloqueados e inadimplentes. o aluno pode cancelar a matrícula, o que encerra a geração de mensalidades futuras. perfis: recepção e gerência.";
        readonly details: {
            readonly totalAreceberNoMes: {
                readonly type: "money";
                readonly description: "Total das mensalidades a receber no mês consultado.";
            };
            readonly totalRecebidoNoMes: {
                readonly type: "money";
                readonly description: "Total de pagamentos recebidos no mês consultado.";
            };
            readonly quantidadeAlunosAtivos: {
                readonly type: "integer";
                readonly description: "Quantidade de alunos com matrícula ativa no período.";
            };
            readonly quantidadeAlunosBloqueados: {
                readonly type: "integer";
                readonly description: "Quantidade de alunos bloqueados por duas mensalidades vencidas.";
            };
            readonly quantidadeAlunosInadimplentes: {
                readonly type: "integer";
                readonly description: "Quantidade de alunos com ao menos uma mensalidade vencida.";
            };
        };
    };
    export type MensalidadesAcademiaModuleType = typeof mensalidadesAcademiaModule;
    export default mensalidadesAcademiaModule;
}
declare module "_102047_/l4/mensalidadesAcademia/rules.defs" {
    export const mensalidadesAcademiaRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "mensalidadesAcademia";
        readonly rules: [{
            readonly ruleId: "modalidadePlanoPermitida";
            readonly description: "A modalidade de um plano deve ser mensal, trimestral ou anual.";
        }, {
            readonly ruleId: "gerarMensalidadeParaMatriculaAtiva";
            readonly description: "Em cada mês, deve ser gerada uma mensalidade para cada aluno com matrícula ativa.";
        }, {
            readonly ruleId: "unicidadeMensalidadePorAlunoEmes";
            readonly description: "Um aluno pode ter no máximo uma mensalidade gerada para cada mês de referência.";
        }, {
            readonly ruleId: "valorMensalidadeConformePlano";
            readonly description: "O valor devido de uma mensalidade deve corresponder ao valor do plano da matrícula no momento de sua geração.";
        }, {
            readonly ruleId: "vencimentoMensalidadeConformePlano";
            readonly description: "A data de vencimento de uma mensalidade deve corresponder ao dia de vencimento do plano da matrícula no mês de referência.";
        }, {
            readonly ruleId: "mensalidadeEmAtrasoFicaVencida";
            readonly description: "Uma mensalidade não paga após sua data de vencimento deve ficar vencida.";
        }, {
            readonly ruleId: "bloqueioPorDuasMensalidadesVencidas";
            readonly description: "O aluno com duas ou mais mensalidades vencidas deve permanecer bloqueado para entrada até regularizar sua situação.";
        }, {
            readonly ruleId: "cancelamentoImpedeCobrancasFuturas";
            readonly description: "O cancelamento da matrícula deve impedir a geração de mensalidades para períodos futuros.";
        }, {
            readonly ruleId: "totalAreceberMensal";
            readonly description: "O total a receber no mês deve ser a soma dos saldos em aberto das mensalidades do período.";
        }, {
            readonly ruleId: "totalRecebidoMensal";
            readonly description: "O total recebido no mês deve ser a soma dos valores dos pagamentos registrados para as mensalidades do período.";
        }, {
            readonly ruleId: "quantidadeAlunosAtivos";
            readonly description: "A quantidade de alunos ativos deve corresponder ao número de alunos com matrícula ativa no período.";
        }, {
            readonly ruleId: "quantidadeAlunosBloqueados";
            readonly description: "A quantidade de alunos bloqueados deve corresponder ao número de alunos com duas ou mais mensalidades vencidas.";
        }, {
            readonly ruleId: "quantidadeAlunosInadimplentes";
            readonly description: "A quantidade de alunos inadimplentes deve corresponder ao número de alunos com pelo menos uma mensalidade vencida.";
        }];
    };
    export type MensalidadesAcademiaRulesType = typeof mensalidadesAcademiaRules;
    export default mensalidadesAcademiaRules;
}
declare module "_102047_/l4/mensalidadesAcademia/workflows.defs" {
    export const mensalidadesAcademiaWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly processes: [];
        readonly journeyDecisions: [{
            readonly journeyId: "cadastrarPlano";
            readonly inProcess: false;
        }, {
            readonly journeyId: "atualizarPlano";
            readonly inProcess: false;
        }, {
            readonly journeyId: "matricularAluno";
            readonly inProcess: false;
        }, {
            readonly journeyId: "gerarMensalidadesDoMes";
            readonly inProcess: false;
        }, {
            readonly journeyId: "registrarPagamentoMensalidade";
            readonly inProcess: false;
        }, {
            readonly journeyId: "acompanharPainelMensal";
            readonly inProcess: false;
        }, {
            readonly journeyId: "cancelarPropriaMatricula";
            readonly inProcess: false;
        }];
    };
    export type MensalidadesAcademiaWorkflowsType = typeof mensalidadesAcademiaWorkflows;
    export default mensalidadesAcademiaWorkflows;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/acompanharPainelMensal.defs" {
    export const acompanharPainelMensalJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharPainelMensal";
        readonly business: {
            readonly actorRef: "gerencia";
            readonly title: "Acompanhar painel mensal";
            readonly goal: "Visualizar os indicadores financeiros e a situação dos alunos no período.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarMensalidadesDoPeriodo";
                readonly kind: "locate";
                readonly entity: "Mensalidade";
                readonly title: "Selecionar o período do acompanhamento.";
                readonly description: "Localiza as mensalidades que compõem os indicadores do mês.";
            }, {
                readonly stepId: "inspecionarIndicadoresMensais";
                readonly kind: "inspect";
                readonly entity: "Mensalidade";
                readonly title: "Consultar os indicadores mensais.";
                readonly description: "Visualiza total a receber, total recebido e as quantidades de alunos ativos, bloqueados e inadimplentes.";
            }];
            readonly outcome: {
                readonly statement: "A gerência acompanha a posição financeira mensal e a situação dos alunos.";
                readonly evidence: ["O painel mostra o total a receber e o total recebido no mês.", "O painel mostra as quantidades de alunos ativos, bloqueados e inadimplentes."];
            };
        };
        readonly businessHash: "sha256:f9b4a2236e888151d79cbf36f579d54667335a98842128b28f2fdcfee51fe1f3";
    };
    export type AcompanharPainelMensalJourneyType = typeof acompanharPainelMensalJourney;
    export default acompanharPainelMensalJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/atualizarPlano.defs" {
    export const atualizarPlanoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "atualizarPlano";
        readonly business: {
            readonly actorRef: "gerencia";
            readonly title: "Atualizar condições de um plano";
            readonly goal: "Manter o valor e o dia de vencimento de um plano de academia atualizados.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarPlano";
                readonly kind: "locate";
                readonly entity: "Plano";
                readonly title: "Localizar o plano a ser alterado.";
                readonly description: "Busca o plano a partir do contexto disponível ou da lista de planos.";
            }, {
                readonly stepId: "inspecionarCondicoesPlano";
                readonly kind: "inspect";
                readonly entity: "Plano";
                readonly title: "Conferir as condições atuais do plano.";
                readonly description: "Visualiza modalidade, valor e dia de vencimento cadastrados.";
            }, {
                readonly stepId: "alterarCondicoesPlano";
                readonly kind: "act";
                readonly entity: "Plano";
                readonly effect: "update";
                readonly title: "Alterar as condições do plano.";
                readonly description: "Atualiza o valor e/ou o dia de vencimento do plano.";
            }];
            readonly outcome: {
                readonly statement: "As condições do plano foram atualizadas para uso nas cobranças aplicáveis.";
                readonly evidence: ["O plano exibe o novo valor ou dia de vencimento.", "A alteração fica registrada no plano."];
            };
        };
        readonly businessHash: "sha256:8313981a46af047a3194325af6ac1397da277ed16690686c4adbbaeb99b00e4a";
    };
    export type AtualizarPlanoJourneyType = typeof atualizarPlanoJourney;
    export default atualizarPlanoJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/cadastrarPlano.defs" {
    export const cadastrarPlanoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cadastrarPlano";
        readonly business: {
            readonly actorRef: "gerencia";
            readonly title: "Cadastrar plano de academia";
            readonly goal: "Disponibilizar um plano mensal, trimestral ou anual com valor e dia de vencimento para matrículas.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "informarCondicoesPlano";
                readonly kind: "act";
                readonly entity: "Plano";
                readonly effect: "create";
                readonly title: "Informar modalidade, valor e dia de vencimento do plano.";
                readonly description: "Cadastra um plano que poderá ser selecionado nas matrículas.";
            }];
            readonly outcome: {
                readonly statement: "Um plano com suas condições de cobrança fica disponível para novas matrículas.";
                readonly evidence: ["O plano cadastrado apresenta modalidade, valor e dia de vencimento.", "O plano pode ser selecionado ao matricular um aluno."];
            };
        };
        readonly businessHash: "sha256:d18d870b737f57ba841881bdb2287795223db0c425ee99adab318588fa35f495";
    };
    export type CadastrarPlanoJourneyType = typeof cadastrarPlanoJourney;
    export default cadastrarPlanoJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/cancelarPropriaMatricula.defs" {
    export const cancelarPropriaMatriculaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "cancelarPropriaMatricula";
        readonly business: {
            readonly actorRef: "aluno";
            readonly title: "Cancelar própria matrícula";
            readonly goal: "Encerrar a própria matrícula para impedir a geração de mensalidades futuras.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarPropriaMatricula";
                readonly kind: "locate";
                readonly entity: "Matricula";
                readonly title: "Localizar a própria matrícula ativa.";
                readonly description: "Acessa a matrícula vinculada ao aluno autenticado.";
            }, {
                readonly stepId: "inspecionarPropriaMatricula";
                readonly kind: "inspect";
                readonly entity: "Matricula";
                readonly title: "Conferir os dados da matrícula.";
                readonly description: "Visualiza o plano e a vigência da própria matrícula.";
            }, {
                readonly stepId: "cancelarMatricula";
                readonly kind: "act";
                readonly entity: "Matricula";
                readonly effect: "transition";
                readonly transitionRef: "cancelarMatricula";
                readonly title: "Cancelar a matrícula.";
                readonly description: "Encerra a matrícula ativa do aluno.";
            }];
            readonly outcome: {
                readonly statement: "A matrícula do aluno é encerrada e não participa de gerações futuras de mensalidades.";
                readonly evidence: ["A matrícula apresenta situação de cancelada ou encerrada.", "O aluno deixa de receber novas mensalidades após o encerramento."];
            };
        };
        readonly businessHash: "sha256:c2750452f82a0d0269be9bc25aa83595560eea4f394a14c1b965bc9cc5001ed9";
    };
    export type CancelarPropriaMatriculaJourneyType = typeof cancelarPropriaMatriculaJourney;
    export default cancelarPropriaMatriculaJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/gerarMensalidadesDoMes.defs" {
    export const gerarMensalidadesDoMesJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "gerarMensalidadesDoMes";
        readonly business: {
            readonly actorRef: "gerencia";
            readonly title: "Gerar mensalidades do mês";
            readonly goal: "Criar uma mensalidade mensal para cada aluno com matrícula ativa.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "gerarCobrancasMensais";
                readonly kind: "act";
                readonly entity: "Mensalidade";
                readonly effect: "create";
                readonly title: "Gerar as mensalidades do mês.";
                readonly description: "Cria uma mensalidade por aluno ativo, com o valor do plano e o vencimento correspondente.";
            }];
            readonly outcome: {
                readonly statement: "As mensalidades do período foram geradas para os alunos ativos.";
                readonly evidence: ["Cada aluno com matrícula ativa possui uma mensalidade do mês.", "Cada mensalidade gerada mostra o valor do plano e a data de vencimento."];
            };
        };
        readonly businessHash: "sha256:8284a84a8f19c17f0fd7342c15b4412cb475bf42b93b39c7e58160c1067651db";
    };
    export type GerarMensalidadesDoMesJourneyType = typeof gerarMensalidadesDoMesJourney;
    export default gerarMensalidadesDoMesJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/index.defs" {
    export const mensalidadesAcademiaJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "mensalidadesAcademia";
        readonly journeys: [{
            readonly journeyId: "cadastrarPlano";
            readonly actorRef: "gerencia";
            readonly title: "Cadastrar plano de academia";
        }, {
            readonly journeyId: "atualizarPlano";
            readonly actorRef: "gerencia";
            readonly title: "Atualizar condições de um plano";
        }, {
            readonly journeyId: "matricularAluno";
            readonly actorRef: "recepcao";
            readonly title: "Matricular aluno em um plano";
        }, {
            readonly journeyId: "gerarMensalidadesDoMes";
            readonly actorRef: "gerencia";
            readonly title: "Gerar mensalidades do mês";
        }, {
            readonly journeyId: "registrarPagamentoMensalidade";
            readonly actorRef: "recepcao";
            readonly title: "Registrar pagamento de mensalidade";
        }, {
            readonly journeyId: "acompanharPainelMensal";
            readonly actorRef: "gerencia";
            readonly title: "Acompanhar painel mensal";
        }, {
            readonly journeyId: "cancelarPropriaMatricula";
            readonly actorRef: "aluno";
            readonly title: "Cancelar própria matrícula";
        }];
        readonly systemDecisions: [];
    };
    export type MensalidadesAcademiaJourneyIndexType = typeof mensalidadesAcademiaJourneyIndex;
    export default mensalidadesAcademiaJourneyIndex;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/matricularAluno.defs" {
    export const matricularAlunoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "matricularAluno";
        readonly business: {
            readonly actorRef: "recepcao";
            readonly title: "Matricular aluno em um plano";
            readonly goal: "Registrar a matrícula de um aluno em um plano a partir da data informada.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "informarAlunoPlanoEdata";
                readonly kind: "act";
                readonly entity: "Matricula";
                readonly affects: ["Aluno"];
                readonly effect: "create";
                readonly title: "Informar o aluno, o plano e a data inicial.";
                readonly description: "Cria a matrícula no plano escolhido e cria ou vincula o cadastro do aluno quando necessário.";
            }];
            readonly outcome: {
                readonly statement: "O aluno fica com uma matrícula ativa no plano escolhido a partir da data registrada.";
                readonly evidence: ["A matrícula apresenta o aluno, o plano e a data inicial.", "O aluno passa a constar como ativo para a geração de mensalidades."];
            };
        };
        readonly businessHash: "sha256:7069f1c2e4e085793f7e16a3161e961f44b513f0ce89198b6b933387a17f36f1";
    };
    export type MatricularAlunoJourneyType = typeof matricularAlunoJourney;
    export default matricularAlunoJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/journeys/registrarPagamentoMensalidade.defs" {
    export const registrarPagamentoMensalidadeJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarPagamentoMensalidade";
        readonly business: {
            readonly actorRef: "recepcao";
            readonly title: "Registrar pagamento de mensalidade";
            readonly goal: "Registrar a data, o valor e a forma de pagamento de uma mensalidade do aluno.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarMensalidade";
                readonly kind: "locate";
                readonly entity: "Mensalidade";
                readonly title: "Localizar a mensalidade do aluno.";
                readonly description: "Busca a mensalidade a partir do contexto disponível ou consultando as mensalidades do aluno.";
            }, {
                readonly stepId: "inspecionarMensalidade";
                readonly kind: "inspect";
                readonly entity: "Mensalidade";
                readonly title: "Conferir os dados da mensalidade.";
                readonly description: "Visualiza o aluno, o valor devido, o vencimento e a situação da mensalidade.";
            }, {
                readonly stepId: "registrarDadosPagamento";
                readonly kind: "act";
                readonly entity: "Pagamento";
                readonly affects: ["Mensalidade"];
                readonly effect: "create";
                readonly title: "Registrar os dados do pagamento.";
                readonly description: "Registra a data, o valor e a forma de pagamento vinculados à mensalidade.";
            }];
            readonly outcome: {
                readonly statement: "O pagamento fica registrado e a situação da mensalidade é atualizada conforme o valor recebido.";
                readonly evidence: ["Existe um pagamento com data, valor e forma de pagamento.", "A mensalidade mostra o pagamento registrado e sua situação atual."];
            };
        };
        readonly businessHash: "sha256:8abd8edd88bb7f9b2f97b21fd09f3ba7376938247b881264fef608abbcdfc3c4";
    };
    export type RegistrarPagamentoMensalidadeJourneyType = typeof registrarPagamentoMensalidadeJourney;
    export default registrarPagamentoMensalidadeJourney;
}
declare module "_102047_/l4/mensalidadesAcademia/ontology/Aluno.defs" {
    export const mensalidadesAcademiaEntityAluno: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Aluno";
        readonly title: "Aluno";
        readonly description: "Pessoa que possui matrícula na academia e para a qual são geradas mensalidades.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "mensalidadesAcademia.Aluno";
        };
    };
    export type MensalidadesAcademiaEntityAlunoType = typeof mensalidadesAcademiaEntityAluno;
    export default mensalidadesAcademiaEntityAluno;
}
declare module "_102047_/l4/mensalidadesAcademia/ontology/Matricula.defs" {
    export const mensalidadesAcademiaEntityMatricula: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Matricula";
        readonly title: "Matrícula";
        readonly description: "Vínculo do aluno a um plano de academia a partir de uma data.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "dataInicio";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da matrícula.";
        }, {
            readonly fieldId: "alunoId";
            readonly title: "Aluno";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao aluno ao qual a matrícula pertence.";
        }, {
            readonly fieldId: "planoId";
            readonly title: "Plano";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao plano contratado na matrícula.";
        }, {
            readonly fieldId: "dataInicio";
            readonly title: "Data de início";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data a partir da qual a matrícula passa a vigorar.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "active";
                readonly title: "Ativa";
            }, {
                readonly value: "cancelled";
                readonly title: "Cancelada";
            }];
            readonly description: "Situação atual da matrícula.";
        }];
        readonly lifecycleStates: [{
            readonly state: "active";
            readonly reachedBy: "actor";
        }, {
            readonly state: "cancelled";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "cancelarMatricula";
            readonly from: ["active"];
            readonly to: "cancelled";
            readonly by: ["aluno"];
            readonly description: "Encerra a matrícula ativa do próprio aluno e impede a geração de mensalidades futuras.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type MensalidadesAcademiaEntityMatriculaType = typeof mensalidadesAcademiaEntityMatricula;
    export default mensalidadesAcademiaEntityMatricula;
}
declare module "_102047_/l4/mensalidadesAcademia/ontology/Mensalidade.defs" {
    export const mensalidadesAcademiaEntityMensalidade: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Mensalidade";
        readonly title: "Mensalidade";
        readonly description: "Cobrança mensal gerada para uma matrícula ativa, com valor e vencimento do período.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "competencia";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da mensalidade.";
        }, {
            readonly fieldId: "matriculaId";
            readonly title: "Matrícula";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à matrícula para a qual a mensalidade foi gerada.";
        }, {
            readonly fieldId: "competencia";
            readonly title: "Competência";
            readonly type: "date";
            readonly required: true;
            readonly description: "Mês de referência da cobrança.";
        }, {
            readonly fieldId: "valorDevido";
            readonly title: "Valor devido";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor da mensalidade definido pelo plano no momento da geração.";
        }, {
            readonly fieldId: "dataVencimento";
            readonly title: "Data de vencimento";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data limite para pagamento da mensalidade.";
        }];
        readonly uniqueKeys: [["matriculaId", "competencia"]];
        readonly details: {
            readonly valorPago: {
                readonly type: "money";
                readonly description: "Soma dos pagamentos registrados para esta mensalidade.";
            };
            readonly saldoEmAberto: {
                readonly type: "money";
                readonly description: "Diferença entre o valor devido e o valor pago registrado.";
            };
            readonly situacaoCobranca: {
                readonly type: "string";
                readonly description: "Situação calculada da cobrança conforme pagamentos e vencimento.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type MensalidadesAcademiaEntityMensalidadeType = typeof mensalidadesAcademiaEntityMensalidade;
    export default mensalidadesAcademiaEntityMensalidade;
}
declare module "_102047_/l4/mensalidadesAcademia/ontology/Pagamento.defs" {
    export const mensalidadesAcademiaEntityPagamento: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Pagamento";
        readonly title: "Pagamento";
        readonly description: "Registro do pagamento realizado para uma mensalidade.";
        readonly kind: "event";
        readonly party: "none";
        readonly displayField: "dataPagamento";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do registro de pagamento.";
        }, {
            readonly fieldId: "mensalidadeId";
            readonly title: "Mensalidade";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à mensalidade para a qual o pagamento foi registrado.";
        }, {
            readonly fieldId: "dataPagamento";
            readonly title: "Data do pagamento";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data em que o pagamento foi realizado.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor pago";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor efetivamente pago para a mensalidade.";
        }, {
            readonly fieldId: "formaPagamento";
            readonly title: "Forma de pagamento";
            readonly type: "string";
            readonly required: true;
            readonly constraints: {
                readonly maxLength: 100;
            };
            readonly description: "Forma utilizada para realizar o pagamento.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type MensalidadesAcademiaEntityPagamentoType = typeof mensalidadesAcademiaEntityPagamento;
    export default mensalidadesAcademiaEntityPagamento;
}
declare module "_102047_/l4/mensalidadesAcademia/ontology/Plano.defs" {
    export const mensalidadesAcademiaEntityPlano: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly entityId: "Plano";
        readonly title: "Plano";
        readonly description: "Condição comercial de matrícula da academia, com modalidade, valor e dia de vencimento.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "modalidade";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do plano de academia.";
        }, {
            readonly fieldId: "modalidade";
            readonly title: "Modalidade";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly enum: [{
                readonly value: "mensal";
                readonly title: "Mensal";
            }, {
                readonly value: "trimestral";
                readonly title: "Trimestral";
            }, {
                readonly value: "anual";
                readonly title: "Anual";
            }];
            readonly description: "Periodicidade comercial do plano de academia.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor cobrado pelo plano em cada mensalidade gerada.";
        }, {
            readonly fieldId: "diaVencimento";
            readonly title: "Dia de vencimento";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 1;
                readonly max: 31;
            };
            readonly description: "Dia do mês em que as mensalidades vinculadas ao plano vencem.";
        }];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type MensalidadesAcademiaEntityPlanoType = typeof mensalidadesAcademiaEntityPlano;
    export default mensalidadesAcademiaEntityPlano;
}
declare module "_102047_/l4/mensalidadesAcademia/ontology/index.defs" {
    export const mensalidadesAcademiaOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "mensalidadesAcademia";
        readonly businessDomain: "Gestão de matrículas, mensalidades e pagamentos de academia.";
        readonly entities: ["Plano", "Aluno", "Matricula", "Mensalidade", "Pagamento"];
        readonly relationships: [{
            readonly relationshipId: "matriculaAluno";
            readonly fromEntity: "Matricula";
            readonly toEntity: "Aluno";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada matrícula pertence a um aluno da academia.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Matricula";
                readonly from: {
                    readonly entityId: "Matricula";
                    readonly fieldIds: ["alunoId"];
                };
                readonly to: {
                    readonly entityId: "Aluno";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "matriculaPlano";
            readonly fromEntity: "Matricula";
            readonly toEntity: "Plano";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada matrícula é realizada em um plano de academia.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Matricula";
                readonly from: {
                    readonly entityId: "Matricula";
                    readonly fieldIds: ["planoId"];
                };
                readonly to: {
                    readonly entityId: "Plano";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "mensalidadeMatricula";
            readonly fromEntity: "Mensalidade";
            readonly toEntity: "Matricula";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada mensalidade é gerada para uma matrícula ativa.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Mensalidade";
                readonly from: {
                    readonly entityId: "Mensalidade";
                    readonly fieldIds: ["matriculaId"];
                };
                readonly to: {
                    readonly entityId: "Matricula";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "pagamentoMensalidade";
            readonly fromEntity: "Pagamento";
            readonly toEntity: "Mensalidade";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada pagamento é registrado para uma mensalidade.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Pagamento";
                readonly from: {
                    readonly entityId: "Pagamento";
                    readonly fieldIds: ["mensalidadeId"];
                };
                readonly to: {
                    readonly entityId: "Mensalidade";
                    readonly fieldIds: ["id"];
                };
            };
        }];
    };
    export type MensalidadesAcademiaOntologyIndexType = typeof mensalidadesAcademiaOntologyIndex;
    export default mensalidadesAcademiaOntologyIndex;
}
declare module "_102047_/l4/ordenServicio/access.defs" {
    export const ordenServicioAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "ordenServicio";
        readonly actors: [{
            readonly actorId: "recepcionista";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Recepcionista";
            readonly description: "Personal que abre órdenes de servicio y entrega los aparatos reparados a los clientes.";
        }, {
            readonly actorId: "tecnico";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Técnico";
            readonly description: "Personal que analiza los aparatos, prepara presupuestos y realiza las reparaciones.";
        }, {
            readonly actorId: "cliente";
            readonly kind: "external";
            readonly origin: "named";
            readonly title: "Cliente";
            readonly description: "Persona que consulta sus órdenes y aprueba o rechaza presupuestos desde el portal.";
        }];
        readonly grants: [{
            readonly grantId: "recepcionGestionaOrdenes";
            readonly actorRef: "recepcionista";
            readonly title: "Gestionar recepción y entrega de órdenes";
            readonly description: "Permite identificar clientes y aparatos, abrir órdenes de servicio y registrar la entrega final de los aparatos.";
            readonly entityRefs: ["Cliente", "Aparato", "OrdenServicio"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Puede gestionar las recepciones y entregas de todas las órdenes de la organización.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Puede consultar todos los datos de clientes, aparatos y órdenes necesarios para la recepción y entrega.";
            };
        }, {
            readonly grantId: "tecnicoGestionaDiagnosticoReparacion";
            readonly actorRef: "tecnico";
            readonly title: "Gestionar diagnóstico, presupuesto y reparación";
            readonly description: "Permite consultar órdenes y aparatos, registrar diagnósticos, piezas, costos internos, presupuestos y reparaciones.";
            readonly entityRefs: ["Aparato", "OrdenServicio", "BudgetPart"];
            readonly dataScope: {
                readonly mode: "organization";
                readonly description: "Puede trabajar sobre las órdenes de servicio de toda la organización.";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Puede consultar todos los datos técnicos, presupuestarios y de piezas necesarios para diagnosticar y reparar.";
            };
        }, {
            readonly grantId: "clienteConsultaYdecideSusOrdenes";
            readonly actorRef: "cliente";
            readonly title: "Consultar y responder presupuestos propios";
            readonly description: "Permite consultar el estado, diagnóstico y valor presupuestado de las órdenes propias, y aprobar o rechazar el presupuesto.";
            readonly entityRefs: ["OrdenServicio"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Solo puede acceder a las órdenes vinculadas con su propio registro de cliente.";
                readonly anchorEntity: "Cliente";
            };
            readonly disclosure: {
                readonly mode: "fieldsOnly";
                readonly description: "Puede ver únicamente la identificación, el estado, el diagnóstico y el valor del presupuesto; no puede ver costos internos ni anotaciones técnicas.";
                readonly allowedFields: ["OrdenServicio.id", "OrdenServicio.numeroOrden", "OrdenServicio.diagnostico", "OrdenServicio.valorPresupuesto", "OrdenServicio.status"];
                readonly deniedFields: ["OrdenServicio.clienteId", "OrdenServicio.aparatoId", "OrdenServicio.defectoInformado", "OrdenServicio.fotosRecepcion", "OrdenServicio.recibidoEn", "OrdenServicio.anotacionesTecnicas", "OrdenServicio.reparacionRealizada", "OrdenServicio.entregadoEn", "OrdenServicio.details.costoInternoTotal"];
            };
        }];
    };
    export type OrdenServicioAccessType = typeof ordenServicioAccess;
    export default ordenServicioAccess;
}
declare module "_102047_/l4/ordenServicio/integration.defs" {
    export const ordenServicioIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "ordenServicio";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "enviarPresupuesto";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "enviarPresupuesto";
            readonly on: "OrdenServicio.enviarPresupuesto";
            readonly description: "Publica que el presupuesto de una orden de servicio fue enviado al cliente.";
            readonly entityRefs: ["OrdenServicio"];
        }, {
            readonly id: "aprobarPresupuesto";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "aprobarPresupuesto";
            readonly on: "OrdenServicio.aprobarPresupuesto";
            readonly description: "Publica que el cliente aprobó el presupuesto de una orden de servicio.";
            readonly entityRefs: ["OrdenServicio"];
        }, {
            readonly id: "rechazarPresupuesto";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "rechazarPresupuesto";
            readonly on: "OrdenServicio.rechazarPresupuesto";
            readonly description: "Publica que el cliente rechazó el presupuesto y que el aparato quedó disponible para retiro.";
            readonly entityRefs: ["OrdenServicio"];
        }, {
            readonly id: "marcarLista";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "marcarLista";
            readonly on: "OrdenServicio.marcarLista";
            readonly description: "Publica que la reparación fue terminada y la orden está lista para entrega.";
            readonly entityRefs: ["OrdenServicio"];
        }, {
            readonly id: "entregarYfinalizar";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "entregarYfinalizar";
            readonly on: "OrdenServicio.entregarYfinalizar";
            readonly description: "Publica que el aparato fue entregado al cliente y la orden de servicio fue finalizada.";
            readonly entityRefs: ["OrdenServicio"];
        }];
        readonly plugins: [];
    };
    export type OrdenServicioIntegrationType = typeof ordenServicioIntegration;
    export default ordenServicioIntegration;
}
declare module "_102047_/l4/ordenServicio/module.defs" {
    export const ordenServicioModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "ordenServicio";
        readonly title: "Órdenes de servicio técnico";
        readonly userLanguage: "es";
        readonly productLanguages: ["es"];
        readonly defaultLanguage: "es";
        readonly sourcePrompt: "crear el módulo ordenServicio, en español, para un servicio técnico de electrónica. el cliente trae un aparato y el recepcionista abre una orden de servicio con los datos del cliente, el aparato, el defecto informado y fotos. el técnico analiza y registra el diagnóstico, las piezas necesarias con costo interno y el valor del presupuesto para el cliente. el cliente recibe el presupuesto y lo aprueba o lo rechaza desde el portal; si lo rechaza, la orden se cierra como rechazada y el aparato queda disponible para retiro. si lo aprueba, el técnico realiza la reparación, registra lo que hizo y la marca como lista; el recepcionista entrega y finaliza. el cliente accede al portal y ve solamente sus propias órdenes, con estado, diagnóstico y valor del presupuesto — nunca el costo interno de las piezas ni las anotaciones del técnico. perfiles: recepcionista, técnico y cliente.";
    };
    export type OrdenServicioModuleType = typeof ordenServicioModule;
    export default ordenServicioModule;
}
declare module "_102047_/l4/ordenServicio/rules.defs" {
    export const ordenServicioRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "ordenServicio";
        readonly rules: [{
            readonly ruleId: "presupuestoDebeEstarDisponibleParaDecision";
            readonly description: "El cliente solo puede aprobar o rechazar un presupuesto cuando este está disponible para su respuesta.";
        }, {
            readonly ruleId: "rechazoCierraOrdenYhabilitaRetiro";
            readonly description: "El rechazo del presupuesto cierra la orden como rechazada y deja el aparato disponible para retiro.";
        }, {
            readonly ruleId: "reparacionRequierePresupuestoAprobado";
            readonly description: "La reparación solo puede realizarse cuando el presupuesto ha sido aprobado por el cliente.";
        }, {
            readonly ruleId: "ordenListaRequiereReparacionRegistrada";
            readonly description: "Una orden solo puede marcarse como lista para entrega después de registrar la reparación realizada.";
        }, {
            readonly ruleId: "entregaRequiereOrdenLista";
            readonly description: "El aparato solo puede entregarse y la orden finalizarse cuando la orden está marcada como lista para entrega.";
        }, {
            readonly ruleId: "consultaClienteRestringidaAordenesPropias";
            readonly description: "El cliente solo puede consultar sus propias órdenes y ver su estado, diagnóstico y valor del presupuesto, sin acceso al costo interno de las piezas ni a las anotaciones técnicas.";
        }];
    };
    export type OrdenServicioRulesType = typeof ordenServicioRules;
    export default ordenServicioRules;
}
declare module "_102047_/l4/ordenServicio/workflows.defs" {
    export const ordenServicioWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "ordenServicio";
        readonly processes: [{
            readonly processId: "abrirYPrepararPresupuesto";
            readonly title: "Apertura y preparación de presupuesto";
            readonly description: "Coordina la recepción del aparato y el análisis técnico hasta dejar el presupuesto disponible para el cliente.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "recepcionista";
            };
            readonly tasks: [{
                readonly taskId: "abrirOrden";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "abrirOrdenServicio";
                readonly next: ["prepararPresupuesto"];
                readonly description: "El recepcionista registra la recepción del aparato y abre la orden de servicio.";
            }, {
                readonly taskId: "prepararPresupuesto";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "prepararPresupuesto";
                readonly next: [];
                readonly description: "El técnico analiza el aparato, registra el diagnóstico y deja el presupuesto disponible para el cliente.";
            }];
        }, {
            readonly processId: "repararYEntregarAparato";
            readonly title: "Reparación y entrega del aparato";
            readonly description: "Coordina la reparación autorizada y la entrega final del aparato al cliente.";
            readonly trigger: {
                readonly kind: "event";
                readonly event: "OrdenServicio.aprobarPresupuesto";
            };
            readonly tasks: [{
                readonly taskId: "realizarReparacion";
                readonly kind: "human";
                readonly actorRef: "tecnico";
                readonly journeyRef: "realizarReparacion";
                readonly next: ["entregarAparato"];
                readonly description: "El técnico realiza la reparación autorizada, registra el trabajo efectuado y deja el aparato listo para entrega.";
            }, {
                readonly taskId: "entregarAparato";
                readonly kind: "human";
                readonly actorRef: "recepcionista";
                readonly journeyRef: "entregarAparatoReparado";
                readonly next: [];
                readonly description: "El recepcionista verifica la entrega, entrega el aparato al cliente y finaliza la orden.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "abrirOrdenServicio";
            readonly inProcess: true;
            readonly processId: "abrirYPrepararPresupuesto";
        }, {
            readonly journeyId: "prepararPresupuesto";
            readonly inProcess: true;
            readonly processId: "abrirYPrepararPresupuesto";
        }, {
            readonly journeyId: "aprobarPresupuesto";
            readonly inProcess: false;
        }, {
            readonly journeyId: "rechazarPresupuesto";
            readonly inProcess: false;
        }, {
            readonly journeyId: "realizarReparacion";
            readonly inProcess: true;
            readonly processId: "repararYEntregarAparato";
        }, {
            readonly journeyId: "entregarAparatoReparado";
            readonly inProcess: true;
            readonly processId: "repararYEntregarAparato";
        }, {
            readonly journeyId: "consultarMisOrdenes";
            readonly inProcess: false;
        }];
    };
    export type OrdenServicioWorkflowsType = typeof ordenServicioWorkflows;
    export default ordenServicioWorkflows;
}
declare module "_102047_/l4/ordenServicio/journeys/abrirOrdenServicio.defs" {
    export const abrirOrdenServicioJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "abrirOrdenServicio";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Abrir orden de servicio";
            readonly goal: "Registrar la recepción del aparato y abrir su orden de servicio.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "identificarClienteYaparato";
                readonly kind: "locate";
                readonly entity: "Cliente";
                readonly title: "Identificar cliente y aparato";
                readonly description: "Identifica al cliente y su aparato; si no existen previamente, los datos aportados permiten crear o asociar sus registros maestros.";
            }, {
                readonly stepId: "registrarRecepcion";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly affects: ["Cliente", "Aparato"];
                readonly effect: "create";
                readonly title: "Registrar recepción";
                readonly description: "Abre la orden con el defecto informado, los datos de recepción y las fotografías del aparato.";
            }];
            readonly outcome: {
                readonly statement: "La orden queda abierta y el aparato queda registrado para su análisis técnico.";
                readonly evidence: ["Existe una orden de servicio asociada al cliente y al aparato.", "La orden conserva el defecto informado y las fotografías de recepción."];
            };
        };
        readonly businessHash: "sha256:82405cf01c03119c7ef464c7b7c34bb46af25bd566b8e13bafb0ccb2a765488d";
    };
    export type AbrirOrdenServicioJourneyType = typeof abrirOrdenServicioJourney;
    export default abrirOrdenServicioJourney;
}
declare module "_102047_/l4/ordenServicio/journeys/aprobarPresupuesto.defs" {
    export const aprobarPresupuestoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "aprobarPresupuesto";
        readonly business: {
            readonly actorRef: "cliente";
            readonly title: "Aprobar presupuesto";
            readonly goal: "Autorizar la reparación del aparato desde el portal.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenNotificada";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar orden notificada";
                readonly description: "Localiza la orden asociada al presupuesto recibido en la notificación.";
            }, {
                readonly stepId: "abrirPresupuestoRecibido";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Consultar presupuesto recibido";
                readonly description: "Consulta el estado de la orden, el diagnóstico y el valor del presupuesto recibido.";
            }, {
                readonly stepId: "decidirAprobacion";
                readonly kind: "decide";
                readonly entity: "OrdenServicio";
                readonly title: "Decidir aprobación";
                readonly description: "Elige aprobar el presupuesto en lugar de rechazarlo.";
            }, {
                readonly stepId: "confirmarAprobacion";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "transition";
                readonly transitionRef: "aprobarPresupuesto";
                readonly title: "Confirmar aprobación";
                readonly description: "Registra la aprobación del presupuesto y autoriza la reparación.";
            }];
            readonly outcome: {
                readonly statement: "La orden queda autorizada para reparación.";
                readonly evidence: ["La respuesta del cliente registra la aprobación del presupuesto.", "La orden queda disponible para que el técnico realice la reparación."];
            };
        };
        readonly businessHash: "sha256:39fc6780e33be8217552b0308e8b4a87eb3694073927ff0d682b40929cd1ded1";
    };
    export type AprobarPresupuestoJourneyType = typeof aprobarPresupuestoJourney;
    export default aprobarPresupuestoJourney;
}
declare module "_102047_/l4/ordenServicio/journeys/consultarMisOrdenes.defs" {
    export const consultarMisOrdenesJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "consultarMisOrdenes";
        readonly business: {
            readonly actorRef: "cliente";
            readonly title: "Consultar mis órdenes de servicio";
            readonly goal: "Ver el seguimiento de las órdenes propias desde el portal.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "localizarMisOrdenes";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar mis órdenes";
                readonly description: "Localiza únicamente las órdenes de servicio propias.";
            }, {
                readonly stepId: "consultarEstadoYpresupuesto";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Consultar estado y presupuesto";
                readonly description: "Consulta el estado, el diagnóstico y el valor del presupuesto de una orden propia, sin acceder al costo interno de las piezas ni a las anotaciones técnicas.";
            }];
            readonly outcome: {
                readonly statement: "El cliente conoce el estado y la información visible de sus propias órdenes.";
                readonly evidence: ["El portal muestra las órdenes asociadas al cliente autenticado.", "Cada orden consultada muestra su estado, diagnóstico y valor del presupuesto."];
            };
        };
        readonly businessHash: "sha256:bd87b28d25b94db61e9e7fb91b919f885a4123f47dd772248414141744adc90b";
    };
    export type ConsultarMisOrdenesJourneyType = typeof consultarMisOrdenesJourney;
    export default consultarMisOrdenesJourney;
}
declare module "_102047_/l4/ordenServicio/journeys/entregarAparatoReparado.defs" {
    export const entregarAparatoReparadoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "entregarAparatoReparado";
        readonly business: {
            readonly actorRef: "recepcionista";
            readonly title: "Entregar aparato reparado";
            readonly goal: "Entregar al cliente un aparato listo y finalizar la orden.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenLista";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar orden lista";
                readonly description: "Localiza la orden marcada como lista para entrega.";
            }, {
                readonly stepId: "verificarEntrega";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Verificar entrega";
                readonly description: "Verifica la identidad del cliente, el aparato y que la orden está lista para entrega.";
            }, {
                readonly stepId: "entregarYfinalizarOrden";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "transition";
                readonly transitionRef: "entregarYfinalizar";
                readonly title: "Entregar y finalizar orden";
                readonly description: "Entrega el aparato reparado al cliente y finaliza la orden.";
            }];
            readonly outcome: {
                readonly statement: "El aparato reparado fue entregado y la orden quedó finalizada.";
                readonly evidence: ["La orden registra la entrega al cliente.", "El estado de la orden indica que está finalizada."];
            };
        };
        readonly businessHash: "sha256:0d94a48b9c01e5a64a58a0e8cf7503c25c0541914925e562f48d5cbc5d39c60d";
    };
    export type EntregarAparatoReparadoJourneyType = typeof entregarAparatoReparadoJourney;
    export default entregarAparatoReparadoJourney;
}
declare module "_102047_/l4/ordenServicio/journeys/index.defs" {
    export const ordenServicioJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "ordenServicio";
        readonly journeys: [{
            readonly journeyId: "abrirOrdenServicio";
            readonly actorRef: "recepcionista";
            readonly title: "Abrir orden de servicio";
        }, {
            readonly journeyId: "prepararPresupuesto";
            readonly actorRef: "tecnico";
            readonly title: "Analizar aparato y preparar presupuesto";
        }, {
            readonly journeyId: "aprobarPresupuesto";
            readonly actorRef: "cliente";
            readonly title: "Aprobar presupuesto";
        }, {
            readonly journeyId: "rechazarPresupuesto";
            readonly actorRef: "cliente";
            readonly title: "Rechazar presupuesto";
        }, {
            readonly journeyId: "realizarReparacion";
            readonly actorRef: "tecnico";
            readonly title: "Realizar reparación";
        }, {
            readonly journeyId: "entregarAparatoReparado";
            readonly actorRef: "recepcionista";
            readonly title: "Entregar aparato reparado";
        }, {
            readonly journeyId: "consultarMisOrdenes";
            readonly actorRef: "cliente";
            readonly title: "Consultar mis órdenes de servicio";
        }];
        readonly systemDecisions: [];
    };
    export type OrdenServicioJourneyIndexType = typeof ordenServicioJourneyIndex;
    export default ordenServicioJourneyIndex;
}
declare module "_102047_/l4/ordenServicio/journeys/prepararPresupuesto.defs" {
    export const prepararPresupuestoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "prepararPresupuesto";
        readonly business: {
            readonly actorRef: "tecnico";
            readonly title: "Analizar aparato y preparar presupuesto";
            readonly goal: "Diagnosticar el aparato y poner un presupuesto a disposición del cliente.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenAbierta";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar orden abierta";
                readonly description: "Localiza la orden abierta del aparato recibido.";
            }, {
                readonly stepId: "inspeccionarOrdenYaparato";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Inspeccionar orden y aparato";
                readonly description: "Revisa los datos de recepción, el defecto informado, las fotografías y el aparato para realizar el análisis.";
            }, {
                readonly stepId: "registrarDiagnosticoYpiezas";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "update";
                readonly title: "Registrar diagnóstico y piezas";
                readonly description: "Registra el diagnóstico, las piezas necesarias con su costo interno y el valor del presupuesto para el cliente.";
            }, {
                readonly stepId: "enviarPresupuestoAlCliente";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "transition";
                readonly transitionRef: "enviarPresupuesto";
                readonly title: "Enviar presupuesto al cliente";
                readonly description: "Deja el presupuesto disponible para que el cliente lo responda desde el portal.";
            }];
            readonly outcome: {
                readonly statement: "El cliente tiene un presupuesto disponible para aprobar o rechazar.";
                readonly evidence: ["La orden muestra el diagnóstico y el valor presupuestado para el cliente.", "La orden está pendiente de respuesta del presupuesto."];
            };
        };
        readonly businessHash: "sha256:497523fa22dfba656a9d7e89c00f2dfef3230eae26a0c5ecb02b8d4333d0dd75";
    };
    export type PrepararPresupuestoJourneyType = typeof prepararPresupuestoJourney;
    export default prepararPresupuestoJourney;
}
declare module "_102047_/l4/ordenServicio/journeys/realizarReparacion.defs" {
    export const realizarReparacionJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "realizarReparacion";
        readonly business: {
            readonly actorRef: "tecnico";
            readonly title: "Realizar reparación";
            readonly goal: "Reparar un aparato con presupuesto aprobado y dejarlo listo para entrega.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarOrdenAprobada";
                readonly kind: "locate";
                readonly entity: "OrdenServicio";
                readonly title: "Localizar orden aprobada";
                readonly description: "Localiza una orden cuyo presupuesto fue aprobado.";
            }, {
                readonly stepId: "registrarReparacionRealizada";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "update";
                readonly title: "Registrar reparación realizada";
                readonly description: "Registra las acciones técnicas realizadas durante la reparación.";
            }, {
                readonly stepId: "marcarAparatoListo";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "transition";
                readonly transitionRef: "marcarLista";
                readonly title: "Marcar aparato listo";
                readonly description: "Marca la orden como lista para entregar el aparato al cliente.";
            }];
            readonly outcome: {
                readonly statement: "El aparato reparado queda listo para entrega.";
                readonly evidence: ["La orden conserva el registro de la reparación realizada.", "El estado de la orden indica que está lista para entrega."];
            };
        };
        readonly businessHash: "sha256:0b119e26774c79cfd598de5da6947ad7f82cbbeb07ca48d3243e8ffd668309aa";
    };
    export type RealizarReparacionJourneyType = typeof realizarReparacionJourney;
    export default realizarReparacionJourney;
}
declare module "_102047_/l4/ordenServicio/journeys/rechazarPresupuesto.defs" {
    export const rechazarPresupuestoJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "rechazarPresupuesto";
        readonly business: {
            readonly actorRef: "cliente";
            readonly title: "Rechazar presupuesto";
            readonly goal: "Rechazar el presupuesto y dejar el aparato disponible para retiro.";
            readonly entry: {
                readonly mode: "fromNotification";
            };
            readonly steps: [{
                readonly stepId: "abrirPresupuestoParaRechazo";
                readonly kind: "inspect";
                readonly entity: "OrdenServicio";
                readonly title: "Consultar presupuesto para rechazo";
                readonly description: "Consulta el estado de la orden, el diagnóstico y el valor del presupuesto recibido.";
            }, {
                readonly stepId: "decidirRechazo";
                readonly kind: "decide";
                readonly entity: "OrdenServicio";
                readonly title: "Decidir rechazo";
                readonly description: "Elige rechazar el presupuesto en lugar de aprobarlo.";
            }, {
                readonly stepId: "confirmarRechazo";
                readonly kind: "act";
                readonly entity: "OrdenServicio";
                readonly effect: "transition";
                readonly transitionRef: "rechazarPresupuesto";
                readonly title: "Confirmar rechazo";
                readonly description: "Registra el rechazo y cierra la orden, dejando el aparato disponible para retiro.";
            }];
            readonly outcome: {
                readonly statement: "La orden queda cerrada como rechazada y el aparato queda disponible para retiro.";
                readonly evidence: ["La orden registra el rechazo del presupuesto.", "El estado de la orden indica que fue rechazada y que el aparato está disponible para retiro."];
            };
        };
        readonly businessHash: "sha256:fecfc22126ba9f32271d6e21ea2cfaa838354ae1ee600d55768f85fc312d1e89";
    };
    export type RechazarPresupuestoJourneyType = typeof rechazarPresupuestoJourney;
    export default rechazarPresupuestoJourney;
}
declare module "_102047_/l4/ordenServicio/ontology/Aparato.defs" {
    export const ordenServicioEntityAparato: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "ordenServicio";
        readonly entityId: "Aparato";
        readonly title: "Aparato";
        readonly description: "Aparato electrónico recibido para diagnóstico, presupuesto, reparación o retiro.";
        readonly kind: "mdm";
        readonly party: "none";
        readonly mdmSubtype: "AssetEquipment";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "ordenServicio.Aparato";
        };
    };
    export type OrdenServicioEntityAparatoType = typeof ordenServicioEntityAparato;
    export default ordenServicioEntityAparato;
}
declare module "_102047_/l4/ordenServicio/ontology/BudgetPart.defs" {
    export const ordenServicioEntityBudgetPart: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "ordenServicio";
        readonly entityId: "BudgetPart";
        readonly title: "Pieza presupuestada";
        readonly description: "Pieza necesaria identificada durante el diagnóstico de una orden, incluyendo su costo interno para el servicio técnico.";
        readonly kind: "supporting";
        readonly party: "none";
        readonly displayField: "descripcion";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la pieza presupuestada.";
        }, {
            readonly fieldId: "ordenServicioId";
            readonly title: "Orden de servicio";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referencia a la orden de servicio a la que pertenece esta pieza presupuestada.";
        }, {
            readonly fieldId: "descripcion";
            readonly title: "Descripción";
            readonly type: "string";
            readonly required: true;
            readonly constraints: {
                readonly maxLength: 500;
            };
            readonly description: "Descripción de la pieza necesaria para la reparación.";
        }, {
            readonly fieldId: "cantidad";
            readonly title: "Cantidad";
            readonly type: "integer";
            readonly required: true;
            readonly constraints: {
                readonly min: 1;
            };
            readonly description: "Cantidad de unidades de la pieza necesarias para la reparación.";
        }, {
            readonly fieldId: "costoInterno";
            readonly title: "Costo interno";
            readonly type: "money";
            readonly required: true;
            readonly constraints: {
                readonly min: 0;
                readonly precision: 2;
            };
            readonly description: "Costo interno estimado de las piezas para el servicio técnico.";
        }];
        readonly details: {
            readonly costoInternoTotal: {
                readonly type: "money";
                readonly description: "Costo interno total calculado al multiplicar la cantidad por el costo interno de la pieza.";
            };
        };
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
        readonly mutability: "appendOnly";
    };
    export type OrdenServicioEntityBudgetPartType = typeof ordenServicioEntityBudgetPart;
    export default ordenServicioEntityBudgetPart;
}
declare module "_102047_/l4/ordenServicio/ontology/Cliente.defs" {
    export const ordenServicioEntityCliente: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "ordenServicio";
        readonly entityId: "Cliente";
        readonly title: "Cliente";
        readonly description: "Persona cliente identificada para registrar sus órdenes de servicio y consultar sus propias órdenes desde el portal.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "id";
            readonly mdmType: "ordenServicio.Cliente";
        };
    };
    export type OrdenServicioEntityClienteType = typeof ordenServicioEntityCliente;
    export default ordenServicioEntityCliente;
}
declare module "_102047_/l4/ordenServicio/ontology/OrdenServicio.defs" {
    export const ordenServicioEntityOrdenServicio: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "ordenServicio";
        readonly entityId: "OrdenServicio";
        readonly title: "Orden de servicio";
        readonly description: "Registro transaccional de la recepción, diagnóstico, presupuesto, decisión del cliente, reparación y entrega de un aparato.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "numeroOrden";
        readonly fields: [{
            readonly fieldId: "id";
            readonly title: "Identificador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único de la orden de servicio.";
        }, {
            readonly fieldId: "numeroOrden";
            readonly title: "Número de orden";
            readonly type: "string";
            readonly required: true;
            readonly unique: true;
            readonly description: "Número secuencial asignado a la orden de servicio.";
        }, {
            readonly fieldId: "clienteId";
            readonly title: "Cliente";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referencia al cliente que presentó el aparato para servicio.";
        }, {
            readonly fieldId: "aparatoId";
            readonly title: "Aparato";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referencia al aparato recibido para su atención técnica.";
        }, {
            readonly fieldId: "defectoInformado";
            readonly title: "Defecto informado";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descripción del problema reportado por el cliente al recibir el aparato.";
        }, {
            readonly fieldId: "fotosRecepcion";
            readonly title: "Fotografías de recepción";
            readonly type: "json";
            readonly required: false;
            readonly description: "Referencias a las fotografías tomadas del aparato durante su recepción.";
        }, {
            readonly fieldId: "recibidoEn";
            readonly title: "Fecha y hora de recepción";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Fecha y hora en que el aparato fue recibido para servicio.";
        }, {
            readonly fieldId: "diagnostico";
            readonly title: "Diagnóstico";
            readonly type: "text";
            readonly required: false;
            readonly description: "Resultado técnico del análisis del aparato.";
        }, {
            readonly fieldId: "valorPresupuesto";
            readonly title: "Valor del presupuesto";
            readonly type: "money";
            readonly required: false;
            readonly description: "Importe presupuestado al cliente para realizar la reparación.";
        }, {
            readonly fieldId: "anotacionesTecnicas";
            readonly title: "Anotaciones técnicas";
            readonly type: "text";
            readonly required: false;
            readonly description: "Notas internas del técnico sobre el análisis o la reparación.";
        }, {
            readonly fieldId: "reparacionRealizada";
            readonly title: "Reparación realizada";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descripción de las acciones técnicas efectuadas para reparar el aparato.";
        }, {
            readonly fieldId: "entregadoEn";
            readonly title: "Fecha y hora de entrega";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Fecha y hora en que el aparato reparado fue entregado al cliente.";
        }, {
            readonly fieldId: "status";
            readonly title: "Estado";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "open";
                readonly title: "Abierta";
            }, {
                readonly value: "quoteSent";
                readonly title: "Presupuesto enviado";
            }, {
                readonly value: "quoteApproved";
                readonly title: "Presupuesto aprobado";
            }, {
                readonly value: "rejected";
                readonly title: "Rechazada";
            }, {
                readonly value: "readyForPickup";
                readonly title: "Lista para entrega";
            }, {
                readonly value: "completed";
                readonly title: "Finalizada";
            }];
            readonly description: "Estado actual de la orden de servicio.";
        }];
        readonly details: {
            readonly costoInternoTotal: {
                readonly type: "money";
                readonly description: "Suma de los costos internos de las piezas registradas para el presupuesto de la orden.";
            };
        };
        readonly lifecycleStates: [{
            readonly state: "open";
            readonly reachedBy: "actor";
        }, {
            readonly state: "quoteSent";
            readonly reachedBy: "actor";
        }, {
            readonly state: "quoteApproved";
            readonly reachedBy: "actor";
        }, {
            readonly state: "rejected";
            readonly reachedBy: "actor";
        }, {
            readonly state: "readyForPickup";
            readonly reachedBy: "actor";
        }, {
            readonly state: "completed";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "enviarPresupuesto";
            readonly from: ["open"];
            readonly to: "quoteSent";
            readonly by: ["tecnico"];
            readonly description: "El técnico deja el presupuesto disponible para la respuesta del cliente.";
        }, {
            readonly transitionId: "aprobarPresupuesto";
            readonly from: ["quoteSent"];
            readonly to: "quoteApproved";
            readonly by: ["cliente"];
            readonly description: "El cliente aprueba el presupuesto y autoriza la reparación.";
        }, {
            readonly transitionId: "rechazarPresupuesto";
            readonly from: ["quoteSent"];
            readonly to: "rejected";
            readonly by: ["cliente"];
            readonly description: "El cliente rechaza el presupuesto y la orden queda cerrada con el aparato disponible para retiro.";
        }, {
            readonly transitionId: "marcarLista";
            readonly from: ["quoteApproved"];
            readonly to: "readyForPickup";
            readonly by: ["tecnico"];
            readonly description: "El técnico marca la orden como lista para entregar el aparato reparado.";
        }, {
            readonly transitionId: "entregarYfinalizar";
            readonly from: ["readyForPickup"];
            readonly to: "completed";
            readonly by: ["recepcionista"];
            readonly description: "El recepcionista entrega el aparato reparado al cliente y finaliza la orden.";
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "id";
        };
    };
    export type OrdenServicioEntityOrdenServicioType = typeof ordenServicioEntityOrdenServicio;
    export default ordenServicioEntityOrdenServicio;
}
declare module "_102047_/l4/ordenServicio/ontology/index.defs" {
    export const ordenServicioOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "ordenServicio";
        readonly businessDomain: "Gestión de órdenes de servicio para diagnóstico, presupuesto, reparación y entrega de aparatos electrónicos.";
        readonly entities: ["Cliente", "Aparato", "OrdenServicio", "BudgetPart"];
        readonly relationships: [{
            readonly relationshipId: "customerOwnsEquipment";
            readonly fromEntity: "Cliente";
            readonly toEntity: "Aparato";
            readonly type: "oneToMany";
            readonly required: false;
            readonly description: "El cliente es propietario del aparato que presenta al servicio técnico.";
            readonly persistence: {
                readonly mode: "mdmRelationship";
            };
            readonly realization: {
                readonly kind: "mdmRelationship";
                readonly ownerEntity: "Cliente";
                readonly from: {
                    readonly entityId: "Cliente";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "Aparato";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "serviceOrderForCustomer";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Cliente";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "La orden de servicio corresponde al cliente que presentó el aparato.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["clienteId"];
                };
                readonly to: {
                    readonly entityId: "Cliente";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "serviceOrderForEquipment";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "Aparato";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "La orden de servicio registra el aparato recibido para su atención.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "OrdenServicio";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["aparatoId"];
                };
                readonly to: {
                    readonly entityId: "Aparato";
                    readonly fieldIds: ["id"];
                };
            };
        }, {
            readonly relationshipId: "serviceOrderHasBudgetParts";
            readonly fromEntity: "OrdenServicio";
            readonly toEntity: "BudgetPart";
            readonly type: "oneToMany";
            readonly required: false;
            readonly description: "La orden de servicio incluye las piezas necesarias consideradas para el presupuesto.";
            readonly persistence: {
                readonly mode: "moduleReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "BudgetPart";
                readonly from: {
                    readonly entityId: "OrdenServicio";
                    readonly fieldIds: ["id"];
                };
                readonly to: {
                    readonly entityId: "BudgetPart";
                    readonly fieldIds: ["ordenServicioId"];
                };
            };
        }];
    };
    export type OrdenServicioOntologyIndexType = typeof ordenServicioOntologyIndex;
    export default ordenServicioOntologyIndex;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases" {
    /**
     * English catalogue slice for the E1-E6 clarification widgets.
     * Merged into NS4_PHRASES so the root planner translates widget chrome once per run.
     */
    export const NS4_WIDGET_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
    };
    export const NS4_WIDGET_KEYS: {
        readonly intake: readonly ["adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly journeys: readonly ["subtitle", "actor", "goal", "steps", "rules", "outcome", "filters", "impact", "noPolicyDecision", "journeys", "journeysFound", "selectJourney", "allActors", "actorMap", "actors", "overview", "actual", "rulesHelp", "adjustment", "placeholder", "requestChanges", "approve", "round", "step", "of", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly accessMatrix: readonly ["subtitle", "step", "of", "round", "profiles", "internal", "external", "actors", "landing", "matrix", "profileAccess", "authority", "noAccess", "full", "limited", "details", "reason", "scope", "disclosure", "allowed", "denied", "ruleRefs", "journeySteps", "informationNeeds", "close", "adjustment", "placeholder", "requestChanges", "approve", "adjustmentRequired", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking"];
        readonly ontology: readonly ["subtitle", "step", "of", "round", "mode", "changes", "entities", "fields", "relationships", "lifecycle", "ruleRefs", "overview", "descriptions", "source", "storage", "required", "optional", "constraints", "persistenceMap", "persistenceHint", "targetMdm", "targetModuleDatabase", "targetDerived", "targetExternal", "targetEmbedded", "scope", "mdmType", "idField", "reason", "fieldRulesHint", "crossStore", "sourceRelationships", "destinationRelationships", "noRelationships", "implementation", "editInPlace", "direct", "directHint", "entityTitle", "entityDescription", "fieldTitle", "fieldDescription", "structural", "structuralHint", "placeholder", "request", "approve", "requiredAdjustment", "empty", "processingApproval", "processingChanges", "processingCancel", "revise", "cancel", "cancelTitle", "cancelText", "keepWorking", "assumedDecisions", "changeHint"];
        readonly rules: readonly ["step", "review", "rules", "search", "noRule", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint", "edit"];
        readonly composition: readonly ["step", "review", "empty", "horizontalModule", "plugin", "include", "defer", "adjustment", "placeholder", "request", "approve", "cancel", "adjustmentRequired", "processingApproval", "processingChanges", "processingCancel", "revise", "cancelTitle", "cancelText", "keepWorking", "hint"];
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Text" {
    /**
     * Deterministic user-facing phrases of agentNewSolution. English is the only text in code.
     * The root planner translates the catalogue once per run into `presentation.phrases`; readers
     * fall back to this object when a key is missing. Placeholders `{name}` stay verbatim in every
     * language. Internal messages (throw, statusTask, trace) are English literals, not keys.
     */
    import { NS4_WIDGET_KEYS } from "_102035_/l2/agentNewSolution/helpers/ns4WidgetPhrases";
    export const NS4_PHRASE_MAX_LENGTH: 200;
    export const NS4_PHRASES: {
        readonly 'widget.intake.adjustmentRequired': "Describe what should change before generating another proposal.";
        readonly 'widget.intake.processingApproval': "Validating initial definition…";
        readonly 'widget.intake.processingChanges': "Preparing a new review…";
        readonly 'widget.intake.processingCancel': "Cancelling execution…";
        readonly 'widget.intake.revise': "Review the items below";
        readonly 'widget.intake.cancel': "Cancel execution";
        readonly 'widget.intake.cancelTitle': "Cancel this execution?";
        readonly 'widget.intake.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.intake.keepWorking': "Keep working";
        readonly 'widget.journeys.subtitle': "These journeys will become the permanent source of truth for the product.";
        readonly 'widget.journeys.actor': "Actor";
        readonly 'widget.journeys.goal': "Goal";
        readonly 'widget.journeys.steps': "Steps";
        readonly 'widget.journeys.rules': "Rules";
        readonly 'widget.journeys.outcome': "Outcome and evidence";
        readonly 'widget.journeys.filters': "Filters";
        readonly 'widget.journeys.impact': "Impact";
        readonly 'widget.journeys.noPolicyDecision': "No policy decision was provided for this journey.";
        readonly 'widget.journeys.journeys': "Journeys";
        readonly 'widget.journeys.journeysFound': "journeys found";
        readonly 'widget.journeys.selectJourney': "Select a journey to review.";
        readonly 'widget.journeys.allActors': "All actors";
        readonly 'widget.journeys.actorMap': "Journey map by actor";
        readonly 'widget.journeys.actors': "actors";
        readonly 'widget.journeys.overview': "Overview";
        readonly 'widget.journeys.actual': "(actual)";
        readonly 'widget.journeys.rulesHelp': "Rules that must remain true in every execution of this journey.";
        readonly 'widget.journeys.adjustment': "What should change?";
        readonly 'widget.journeys.placeholder': "Describe the needed change without rewriting what is already correct.";
        readonly 'widget.journeys.requestChanges': "Request changes";
        readonly 'widget.journeys.approve': "Approve journeys";
        readonly 'widget.journeys.round': "Review";
        readonly 'widget.journeys.step': "Step";
        readonly 'widget.journeys.of': "of";
        readonly 'widget.journeys.adjustmentRequired': "Describe what must change before requesting another version.";
        readonly 'widget.journeys.processingApproval': "Validating journeys…";
        readonly 'widget.journeys.processingChanges': "Preparing a new review…";
        readonly 'widget.journeys.processingCancel': "Cancelling execution…";
        readonly 'widget.journeys.revise': "Review the items below";
        readonly 'widget.journeys.cancel': "Cancel execution";
        readonly 'widget.journeys.cancelTitle': "Cancel this execution?";
        readonly 'widget.journeys.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.journeys.keepWorking': "Keep working";
        readonly 'widget.journeys.assumedDecisions': "Assumed decisions";
        readonly 'widget.journeys.changeHint': "How to change later";
        readonly 'widget.accessMatrix.subtitle': "Review who may perform each capability and exactly which information may be disclosed.";
        readonly 'widget.accessMatrix.step': "Step";
        readonly 'widget.accessMatrix.of': "of";
        readonly 'widget.accessMatrix.round': "Review";
        readonly 'widget.accessMatrix.profiles': "Access profiles";
        readonly 'widget.accessMatrix.internal': "Internal";
        readonly 'widget.accessMatrix.external': "External";
        readonly 'widget.accessMatrix.actors': "E2 actors";
        readonly 'widget.accessMatrix.landing': "Starting point";
        readonly 'widget.accessMatrix.matrix': "Profile × authority matrix";
        readonly 'widget.accessMatrix.profileAccess': "Authorities for this profile";
        readonly 'widget.accessMatrix.authority': "Authority";
        readonly 'widget.accessMatrix.noAccess': "No access";
        readonly 'widget.accessMatrix.full': "Full record";
        readonly 'widget.accessMatrix.limited': "Limited";
        readonly 'widget.accessMatrix.details': "Access details";
        readonly 'widget.accessMatrix.reason': "Business reason";
        readonly 'widget.accessMatrix.scope': "Data scope";
        readonly 'widget.accessMatrix.disclosure': "Disclosure boundary";
        readonly 'widget.accessMatrix.allowed': "May expose";
        readonly 'widget.accessMatrix.denied': "Must not expose";
        readonly 'widget.accessMatrix.ruleRefs': "Rule references";
        readonly 'widget.accessMatrix.journeySteps': "Journey steps";
        readonly 'widget.accessMatrix.informationNeeds': "Information needs";
        readonly 'widget.accessMatrix.close': "Close";
        readonly 'widget.accessMatrix.adjustment': "What should change?";
        readonly 'widget.accessMatrix.placeholder': "Example: Add authority to view project budgets; some clients may see a summary without seeing the whole project.";
        readonly 'widget.accessMatrix.requestChanges': "Generate another proposal";
        readonly 'widget.accessMatrix.approve': "Approve access matrix";
        readonly 'widget.accessMatrix.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.accessMatrix.empty': "No access matrix available.";
        readonly 'widget.accessMatrix.processingApproval': "Validating access matrix…";
        readonly 'widget.accessMatrix.processingChanges': "Preparing a new review…";
        readonly 'widget.accessMatrix.processingCancel': "Cancelling execution…";
        readonly 'widget.accessMatrix.revise': "Review the items below";
        readonly 'widget.accessMatrix.cancel': "Cancel execution";
        readonly 'widget.accessMatrix.cancelTitle': "Cancel this execution?";
        readonly 'widget.accessMatrix.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.accessMatrix.keepWorking': "Keep working";
        readonly 'widget.ontology.subtitle': "Review the business data, constraints and relationships that frontend and backend will share.";
        readonly 'widget.ontology.step': "Step";
        readonly 'widget.ontology.of': "of";
        readonly 'widget.ontology.round': "Review";
        readonly 'widget.ontology.mode': "New solution";
        readonly 'widget.ontology.changes': "Changes in this round";
        readonly 'widget.ontology.entities': "Entities";
        readonly 'widget.ontology.fields': "Fields";
        readonly 'widget.ontology.relationships': "Relationships";
        readonly 'widget.ontology.lifecycle': "Lifecycle";
        readonly 'widget.ontology.ruleRefs': "Rule references";
        readonly 'widget.ontology.overview': "Overview";
        readonly 'widget.ontology.descriptions': "Descriptions";
        readonly 'widget.ontology.source': "Traceability";
        readonly 'widget.ontology.storage': "Persistence destination";
        readonly 'widget.ontology.required': "Required";
        readonly 'widget.ontology.optional': "Optional";
        readonly 'widget.ontology.constraints': "Field rules";
        readonly 'widget.ontology.persistenceMap': "Persistence map";
        readonly 'widget.ontology.persistenceHint': "Confirm where every entity lives before approval. Select an entity to inspect its reason and fields.";
        readonly 'widget.ontology.targetMdm': "MDM · base records";
        readonly 'widget.ontology.targetModuleDatabase': "Module database · transactions";
        readonly 'widget.ontology.targetDerived': "Derived · no own table";
        readonly 'widget.ontology.targetExternal': "External · platform owned";
        readonly 'widget.ontology.targetEmbedded': "Embedded · owned value";
        readonly 'widget.ontology.scope': "Scope";
        readonly 'widget.ontology.mdmType': "MDM type";
        readonly 'widget.ontology.idField': "Identifier";
        readonly 'widget.ontology.reason': "Reason";
        readonly 'widget.ontology.fieldRulesHint': "Click a field name or description to edit it in place.";
        readonly 'widget.ontology.crossStore': "Cross-store";
        readonly 'widget.ontology.sourceRelationships': "As origin";
        readonly 'widget.ontology.destinationRelationships': "As destination";
        readonly 'widget.ontology.noRelationships': "No relationships for this table.";
        readonly 'widget.ontology.implementation': "Field binding";
        readonly 'widget.ontology.editInPlace': "Click to edit";
        readonly 'widget.ontology.direct': "Direct description edits";
        readonly 'widget.ontology.directHint': "Titles and descriptions are safe to edit here. Structural changes use the separate request panel.";
        readonly 'widget.ontology.entityTitle': "Entity title";
        readonly 'widget.ontology.entityDescription': "Entity description";
        readonly 'widget.ontology.fieldTitle': "Field title";
        readonly 'widget.ontology.fieldDescription': "Field description";
        readonly 'widget.ontology.structural': "What should change?";
        readonly 'widget.ontology.structuralHint': "Use the LLM for entities, fields, types, relationships, lifecycle or constraints.";
        readonly 'widget.ontology.placeholder': "Example: add a client-facing published material-usage projection related to Project, without exposing internal costs.";
        readonly 'widget.ontology.request': "Generate another proposal";
        readonly 'widget.ontology.approve': "Approve ontology";
        readonly 'widget.ontology.requiredAdjustment': "Describe the structural change first.";
        readonly 'widget.ontology.empty': "No ontology proposal available.";
        readonly 'widget.ontology.processingApproval': "Validating ontology…";
        readonly 'widget.ontology.processingChanges': "Preparing a new review…";
        readonly 'widget.ontology.processingCancel': "Cancelling execution…";
        readonly 'widget.ontology.revise': "Review the items below";
        readonly 'widget.ontology.cancel': "Cancel execution";
        readonly 'widget.ontology.cancelTitle': "Cancel this execution?";
        readonly 'widget.ontology.cancelText': "Processing will end. The history and approved artifacts will be preserved.";
        readonly 'widget.ontology.keepWorking': "Keep working";
        readonly 'widget.ontology.assumedDecisions': "Assumed decisions";
        readonly 'widget.ontology.changeHint': "How to change later";
        readonly 'widget.rules.step': "👤 Step 5 of 6 — Business rules";
        readonly 'widget.rules.review': "Review";
        readonly 'widget.rules.rules': "rules";
        readonly 'widget.rules.search': "Search by ID or description";
        readonly 'widget.rules.noRule': "No rules found.";
        readonly 'widget.rules.adjustment': "What should change?";
        readonly 'widget.rules.placeholder': "Example: change clientAvailable to allow only one active client per project.";
        readonly 'widget.rules.request': "Generate another proposal";
        readonly 'widget.rules.approve': "Approve rules";
        readonly 'widget.rules.cancel': "Cancel execution";
        readonly 'widget.rules.adjustmentRequired': "Describe the required change before generating another proposal.";
        readonly 'widget.rules.processingApproval': "Validating rules…";
        readonly 'widget.rules.processingChanges': "Preparing another review…";
        readonly 'widget.rules.processingCancel': "Cancelling execution…";
        readonly 'widget.rules.revise': "Review the items below";
        readonly 'widget.rules.cancelTitle': "Cancel this execution?";
        readonly 'widget.rules.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.rules.keepWorking': "Keep working";
        readonly 'widget.rules.hint': "Each permanent rule contains only a stable ID and one business description.";
        readonly 'widget.rules.edit': "Click to edit the description";
        readonly 'widget.composition.step': "👤 Step 6 of 6 — Additional modules and plugins";
        readonly 'widget.composition.review': "Review";
        readonly 'widget.composition.empty': "No additional horizontal module or plugin was recommended.";
        readonly 'widget.composition.horizontalModule': "Horizontal module";
        readonly 'widget.composition.plugin': "Plugin";
        readonly 'widget.composition.include': "Include";
        readonly 'widget.composition.defer': "Defer";
        readonly 'widget.composition.adjustment': "Would you like to change anything?";
        readonly 'widget.composition.placeholder': "Example: add, remove or defer a recommendation and explain why.";
        readonly 'widget.composition.request': "Generate another proposal";
        readonly 'widget.composition.approve': "Approve analysis";
        readonly 'widget.composition.cancel': "Cancel execution";
        readonly 'widget.composition.adjustmentRequired': "Describe the change before generating another proposal.";
        readonly 'widget.composition.processingApproval': "Validating analysis…";
        readonly 'widget.composition.processingChanges': "Preparing another review…";
        readonly 'widget.composition.processingCancel': "Cancelling execution…";
        readonly 'widget.composition.revise': "Review the items below";
        readonly 'widget.composition.cancelTitle': "Cancel this execution?";
        readonly 'widget.composition.cancelText': "Processing will end. Approved artifacts will be preserved.";
        readonly 'widget.composition.keepWorking': "Keep working";
        readonly 'widget.composition.hint': "This review is conservative: an empty list means the module can proceed without additional components.";
        readonly 'catalogue.list.title': "List {entity}";
        readonly 'catalogue.list.story': "Find the record.";
        readonly 'catalogue.create.title': "Create {entity}";
        readonly 'catalogue.create.story': "Fill in the new record.";
        readonly 'catalogue.update.title': "Update {entity}";
        readonly 'catalogue.update.story': "Correct the chosen record.";
        readonly 'catalogue.section.recordList.intent': "Find {entity}.";
        readonly 'catalogue.section.recordForm.create.intent': "Create {entity}.";
        readonly 'catalogue.section.recordForm.edit.intent': "Create or correct {entity}.";
        readonly 'catalogue.purpose': "{entity} record catalogue.";
        readonly 'catalogue.delete.title': "Delete {entity}";
        readonly 'catalogue.delete.story': "Remove the chosen record.";
        readonly 'catalogue.inactivate.title': "Deactivate {entity}";
        readonly 'catalogue.inactivate.story': "Deactivate the record (history and references are preserved).";
        readonly 'catalogue.reactivate.title': "Reactivate {entity}";
        readonly 'catalogue.reactivate.story': "Reactivate a deactivated record.";
        readonly 'catalogue.get.title': "Get {entity}";
        readonly 'catalogue.get.story': "Read the record by id.";
        readonly 'catalogue.audience.question': "No journey operates {entity}: who maintains this catalogue?";
        readonly 'catalogue.audience.changeHint': "Add an E3 authority over {entity} to restrict this catalogue to a named profile.";
        readonly 'catalogue.list.search': "Search by {field}.";
        readonly 'catalogue.list.sortBy': "Field to sort the listing by.";
        readonly 'catalogue.list.sortOrder': "Sort direction.";
        readonly 'catalogue.list.page': "Listing page (1-based).";
        readonly 'catalogue.list.pageSize': "Page size (default 20, cap 200).";
        readonly 'journey.decide.description': "The decision taken.";
        readonly 'hub.purpose': "{entity} command centre.";
        readonly 'hub.section.collection.intent': "Portfolio and search.";
        readonly 'hub.section.record.intent': "The selected record and what revolves around it.";
        readonly 'projection.unjoined.question': "Use case {useCaseId} reads projection {projectionId} with no derived relationship to {entity}: E4 cannot join them. Omit from the output?";
        readonly 'projection.unjoined.changeHint': "Declare an E4 relationship with realization.kind derived between {projectionId} and {entity}.";
        readonly 'hub.composition.question': "The proposed composition for the {entity} dashboard did not respect the catalogue; use the default order?";
        readonly 'hub.composition.changeHint': "Review the order and highlights of the {entity} dashboard in the next round.";
        readonly 'workflow.unreachable.question': "How should the unreachable {entity}.{state} lifecycle state be handled?";
        readonly 'workflow.unreachable.changeHint': "Add an explicit E2 journey/operation that reaches {entity}.{state} before restoring it to the compiled workflow; the E4 ontology remains unchanged.";
        readonly 'workflow.predicate.question': "The {predicateId} criterion has no effect in this version — none of its states is reachable.";
        readonly 'workflow.predicate.changeHint': "Add an E2 journey that reaches one of {states}; the E5 rule and E4 ontology remain unchanged.";
        readonly 'workflow.omit.question': "{entity} has no operated state flow in this version.";
        readonly 'workflow.omit.changeHint': "Add an E2 journey that operates a {entity} transition; the E4 ontology remains unchanged.";
        readonly 'actor.drop.question': "Actor {actor} was inferred and has no exclusive step. Drop it?";
        readonly 'actor.drop.changeHint': "An inferred external actor whose steps another actor already performs is a persona, not an access role.";
        readonly 'actor.keep.question': "Actor {actor} was inferred and has exclusive steps. Keep it?";
        readonly 'actor.keep.changeHint': "The model invented this actor; exclusive steps are the reason it remains.";
        readonly 'actor.system.question': "Actor {actor} is a system integration point, not a persona. Keep it?";
        readonly 'actor.system.changeHint': "A kind:system actor is an inbound integration, not a demographic persona.";
        readonly 'demotion.chosen': "Standard {entity} record catalogue";
        readonly 'demotion.alternative': "Keep {journey} as its own journey";
        readonly 'demotion.question': "{journey} has no decision and no handoff: should it become the standard {entity} record catalogue?";
        readonly 'dormant.question': "The {title} action stays visible, but transition {transitions} is not reachable in this version.";
        readonly 'dormant.unwritten.question': "State {entity}.{state} is reached only by a transition whose use case does not write {entity}.";
        readonly 'state.unreachable.question': "State {entity}.{state} ({reachedBy}) has no reachable transition. Connect the command that writes it.";
        readonly 'state.filtered.question': "Operation {operation} filters by unreachable state {entity}.{state}.";
        readonly 'writes.beyond.question': "Use case {useCase} records {entities}, which the journey did not name as affected. Keep those writes?";
        readonly 'writes.beyond.changeHint': "Drop the extra writes on {useCase} or add {entities} to the act step affects list.";
        readonly 'route.ambiguous.question': "Which record should the {title} screen open directly?";
        readonly 'route.ambiguous.changeHint': "The {title} screen opens without a direct record link in this version; define a single target context to enable it.";
    };
    export type Ns4PhraseKey = keyof typeof NS4_PHRASES;
    export function isNs4PhraseKey(value: string): value is Ns4PhraseKey;
    export interface Ns4PhraseHolder {
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4PhrasesNormalization {
        phrases: Partial<Record<Ns4PhraseKey, string>>;
        warnings: string[];
    }
    export function ns4Text(presentation: Ns4PhraseHolder | undefined, key: Ns4PhraseKey, params?: Record<string, string>): string;
    type Ns4WidgetName = keyof typeof NS4_WIDGET_KEYS;
    export type Ns4WidgetLabelMap<W extends Ns4WidgetName> = {
        [K in (typeof NS4_WIDGET_KEYS)[W][number]]: string;
    };
    export function ns4WidgetLabels<W extends Ns4WidgetName>(presentation: Ns4PhraseHolder | undefined, widget: W): Ns4WidgetLabelMap<W>;
    export function normalizeNs4Phrases(value: unknown): Ns4PhrasesNormalization;
    export function ns4PlannerPhrasesAppendix(): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Core" {
    import { type Ns4PhraseKey } from "_102035_/l2/agentNewSolution/helpers/ns4Text";
    export const NS4_FLOW_ID: "agentNewSolution";
    export const NS4_FLOW_VERSION: "2026-09-08-ns4-flow-v41";
    export const NS4_E4_MAX_PARALLEL: 20;
    export const NS4_E7_MAX_PARALLEL: 20;
    export const NS4_E8_MAX_PARALLEL: 20;
    export const NS4_MODULE_SCHEMA_VERSION: "2026-08-06-ns4-module-v4";
    export const NS4_PIPELINE_SCHEMA_VERSION: "2026-08-06-ns4-pipeline-v5";
    export type Ns4PermanentFlowVersion = typeof NS4_FLOW_VERSION | '2026-08-14-ns4-flow-v40' | '2026-08-14-ns4-flow-v39' | '2026-08-14-ns4-flow-v38' | '2026-08-14-ns4-flow-v37' | '2026-08-14-ns4-flow-v36' | '2026-08-14-ns4-flow-v35' | '2026-08-14-ns4-flow-v34' | '2026-08-13-ns4-flow-v33' | '2026-08-13-ns4-flow-v32' | '2026-08-13-ns4-flow-v31' | '2026-08-12-ns4-flow-v30' | '2026-08-11-ns4-flow-v24' | '2026-08-11-ns4-flow-v22' | '2026-08-10-ns4-flow-v21' | '2026-08-10-ns4-flow-v20' | '2026-08-09-ns4-flow-v19' | '2026-08-09-ns4-flow-v18' | '2026-08-08-ns4-flow-v17';
    export const NS4_PLAN_IDS: readonly ["e1-clarification", "e1-compile", "e2-journeys", "e3-access-matrix", "e4-ontology", "e4b-access-realization", "e5-rules", "e6-behaviors", "e7-realization", "e8-workspaces", "e9-navigation-compiler", "e10-validation"];
    export type Ns4PlanId = typeof NS4_PLAN_IDS[number];
    export const NS4_HUMAN_CHECKPOINT_ICON: "\uD83D\uDC64";
    export const NS4_AUTOMATED_JUDGE_ICON: "\uD83D\uDD0E";
    export type Ns4ApprovedBy = 'human' | 'auto';
    export type Ns4E1Status = 'running' | 'approved' | 'failed';
    export type Ns4E2Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E3Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E4BStatus = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E5Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E6Status = 'running' | 'waitingHuman' | 'approved' | 'failed' | 'stale';
    export type Ns4E7Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E8Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E9Status = 'running' | 'approved' | 'failed' | 'stale';
    export type Ns4E10Status = 'running' | 'approved' | 'failed';
    export type Ns4CompletedStepId = 'e1' | 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation';
    export type Ns4NextStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler' | 'e10-validation' | 'complete';
    export interface Ns4ClarificationQuestion {
        type: 'open';
        question: string;
        answer: string;
    }
    export interface Ns4Clarification {
        planId: 'e1-clarification';
        userLanguage: string;
        title: string;
        legends: string[];
        questions: Record<string, Ns4ClarificationQuestion>;
    }
    export interface Ns4Presentation {
        userLanguage: string;
        stepTitles: Record<Ns4PlanId, string>;
        phrases?: Partial<Record<Ns4PhraseKey, string>>;
    }
    export interface Ns4RootPlan {
        validPrompt: boolean;
        invalidReason?: string;
        userPrompt: string;
        presentation: Ns4Presentation;
        clarification: Ns4Clarification;
        phraseWarnings?: string[];
    }
    export const NS4_TERMINAL_CANCEL_UNSUPPORTED = "Terminal cancellation still depends on explicit collab-messages support; this review was kept open without changing the pipeline.";
    export const NS4_DESCRIBE_REQUIRED_CHANGE = "Describe the required change before submitting.";
    export interface Ns4ModuleArtifact {
        schemaVersion: typeof NS4_MODULE_SCHEMA_VERSION;
        presentation: Ns4Presentation;
        module: {
            moduleName: string;
            title: string;
            purpose: string;
            languages: string[];
        };
        designContext: {
            initialPrompt: string;
            clarification: {
                mainActors: string;
                mainGoal: string;
                boundaries: string;
            };
        };
        reviewPolicy: {
            mode: 'guided' | 'smart' | 'automatic';
        };
        solutionStrategy: {
            mode: 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
            rationale: string;
            databaseChangePolicy: 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Array<{
                actorId: string;
                title: string;
                kind: 'internal' | 'external' | 'system';
                origin: 'named' | 'inferred';
                expectedOutcome: string;
            }>;
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        specStatus: {
            flowId: typeof NS4_FLOW_ID;
            /** v17 remains readable by tsc, but isNs4Pipeline deliberately rejects it for runtime resume. */
            flowVersion: Ns4PermanentFlowVersion;
            state: 'inProgress' | 'complete';
            artifactCompleteness: 'partial' | 'full';
            completedSteps: Array<{
                stepId: Ns4CompletedStepId;
                status: 'approved';
                approvedBy: Ns4ApprovedBy;
                approvedAt: string;
                /** Present when smart skipped the human checkpoint. */
                autoReason?: string;
            }>;
            nextStep: Ns4NextStep;
            updatedAt: string;
        };
    }
    export interface Ns4PipelineState {
        schemaVersion: typeof NS4_PIPELINE_SCHEMA_VERSION;
        flowId: typeof NS4_FLOW_ID;
        flowVersion: typeof NS4_FLOW_VERSION;
        moduleName: string;
        sourcePrompt: string;
        presentation: Ns4Presentation;
        status: 'inProgress' | 'complete' | 'failed';
        /** Audit of the last explicit regeneration: which step it restarted from, and when. */
        rebuiltFrom?: Ns4RebuildFrom;
        rebuiltAt?: string;
        /** Counts from `/rebuild all` (l1/l2/l4/l5 wipe). Survives on the regenerated pipeline for runNN_*.json. */
        rebuildAll?: Ns4RebuildAllReport;
        steps: {
            e1: {
                status: Ns4E1Status;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                skippedDefaults?: {
                    productLanguages: string[];
                    defaultLanguage: string;
                    moduleName: string;
                    i18nWarnings?: string[];
                };
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e2?: {
                status: Ns4E2Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e3?: {
                status: Ns4E3Status;
                reviewRound: number;
                draftPath?: string;
                artifactPath?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4?: {
                status: Ns4E4Status;
                reviewRound: number;
                solutionMode: 'new';
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e4b?: {
                status: Ns4E4BStatus;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                repairStep?: 'e4-ontology' | 'e4b-access-realization';
                updatedAt: string;
            };
            e5?: {
                status: Ns4E5Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e6?: {
                status: Ns4E6Status;
                reviewRound: number;
                draftPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                autoReason?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e7?: {
                status: Ns4E7Status;
                planPath?: string;
                artifactPaths?: string[];
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e8?: {
                status: Ns4E8Status;
                reviewRound: number;
                skeletonPath?: string;
                artifactPaths?: string[];
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                error?: string;
                failedAt?: string;
                updatedAt: string;
            };
            e9?: {
                status: Ns4E9Status;
                artifactPaths?: string[];
                repairStep?: 'e8-workspaces' | 'e9-navigation-compiler';
                error?: string;
                failedAt?: string;
                approvedAt?: string;
                updatedAt: string;
            };
            e10?: {
                status: Ns4E10Status;
                reportPath?: string;
                artifactPaths?: string[];
                repairStep?: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>;
                error?: string;
                failedAt?: string;
                approvedBy?: Ns4ApprovedBy;
                approvedAt?: string;
                updatedAt: string;
            };
        };
        nextStep: Ns4NextStep;
        createdAt: string;
        updatedAt: string;
        /**
         * E9 audit: an E7 use case that did not become an operation. Only `degraded` is persisted at the
         * top level — a clean emit strips both fields so a prior-run `degraded` cannot come back.
         */
        useCases?: 'degraded';
        useCasesDropped?: {
            notEmitted: string[];
            approved: number;
            emitted: number;
            reasons?: Record<string, string>;
        };
        /** Recorded when `/fast` dispatches the next agent, so a re-entry of E10 does not send twice. */
        fastHandoff?: {
            to: string;
            message: string;
            at: string;
        };
    }
    export type Ns4ExistingAction = 'new' | 'resume-e1' | 'resume-e2' | 'resume-e3' | 'resume-e4' | 'resume-e4b' | 'resume-e5' | 'resume-e6' | 'resume-e7' | 'resume-e8' | 'resume-e9' | 'resume-e10' | 'resume-next' | 'collision';
    /** Steps a partial rebuild can start from. e1 is not one of them: restarting at e1 IS a total rebuild. */
    export type Ns4RebuildFrom = 'e2' | 'e3' | 'e4' | 'e4b' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /** `/rebuild all` is its own mode: wipe l1/l2/l4 of the module, then regenerate from the stored prompt. */
    export type Ns4RebuildArg = Ns4RebuildFrom | 'all';
    export interface Ns4RebuildAllReport {
        at: string;
        deleted: {
            l1: number;
            l2: number;
            l4: number;
            l5: number;
        };
        sanitized: {
            projectJsonRemoved: number;
            configJsonRemoved: number;
        };
    }
    export interface Ns4Invocation {
        fast: boolean;
        /** Explicit regeneration intent. Never inferred from prose — prose only produces a graceful stop. */
        rebuild: boolean;
        /** Set by `/rebuild all` or `/rebuild <eN>`; empty means the existing total rebuild (l4/l5 only). */
        rebuildFrom: Ns4RebuildArg | '';
        /** Suppress the next-agent handoff. Independent of `/fast`; `/nochainlane` does not match. */
        nochain: boolean;
        prompt: string;
    }
    export function parseNs4Invocation(value: string): Ns4Invocation;
    /**
     * A prompt that ASKS for a rebuild in prose and names an existing module.
     *
     * The incident this exists for: `rebuild all criar um site chamado petShop , em …`. The module name sits
     * mid-sentence, so `resolveNs4ExistingModuleToken` (which requires the WHOLE prompt to be one token) read
     * it as a new module, E1 ran, and the existence backstop killed the task — the user asked to rebuild and
     * got a terminal error.
     *
     * BOTH signals are required. Scanning tokens for an existing module name on its own would hijack an
     * ordinary creation prompt that happens to mention one ("a schedule module for petShop"); demanding
     * an explicit rebuild word keeps every prompt without one canonicalized exactly as before. The outcome is
     * only ever a message teaching the flag — nothing is written or deleted on this path.
     *
     * The rebuild word may be a flag (`/rebuild`): the slash sits where a start-or-space used to be
     * required, so the canonical form never reached this helper. Natural-language synonyms are not a
     * command; the status task names `/rebuild`.
     */
    export function detectNs4RebuildIntentModule(value: string, existingModules: ReadonlySet<string>): string;
    export function formatNs4MissingRebuildModuleMessage(existingModules: ReadonlySet<string>): string;
    export function createNs4E2Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E1Step(reviewRound?: number, adjustment?: string, previousReview?: unknown, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E2GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, coverageRepairAttempt: number, gateFeedback: string, stepTitle?: string, coverageIssueIds?: string[], policyDecisionSelections?: Array<{
        decisionId: string;
        selectedChoice: string;
    }>): mls.msg.AIAgentStep;
    export function createNs4E2CoverageRepairStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, coverageFeedback: string, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E2CoverageJudgeStep(moduleName: string, reviewRound: number, coverageRepairAttempt: number, judgeAttempt: number, stepTitle?: string, coverageIssueIds?: string[]): mls.msg.AIAgentStep;
    export function createNs4E3Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /**
     * One bounded structural repair for E3, mirroring the E2 gate repair: the model
     * sees the numbered gate findings plus the persisted invalid draft and returns a
     * complete corrected matrix through the same gate.
     */
    export function createNs4E3GateRepairStep(moduleName: string, reviewRound: number, gateRepairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4RepairStep(moduleName: string, reviewRound: number, repairAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E4FinalizeStep(moduleName: string, reviewRound: number, dependsOn: string[], entityRepairRound?: number, planRepairAttempt?: number, derivationRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4RelationshipBindingStep(moduleName: string, reviewRound: number, bindingRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number): mls.msg.AIAgentStep;
    export function createNs4E4DerivationBindingStep(moduleName: string, reviewRound: number, derivationRepairAttempt?: number, gateFeedback?: string, entityRepairRound?: number, planRepairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E4BStep(moduleName?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E5Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E6Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string, gateFeedback?: string, repairAttempt?: number, transportRetryAttempt?: number): mls.msg.AIAgentStep;
    export function createNs4E7Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export type Ns4StepOwner = 'e1' | 'e2' | 'e3' | 'e4' | 'e4b' | 'e5' | 'e6' | 'e7' | 'e8' | 'e9' | 'e10';
    /**
     * The dispatch table, next to the factories that mint the plan ids it matches. The router and the
     * factories drifted apart once — a factory emitting `e8-workspaces-round-1` against a router that
     * only knew `e8-workspaces` — and the step died before reaching any agent, with no trace to read.
     * One table, one truth, and a test that walks every factory through it.
     */
    export function resolveNs4StepOwner(planId: string): Ns4StepOwner | '';
    /**
     * The E8 plan ids live in ONE place, next to the factories that mint them. The router matched a
     * hand-written pattern once and stopped seeing the real step: a plan id the factory emits and the
     * router does not recognize is a step that dies without ever reaching its agent.
     */
    export function ns4E8StepPlanId(reviewRound: number): string;
    export function ns4E8HubRepairPlanId(reviewRound: number, attempt: number): string;
    export function isNs4E8PlanId(planId: string): boolean;
    export function createNs4E8Step(moduleName?: string, reviewRound?: number, adjustment?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    /** The one bounded repair E8 still schedules: the hub composition over its closed catalogue. */
    export function createNs4E8HubCompositionRepairStep(moduleName: string, reviewRound: number, compositionAttempt: number, gateFeedback: string, stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E9Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export function createNs4E10Step(moduleName?: string, dependsOn?: string[], stepTitle?: string): mls.msg.AIAgentStep;
    export const NS4_DEFAULT_TITLES: Record<Ns4PlanId, string>;
    export function formatNs4VisibleStepTitle(planId: Ns4PlanId, title: string): string;
    export function plainNs4StepTitle(title: string): string;
    /** Dynamic E4 children do not retain planning.planId; hook args are their stable dispatcher key. */
    export function resolveNs4DynamicWorker(value: unknown): 'e4' | 'e7' | 'e8' | '';
    export interface Ns4DynamicWorkerRequest {
        worker: 'e4' | 'e7' | 'e8' | '';
        args: string;
    }
    /**
     * collab-messages supplies the selector as hook args before a parallel prompt, but may omit those
     * args in the after-prompt callback while retaining the selector in step.prompt. Both callbacks must
     * resolve through the same ordered fallback or a valid entity payload reaches the root planner.
     */
    export function resolveNs4DynamicWorkerRequest(args: unknown, stepPrompt: unknown): Ns4DynamicWorkerRequest;
    export function normalizeNs4RootPlan(payload: unknown, sourcePrompt: string): Ns4RootPlan;
    export function buildNs4PlannedSteps(plan: Ns4RootPlan): mls.msg.AIAgentStep[];
    export function isNs4ModuleToken(value: string): boolean;
    export function normalizeNs4ModuleName(value: unknown, fallback?: string): string;
    export function resolveNs4ExistingModuleToken(value: string, existingModules: ReadonlySet<string>): string;
    export function normalizeNs4Clarification(value: unknown): Ns4Clarification;
    export function buildNs4ModuleArtifact(sourcePrompt: string, clarificationInput: unknown, approvedBy: Ns4ApprovedBy, now?: string, presentation?: Ns4Presentation): Ns4ModuleArtifact;
    export function normalizeNs4Languages(value: unknown, fallback?: string): string[];
    export function createNs4Pipeline(moduleNameInput: string, sourcePrompt: string, now?: string, presentation?: Ns4Presentation): Ns4PipelineState;
    export function markNs4E1Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, autoReason?: string, skippedDefaults?: {
        productLanguages: string[];
        defaultLanguage: string;
        moduleName: string;
        i18nWarnings?: string[];
    }): Ns4PipelineState;
    export function markNs4FastHandoff(state: Ns4PipelineState, to: string, message: string, now?: string): Ns4PipelineState;
    export function markNs4E2Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E1Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E2WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E2Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    /** A changed approved E2 contract invalidates only downstream contracts derived from journeys. */
    export function markNs4E2ImpactStale(state: Ns4PipelineState, hasJourneyImpact: boolean, now?: string): Ns4PipelineState;
    export function markNs4ModuleE2Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, invalidateDownstream?: boolean, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E3Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E3WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E3Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E3Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPath: string, now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE3Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E4WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E4Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, approvedReviewRound?: number, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE4Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E4Stale(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4BRunning(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E4BFailed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E4BApproved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE4BApproved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E5Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E5WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E5Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E5Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE5Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E6Running(state: Ns4PipelineState, reviewRound: number, now?: string): Ns4PipelineState;
    export function markNs4E6WaitingHuman(state: Ns4PipelineState, reviewRound: number, draftPath: string, now?: string): Ns4PipelineState;
    export function markNs4E6Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E6Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string, autoReason?: string): Ns4PipelineState;
    export function markNs4ModuleE6Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string, autoReason?: string): Ns4ModuleArtifact;
    export function markNs4E7Running(state: Ns4PipelineState, planPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E7Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E7Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE7Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E8Running(state: Ns4PipelineState, reviewRound?: number, skeletonPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E8Failed(state: Ns4PipelineState, failure: unknown, now?: string): Ns4PipelineState;
    export function markNs4E8Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE8Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function markNs4E9Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    export function markNs4E9Failed(state: Ns4PipelineState, failure: unknown, origin?: 'skeleton' | 'compiler', now?: string): Ns4PipelineState;
    export function markNs4E9Approved(state: Ns4PipelineState, artifactPaths: string[], now?: string): Ns4PipelineState;
    export function markNs4ModuleE9Approved(artifact: Ns4ModuleArtifact, now?: string): Ns4ModuleArtifact;
    export function markNs4E10Running(state: Ns4PipelineState, now?: string): Ns4PipelineState;
    /**
     * E10 failed on a defect of the pipeline, not of the product: nothing upstream is stale, because
     * nothing upstream is wrong. The module waits on a fixed pipeline and re-validates from E10.
     */
    export function markNs4E10PipelineDefect(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Failed(state: Ns4PipelineState, failure: unknown, repairStep: Exclude<Ns4NextStep, 'complete' | 'e10-validation'>, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10RuntimeFailed(state: Ns4PipelineState, failure: unknown, reportPath?: string, now?: string): Ns4PipelineState;
    export function markNs4E10Approved(state: Ns4PipelineState, approvedBy: Ns4ApprovedBy, now?: string, reportPath?: string, artifactPaths?: string[]): Ns4PipelineState;
    export function markNs4ModuleE10Approved(artifact: Ns4ModuleArtifact, approvedBy: Ns4ApprovedBy, now?: string): Ns4ModuleArtifact;
    export function resolveNs4ExistingAction(moduleExists: boolean, pipeline: unknown, moduleArtifactExists: boolean): Ns4ExistingAction;
    /**
     * Everything a TOTAL rebuild archives: the module's whole l4 and l5 trees.
     *
     * The whole folder, not a list of known artifacts — that is the point. A previous run leaves drafts,
     * pipeline traces (`pipeline/msgtask*.json`) and per-entity defs whose names came from ITS ontology; a
     * selective delete keeps whatever the new run happens not to overwrite, and the module ends up a mix of
     * two generations. l2 is NOT touched: it belongs to agentChangeFrontend, which has its own rebuild.
     *
     * PURE over a `mls.stor.files`-shaped map so the selection is testable without the platform.
     */
    export function listNs4RebuildDeletionKeys(files: Record<string, {
        project?: number;
        level?: number;
        folder?: string;
        status?: string;
    } | undefined>, project: number, moduleName: string): string[];
    /** eN and every step after it. */
    export function ns4RebuildRange(from: Ns4RebuildFrom): Ns4RebuildFrom[];
    /**
     * Resets eN..e10 for a partial rebuild.
     *
     * The reset is EXPLICIT and stamped (`rebuiltFrom`/`rebuiltAt`), which is what keeps rule 11 intact: an
     * approved state is never regressed by a late callback, only by an intent the user typed. The step entries
     * are dropped rather than set to a status, because e2..e10 are optional and "absent" is exactly what
     * "not done yet" means in this pipeline.
     */
    export function resetNs4PipelineForRebuild(pipeline: Ns4PipelineState, from: Ns4RebuildFrom, rebuiltAt?: string): Ns4PipelineState;
    /**
     * Drops the rebuilt range from the permanent artifact's completedSteps.
     *
     * Without this the reset is undone silently: the invocation reconciles the pipeline from
     * `specStatus.completedSteps` whenever the artifact says approved and the file still exists, so the very
     * next invocation would re-mark e10 approved and answer "pipeline encerrado" to a second /rebuild e10.
     */
    export function clearNs4ModuleCompletedStepsFrom(artifact: Ns4ModuleArtifact, from: Ns4RebuildFrom): Ns4ModuleArtifact;
    export function isNs4Pipeline(value: unknown): value is Ns4PipelineState;
    export function humanizeNs4ModuleName(moduleName: string): string;
    /** Display names of the language in the user's language, its own language and English. */
    export function ns4LanguageMentioned(language: string, userLanguage: string, foldedText: string): boolean;
    /** Lower case without diacritics, so a folded language name matches with or without marks. */
    export function foldNs4Text(value: string): string;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Resolve" {
    export type Ns4ResolutionClass = 'A' | 'B' | 'C';
    export interface Ns4SystemDecision {
        decisionId: string;
        stage: string;
        question: string;
        chosen: string;
        alternatives: string[];
        decidedBy: 'system';
        findingRef: string;
        changeHint: string;
    }
    interface Ns4ResolutionFindingBase {
        decisionId?: string;
        findingRef: string;
        stage: string;
        question: string;
        alternatives: string[];
        changeHint: string;
    }
    export interface Ns4TypeAFinding extends Ns4ResolutionFindingBase {
        classification: 'A';
    }
    export interface Ns4TypeBFinding extends Ns4ResolutionFindingBase {
        classification: 'B';
        /** The behavior already implicit in the generated artifact. */
        defaultChoice: string;
    }
    export interface Ns4TypeCFinding<TArtifact> extends Ns4ResolutionFindingBase {
        classification: 'C';
        deterministicChoice: string;
        apply: (artifact: TArtifact) => TArtifact;
    }
    export type Ns4ResolutionFinding<TArtifact> = Ns4TypeAFinding | Ns4TypeBFinding | Ns4TypeCFinding<TArtifact>;
    export interface Ns4ResolutionResult<TArtifact> {
        artifact: TArtifact;
        systemDecisions: Ns4SystemDecision[];
        unresolved: Array<Ns4TypeAFinding>;
    }
    /**
     * The single NS4 semantic-resolution boundary. Type A remains unresolved,
     * Type B records the generator's existing choice, and Type C applies its
     * caller-supplied mechanical patch before recording the decision.
     */
    export function resolveNs4Findings<TArtifact>(artifact: TArtifact, findings: Array<Ns4ResolutionFinding<TArtifact>>): Ns4ResolutionResult<TArtifact>;
}
declare module "_102035_/l2/agentNewSolution/helpers/organizationTypes" {
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, } from "_102034_/l1/mdm/defs/level1Types";
    export type { MdmPlatformCatalogArtifact, MdmPlatformService, Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, } from "_102034_/l1/mdm/defs/level1Types";
    /** Schema of the per-project solution registry written by E10. */
    export const NS4_SOLUTION_REGISTRY_SCHEMA_VERSION: "ns4-solution-registry-v1";
    export interface Ns4SolutionRegistryActor {
        actorId: string;
        kind: string;
    }
    export interface Ns4SolutionRegistryRole {
        mdmSubtype: string;
        role: string;
        namespace: string;
    }
    export interface Ns4SolutionRegistryGeneralField {
        fieldId: string;
        type: string;
        promotedBy: string;
        since: string;
    }
    /** Entities this module owns. Siblings read this list instead of opening ontology files. */
    export interface Ns4SolutionRegistryEntity {
        entityId: string;
        kind: string;
        mdmSubtype?: string;
    }
    /** Outbound events this module publishes. `on` is `Entity.transitionId` or `Entity.create`. */
    export interface Ns4SolutionRegistryEvent {
        eventId: string;
        on: string;
    }
    export interface Ns4SolutionRegistryModule {
        moduleName: string;
        actors: Ns4SolutionRegistryActor[];
        roles: Ns4SolutionRegistryRole[];
        generalFields: Ns4SolutionRegistryGeneralField[];
        entities?: Ns4SolutionRegistryEntity[];
        events?: Ns4SolutionRegistryEvent[];
        updatedAt: string;
    }
    export interface Ns4SolutionRegistryArtifact {
        schemaVersion: typeof NS4_SOLUTION_REGISTRY_SCHEMA_VERSION;
        level1SchemaVersion: string;
        modules: Ns4SolutionRegistryModule[];
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e4/contracts" {
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4Level1Subtype } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export const NS4_ONTOLOGY_SCHEMA_VERSION: "2026-09-08-ns4-ontology-v7";
    export const NS4_ONTOLOGY_SCHEMA_VERSION_V6: "2026-08-11-ns4-ontology-v6";
    export type { Ns4Level1Subtype };
    /** Human-text JSON paths the importer may rewrite. Union of entity + index shapes that share this schemaVersion. */
    export const TEXT_PATHS_2026_09_08_ns4_ontology_v7: string[];
    export const TEXT_PATHS_2026_08_11_ns4_ontology_v6: string[];
    export const TEXT_PATHS_2026_08_09_ns4_ontology_v4: string[];
    export const TEXT_PATHS_2026_08_08_ns4_ontology_v3: string[];
    export type Ns4EntityKind = 'core' | 'event' | 'supporting' | 'mdm' | 'projection' | 'valueObject';
    /**
     * Is this entity a PARTY — a natural person or an organization?
     *
     * The question decides where the record lives, and it cannot be answered by a name heuristic (the run of
     * buildFlowFsm sent Client and Project to MDM but left FieldWorker — a person — as a module table, seeded,
     * duplicating the organization's own people). Declaring it makes the rule mechanical: a party is master
     * data of the organization, so `storage.target` must be `mdm`, and the gate says so instead of hoping the
     * prompt was read.
     */
    export type Ns4EntityParty = 'person' | 'organization' | 'none';
    export type Ns4EntityOwnership = 'moduleOwned' | 'external' | 'derived';
    export type Ns4DerivationOp = 'count' | 'sum' | 'min' | 'max' | 'first' | 'groupKey';
    /** One output field of a derived projection, computed from the source named by `derivation.from`. */
    export interface Ns4DerivationAggregate {
        fieldId: string;
        op: Ns4DerivationOp;
        /** Source-entity field when the op needs one (`sum`/`min`/`max`/`first`/`groupKey`). Absent for `count`. */
        sourceField?: string;
        /**
         * Sign of a `sum` from an enum on the source. OPTIONAL so L4 written before this field keeps
         * compiling — nothing is ever migrated. Only valid with `op: 'sum'`; `field` is an enum of
         * `derivation.from`, and rows whose value is in `negativeValues` enter the sum negative.
         */
        signBy?: {
            field: string;
            negativeValues: string[];
        };
    }
    /**
     * How a derived projection is computed. OPTIONAL on the type so L4 written before this field keeps
     * compiling — nothing is ever migrated. The E4 gate requires it on every `kind: projection` +
     * `ownership: derived` this generator now produces.
     */
    export interface Ns4EntityDerivation {
        /** entityId of the persisted source; must exist in the same ontology. */
        from: string;
        /** Predicate on declared fields of the source (`status = valid`). Empty when unfiltered. */
        filter: string;
        /** One entry per output field of the projection. */
        aggregate: Ns4DerivationAggregate[];
    }
    export type Ns4ConstraintSource = 'database' | 'journey' | 'user' | 'inferred' | 'legacyCode';
    export type Ns4StorageTarget = 'mdm' | 'moduleDatabase' | 'derived' | 'external' | 'embedded';
    export type Ns4StorageScope = 'organization' | 'module' | 'platform' | 'none';
    export type Ns4RelationshipPersistenceMode = 'mdmRelationship' | 'moduleReference' | 'crossStoreReference' | 'derivedJoin' | 'externalReference' | 'embedded';
    export type Ns4RelationshipRealizationKind = 'fieldReference' | 'fieldCollection' | 'mdmRelationship' | 'derived' | 'externalReference' | 'embedded';
    export interface Ns4RelationshipEndpointBinding {
        entityId: string;
        fieldIds: string[];
    }
    /** Concrete implementation of one semantic edge using fields that already exist in E4 entities. */
    export interface Ns4RelationshipRealization {
        kind: Ns4RelationshipRealizationKind;
        ownerEntity: string;
        from: Ns4RelationshipEndpointBinding;
        to: Ns4RelationshipEndpointBinding;
        description: string;
    }
    export interface Ns4FieldConstraint {
        constraintId: string;
        kind: 'min' | 'max' | 'minLength' | 'maxLength' | 'pattern' | 'enum' | 'format' | 'unique' | 'custom';
        value: string;
        description: string;
        source: Ns4ConstraintSource;
    }
    /** Display text for one closed-domain code. Array-of-objects so the tool schema can stay additionalProperties:false. */
    export interface Ns4EnumLabel {
        code: string;
        label: string;
    }
    export interface Ns4OntologyField {
        fieldId: string;
        title: string;
        type: 'uuid' | 'string' | 'text' | 'number' | 'integer' | 'boolean' | 'money' | 'date' | 'datetime' | 'json';
        required: boolean;
        description: string;
        constraints: Ns4FieldConstraint[];
        /**
         * The literal values of an enumerated field, derived from its enum constraint (or from the entity
         * lifecycle for a status field). It is what turns a decision into a closed selector on the page
         * instead of a free text box; the constraint stays as the human-readable rule.
         */
        enum?: string[];
        /**
         * User-language labels for `enum` codes. OPTIONAL on the type so L4 written before this field keeps
         * compiling — nothing is ever migrated. New E4 runs backfill any gap with a humanized code and a
         * non-blocking systemDecision; the model should still author the user's language.
         */
        enumLabels?: Ns4EnumLabel[];
    }
    export interface Ns4LifecyclePredicate {
        predicateId: string;
        description: string;
        stateIds: string[];
        source: Ns4ConstraintSource;
    }
    /** How a lifecycle state is reached. A gate reads this without an LLM. */
    export type Ns4LifecycleReachedBy = 'actor' | 'command' | 'time';
    /**
     * One lifecycle state of an entity. A bare string in authored JSON is `reachedBy: 'actor'`.
     * `time` is computed on read and is never a workflow transition; it requires `ruleRef`.
     */
    export interface Ns4LifecycleState {
        state: string;
        reachedBy: Ns4LifecycleReachedBy;
        ruleRef?: string;
    }
    export interface Ns4OntologyEntity {
        entityId: string;
        title: string;
        description: string;
        kind: Ns4EntityKind;
        ownership: Ns4EntityOwnership;
        /**
         * A core entity with one fixed instance (a petition, an institutional page). OPTIONAL so L4
         * written before this field keeps compiling. E8 skips the record catalogue when it is present.
         */
        cardinality?: 'singleton';
        /**
         * Whether records of this entity may be corrected or removed after they exist. OPTIONAL so L4
         * written before this field keeps compiling — nothing is ever migrated; absent = editable.
         * `appendOnly` is a fact, a posting, a meter reading, a signature: E8 emits no update/delete.
         */
        mutability?: 'editable' | 'appendOnly';
        /**
         * Required by the gate for everything this generator now produces; OPTIONAL in the type so the L4
         * artifacts written before it (schema v6, no `party`) keep compiling — nothing is ever migrated.
         */
        party?: Ns4EntityParty;
        /**
         * Required by the gate when `kind === 'projection'` and `ownership === 'derived'`; OPTIONAL in the
         * type so L4 written before this field keeps compiling — nothing is ever migrated.
         */
        derivation?: Ns4EntityDerivation;
        /**
         * Required by the gate when `kind === 'mdm'`; OPTIONAL in the type so L4 written before this field
         * (schema v6) keeps compiling — nothing is ever migrated.
         */
        mdmSubtype?: Ns4Level1Subtype;
        /**
         * Module role tag `<moduleName>.<EntityId>`. Derived by the generator; not authored by the model.
         * OPTIONAL so L4 written before this field keeps compiling.
         */
        role?: string;
        /**
         * The field a person reads to recognise the record. A fieldId of this entity, or of the level-1
         * subtype when `kind === 'mdm'`. OPTIONAL in the type so v6 L4 keeps compiling; the gate requires it.
         */
        displayField?: string;
        sourceRefs: {
            journeyIds: string[];
            featureIds: string[];
            authorityRefs: string[];
        };
        fields: Ns4OntologyField[];
        lifecycleStates: Ns4LifecycleState[];
        /** The lifecycle values as a literal union; mirrors lifecycleStates and is never a second truth. */
        statusEnum?: string[];
        /** User-language labels for `lifecycleStates`. OPTIONAL on the type; new E4 runs backfill a gap. */
        lifecycleLabels?: Ns4EnumLabel[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates: Ns4LifecyclePredicate[];
        useRules: string[];
        storage: {
            target: Ns4StorageTarget;
            scope: Ns4StorageScope;
            idField?: string;
            mdmType?: string;
            notes: string;
        };
    }
    export interface Ns4OntologyRelationship {
        relationshipId: string;
        fromEntity: string;
        toEntity: string;
        type: 'oneToOne' | 'oneToMany' | 'manyToOne' | 'manyToMany';
        required: boolean;
        description: string;
        persistence: {
            mode: Ns4RelationshipPersistenceMode;
        };
        /** Absent only in the compact overview; mandatory before review and permanent emission. */
        realization?: Ns4RelationshipRealization;
    }
    export type Ns4ResolvedOntologyRelationship = Ns4OntologyRelationship & {
        realization: Ns4RelationshipRealization;
    };
    export type Ns4OntologyEntityPlan = Omit<Ns4OntologyEntity, 'fields' | 'useRules'>;
    export interface Ns4E4PlanDraft {
        planId: 'e4-ontology-plan';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntityPlan[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
    }
    export interface Ns4E4EntityDraft {
        planId: 'e4-ontology-entity';
        moduleName: string;
        reviewRound: number;
        entityId: string;
        fields: Ns4OntologyField[];
        useRules: string[];
        /** Field ids the model proposes for the organization `general` layer. Not stored on the entity. */
        promoteToGeneral?: string[];
    }
    export interface Ns4E4RelationshipBinding {
        relationshipId: string;
        realization: Ns4RelationshipRealization;
    }
    export interface Ns4E4RelationshipBindingsDraft {
        planId: 'e4-relationship-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4RelationshipBinding[];
    }
    export interface Ns4E4DerivationBinding {
        entityId: string;
        derivation: Ns4EntityDerivation;
    }
    export interface Ns4E4DerivationBindingsDraft {
        planId: 'e4-derivation-bindings';
        moduleName: string;
        reviewRound: number;
        bindings: Ns4E4DerivationBinding[];
        changeSummary?: string[];
    }
    export interface Ns4E4DerivationBindingIssue {
        code: string;
        path: string;
        message: string;
    }
    export interface Ns4E4DerivationFieldIdChange {
        entityId: string;
        before: string[];
        after: string[];
    }
    /** Binding-gate finding that the entity fan-out must repair — travels as a typed payload, not a loose string. */
    export interface Ns4E4EntityFeedback {
        entityId: string;
        feedback: string;
    }
    export interface Ns4E4Review {
        planId: 'e4-ontology-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        solutionMode: 'new';
        businessDomain: string;
        entities: Ns4OntologyEntity[];
        relationships: Ns4OntologyRelationship[];
        changeSummary: string[];
        /** Type C label backfills and Type B registrars such as NS4_E4_CORE_READ_ONLY. */
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4E4ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E4Review;
    }
    export interface Ns4OntologyEntityArtifactV5 extends Ns4OntologyEntity {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
    }
    /** Compile-only compatibility for L4 written against ontology v6. Nothing is migrated. */
    export interface Ns4OntologyEntityArtifactV6 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION_V6;
    }
    /** Compile-only compatibility for already generated v3 L4 artifacts. */
    export interface Ns4OntologyEntityArtifactV4 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion'> {
        schemaVersion: '2026-08-09-ns4-ontology-v4';
    }
    export interface Ns4OntologyEntityArtifactV3 extends Omit<Ns4OntologyEntityArtifactV5, 'schemaVersion' | 'useRules'> {
        schemaVersion: '2026-08-08-ns4-ontology-v3';
        invariants: Array<{
            invariantId: string;
            description: string;
            source: Ns4ConstraintSource;
        }>;
    }
    export type Ns4OntologyEntityArtifact = Ns4OntologyEntityArtifactV5 | Ns4OntologyEntityArtifactV6 | Ns4OntologyEntityArtifactV4 | Ns4OntologyEntityArtifactV3;
    interface Ns4OntologyIndexArtifactBase {
        moduleName: string;
        userLanguage: string;
        solutionMode: 'new';
        title: string;
        businessDomain: string;
        entities: Array<{
            entityId: string;
            title: string;
            kind: Ns4EntityKind;
            storage: Pick<Ns4OntologyEntity['storage'], 'target' | 'scope' | 'idField' | 'mdmType'>;
            definitionRef: string;
        }>;
        ontologyHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromOntologyHash: string;
        };
        systemDecisions?: Ns4SystemDecision[];
    }
    export interface Ns4OntologyIndexArtifactV5 extends Ns4OntologyIndexArtifactBase {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION;
        relationships: Ns4ResolvedOntologyRelationship[];
    }
    /** Compile-only compatibility for L4 written against ontology v6. Nothing is migrated. */
    export interface Ns4OntologyIndexArtifactV6 extends Omit<Ns4OntologyIndexArtifactV5, 'schemaVersion'> {
        schemaVersion: typeof NS4_ONTOLOGY_SCHEMA_VERSION_V6;
    }
    /** Compile-only compatibility for already generated v3/v4 L4 artifacts. */
    export interface Ns4OntologyIndexArtifactLegacy extends Ns4OntologyIndexArtifactBase {
        schemaVersion: '2026-08-09-ns4-ontology-v4' | '2026-08-08-ns4-ontology-v3';
        relationships: Ns4OntologyRelationship[];
    }
    export type Ns4OntologyIndexArtifact = Ns4OntologyIndexArtifactV5 | Ns4OntologyIndexArtifactV6 | Ns4OntologyIndexArtifactLegacy;
    export function normalizeNs4E4Review(value: unknown, fallbackModule?: string): Ns4E4Review;
    /** `inProgress` → `In progress`. Fallback when the model omitted a user-language label. */
    export function humanizeNs4EnumCode(code: string): string;
    export function normalizeNs4E4PlanDraft(value: unknown, fallbackModule?: string): Ns4E4PlanDraft;
    export function normalizeNs4E4EntityDraft(value: unknown, moduleName: string, reviewRound: number, entityId: string): Ns4E4EntityDraft;
    /**
     * Removes the derived literal union from fields before they are echoed back to an entity worker.
     * The union is a projection E4 adds for the consumers; the worker's strict tool schema forbids the
     * key, so showing it in a prompt would invite an invalid repair answer.
     */
    export function stripNs4DerivedFieldUnions<T extends {
        fields?: unknown;
    }>(value: T): T;
    export function stripNs4DerivedFieldUnions(value: Ns4OntologyField[]): Ns4OntologyField[];
    export function assembleNs4E4Review(plan: Ns4E4PlanDraft, details: Ns4E4EntityDraft[]): Ns4E4Review;
    export function normalizeNs4E4RelationshipBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4RelationshipBindingsDraft;
    export function applyNs4E4RelationshipBindings(review: Ns4E4Review, draft: Ns4E4RelationshipBindingsDraft): Ns4E4Review;
    export function normalizeNs4E4DerivationBindings(value: unknown, moduleName: string, reviewRound: number): Ns4E4DerivationBindingsDraft;
    export function applyNs4E4DerivationBindings(plan: Ns4E4PlanDraft, payload: unknown): {
        plan: Ns4E4PlanDraft;
        issues: Ns4E4DerivationBindingIssue[];
        fieldIdChanges: Ns4E4DerivationFieldIdChange[];
    };
    export function buildNs4OntologyArtifacts(review: Ns4E4Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<{
        entities: Ns4OntologyEntityArtifactV5[];
        index: Ns4OntologyIndexArtifactV5;
    }>;
    export function normalizeDerivation(value: unknown): Ns4EntityDerivation | undefined;
    /** Bare string = `actor`. After normalize, every entity carries objects. */
    export function normalizeLifecycleStates(value: unknown): Ns4LifecycleState[];
    export function lifecycleStateIds(states: ReadonlyArray<string | Ns4LifecycleState>): string[];
    export function hasLifecycleState(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): boolean;
    export function lifecycleReachedBy(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): Ns4LifecycleReachedBy;
    export function lifecycleRuleRef(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): string;
    export function isTimeLifecycleState(states: ReadonlyArray<string | Ns4LifecycleState>, state: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4EntityFields" {
    /**
     * Fields an NS artifact may name on an entity: declared `fields[]` plus the logical identity
     * `storage.idField` when that id is absent from the list (mdm after n04 is namespace-only).
     * Structural: never inferred from a field name.
     */
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export const NS4_IDENTITY_FIELD_DESCRIPTION = "Logical record identity. Required uuid named by storage.idField.";
    export type Ns4EntityFieldsSource = {
        entityId?: string;
        kind?: string;
        fields?: ReadonlyArray<{
            fieldId: string;
            type?: Ns4OntologyField['type'];
            required?: boolean;
            description?: string;
            title?: string;
            constraints?: Ns4OntologyField['constraints'];
            enum?: string[];
            enumLabels?: Ns4OntologyField['enumLabels'];
        }>;
        storage?: {
            idField?: string;
        } | null;
    };
    export function ns4EntityIdField(entity: Ns4EntityFieldsSource | undefined | null): string;
    export function ns4ResolvableFields(entity: Ns4EntityFieldsSource | undefined | null): Ns4OntologyField[];
    export function ns4ResolvableFieldIds(entity: Ns4EntityFieldsSource | undefined | null): Set<string>;
    export function ns4ResolvableFieldOf(entity: Ns4EntityFieldsSource | undefined | null, fieldId: string): Ns4OntologyField | undefined;
    /** Compact entity payload for the E4 relationship-binding prompt: exact available fields. */
    export function ns4BindingPromptEntity(entity: Ns4EntityFieldsSource & {
        entityId: string;
    }): {
        entityId: string;
        kind?: string;
        storage: Ns4EntityFieldsSource['storage'];
        fields: Array<{
            fieldId: string;
            type: Ns4OntologyField['type'];
            required: boolean;
            description: string;
        }>;
    };
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4Context" {
    export type Ns4ContextStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export interface Ns4DerivedContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        idFieldRef?: string;
    }
    export interface Ns4DerivedStepContexts {
        journeyId: string;
        stepId: string;
        stepRef: string;
        kind: Ns4ContextStepKind;
        entity: string;
        /** True when the step introduces its own entity instead of operating on an existing record. */
        creates: boolean;
        requires: Ns4DerivedContext[];
        provides: Ns4DerivedContext[];
    }
    export interface Ns4DerivedContextGraph {
        catalog: Ns4DerivedContext[];
        steps: Ns4DerivedStepContexts[];
        byStepRef: Map<string, Ns4DerivedStepContexts>;
        entryByJourneyId: Map<string, Ns4DerivedContext[]>;
    }
    export interface Ns4ContextJourneyStep {
        stepId: string;
        kind: Ns4ContextStepKind;
        entity: string;
        affects?: string[];
        targetProfile?: string;
    }
    export interface Ns4ContextJourney {
        journeyId: string;
        business: {
            actorRef: string;
            entry: {
                mode: string;
                preferredFromJourneyRef?: string;
            };
            steps: Ns4ContextJourneyStep[];
        };
    }
    export interface Ns4ContextEntity {
        entityId: string;
        ownership?: string;
        storage?: {
            target?: string;
            scope?: string;
            idField?: string;
        };
        fields?: Array<{
            fieldId: string;
        }>;
    }
    export interface Ns4ContextRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
    }
    export interface Ns4ContextSources {
        journeys: {
            journeys: Ns4ContextJourney[];
        };
        ontology: {
            entities: Ns4ContextEntity[];
            relationships: Ns4ContextRelationship[];
        };
        access?: {
            profiles: Array<{
                profileId: string;
                actorRefs: string[];
            }>;
        };
    }
    /** A context id is a pure function of its entity, so the catalog and the E9 store are entity-keyed. */
    export function ns4ContextIdOf(entity: string): string;
    /**
     * Inspect of entity X that still has no selected X, while a later step locates X, is a collection
     * summary (counts of the listing) — not getById of one record. Identity-free by construction.
     */
    export function isNs4CollectionInspect(steps: ReadonlyArray<{
        kind: string;
        entity: string;
    }>, index: number): boolean;
    /**
     * Platform-owned records are supplied by the runtime session, never selected by the user, so they
     * are not a coordination requirement of a business step.
     */
    export function isNs4PlatformOwnedEntity(entity: Ns4ContextEntity): boolean;
    export function deriveNs4Contexts(sources: Ns4ContextSources): Ns4DerivedContextGraph;
    /** Business objects the ontology must realize: exactly the entities the journeys operate on. */
    export function collectNs4JourneyEntities(journeys: {
        journeys: Ns4ContextJourney[];
    }): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e2/coverageSignals" {
    export const NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL: "moduleWithoutDecide";
    export const NS4_E2_JOURNEY_WITHOUT_PROCESS_SIGNAL: "journeyWithoutProcess";
    export interface Ns4E2StepKindHistogram {
        locate: number;
        inspect: number;
        act: number;
        decide: number;
        handoff: number;
    }
    export type Ns4E2MechanicalFindingSeverity = 'registrar';
    export interface Ns4E2MechanicalCoverageFinding {
        signalId: typeof NS4_E2_MODULE_WITHOUT_DECIDE_SIGNAL;
        severity: Ns4E2MechanicalFindingSeverity;
    }
    export interface Ns4E2MechanicalCoverageReport {
        stepKindHistogram: Ns4E2StepKindHistogram;
        findings: Ns4E2MechanicalCoverageFinding[];
        /** Journeys that carry no process: pure capture or maintenance of one record catalogue. */
        captureOnlyJourneys: Array<{
            journeyId: string;
            entity: string;
        }>;
    }
    interface Ns4E2StepSource {
        journeys: Array<{
            journeyId?: unknown;
            business: {
                steps: Array<{
                    kind: unknown;
                    entity?: unknown;
                    affects?: unknown;
                }>;
            };
        }>;
    }
    export function analyzeNs4E2MechanicalCoverage(source: Ns4E2StepSource): Ns4E2MechanicalCoverageReport;
    /**
     * A journey with no decision, no handoff and one single entity is the record catalogue of that
     * entity written as a flow. Tier 1 already owns that screen, so the module records the demotion as
     * a visible product choice instead of shipping the same catalogue twice.
     */
    export function ns4E2DemotionDecisionId(journeyId: string): string;
    export function isNs4E2DemotionDecisionId(decisionId: string): boolean;
}
declare module "_102035_/l2/agentNewSolution/steps/e2/contracts" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import { Ns4E2StepKindHistogram } from "_102035_/l2/agentNewSolution/steps/e2/coverageSignals";
    export const NS4_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-v5";
    export const NS4_JOURNEY_INDEX_SCHEMA_VERSION: "2026-08-15-ns4-journey-index-v7";
    export const NS4_REALIZED_JOURNEY_SCHEMA_VERSION: "2026-08-14-ns4-journey-realized-v5";
    export const NS4_E2_IMPACT_REPORT_SCHEMA_VERSION: "2026-08-13-ns4-e2-impact-report-v2";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_14_ns4_journey_v5: string[];
    export const TEXT_PATHS_2026_08_14_ns4_journey_realized_v5: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_v3: string[];
    export const TEXT_PATHS_2026_08_09_ns4_journey_v2: string[];
    export const TEXT_PATHS_2026_08_04_ns4_journey_v1: string[];
    export const TEXT_PATHS_2026_08_15_ns4_journey_index_v7: string[];
    export const TEXT_PATHS_2026_08_14_ns4_journey_index_v6: string[];
    export const TEXT_PATHS_2026_08_12_ns4_journey_index_v5: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_journey_index_v3: string[];
    export const TEXT_PATHS_2026_08_09_ns4_journey_index_v2: string[];
    export const TEXT_PATHS_2026_08_04_ns4_journey_index_v1: string[];
    export type Ns4JourneyEntryMode = 'coldStart' | 'contextRequired' | 'contextOrLookup' | 'eventDriven';
    export type Ns4JourneyStepKind = 'locate' | 'inspect' | 'act' | 'decide' | 'handoff';
    export type Ns4FeaturePriority = 'now' | 'next' | 'later';
    /**
     * A step names what it does and to which business record. Everything about context — who provides
     * it, what it carries, how many — is derived by helpers/ns4Context.ts from this entity, the step
     * kind, the journey sequence and the approved ontology.
     */
    export interface Ns4JourneyStep {
        stepId: string;
        kind: Ns4JourneyStepKind;
        entity: string;
        /**
         * Other business objects this act also changes. Same vocabulary as `entity`
         * (PascalCase ids, no fields, no transition). Absent when the step records only `entity`.
         */
        affects?: string[];
        title: string;
        description: string;
        featureRefs: string[];
        /** Only a handoff names the receiving E3 profile; it is the routing fact E9 compiles. */
        targetProfile?: string;
    }
    export interface Ns4JourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
        };
        steps: Ns4JourneyStep[];
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    /** Frozen shape of journeys written by flow versions before the context graph became derived. */
    export interface Ns4LegacyJourneyContext {
        contextId: string;
        businessObject: string;
        cardinality: 'one' | 'many';
        required: boolean;
        description: string;
        stateRequirement?: string;
    }
    export interface Ns4LegacyJourneyBusiness {
        actorRef: string;
        title: string;
        goal: string;
        prerequisites: Array<{
            journeyRef: string;
            reason: string;
            required: boolean;
            providesContext: string[];
        }>;
        entry: {
            mode: Ns4JourneyEntryMode;
            preferredFromJourneyRef?: string;
            carries: Ns4LegacyJourneyContext[];
        };
        steps: Array<{
            stepId: string;
            kind: Ns4JourneyStepKind;
            intent: string;
            requiresContext: string[];
            providesContext: Ns4LegacyJourneyContext[];
            result: string;
            featureRefs: string[];
        }>;
        outcome: {
            statement: string;
            evidence: string[];
        };
        useRules: string[];
    }
    export interface Ns4JourneyProposal {
        journeyId: string;
        business: Ns4JourneyBusiness;
        policyDecisions: Ns4PolicyDecision[];
    }
    /** A product choice made while generating a journey, before any human review. */
    export interface Ns4PolicyDecision {
        decisionId: string;
        question: string;
        chosen: string;
        alternatives: string[];
        /** Only the independent E2 judge may add this explanation. */
        impact?: string;
        relatedJourneyIds?: string[];
    }
    /** Durable audit record of the choice the reviewer approved. */
    export interface Ns4PolicyDecisionSelection {
        decisionId: string;
        generatedChoice: string;
        selectedChoice: string;
        selectedBy: 'human' | 'auto';
        selectedAt: string;
    }
    export interface Ns4E2Feature {
        featureId: string;
        title: string;
        priority: Ns4FeaturePriority;
        journeyStepRefs: string[];
    }
    export interface Ns4E2Review {
        planId: 'e2-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        journeys: Ns4JourneyProposal[];
        features: Ns4E2Feature[];
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4JourneyArtifactV5 extends Ns4JourneyProposal {
        schemaVersion: typeof NS4_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'pending';
            contexts: Record<string, never>;
        };
        realization: {
            status: 'pending';
            compiledFromBusinessHash: string;
            steps: never[];
            transitionRefs: never[];
        };
    }
    /** The derived context, plus the structural provenance E7 records for the compiled journey. */
    export interface Ns4JourneyResolvedContext extends Ns4DerivedContext {
        sourceRefs: string[];
        consumerStepRefs: string[];
    }
    export interface Ns4JourneyStepRealization {
        stepId: string;
        useCaseRefs: string[];
    }
    export interface Ns4JourneyArtifactV5Realized extends Omit<Ns4JourneyProposal, 'policyDecisions'> {
        schemaVersion: typeof NS4_REALIZED_JOURNEY_SCHEMA_VERSION;
        revision: number;
        businessHash: string;
        resolution: {
            status: 'compiled';
            contexts: Record<string, Ns4JourneyResolvedContext>;
        };
        realization: {
            status: 'compiled';
            compiledFromBusinessHash: string;
            steps: Ns4JourneyStepRealization[];
            transitionRefs: string[];
            realizationHash: string;
        };
    }
    /**
     * Compile-only compatibility for permanent artifacts written by previous flow versions. They are
     * never resumed or migrated; the union only keeps already-generated L4 modules type-safe.
     */
    export interface Ns4LegacyJourneyArtifact {
        schemaVersion: '2026-08-04-ns4-journey-v1' | '2026-08-09-ns4-journey-v2' | '2026-08-10-ns4-journey-v3' | '2026-08-10-ns4-journey-v4';
        journeyId: string;
        revision: number;
        business: Ns4LegacyJourneyBusiness | (Omit<Ns4LegacyJourneyBusiness, 'useRules'> & {
            businessRules: Array<{
                journeyRuleId: string;
                statement: string;
            }>;
        });
        policyDecisions?: Ns4PolicyDecision[];
        businessHash: string;
        resolution: {
            status: 'pending' | 'compiled';
            contexts: Record<string, unknown>;
        };
        realization: {
            status: 'pending' | 'compiled';
            compiledFromBusinessHash: string;
            steps: Array<{
                stepId: string;
                useCaseRefs: string[];
            }>;
            transitionRefs: string[];
            realizationHash?: string;
        };
    }
    export type Ns4JourneyArtifact = Ns4JourneyArtifactV5 | Ns4JourneyArtifactV5Realized | Ns4LegacyJourneyArtifact;
    /** A journey written by a previous flow version still declares its context graph; it is never compiled. */
    export function isNs4CurrentJourneyBusiness(value: Ns4JourneyArtifact['business']): value is Ns4JourneyBusiness;
    export interface Ns4JourneyIndex {
        schemaVersion: typeof NS4_JOURNEY_INDEX_SCHEMA_VERSION | '2026-08-14-ns4-journey-index-v6' | '2026-08-12-ns4-journey-index-v5' | '2026-08-10-ns4-journey-index-v4' | '2026-08-04-ns4-journey-index-v1' | '2026-08-10-ns4-journey-index-v3' | '2026-08-09-ns4-journey-index-v2';
        moduleName: string;
        approvedAt: string;
        approvedBy: 'human' | 'auto';
        journeys: Array<{
            journeyId: string;
            actorRef: string;
            title: string;
            goal: string;
            entryMode: Ns4JourneyEntryMode;
            businessHash: string;
            artifactPath: string;
            useCaseRefs?: string[];
        }>;
        features: Ns4E2Feature[];
        /**
         * The decisions themselves, next to the selections that answer them. This is their durable home:
         * the journey artifact carries a copy while E2 is still reviewing, and E7 rewrites the artifact as
         * realized-v5, which has no policyDecisions — everything read after E7 reads the index.
         */
        policyDecisions?: Ns4JourneyIndexPolicyDecision[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        systemDecisions?: Ns4SystemDecision[];
        realizationHash?: string;
    }
    /** A policy decision with the journey that owns it; the index is flat, journeys reference by id. */
    export interface Ns4JourneyIndexPolicyDecision extends Ns4PolicyDecision {
        journeyRef: string;
    }
    export interface Ns4E2ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E2Review;
        policyDecisionSelections: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>;
    }
    export interface Ns4E2ImpactReport {
        schemaVersion: typeof NS4_E2_IMPACT_REPORT_SCHEMA_VERSION;
        moduleName: string;
        generatedAt: string;
        stepKindHistogram: Ns4E2StepKindHistogram;
        changes: Array<{
            journeyId: string;
            reason: 'hashDivergent' | 'journeyNew' | 'journeyRemoved';
        }>;
        affectedSteps: Array<'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e7-realization'>;
    }
    export function normalizeNs4E2Review(value: unknown, fallbackModule?: string, presentation?: Ns4Presentation): Ns4E2Review;
    export function buildNs4JourneyArtifacts(review: Ns4E2Review): Promise<Ns4JourneyArtifactV5[]>;
    export function buildNs4JourneyIndex(moduleName: string, review: Ns4E2Review, artifacts: Ns4JourneyArtifactV5[], artifactPaths: string[], approvedBy: 'human' | 'auto', approvedAt: string, policyDecisionSelections?: Ns4PolicyDecisionSelection[]): Ns4JourneyIndex;
    export function buildNs4PolicyDecisionSelections(review: Ns4E2Review, selectedChoices: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>, selectedBy: 'human' | 'auto', selectedAt: string): Ns4PolicyDecisionSelection[];
    export function buildNs4E2ImpactReport(moduleName: string, previousIndex: Ns4JourneyIndex | null, artifacts: Array<Pick<Ns4JourneyArtifactV5, 'journeyId' | 'businessHash'>>, generatedAt: string, review: Pick<Ns4E2Review, 'journeys'>): Ns4E2ImpactReport;
    export function sha256Ns4(value: unknown): Promise<string>;
    export function stableNs4Stringify(value: unknown): string;
    /**
     * Turns a human-spaced or already technical business noun into the stable PascalCase id shared by
     * journeys and ontology entities. The transformation is intentionally lexical: it never translates
     * or substitutes a domain noun.
     */
    export function normalizeNs4BusinessObjectId(value: unknown): string;
    /**
     * A journey with no decision, no handoff and one single entity IS the record catalogue of that
     * entity. Tier 1 already owns that screen, so the module records the demotion as a visible product
     * choice at the E2 checkpoint instead of shipping the same catalogue twice. The decision is
     * deterministic: it is recomputed on every round and is never authored by the generator.
     */
    export function withNs4DemotionDecisions(journeys: Ns4JourneyProposal[], presentation?: Ns4Presentation): Ns4JourneyProposal[];
    /** The journeys the approved review demoted to the tier 1 record catalogue of their entity. */
    export function collectNs4DemotedJourneyIds(review: Pick<Ns4E2Review, 'journeys'>, selections?: Array<Pick<Ns4PolicyDecisionSelection, 'decisionId' | 'selectedChoice'>>): string[];
    /** Business objects that later ontology compilation must realize as entities or projections. */
    export function collectNs4RequiredJourneyBusinessObjects(review: Ns4E2Review): string[];
}
declare module "_102035_/l2/agentNewSolution/steps/e3/contracts" {
    export const NS4_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-09-ns4-access-matrix-v2";
    export const NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-10-ns4-access-matrix-v3";
    export const NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION: "2026-08-13-ns4-access-matrix-v4";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_access_matrix_v2: string[];
    export const TEXT_PATHS_2026_08_10_ns4_access_matrix_v3: string[];
    export const TEXT_PATHS_2026_08_13_ns4_access_matrix_v4: string[];
    export const TEXT_PATHS_2026_08_05_ns4_access_matrix_v1: string[];
    export type Ns4AccessProfileKind = 'internal' | 'external';
    export type Ns4AccessScopeMode = 'organization' | 'assigned' | 'own' | 'related' | 'public' | 'custom';
    export type Ns4DisclosureMode = 'fullRecord' | 'summaryOnly' | 'fieldsOnly' | 'aggregateOnly';
    export interface Ns4AccessProfile {
        profileId: string;
        title: string;
        kind: Ns4AccessProfileKind;
        description: string;
        actorRefs: string[];
        landingIntent: string;
    }
    export interface Ns4AccessAuthority {
        authorityRef: string;
        title: string;
        description: string;
        journeyStepRefs: string[];
        informationNeeds: string[];
    }
    export interface Ns4AccessGrant {
        profileRef: string;
        authorityRef: string;
        reason: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        useRules: string[];
    }
    export interface Ns4E3Review {
        planId: 'e3-access-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        changeSummary: string[];
    }
    export interface Ns4E3ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E3Review;
    }
    export interface Ns4AccessMatrixArtifactV2 {
        schemaVersion: typeof NS4_ACCESS_MATRIX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        profiles: Ns4AccessProfile[];
        authorities: Ns4AccessAuthority[];
        grants: Ns4AccessGrant[];
        accessHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromAccessHash: string;
            operationAuthorityRefs: never[];
        };
    }
    export interface Ns4AccessUseCaseAuthorityRef {
        useCaseId: string;
        authorityRef: string;
        journeyStepRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV3 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'useCasesCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            realizationHash: string;
        };
    }
    export interface Ns4AccessOperationAuthorityRef {
        operationRef: string;
        route: string;
        workspaceId: string;
        functionId: string;
        useCaseId?: string;
        authorityRefs: string[];
    }
    export interface Ns4AccessMatrixArtifactV4 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'realization'> {
        schemaVersion: typeof NS4_NAVIGATION_REALIZED_ACCESS_MATRIX_SCHEMA_VERSION;
        realization: {
            status: 'navigationCompiled';
            compiledFromAccessHash: string;
            useCaseAuthorityRefs: Ns4AccessUseCaseAuthorityRef[];
            operationAuthorityRefs: Ns4AccessOperationAuthorityRef[];
            realizationHash: string;
        };
    }
    /** Compile-only compatibility for already generated v1 L4 artifacts. */
    export interface Ns4AccessMatrixArtifactV1 extends Omit<Ns4AccessMatrixArtifactV2, 'schemaVersion' | 'grants'> {
        schemaVersion: '2026-08-05-ns4-access-matrix-v1';
        grants: Array<Omit<Ns4AccessGrant, 'useRules'> & {
            constraints: string[];
        }>;
    }
    export type Ns4AccessMatrixArtifact = Ns4AccessMatrixArtifactV4 | Ns4AccessMatrixArtifactV3 | Ns4AccessMatrixArtifactV2 | Ns4AccessMatrixArtifactV1;
    export function normalizeNs4E3Review(value: unknown, fallbackModule?: string): Ns4E3Review;
    export function buildNs4AccessMatrixArtifact(review: Ns4E3Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4AccessMatrixArtifactV2>;
}
declare module "_102035_/l2/agentNewSolution/steps/e4b/contracts" {
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessGrant, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4DerivationAggregate, Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export const NS4_ACCESS_BINDINGS_SCHEMA_VERSION: "2026-09-08-ns4-access-bindings-v1";
    export const NS4_PERSON_LOGIN_FIELD: "platformUserId";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_09_08_ns4_access_bindings_v1: string[];
    export const NS4_SYNTH_AUTHORITY_PREFIX: "synth:";
    export const NS4_LIMITED_DISCLOSURE_MODES: readonly Ns4DisclosureMode[];
    export type Ns4AnchorDirection = 'forward' | 'incoming';
    export interface Ns4AccessAnchorHop {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: Ns4AnchorDirection;
    }
    export interface Ns4AccessAnchor {
        hops: Ns4AccessAnchorHop[];
        terminus: {
            entityRef: string;
            fieldId: typeof NS4_PERSON_LOGIN_FIELD;
        };
    }
    export interface Ns4AccessBinding {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        dataScope: {
            mode: Ns4AccessScopeMode;
            description: string;
        };
        disclosure: {
            mode: Ns4DisclosureMode;
            description: string;
            allowedInformation: string[];
            deniedInformation: string[];
        };
        anchor: Ns4AccessAnchor | null;
        /** Present when `anchor` is null: organization / custom / public have no person path. */
        anchorReason?: string;
        /**
         * Machine artifact (E4B): entityId of the disclosure projection for a limited external grant.
         * Not a field on the human grant.
         */
        projectionRef?: string;
        /**
         * Machine artifact (E4B): field ids the model excluded from the disclosure view, for a human to read.
         * Not a field on the human grant.
         */
        excludedFields?: string[];
    }
    export interface Ns4SynthesizedAuthority {
        authorityRef: string;
        entityRef: string;
        profileRef: string;
        dataScope: Ns4AccessBinding['dataScope'];
        disclosure: Ns4AccessBinding['disclosure'];
        sourceGrant: {
            profileRef: string;
            authorityRef: string;
        };
        anchor: Ns4AccessAnchor | null;
    }
    export interface Ns4AccessBindingsArtifact {
        schemaVersion: typeof NS4_ACCESS_BINDINGS_SCHEMA_VERSION;
        moduleName: string;
        compiledFromAccessHash: string;
        compiledFromOntologyHash: string;
        bindings: Ns4AccessBinding[];
        synthesizedAuthorities: Ns4SynthesizedAuthority[];
        bindingsHash: string;
    }
    export interface Ns4E4BProjectionProposal {
        fields: string[];
        excludedFields: string[];
        /** aggregateOnly: derivation ops. Absent for a field-subset view (`op: first` per field). */
        aggregate?: Ns4DerivationAggregate[];
    }
    export interface Ns4E4BProposal {
        profileRef: string;
        authorityRef: string;
        entityRef: string;
        hops: Ns4AccessAnchorHop[];
        /** The model names a field the ontology does not have; the gate turns this into a finding. */
        missingField?: {
            entityRef: string;
            fieldId: string;
        };
        /** Disclosure view extracted from grant prose. Machine artifact, not a human grant field. */
        projection?: Ns4E4BProjectionProposal;
    }
    export interface Ns4E4BSources {
        moduleName: string;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        journeys: Ns4E2Review;
        accessHash: string;
        ontologyHash: string;
        /** Optional: E5 has not run yet on a first pass; present on resume/rebuild. */
        rules?: Array<{
            id: string;
            description: string;
        }>;
    }
    export interface Ns4E4BFinding {
        code: string;
        path: string;
        message: string;
        repairStep?: 'e4-ontology' | 'e4b-access-realization';
    }
    export interface Ns4E4BCompileResult {
        artifact: Ns4AccessBindingsArtifact;
        /** Disclosure views to persist as `ontology/<Entity><Profile>View.defs.ts`. Not added to the E4 index. */
        projections: Ns4OntologyEntity[];
        findings: Ns4E4BFinding[];
    }
    export function ns4SynthesizedAuthorityRef(entityRef: string, profileRef: string): string;
    export function ns4DisclosureProjectionId(entityRef: string, profileRef: string): string;
    export function ns4NeedsDisclosureProjection(grant: Ns4AccessGrant, profileKind: string | undefined): boolean;
    export function ns4GrantCoversEntity(grant: Ns4AccessGrant, entityRef: string, access: Pick<Ns4E3Review, 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): boolean;
    export function ns4EntityIdsCoveredByGrant(grant: Ns4AccessGrant, access: Pick<Ns4E3Review, 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): string[];
    /** Catalogue audience: profiles with an organization-scope grant covering the entity. */
    export function ns4CatalogueProfileIds(entityRef: string, access: Pick<Ns4E3Review, 'grants' | 'authorities'>, journeys: Pick<Ns4E2Review, 'journeys'>): string[];
    export function ns4JourneyAuthorityRefs(compiledFrom: string[], access: Pick<Ns4E3Review, 'authorities'>): string[];
    export function compileNs4AccessBindings(sources: Ns4E4BSources, proposals?: Ns4E4BProposal[]): Promise<Ns4E4BCompileResult>;
    export function isPersonEntity(entity: Ns4OntologyEntity): boolean;
    export interface Ns4AccessFieldEdge {
        entityRef: string;
        fieldId: string;
        targetEntityRef: string;
        direction: Ns4AnchorDirection;
    }
    export function ns4AccessFieldGraph(ontology: Pick<Ns4E4Review, 'relationships'>): Ns4AccessFieldEdge[];
    export function checkAnchorPath(hops: Ns4AccessAnchorHop[], startEntity: string, graph: Ns4AccessFieldEdge[], personEntities: Set<string>, path: string): {
        anchor?: Ns4AccessAnchor;
        finding?: Ns4E4BFinding;
    };
    export function missingFieldFinding(path: string, entityRef: string, fieldId: string): Ns4E4BFinding;
}
declare module "_102035_/l2/agentNewSolution/steps/e5/contracts" {
    export const NS4_RULES_SCHEMA_VERSION: "2026-08-09-ns4-rules-v2";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_rules_v2: string[];
    /** The permanent business-rule contract. Meaning lives here; consumers keep only the id. */
    export interface Ns4RuleDefinition {
        id: string;
        description: string;
    }
    export interface Ns4E5Review {
        planId: 'e5-rules-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        rules: Ns4RuleDefinition[];
        changeSummary: string[];
    }
    export interface Ns4E5ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E5Review;
    }
    export interface Ns4RulesArtifact {
        schemaVersion: typeof NS4_RULES_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        rules: Ns4RuleDefinition[];
        rulesHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromRulesHash: string;
        };
    }
    export function normalizeNs4E5Review(value: unknown, fallbackModule?: string): Ns4E5Review;
    export function buildNs4RulesArtifact(review: Ns4E5Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4RulesArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e6/contracts" {
    export const NS4_COMPOSITION_SCHEMA_VERSION: "2026-08-09-ns4-composition-v1";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_09_ns4_composition_v1: string[];
    export type Ns4AdditionalCapabilityKind = 'horizontalModule' | 'plugin';
    export type Ns4AdditionalCapabilityDecision = 'include' | 'defer';
    export interface Ns4AdditionalCapability {
        id: string;
        kind: Ns4AdditionalCapabilityKind;
        title: string;
        purpose: string;
        decision: Ns4AdditionalCapabilityDecision;
        /** True when the capability is already realized by a sibling module (reuse, never a new module). */
        existing?: boolean;
    }
    export interface Ns4E6Review {
        planId: 'e6-composition-review';
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        changeSummary: string[];
    }
    export interface Ns4E6ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E6Review;
    }
    export interface Ns4CompositionArtifact {
        schemaVersion: typeof NS4_COMPOSITION_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        analysisSummary: string;
        recommendations: Ns4AdditionalCapability[];
        compositionHash: string;
        approvedBy: 'human' | 'auto';
        approvedAt: string;
        realization: {
            status: 'pending';
            compiledFromCompositionHash: string;
        };
    }
    export function normalizeNs4E6Review(value: unknown, fallbackModule?: string): Ns4E6Review;
    export function buildNs4CompositionArtifact(review: Ns4E6Review, approvedBy: 'human' | 'auto', approvedAt: string): Promise<Ns4CompositionArtifact>;
}
declare module "_102035_/l2/agentNewSolution/steps/e7/contracts" {
    import type { Ns4E2Review, Ns4JourneyArtifact, Ns4JourneyArtifactV5Realized, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact, Ns4AccessMatrixArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import { type Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4DerivedContextGraph } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_USE_CASE_DRAFT_VERSION: "2026-09-09-ns4-usecase-draft-v4";
    export const NS4_USE_CASE_SCHEMA_VERSION: "2026-09-09-ns4-usecase-v4";
    export const NS4_USE_CASE_INDEX_SCHEMA_VERSION: "2026-09-09-ns4-usecase-index-v4";
    export const NS4_WORKFLOW_SCHEMA_VERSION: "2026-08-11-ns4-workflow-v4";
    export const NS4_WORKFLOW_INDEX_SCHEMA_VERSION: "2026-08-12-ns4-workflow-index-v5";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_09_09_ns4_usecase_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_v3: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_v2: string[];
    export const TEXT_PATHS_2026_09_09_ns4_usecase_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_usecase_index_v2: string[];
    /** Workflow artifacts are ids and transitions; no human prose. */
    export const TEXT_PATHS_2026_08_11_ns4_workflow_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_workflow_v1: string[];
    export const TEXT_PATHS_2026_08_12_ns4_workflow_index_v5: string[];
    export const TEXT_PATHS_2026_08_11_ns4_workflow_index_v4: string[];
    export const TEXT_PATHS_2026_08_10_ns4_workflow_index_v1: string[];
    export type Ns4UseCaseKind = 'query' | 'command';
    export type Ns4UseCaseFieldType = Ns4OntologyField['type'];
    export interface Ns4E7SourceHashes {
        journeys: Array<{
            journeyId: string;
            businessHash: string;
        }>;
        ontologyHash: string;
        rulesHash: string;
    }
    export interface Ns4E7PlanUseCase {
        useCaseId: string;
        title: string;
        kind: Ns4UseCaseKind;
        compiledFrom: string[];
        contexts: {
            requires: string[];
            provides: string[];
        };
    }
    export interface Ns4E7PlanDraft {
        planId: 'e7-realization-plan';
        moduleName: string;
        userLanguage: string;
        useCases: Ns4E7PlanUseCase[];
        sourceHashes: Ns4E7SourceHashes;
        presentation?: Ns4Presentation;
    }
    export interface Ns4UseCaseFieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4UseCaseInput {
        inputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseOutput {
        outputId: string;
        type?: Ns4UseCaseFieldType;
        required: boolean;
        contextId?: string;
        fieldRef?: Ns4UseCaseFieldRef;
        description: string;
    }
    export interface Ns4UseCaseEntityAccess {
        entityId: string;
        fieldRefs: string[];
    }
    /** Entities this behavior records. fieldRefs optional: omit when the whole record is written. */
    export interface Ns4UseCaseWrite {
        entityId: string;
        fieldRefs?: string[];
    }
    export interface Ns4UseCaseTransition {
        transitionId: string;
        entityRef: string;
        fromStates: string[];
        toState: string;
        useRules: string[];
    }
    export interface Ns4UseCaseError {
        errorId: string;
        description: string;
        when: string;
        useRules: string[];
    }
    export interface Ns4UseCaseDraft extends Ns4E7PlanUseCase {
        draftVersion: typeof NS4_USE_CASE_DRAFT_VERSION;
        planId: 'e7-usecase';
        moduleName: string;
        description: string;
        contexts: {
            requires: string[];
            provides: string[];
        };
        entityRefs: string[];
        writes: Ns4UseCaseWrite[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
    }
    export interface Ns4UseCaseArtifactV3 extends Omit<Ns4UseCaseDraft, 'planId' | 'draftVersion' | 'transitions'> {
        schemaVersion: typeof NS4_USE_CASE_SCHEMA_VERSION;
        transitionRefs: string[];
        useCaseHash: string;
    }
    export interface Ns4UseCaseIndexArtifactV3 {
        schemaVersion: typeof NS4_USE_CASE_INDEX_SCHEMA_VERSION;
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4WorkflowTransition extends Ns4UseCaseTransition {
        useCaseId?: string;
        trigger?: 'system';
    }
    /** Lifecycle facts are owned by E4 and copied mechanically into E7 workflows. */
    export interface Ns4WorkflowLifecycleDefinition {
        states: string[];
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
        /** Per-state `reachedBy`. Absent keys default to `actor`. `time` never enters the workflow. */
        reachedBy?: Record<string, 'actor' | 'command' | 'time'>;
    }
    export function workflowLifecycleOf(entity: {
        lifecycleStates: Array<string | {
            state: string;
            reachedBy: 'actor' | 'command' | 'time';
        }>;
        initialState?: string;
        terminalStates?: string[];
        lifecyclePredicates?: Array<{
            predicateId: string;
            stateIds: string[];
        }>;
    }): Ns4WorkflowLifecycleDefinition;
    export interface Ns4WorkflowArtifactV2 {
        schemaVersion: typeof NS4_WORKFLOW_SCHEMA_VERSION;
        moduleName: string;
        workflowId: string;
        entityRef: string;
        initialState: string;
        terminalStates: string[];
        states: string[];
        transitions: Ns4WorkflowTransition[];
        workflowHash: string;
    }
    export interface Ns4WorkflowIndexArtifactV2 {
        schemaVersion: '2026-08-11-ns4-workflow-index-v4';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifactV3 extends Omit<Ns4WorkflowIndexArtifactV2, 'schemaVersion'> {
        schemaVersion: typeof NS4_WORKFLOW_INDEX_SCHEMA_VERSION;
        systemDecisions: Ns4SystemDecision[];
    }
    export interface Ns4UseCaseArtifact extends Ns4E7PlanUseCase {
        schemaVersion: '2026-08-10-ns4-usecase-v2';
        moduleName: string;
        description: string;
        inputs: Ns4UseCaseInput[];
        outputs: Ns4UseCaseOutput[];
        reads: Ns4UseCaseEntityAccess[];
        writes: Ns4UseCaseEntityAccess[];
        useRules: string[];
        transitions: Ns4UseCaseTransition[];
        errors: Ns4UseCaseError[];
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCaseHash: string;
        generatedAt: string;
    }
    export interface Ns4UseCaseIndexArtifact {
        schemaVersion: '2026-08-10-ns4-usecase-index-v2';
        moduleName: string;
        userLanguage: string;
        sourceHashes: Ns4E7SourceHashes;
        useCases: Array<{
            useCaseId: string;
            title: string;
            kind: Ns4UseCaseKind;
            compiledFrom: string[];
            useCaseHash: string;
            artifactPath: string;
        }>;
        realizationHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-v1';
        moduleName: string;
        userLanguage: string;
        workflowId: string;
        entityRef: string;
        states: string[];
        transitions: Ns4WorkflowTransition[];
        sourceHashes: Ns4E7SourceHashes;
        workflowHash: string;
        generatedAt: string;
    }
    export interface Ns4WorkflowIndexArtifact {
        schemaVersion: '2026-08-10-ns4-workflow-index-v1';
        moduleName: string;
        userLanguage: string;
        workflows: Array<{
            workflowId: string;
            entityRef: string;
            workflowHash: string;
            artifactPath: string;
        }>;
        sourceHashes: Ns4E7SourceHashes;
        realizationHash: string;
        generatedAt: string;
    }
    /** Contexts come from the derivation, never from the journey text: E7 copies no declared name. */
    export function buildNs4E7Plan(moduleName: string, userLanguage: string, journeys: Ns4E2Review, sourceHashes: Ns4E7SourceHashes, contexts: Ns4DerivedContextGraph, presentation?: Ns4Presentation): Ns4E7PlanDraft;
    export function normalizeNs4UseCaseDraft(value: unknown, plan: Ns4E7PlanDraft, useCaseId: string): Ns4UseCaseDraft;
    export function buildNs4UseCaseArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], generatedAt: string, systemDecisions?: Ns4SystemDecision[]): Promise<{
        artifacts: Ns4UseCaseArtifactV3[];
        index: Ns4UseCaseIndexArtifactV3;
    }>;
    export function buildNs4WorkflowArtifacts(plan: Ns4E7PlanDraft, drafts: Ns4UseCaseDraft[], ontologyLifecycles: Map<string, Ns4WorkflowLifecycleDefinition>, generatedAt: string): Promise<{
        artifacts: Ns4WorkflowArtifactV2[];
        index: Ns4WorkflowIndexArtifactV3;
    }>;
    export function buildNs4RealizedJourneyArtifact(source: Ns4JourneyArtifact, useCases: Ns4UseCaseArtifactV3[], derived: Ns4DerivedContextGraph): Promise<Ns4JourneyArtifactV5Realized>;
    export function buildNs4RealizedJourneyIndex(source: Ns4JourneyIndex, journeys: Ns4JourneyArtifactV5Realized[]): Promise<Ns4JourneyIndex>;
    export function buildNs4RealizedAccessArtifact(source: Ns4AccessMatrixArtifact, useCases: Ns4UseCaseArtifactV3[]): Promise<Ns4AccessMatrixArtifactV3>;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4ForeignKeys" {
    /**
     * Where a foreign key POINTS.
     *
     * An input's `fieldRef` names the entity that OWNS the field (`BillingLaborAllocation.clientBillingSummaryId`),
     * never the entity the id refers to. Reading the target off that prefix is how the E8 picker check
     * ended up comparing an entity with itself and passing in silence, while 48 command inputs across 15
     * workspaces asked the user to pick a record the screen could not show. The target only exists in the
     * relationship graph, so it is resolved here, once, for every consumer.
     */
    export interface Ns4FkRelationship {
        fromEntity: string;
        toEntity: string;
        type: string;
        required: boolean;
        realization?: {
            ownerEntity?: string;
            from?: {
                fieldIds?: string[];
            };
        };
    }
    export interface Ns4FkParent {
        parent: string;
        fieldId: string;
        required: boolean;
    }
    /** Owner entity -> the parents it references, with the field that holds each id. */
    export function buildNs4ParentIndex(relationships: readonly Ns4FkRelationship[]): Map<string, Ns4FkParent[]>;
    /** The entity a given field of a given entity points at, or null when the field is not a key. */
    export function ns4FkParentOf(index: Map<string, Ns4FkParent[]>, entityId: string, fieldId: string): Ns4FkParent | null;
}
declare module "_102035_/l2/agentNewSolution/steps/e8/contracts" {
    import type { Ns4E2Review, Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import { type Ns4DerivedContext } from "_102035_/l2/agentNewSolution/helpers/ns4Context";
    import type { Ns4E3Review } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export { TEXT_PATHS_2026_08_14_ns4_e8_model_v1 } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export interface Ns4E8HubScore {
        entityRef: string;
        score: number;
        anchoredJourneyCount: number;
        requiredRelationshipCount: number;
        projectionCount: number;
        locateUseCaseCount: number;
    }
    /** A workspace context is exactly the derived journey context; E8 never invents another shape. */
    export type Ns4WorkspaceContext = Ns4DerivedContext;
    /**
     * The E1 prose a contentPage may quote into organisms. Detection itself is structural
     * (public external grant + singleton read) — this blob is copy, not the door.
     */
    export interface Ns4E8ModuleSignals {
        title: string;
        purpose: string;
        mainGoal?: string;
        expectedOutcomes?: Array<{
            outcomeId?: string;
            title: string;
            description: string;
        }>;
        inScope?: string[];
        outOfScope?: string[];
        boundaries?: string;
    }
    /** The approved contracts every E8 derivation reads. */
    export interface Ns4E8Sources {
        journeys: Ns4E2Review;
        access: Ns4E3Review;
        ontology: Ns4E4Review;
        useCases: Ns4UseCaseArtifactV3[];
        workflows: Ns4WorkflowArtifactV2[];
        policyDecisionSelections?: Ns4PolicyDecisionSelection[];
        module?: Ns4E8ModuleSignals;
        presentation?: Ns4Presentation;
        accessBindings?: Ns4AccessBindingsArtifact;
        /** Disclosure views loaded by projectionRef; not listed on the E4 ontology index. */
        disclosureProjections?: Ns4OntologyEntity[];
    }
    /** E9/E10 compile against the E4 index plus disclosure views that E8 already pointed at. */
    export function ns4OntologyWithDisclosure(ontology: Ns4E4Review, projections?: readonly Ns4OntologyEntity[]): Ns4E4Review;
    export interface Ns4E8Edge {
        from: string;
        to: string;
        carries: string[];
        preferredFromJourneyRef?: string;
    }
    export function deriveE8HubScore(sources: Ns4E8Sources, derived?: import("/_102035_/l2/agentNewSolution/helpers/ns4Context.js").Ns4DerivedContextGraph): Ns4E8HubScore[];
    export function isPlatformOwnedEntity(entity: Ns4E4Review['entities'][number]): boolean;
    /**
     * Compile-only compatibility for workspaces written by the previous E8 model (runs 38-44). They are
     * never read or migrated — the union exists so already-generated L4 folders keep type-checking.
     */
    export interface Ns4WorkspaceArtifact {
        schemaVersion: string;
        moduleName: string;
        workspaceId: string;
        kind: string;
        title: string;
        description: string;
        anchorEntity?: string;
        profileRefs: string[];
        pageContext: Array<Record<string, unknown>>;
        scenarios: Array<Record<string, unknown>>;
        viewCall: {
            uses: Array<Record<string, unknown>>;
        };
        commands: string[];
        invalidations: Array<{
            useCaseId: string;
            sliceIds: string[];
        }>;
        skeletonHash: string;
        workspaceHash: string;
    }
    export interface Ns4WorkspaceIndex {
        schemaVersion: string;
        moduleName: string;
        userLanguage: string;
        workspaces: Array<Record<string, unknown>>;
        hubs: Array<Record<string, unknown>>;
        menu: Record<string, unknown>;
        skeletonHash: string;
        systemDecisions: Array<Record<string, unknown>>;
        approvedBy: string;
        approvedAt: string;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e8/model" {
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E8Sources } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export const NS4_E8_MODEL_VERSION: "2026-08-14-ns4-e8-model-v1";
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_14_ns4_e8_model_v1: string[];
    export type Ns4WorkspaceTier = 'recordCatalogue' | 'journey' | 'hub' | 'projection' | 'contentPage';
    /** Organisms of type `content` use these roles; they exist only on a `contentPage`. */
    export type Ns4E8ContentRole = 'hero' | 'richText' | 'imageSet' | 'ctaLink';
    /**
     * The only origins a page can render by, in the vocabulary the frontend actually reads from an
     * operation input: userInput is a form field, selectedEntity is a picker over a query on the page,
     * routeParam comes from the URL, and the rest is resolved at runtime and never rendered.
     */
    export type Ns4E8InputSource = 'userInput' | 'selectedEntity' | 'routeParam' | 'actorSession' | 'systemDefault';
    /**
     * The record-owner handle: a field that points at a `party: person` entity (its own identity, or a
     * foreign key to one) when every E3 grant that operates the record is `dataScope.mode: own` — or
     * when the session actor is that person (an `own`/`assigned`/`related` grant). Never a field name.
     */
    export function isNs4OwnerHandleInput(input: {
        fieldRef: Ns4E8FieldRef;
        inputId?: string;
    }, sources: Ns4E8Sources): boolean;
    export type Ns4E8AccessPatternKind = 'list' | 'getById' | 'create' | 'update' | 'delete' | 'transition' | 'commandInput';
    export interface Ns4E8FieldRef {
        entityId: string;
        fieldId: string;
    }
    export interface Ns4E8Input {
        inputId: string;
        fieldRef: Ns4E8FieldRef;
        source: Ns4E8InputSource;
        required: boolean;
        description: string;
        /** The literal union of an enumerated field, carried from the approved ontology. */
        enumValues?: string[];
        /** Present when the input is not the borrowed fieldRef's type (`page`/`pageSize` are numbers). */
        type?: 'number' | 'boolean' | 'string';
    }
    /**
     * One operation of the module. A journey step compiles into the E7 use case it already owns; a
     * record catalogue synthesizes its five operations from the ontology (list, getById, create,
     * update, and delete or the mdm inactivate/reactivate pair), because E7 only compiles journeys
     * and a catalogue is not a journey. getById is emitted even when no page consumes it.
     */
    /**
     * Master-data semantics of one operation. Master data is referenced by other
     * records, so an mdm catalogue deactivates instead of deleting.
     *
     * It is ONE optional block on purpose. The backend generator reads this artifact
     * as JSON and its accessPattern vocabulary is a closed set, so the lifecycle pair
     * keeps `kind: 'update'` — a command that mutates one identified record, which the
     * consumer already understands — and the meaning travels here. A consumer that
     * ignores the block behaves exactly as before.
     */
    export interface Ns4E8MdmSemantics {
        /** The command replaces a hard delete: route it to the MDM record lifecycle. */
        lifecycle?: 'inactivate' | 'reactivate';
        /** Optional request flag on a list: absent means only active records. */
        activeFilterInput?: 'includeInactive';
        /**
         * Response member carrying the situation. Derived from the MDM record lifecycle,
         * so it is NOT an ontology field and deliberately has no field ref: the ontology
         * declares no `active` field and the model must not invent one.
         */
        situationOutput?: 'active';
    }
    export interface Ns4E8Operation {
        operationId: string;
        title: string;
        kind: 'query' | 'command';
        entityRef: string;
        entityRefs: string[];
        accessPattern: {
            kind: Ns4E8AccessPatternKind;
            pagination?: 'optional';
        };
        inputs: Ns4E8Input[];
        outputRefs: string[];
        useRules: string[];
        transitionRefs: string[];
        story: string[];
        /** Present when the operation is an approved E7 use case; absent when the catalogue derived it. */
        useCaseId?: string;
        /** E3 authority refs or synthesized `synth:<entity>:<profile>` ids. Never empty. */
        authorityRefs: string[];
        /** Present only on a catalogue operation of an entity whose storage.target is mdm. */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4E8BffCall {
        bffId: string;
        kind: 'query' | 'command';
        operationId: string;
        outputKind: 'object' | 'list' | 'paginated';
        entityRef: string;
        /**
         * Which LOCAL call feeds each input of this one. Operations are shared and calls are per workspace,
         * so "where the user picks this record from" is a property of the call, never of the operation.
         * Without it the screen knows an id must be chosen and not which query to choose it from.
         */
        inputSources?: Array<{
            inputId: string;
            bffId: string;
        }>;
    }
    export type Ns4E8OrganismRole = 'primarySurface' | 'detailPanel' | 'filterControl' | 'contextualAction' | Ns4E8ContentRole;
    export interface Ns4E8Organism {
        role: Ns4E8OrganismRole;
        /** Present only on a content organism (hero/richText/imageSet/ctaLink). Never on a data-bound surface. */
        type?: 'content';
        dataSource?: string;
        action?: string;
        /** A picker is a query rendered to choose the record another call consumes. summary is counts of that list, not a row. */
        usage?: 'picker' | 'summary';
        /** Query bffId whose optional list inputs (search/sort) this filterControl drives. */
        attachTo?: string;
    }
    export interface Ns4E8Section {
        sectionId: string;
        intent: string;
        organisms: Ns4E8Organism[];
    }
    export interface Ns4E8ModelWorkspace {
        workspaceId: string;
        tier: Ns4WorkspaceTier;
        title: string;
        purpose: string;
        /** Classic workspace kind: operation, workflow, landing or record. */
        kind: 'operation' | 'workflow' | 'landing' | 'record';
        entity: string;
        workflowId?: string;
        actors: string[];
        profileRefs: string[];
        featureRefs: string[];
        hostedStepRefs: string[];
        journeyRef?: string;
        categoryRef: string;
        bffCalls: Ns4E8BffCall[];
        sections: Ns4E8Section[];
        /** Only a hub carries the closed catalogue its composition call may order and name. */
        hubCatalogue?: Ns4E8HubCatalogue;
        /** Workspaces this one links to; the site map turns them into navigation edges. */
        navigation?: Ns4E8NavigationTarget[];
    }
    export interface Ns4E8HubCatalogueItem {
        itemId: string;
        kind: 'projectionTile' | 'relatedList' | 'action' | 'pending';
        label: string;
        entityRef: string;
        /** The workspace the item belongs to; never invented by the composition call. */
        targetRef: string;
        /**
         * For an item the hub READS: the operation behind it. Operations are shared across the module and
         * calls are per workspace, so a tile becomes a local call of the hub over the same operation — an
         * organism only ever consumes a call of its own workspace.
         */
        sourceOperationId?: string;
        sourceBffId?: string;
        /** The shape the source call declares; a list read as an object would project a single record. */
        sourceOutputKind?: 'object' | 'list' | 'paginated';
        score: number;
    }
    /**
     * A journey reached from the hub is NAVIGATION, not an embedded command: it leaves the sections and
     * travels to the site map, carrying the prominence and order the composition chose.
     */
    export interface Ns4E8NavigationTarget {
        targetWorkspaceId: string;
        label: string;
        prominence: 'primary' | 'contextual';
        order: number;
    }
    export interface Ns4E8HubCatalogue {
        anchorEntity: string;
        items: Ns4E8HubCatalogueItem[];
    }
    export interface Ns4E8HubComposition {
        workspaceId: string;
        title: string;
        /** Catalogue item ids, in display order. Never a new id. */
        tileOrder: string[];
        primaryActionIds: string[];
        labels: Array<{
            itemId: string;
            label: string;
        }>;
        menuGroups: Array<{
            groupId: string;
            label: string;
            itemIds: string[];
        }>;
    }
    export interface Ns4E8MenuEntry {
        workspaceId: string;
        label: string;
        featureRef: string;
        tier: Ns4WorkspaceTier;
        profileRefs: string[];
    }
    export interface Ns4E8Model {
        planId: 'e8-workspace-model';
        schemaVersion: typeof NS4_E8_MODEL_VERSION;
        moduleName: string;
        userLanguage: string;
        title: string;
        reviewRound: number;
        hubEntity: string;
        workspaces: Ns4E8ModelWorkspace[];
        operations: Ns4E8Operation[];
        /** The menu lists places only: catalogues, hubs, projections and content pages. A journey is never a menu item. */
        menu: Ns4E8MenuEntry[];
        landings: Ns4E8Landing[];
        systemDecisions: Ns4SystemDecision[];
        modelHash?: string;
    }
    /**
     * Why this profile lands on this workspace. Closed machine token — never prose, never
     * `landingIntent` (that stays E3 copy for the human and the CF).
     */
    export type Ns4E8LandingReason = 'exclusive' | 'firstJourney' | 'rank';
    export interface Ns4E8Landing {
        profileRef: string;
        workspaceId: string;
        reason: Ns4E8LandingReason;
    }
}
declare module "_102035_/l2/agentNewSolution/steps/e9/classic" {
    import { type Ns4AccessMatrixArtifact, type Ns4AccessMatrixArtifactV4 } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyField } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4E8Input, Ns4E8MdmSemantics, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export const NS4_CLASSIC_WORKSPACE_VERSION: "2026-08-14-ns4-classic-workspace-v6";
    export const NS4_E9_OUTPUT_REF_UNKNOWN: "NS4_E9_OUTPUT_REF_UNKNOWN";
    /** Human-text JSON paths the importer may rewrite. Classic L4 has no schemaVersion on operations/siteMap. */
    export const TEXT_PATHS_2026_08_14_ns4_classic_workspace_v6: string[];
    export const TEXT_PATHS_CLASSIC_WORKSPACE: string[];
    export const TEXT_PATHS_CLASSIC_OPERATION: string[];
    export const TEXT_PATHS_CLASSIC_SITE_MAP: string[];
    export class Ns4E9OutputRefError extends Error {
        readonly code: "NS4_E9_OUTPUT_REF_UNKNOWN";
        constructor(ref: string);
    }
    export interface Ns4ClassicField {
        name: string;
        from: string;
        type?: string;
        required?: boolean;
        item?: {
            fields: Ns4ClassicField[];
        };
    }
    export interface Ns4ClassicBffCall {
        bffId: string;
        kind: 'query' | 'command';
        uses: Array<{
            operationId: string;
        }>;
        input: Array<{
            name: string;
            from: string;
            required?: boolean;
            source: string;
            sourceRef?: string;
            type: string;
            enumValues?: string[];
        }>;
        output: {
            kind: 'object' | 'list' | 'paginated';
            fields: Ns4ClassicField[];
        };
        route: string;
    }
    export interface Ns4ClassicWorkspace {
        workspaceId: string;
        title: string;
        actors: string[];
        kind: string;
        entity: string;
        workflowId?: string;
        bffCalls: Ns4ClassicBffCall[];
        sections: Array<{
            sectionId: string;
            intent: string;
            organisms: Array<Record<string, string>>;
        }>;
        operationIds: string[];
        purpose: string;
        presentation: {
            categoryRef: string;
            confidence: number;
            classificationNote: string;
        };
        sliceHash: string;
    }
    export interface Ns4ClassicOperation {
        operationId: string;
        title: string;
        actors: string[];
        entity: string;
        kind: string;
        reads: string[];
        writes: string[];
        rulesApplied: string[];
        story: {
            actor: string;
            goal: string;
            steps: string[];
            outcome: string;
        };
        accessPattern: {
            kind: string;
            description: string;
            entity: string;
            keyField: string;
            pagination: string;
            selection: string;
            output: string[];
        };
        outputShape: {
            kind: 'object' | 'list' | 'paginated';
            fields: Array<{
                name: string;
                type: string;
                required: boolean;
                fieldRef?: string;
                item?: {
                    fields: Array<{
                        name: string;
                        type: string;
                        required: boolean;
                        fieldRef: string;
                    }>;
                };
            }>;
        };
        inputs: Array<{
            inputId: string;
            fieldRef: string;
            required: boolean;
            source: string;
            description: string;
            enumValues?: string[];
            type?: string;
        }>;
        pageId: string;
        commandName: string;
        bffName: string;
        /**
         * Carried verbatim from the model when the operation is a master-data catalogue
         * operation. It is what lets the backend generator route the lifecycle pair to
         * the MDM facade and keep the list active-only. Optional, so a consumer that
         * ignores it is unaffected.
         */
        mdm?: Ns4E8MdmSemantics;
    }
    export interface Ns4ClassicSiteMap {
        moduleName: string;
        note: string;
        workspaces: Array<{
            workspaceId: string;
            title: string;
            actors: string[];
            kind: string;
            entity: string;
            operationIds: string[];
            purpose: string;
        }>;
        landings: Array<{
            actorId: string;
            workspaceId: string;
            reason: string;
        }>;
        navigationEdges: Array<{
            from: string;
            to: string;
            operationId: string;
            description: string;
            prominence?: 'primary' | 'contextual';
            order?: number;
        }>;
        workspaceIds: string[];
    }
    /** `<operationId>.<inputId>`: the only path both consumers know how to trace back. */
    export function ns4ClassicFrom(operationId: string, member: string): string;
    export type Ns4ClassicUseCaseWrites = Array<{
        useCaseId: string;
        writes?: Array<{
            entityId: string;
        }>;
    }>;
    export function transposeNs4ClassicOperation(model: Ns4E8Model, operation: Ns4E8Operation, ontology: Ns4E4Review, useCases?: Ns4ClassicUseCaseWrites): Ns4ClassicOperation;
    export function transposeNs4ClassicWorkspace(model: Ns4E8Model, workspace: Ns4E8ModelWorkspace, operations: Map<string, Ns4E8Operation>, ontology: Ns4E4Review, sliceHash: string): Ns4ClassicWorkspace;
    export function fieldTypeOf(ontology: Ns4E4Review, entityId: string, fieldId: string): Ns4OntologyField['type'];
    type ClassicOutputField = {
        name: string;
        type: string;
        required: boolean;
        fieldRef: string;
    };
    /**
     * The wire shape is what E8 declared in outputRefs. A catalogue command whose refs are only the
     * identity still projects the entity fields it always did, so modules without a joined projection
     * keep today's outputShape. An unknown ref is a blocking E9 finding, never a silent `unknown`.
     */
    export function resolveClassicOutputFields(operation: Ns4E8Operation, ontology: Ns4E4Review): ClassicOutputField[];
    /** One TypeScript contract file per bffCall, byte-compatible with what the CFE reads today. */
    export function buildNs4ClassicContractSource(args: {
        moduleName: string;
        workspaceId: string;
        call: Ns4ClassicBffCall;
        fileRef: string;
        sourceRef: string;
    }): string;
    export function buildNs4ClassicSiteMap(model: Ns4E8Model, classic: Ns4ClassicWorkspace[]): Ns4ClassicSiteMap;
    /** Declared collection name on the wire — never the generic `items`. */
    export function collectionFieldName(entityId: string): string;
    export interface Ns4ClassicL4 {
        workspaces: Ns4ClassicWorkspace[];
        operations: Ns4ClassicOperation[];
        contracts: Array<{
            workspaceId: string;
            bffId: string;
            route: string;
            source: string;
        }>;
        siteMap: Ns4ClassicSiteMap;
    }
    export function buildNs4NavigationRealizedAccess(source: Ns4AccessMatrixArtifact, model: Ns4E8Model, classic: Ns4ClassicL4): Promise<Ns4AccessMatrixArtifactV4>;
    /** The whole transposition: what E9 writes to L4 from an approved E8 model. */
    export function compileNs4ClassicL4(model: Ns4E8Model, ontology: Ns4E4Review, useCases?: Ns4ClassicUseCaseWrites): Promise<Ns4ClassicL4>;
    export type Ns4ClassicInput = Ns4E8Input;
}
declare module "_102035_/l2/agentNewSolution/steps/e10/contracts" {
    import { type Ns4JourneyIndex, type Ns4PolicyDecisionSelection } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4UseCaseIndexArtifactV3, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4SystemDecision } from "_102035_/l2/agentNewSolution/helpers/ns4Resolve";
    import type { Ns4E2Review } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4E4Review, Ns4OntologyEntity } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4UseCaseArtifactV3, Ns4WorkflowArtifactV2 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4E8Model } from "_102035_/l2/agentNewSolution/steps/e8/model";
    import type { Ns4ClassicL4 } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    import type { Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export const NS4_E10_VALIDATION_REPORT_VERSION: "2026-08-15-ns4-e10-validation-report-v2";
    export const NS4_L5_TODO_FRONTEND_VERSION: "2026-08-13-ns4-todo-frontend-v1";
    export const NS4_L5_TODO_BACKEND_VERSION: "2026-08-13-ns4-todo-backend-v1";
    export const NS4_L5_PROCESS_VERSION: "2026-08-13-ns4-process-v1";
    export const NS4_E10_MENU_LIMIT: 7;
    export type Ns4E10RepairStep = 'e2-journeys' | 'e3-access-matrix' | 'e4-ontology' | 'e4b-access-realization' | 'e5-rules' | 'e6-behaviors' | 'e7-realization' | 'e8-workspaces' | 'e9-navigation-compiler';
    /** E10 validates the approved E8 model against the classic L4 that E9 actually wrote to disk. */
    export interface Ns4E10Sources {
        moduleName: string;
        userLanguage: string;
        presentation?: Ns4Presentation;
        journeys: Ns4E2Review;
        journeyIndex: Ns4JourneyIndex;
        ontology: Ns4E4Review;
        ontologyIndex: Ns4OntologyIndexArtifact;
        rules: Ns4RulesArtifact;
        access: Ns4AccessMatrixArtifact;
        accessBindings?: Ns4AccessBindingsArtifact;
        disclosureProjections?: Ns4OntologyEntity[];
        useCases: Ns4UseCaseArtifactV3[];
        useCaseIndex: Ns4UseCaseIndexArtifactV3;
        workflows: Ns4WorkflowArtifactV2[];
        workflowIndex: Ns4WorkflowIndexArtifactV2 | Ns4WorkflowIndexArtifactV3;
        model: Ns4E8Model;
        /** What E9 emitted, read back from L4: the staleness check compares it to a fresh compilation. */
        saved: Ns4ClassicL4;
    }
    export interface Ns4E10Issue {
        code: string;
        path: string;
        message: string;
        repairStep?: Ns4E10RepairStep;
    }
    export interface Ns4E10CheckSummary {
        checkId: 'A1-resolution' | 'A2-journeys' | 'A3-decisions' | 'A4-disclosure' | 'A5-fsm' | 'A6-staleness' | 'A7-warnings' | 'A8-dormant-commands' | 'A9-authority';
        status: 'passed' | 'failed' | 'reported';
        errorCount: number;
        warningCount: number;
        registrarCount: number;
    }
    export interface Ns4L5NavigationItem {
        id: string;
        label: string;
        href: string;
        description: string;
        actors: string[];
        workspaceId: string;
        scenarioId: string;
        sectionId: string;
        hub?: string;
    }
    export interface Ns4L5HeaderLink {
        id: string;
        label: string;
        href: string;
        actors: string[];
        manageable: true;
        hub?: string;
    }
    export interface Ns4L5ModuleNavigation {
        moduleId: string;
        basePath: string;
        userLanguage: string;
        navigation: Ns4L5NavigationItem[];
        headerLinks: Ns4L5HeaderLink[];
    }
    export interface Ns4E10ValidationReport {
        schemaVersion: typeof NS4_E10_VALIDATION_REPORT_VERSION;
        moduleName: string;
        userLanguage: string;
        finalStatus: 'passed' | 'failed';
        checks: Ns4E10CheckSummary[];
        errors: Ns4E10Issue[];
        warnings: Ns4E10Issue[];
        registrars: Ns4E10Issue[];
        policyDecisions: Ns4PolicyDecisionSelection[];
        systemDecisions: Ns4SystemDecision[];
        repairStep?: Ns4E10RepairStep;
        /**
         * The failure is a defect of the pipeline itself, not of the product: no step can repair it, so
         * nothing is marked stale and the module waits for a fixed pipeline instead of re-running whole.
         */
        pipelineDefect?: true;
        sourceHashes: {
            journeys: Array<{
                journeyId: string;
                businessHash: string;
            }>;
            accessHash: string;
            ontologyHash: string;
            rulesHash: string;
        };
        counts: {
            journeys: number;
            workspaces: number;
            operations: number;
            contracts: number;
            decisions: number;
        };
        menuPreview: Ns4L5ModuleNavigation;
        reportHash: string;
    }
    /**
     * e10 always EMITS 'toCreate', but the todo file is the ledger the downstream agents own: changeBackend
     * and changeFrontend flip each owner to 'inProgress' and 'done' in place, keeping the `satisfies` the
     * generator wrote. Pinning the literal made the artifact stop type-checking as soon as work progressed —
     * 264 TS2322 in one module's todoFrontend. The type describes the file, so it carries the whole lifecycle.
     */
    export type Ns4L5OwnerStatus = 'toCreate' | 'inProgress' | 'done';
    export interface Ns4L5FrontendOwner {
        ownerType: 'workspace' | 'contract';
        ownerId: string;
        workspaceId: string;
        statusFrontend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5BackendOwner {
        ownerType: 'useCase';
        ownerId: string;
        statusBackend: Ns4L5OwnerStatus;
    }
    export interface Ns4L5TodoFrontendArtifact {
        schemaVersion: typeof NS4_L5_TODO_FRONTEND_VERSION;
        layer: 'frontend';
        moduleName: string;
        owners: Ns4L5FrontendOwner[];
    }
    export interface Ns4L5TodoBackendArtifact {
        schemaVersion: typeof NS4_L5_TODO_BACKEND_VERSION;
        layer: 'backend';
        moduleName: string;
        owners: Ns4L5BackendOwner[];
    }
    export interface Ns4L5ProcessArtifact {
        schemaVersion: typeof NS4_L5_PROCESS_VERSION;
        moduleName: string;
        sourceHashes: Ns4E10ValidationReport['sourceHashes'];
        counts: Ns4E10ValidationReport['counts'];
        validation: {
            status: 'passed';
            reportPath: string;
            reportHash: string;
            warningCount: number;
            registrarCount: number;
        };
        next: {
            frontend: 'todoFrontend';
            backend: 'todoBackend';
        };
        processHash: string;
    }
    export interface Ns4E10Delivery {
        config: Record<string, unknown>;
        moduleNavigation: Ns4L5ModuleNavigation;
        todoFrontend: Ns4L5TodoFrontendArtifact;
        todoBackend: Ns4L5TodoBackendArtifact;
        process: Ns4L5ProcessArtifact;
    }
    /**
     * The L5 menu preview. The frontend rebuilds navigation as E8 `model.menu` ∩ materialized pages
     * (nodejsSaveConfigJson.ts), with `/<module>/<workspaceId>` as the href — this mirrors that
     * derivation so the report shows the menu the module will actually have.
     */
    export function compileNs4L5ModuleNavigation(sources: Ns4E10Sources): Ns4L5ModuleNavigation;
    export function compileNs4E10Delivery(sources: Ns4E10Sources, report: Ns4E10ValidationReport, existingConfig: unknown, projectId: number): Promise<Ns4E10Delivery>;
    export function mergeNs4L5Config(existing: unknown, projectId: number, moduleNavigation: Ns4L5ModuleNavigation): Record<string, unknown>;
}
declare module "_102035_/l2/agentNewSolution/steps/e1/contracts" {
    import { Ns4ApprovedBy, Ns4ModuleArtifact, Ns4Presentation } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type Ns4ReviewPolicy = 'guided' | 'smart' | 'automatic';
    export type Ns4SolutionStrategy = 'newSolution' | 'modernizePreserveDatabase' | 'modernizeEvolveDatabase' | 'replaceAndMigrateData';
    export type Ns4DatabaseChangePolicy = 'new' | 'forbidden' | 'additiveControlled' | 'replacement';
    export type Ns4ActorKind = 'internal' | 'external' | 'system';
    export type Ns4ActorOrigin = 'named' | 'inferred';
    /** Human-text JSON paths the importer may rewrite. Metadata per schemaVersion, not an artifact field. */
    export const TEXT_PATHS_2026_08_06_ns4_module_v4: string[];
    /** E1 business actor. `origin` is `named` only when the request itself names the profile. */
    export interface Ns4BusinessActor {
        actorId: string;
        title: string;
        kind: Ns4ActorKind;
        origin: Ns4ActorOrigin;
        expectedOutcome: string;
    }
    export interface Ns4E1Review {
        planId: 'e1-review';
        reviewRound: number;
        userLanguage: string;
        reviewPolicy: {
            mode: Ns4ReviewPolicy;
        };
        module: {
            moduleName: string;
            title: string;
            purpose: string;
        };
        strategy: {
            mode: Ns4SolutionStrategy;
            rationale: string;
            databaseChangePolicy: Ns4DatabaseChangePolicy;
            modernization?: {
                sourceSystemName: string;
                sourceTechnology?: string;
                databaseEngine?: string;
                databaseVersion?: string;
                schemaAvailability: 'uploadAtE4' | 'metadataAtE4' | 'notAvailableYet';
                notes?: string;
            };
        };
        businessScope: {
            mainGoal: string;
            actors: Ns4BusinessActor[];
            expectedOutcomes: Array<{
                outcomeId: string;
                title: string;
                description: string;
            }>;
            inScope: string[];
            outOfScope: string[];
        };
        localization: {
            productLanguages: string[];
            defaultLanguage: string;
            defaultLocale?: string;
            currency?: string;
            timeZone?: string;
            primaryMarket?: string;
        };
        declaredConstraints: {
            mandatoryIntegrations: Array<{
                dependencyId: string;
                title: string;
                kind: 'externalSystem' | 'platform' | 'unknown';
                reason: string;
            }>;
            regulatoryNotes?: string;
            criticalNotes?: string;
        };
        changeSummary: string[];
        /**
         * Product languages the normalizer discarded for lacking user provenance (run02 102047: the LLM
         * invented en/es for a pt-BR-only request). Trace-only: never copied into the l4 artifact.
         */
        i18nWarnings?: string[];
    }
    export interface Ns4E1ReviewEvent {
        action: 'approve' | 'requestChanges' | 'cancel';
        adjustment: string;
        review: Ns4E1Review;
    }
    export interface Ns4E1ReviewIssue {
        severity: 'error' | 'warning';
        code: string;
        message: string;
        path?: string;
    }
    export interface Ns4E1ReviewGate {
        ok: boolean;
        issues: Ns4E1ReviewIssue[];
    }
    export function normalizeNs4E1Review(value: unknown, fallback?: {
        userLanguage?: string;
        moduleName?: string;
        productLanguages?: string;
        mainActors?: string;
        mainGoal?: string;
        boundaries?: string;
        sourcePrompt?: string;
        /**
         * Under `/fast` the clarification answer is the planner's own proposal, never a user citation.
         * When true, language provenance comes only from `sourcePrompt` (and `userLanguage`).
         */
        answerIsProposal?: boolean;
    }): Ns4E1Review;
    export function policyFor(mode: Ns4SolutionStrategy): Ns4DatabaseChangePolicy;
    export function validateNs4E1Review(review: Ns4E1Review): Ns4E1ReviewGate;
    export function buildNs4ModuleArtifactFromReview(review: Ns4E1Review, sourcePrompt: string, approvedBy: Ns4ApprovedBy, presentation: Ns4Presentation, now?: string): Ns4ModuleArtifact;
}
declare module "_102035_/l2/agentNewSolution/helpers/ns4TextPaths" {
    import { TEXT_PATHS_CLASSIC_OPERATION, TEXT_PATHS_CLASSIC_SITE_MAP, TEXT_PATHS_CLASSIC_WORKSPACE } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export const TEXT_PATHS_VERSION: "2026-09-09-n14";
    export const TEXT_PATHS_BY_SCHEMA: Record<string, readonly string[]>;
    export function textPathsForArtifact(relativePath: string, artifact: unknown): readonly string[];
    export function schemaVersionOf(value: unknown): string;
    export interface StringHit {
        path: string;
        value: string;
    }
    export function walkStrings(value: unknown, prefix?: string): StringHit[];
    export function pathMatches(path: string, pattern: string): boolean;
    export function isCoveredPath(path: string, patterns: readonly string[]): boolean;
    export function extractI18n(artifact: unknown, patterns: readonly string[]): Record<string, string>;
    export function injectI18n<T>(artifact: T, i18n: Record<string, string>): T;
    export function uncoveredNonAscii(artifact: unknown, patterns: readonly string[]): StringHit[];
    export { TEXT_PATHS_CLASSIC_OPERATION, TEXT_PATHS_CLASSIC_SITE_MAP, TEXT_PATHS_CLASSIC_WORKSPACE };
}
declare module "_102035_/l2/agentNewSolution/types" {
    import type { Ns4ModuleArtifact } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    import type { Ns4JourneyArtifact, Ns4JourneyIndex } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    import type { Ns4AccessMatrixArtifact } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    import type { Ns4OntologyEntityArtifact, Ns4OntologyIndexArtifact } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    import type { Ns4AccessBindingsArtifact } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    import type { Ns4RulesArtifact } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    import type { Ns4CompositionArtifact } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    import type { Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3 } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    import type { Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    import type { Ns4Level1EntityArtifact, Ns4Level1IndexArtifact, Ns4SolutionRegistryArtifact } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export type { Ns4ActorKind, Ns4ActorOrigin, Ns4BusinessActor, } from "_102035_/l2/agentNewSolution/steps/e1/contracts";
    export type { Ns4ApprovedBy, Ns4CompletedStepId, Ns4E1Status, Ns4E2Status, Ns4E3Status, Ns4E4Status, Ns4E4BStatus, Ns4E5Status, Ns4E6Status, Ns4E7Status, Ns4E8Status, Ns4E9Status, Ns4E10Status, Ns4ModuleArtifact, Ns4NextStep, Ns4PipelineState, Ns4Presentation, } from "_102035_/l2/agentNewSolution/helpers/ns4Core";
    export type { Ns4E2Feature, Ns4E2Review, Ns4E2ReviewEvent, Ns4FeaturePriority, Ns4JourneyArtifact, Ns4JourneyBusiness, Ns4JourneyEntryMode, Ns4JourneyIndex, Ns4JourneyProposal, Ns4JourneyStep, Ns4JourneyStepKind, Ns4LegacyJourneyArtifact, Ns4LegacyJourneyBusiness, Ns4LegacyJourneyContext, Ns4PolicyDecision, Ns4PolicyDecisionSelection, } from "_102035_/l2/agentNewSolution/steps/e2/contracts";
    export type { Ns4AccessAuthority, Ns4AccessMatrixArtifactV4, Ns4AccessOperationAuthorityRef, Ns4AccessGrant, Ns4AccessMatrixArtifact, Ns4AccessProfile, Ns4AccessProfileKind, Ns4AccessScopeMode, Ns4DisclosureMode, Ns4E3Review, Ns4E3ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e3/contracts";
    export type { Ns4ConstraintSource, Ns4DerivationAggregate, Ns4DerivationOp, Ns4E4EntityDraft, Ns4E4PlanDraft, Ns4E4RelationshipBinding, Ns4E4RelationshipBindingsDraft, Ns4E4Review, Ns4E4ReviewEvent, Ns4EntityDerivation, Ns4EntityKind, Ns4EntityOwnership, Ns4FieldConstraint, Ns4LifecyclePredicate, Ns4LifecycleReachedBy, Ns4LifecycleState, Ns4OntologyEntity, Ns4OntologyEntityArtifact, Ns4OntologyEntityPlan, Ns4OntologyField, Ns4OntologyIndexArtifact, Ns4OntologyRelationship, Ns4RelationshipEndpointBinding, Ns4RelationshipPersistenceMode, Ns4RelationshipRealization, Ns4RelationshipRealizationKind, Ns4ResolvedOntologyRelationship, Ns4StorageScope, Ns4StorageTarget, } from "_102035_/l2/agentNewSolution/steps/e4/contracts";
    export type { Ns4AccessAnchor, Ns4AccessAnchorHop, Ns4AccessBinding, Ns4AccessBindingsArtifact, Ns4SynthesizedAuthority, } from "_102035_/l2/agentNewSolution/steps/e4b/contracts";
    export type { Ns4E5Review, Ns4E5ReviewEvent, Ns4RuleDefinition, Ns4RulesArtifact, } from "_102035_/l2/agentNewSolution/steps/e5/contracts";
    export type { Ns4AdditionalCapability, Ns4AdditionalCapabilityDecision, Ns4AdditionalCapabilityKind, Ns4CompositionArtifact, Ns4E6Review, Ns4E6ReviewEvent, } from "_102035_/l2/agentNewSolution/steps/e6/contracts";
    export type { Ns4E7PlanDraft, Ns4E7PlanUseCase, Ns4E7SourceHashes, Ns4UseCaseArtifact, Ns4UseCaseArtifactV3, Ns4UseCaseDraft, Ns4UseCaseEntityAccess, Ns4UseCaseError, Ns4UseCaseFieldRef, Ns4UseCaseIndexArtifact, Ns4UseCaseIndexArtifactV3, Ns4UseCaseInput, Ns4UseCaseKind, Ns4UseCaseOutput, Ns4UseCaseTransition, Ns4WorkflowArtifact, Ns4WorkflowArtifactV2, Ns4WorkflowIndexArtifact, Ns4WorkflowIndexArtifactV2, Ns4WorkflowIndexArtifactV3, Ns4WorkflowTransition, } from "_102035_/l2/agentNewSolution/steps/e7/contracts";
    export type { Ns4E8Edge, Ns4E8HubScore, Ns4E8ModuleSignals, Ns4E8Sources, Ns4WorkspaceArtifact, Ns4WorkspaceContext, Ns4WorkspaceIndex, } from "_102035_/l2/agentNewSolution/steps/e8/contracts";
    export type { Ns4E8BffCall, Ns4E8HubCatalogue, Ns4E8HubCatalogueItem, Ns4E8HubComposition, Ns4E8Input, Ns4E8InputSource, Ns4E8MenuEntry, Ns4E8Model, Ns4E8ModelWorkspace, Ns4E8Operation, Ns4E8Organism, Ns4E8Section, Ns4WorkspaceTier, } from "_102035_/l2/agentNewSolution/steps/e8/model";
    export type { Ns4ClassicBffCall, Ns4ClassicL4, Ns4ClassicOperation, Ns4ClassicSiteMap, Ns4ClassicWorkspace, } from "_102035_/l2/agentNewSolution/steps/e9/classic";
    export type { Ns4E10CheckSummary, Ns4E10Delivery, Ns4E10Issue, Ns4E10RepairStep, Ns4E10ValidationReport, Ns4L5BackendOwner, Ns4L5FrontendOwner, Ns4L5HeaderLink, Ns4L5ModuleNavigation, Ns4L5NavigationItem, Ns4L5ProcessArtifact, Ns4L5TodoBackendArtifact, Ns4L5TodoFrontendArtifact, } from "_102035_/l2/agentNewSolution/steps/e10/contracts";
    export type { Ns4Level1AllowedRelationship, Ns4Level1EntityArtifact, Ns4Level1Field, Ns4Level1IndexArtifact, Ns4Level1RelationshipRef, Ns4Level1Subtype, Ns4SolutionRegistryActor, Ns4SolutionRegistryArtifact, Ns4SolutionRegistryGeneralField, Ns4SolutionRegistryModule, Ns4SolutionRegistryRole, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { NS4_LEVEL1_SCHEMA_VERSION, NS4_LEVEL1_SUBTYPE_VALUES, NS4_SOLUTION_REGISTRY_SCHEMA_VERSION, } from "_102035_/l2/agentNewSolution/helpers/organizationTypes";
    export { TEXT_PATHS_BY_SCHEMA, TEXT_PATHS_VERSION, textPathsForArtifact, } from "_102035_/l2/agentNewSolution/helpers/ns4TextPaths";
    export const NS4_PERMANENT_ARTIFACT_TYPE_NAMES: readonly ["Ns4ModuleArtifact", "Ns4JourneyArtifact", "Ns4JourneyIndex", "Ns4AccessMatrixArtifact", "Ns4AccessBindingsArtifact", "Ns4OntologyEntityArtifact", "Ns4OntologyIndexArtifact", "Ns4RulesArtifact", "Ns4CompositionArtifact", "Ns4UseCaseArtifact", "Ns4UseCaseArtifactV3", "Ns4UseCaseIndexArtifact", "Ns4UseCaseIndexArtifactV3", "Ns4WorkflowArtifact", "Ns4WorkflowArtifactV2", "Ns4WorkflowIndexArtifact", "Ns4WorkflowIndexArtifactV2", "Ns4WorkflowIndexArtifactV3", "Ns4L5TodoFrontendArtifact", "Ns4L5TodoBackendArtifact", "Ns4L5ProcessArtifact", "Ns4Level1EntityArtifact", "Ns4Level1IndexArtifact", "Ns4SolutionRegistryArtifact"];
    export type Ns4PermanentArtifactTypeName = typeof NS4_PERMANENT_ARTIFACT_TYPE_NAMES[number];
    export interface Ns4PermanentArtifactByType {
        Ns4ModuleArtifact: Ns4ModuleArtifact;
        Ns4JourneyArtifact: Ns4JourneyArtifact;
        Ns4JourneyIndex: Ns4JourneyIndex;
        Ns4AccessMatrixArtifact: Ns4AccessMatrixArtifact;
        Ns4AccessBindingsArtifact: Ns4AccessBindingsArtifact;
        Ns4OntologyEntityArtifact: Ns4OntologyEntityArtifact;
        Ns4OntologyIndexArtifact: Ns4OntologyIndexArtifact;
        Ns4RulesArtifact: Ns4RulesArtifact;
        Ns4CompositionArtifact: Ns4CompositionArtifact;
        Ns4UseCaseArtifact: Ns4UseCaseArtifact;
        Ns4UseCaseArtifactV3: Ns4UseCaseArtifactV3;
        Ns4UseCaseIndexArtifact: Ns4UseCaseIndexArtifact;
        Ns4UseCaseIndexArtifactV3: Ns4UseCaseIndexArtifactV3;
        Ns4WorkflowArtifact: Ns4WorkflowArtifact;
        Ns4WorkflowArtifactV2: Ns4WorkflowArtifactV2;
        Ns4WorkflowIndexArtifact: Ns4WorkflowIndexArtifact;
        Ns4WorkflowIndexArtifactV2: Ns4WorkflowIndexArtifactV2;
        Ns4WorkflowIndexArtifactV3: Ns4WorkflowIndexArtifactV3;
        Ns4L5TodoFrontendArtifact: Ns4L5TodoFrontendArtifact;
        Ns4L5TodoBackendArtifact: Ns4L5TodoBackendArtifact;
        Ns4L5ProcessArtifact: Ns4L5ProcessArtifact;
        Ns4Level1EntityArtifact: Ns4Level1EntityArtifact;
        Ns4Level1IndexArtifact: Ns4Level1IndexArtifact;
        Ns4SolutionRegistryArtifact: Ns4SolutionRegistryArtifact;
    }
}
declare module "_102047_/l4/organization/registry.defs" {
    export const solutionRegistry: {
        readonly schemaVersion: "ns4-solution-registry-v1";
        readonly level1SchemaVersion: "ns4-level1-v1";
        readonly modules: [{
            readonly moduleName: "controleEstoque";
            readonly actors: [{
                readonly actorId: "estoquista";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Product";
                readonly role: "controleEstoque.Produto";
                readonly namespace: "controleEstoque";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Produto";
                readonly kind: "mdm";
                readonly mdmSubtype: "Product";
            }, {
                readonly entityId: "MovimentacaoEstoque";
                readonly kind: "event";
            }];
            readonly events: [{
                readonly eventId: "estoqueAbaixoDoMinimo";
                readonly on: "MovimentacaoEstoque.create";
            }];
            readonly updatedAt: "2026-09-12T19:32:37.338Z";
        }, {
            readonly moduleName: "agendaClinica";
            readonly actors: [{
                readonly actorId: "recepcionista";
                readonly kind: "internal";
            }, {
                readonly actorId: "profissional";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "agendaClinica.Paciente";
                readonly namespace: "agendaClinica";
            }, {
                readonly mdmSubtype: "Person";
                readonly role: "agendaClinica.Profissional";
                readonly namespace: "agendaClinica";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Paciente";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Profissional";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Consulta";
                readonly kind: "core";
            }];
            readonly events: [{
                readonly eventId: "consultaConfirmada";
                readonly on: "Consulta.confirmarConsulta";
            }, {
                readonly eventId: "consultaComFaltaRegistrada";
                readonly on: "Consulta.registrarFalta";
            }, {
                readonly eventId: "consultaAtendida";
                readonly on: "Consulta.registrarAtendimento";
            }];
            readonly updatedAt: "2026-09-12T19:43:15.338Z";
        }, {
            readonly moduleName: "reembolsoDespesas";
            readonly actors: [{
                readonly actorId: "colaborador";
                readonly kind: "internal";
            }, {
                readonly actorId: "gestorEquipe";
                readonly kind: "internal";
            }, {
                readonly actorId: "financeiro";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "reembolsoDespesas.Colaborador";
                readonly namespace: "reembolsoDespesas";
            }, {
                readonly mdmSubtype: "Person";
                readonly role: "reembolsoDespesas.GestorEquipe";
                readonly namespace: "reembolsoDespesas";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Despesa";
                readonly kind: "core";
            }, {
                readonly entityId: "Colaborador";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "GestorEquipe";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }];
            readonly events: [{
                readonly eventId: "despesaEnviadaParaAprovacao";
                readonly on: "Despesa.submitForApproval";
            }, {
                readonly eventId: "despesaReenviadaParaAprovacao";
                readonly on: "Despesa.resubmitForApproval";
            }, {
                readonly eventId: "decisaoDeAprovacaoRegistrada";
                readonly on: "Despesa.recordApprovalDecision";
            }, {
                readonly eventId: "pagamentoDeDespesaRegistrado";
                readonly on: "Despesa.registerPayment";
            }];
            readonly updatedAt: "2026-09-12T19:47:57.034Z";
        }, {
            readonly moduleName: "hiringPipeline";
            readonly actors: [{
                readonly actorId: "recruiter";
                readonly kind: "internal";
            }, {
                readonly actorId: "hiringManager";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "hiringPipeline.Candidate";
                readonly namespace: "hiringPipeline";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "JobPosition";
                readonly kind: "core";
            }, {
                readonly entityId: "Candidate";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Application";
                readonly kind: "core";
            }];
            readonly events: [{
                readonly eventId: "advanceToInterview";
                readonly on: "Application.advanceToInterview";
            }, {
                readonly eventId: "issueOffer";
                readonly on: "Application.issueOffer";
            }, {
                readonly eventId: "markHired";
                readonly on: "Application.markHired";
            }, {
                readonly eventId: "rejectApplication";
                readonly on: "Application.rejectApplication";
            }];
            readonly updatedAt: "2026-09-12T19:59:56.097Z";
        }, {
            readonly moduleName: "manutencaoFrota";
            readonly actors: [{
                readonly actorId: "motorista";
                readonly kind: "internal";
            }, {
                readonly actorId: "gestorFrota";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "manutencaoFrota.Motorista";
                readonly namespace: "manutencaoFrota";
            }, {
                readonly mdmSubtype: "Company";
                readonly role: "manutencaoFrota.Oficina";
                readonly namespace: "manutencaoFrota";
            }, {
                readonly mdmSubtype: "AssetVehicle";
                readonly role: "manutencaoFrota.Veiculo";
                readonly namespace: "manutencaoFrota";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Abastecimento";
                readonly kind: "event";
            }, {
                readonly entityId: "Motorista";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Oficina";
                readonly kind: "mdm";
                readonly mdmSubtype: "Company";
            }, {
                readonly entityId: "Veiculo";
                readonly kind: "mdm";
                readonly mdmSubtype: "AssetVehicle";
            }, {
                readonly entityId: "PlanoManutencao";
                readonly kind: "core";
            }, {
                readonly entityId: "OrdemManutencao";
                readonly kind: "core";
            }];
            readonly events: [{
                readonly eventId: "preventivaVencida";
                readonly on: "Abastecimento.create";
            }];
            readonly updatedAt: "2026-09-12T20:05:09.582Z";
        }, {
            readonly moduleName: "mensalidadesAcademia";
            readonly actors: [{
                readonly actorId: "recepcao";
                readonly kind: "internal";
            }, {
                readonly actorId: "gerencia";
                readonly kind: "internal";
            }, {
                readonly actorId: "aluno";
                readonly kind: "external";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "mensalidadesAcademia.Aluno";
                readonly namespace: "mensalidadesAcademia";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Plano";
                readonly kind: "core";
            }, {
                readonly entityId: "Aluno";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Matricula";
                readonly kind: "core";
            }, {
                readonly entityId: "Mensalidade";
                readonly kind: "event";
            }, {
                readonly entityId: "Pagamento";
                readonly kind: "event";
            }];
            readonly events: [{
                readonly eventId: "matriculaCancelada";
                readonly on: "Matricula.cancelarMatricula";
            }];
            readonly updatedAt: "2026-09-12T20:09:09.008Z";
        }, {
            readonly moduleName: "ordenServicio";
            readonly actors: [{
                readonly actorId: "recepcionista";
                readonly kind: "internal";
            }, {
                readonly actorId: "tecnico";
                readonly kind: "internal";
            }, {
                readonly actorId: "cliente";
                readonly kind: "external";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "ordenServicio.Cliente";
                readonly namespace: "ordenServicio";
            }, {
                readonly mdmSubtype: "AssetEquipment";
                readonly role: "ordenServicio.Aparato";
                readonly namespace: "ordenServicio";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Cliente";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Aparato";
                readonly kind: "mdm";
                readonly mdmSubtype: "AssetEquipment";
            }, {
                readonly entityId: "OrdenServicio";
                readonly kind: "core";
            }, {
                readonly entityId: "BudgetPart";
                readonly kind: "supporting";
            }];
            readonly events: [{
                readonly eventId: "enviarPresupuesto";
                readonly on: "OrdenServicio.enviarPresupuesto";
            }, {
                readonly eventId: "aprobarPresupuesto";
                readonly on: "OrdenServicio.aprobarPresupuesto";
            }, {
                readonly eventId: "rechazarPresupuesto";
                readonly on: "OrdenServicio.rechazarPresupuesto";
            }, {
                readonly eventId: "marcarLista";
                readonly on: "OrdenServicio.marcarLista";
            }, {
                readonly eventId: "entregarYfinalizar";
                readonly on: "OrdenServicio.entregarYfinalizar";
            }];
            readonly updatedAt: "2026-09-12T21:31:27.732Z";
        }, {
            readonly moduleName: "locacaoEquipamentos";
            readonly actors: [{
                readonly actorId: "atendente";
                readonly kind: "internal";
            }, {
                readonly actorId: "gerente";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "locacaoEquipamentos.Cliente";
                readonly namespace: "locacaoEquipamentos";
            }, {
                readonly mdmSubtype: "AssetEquipment";
                readonly role: "locacaoEquipamentos.Equipamento";
                readonly namespace: "locacaoEquipamentos";
            }, {
                readonly mdmSubtype: "Person";
                readonly role: "locacaoEquipamentos.Atendente";
                readonly namespace: "locacaoEquipamentos";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Cliente";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Equipamento";
                readonly kind: "mdm";
                readonly mdmSubtype: "AssetEquipment";
            }, {
                readonly entityId: "Atendente";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "ContratoLocacao";
                readonly kind: "core";
            }, {
                readonly entityId: "RentalItem";
                readonly kind: "supporting";
            }];
            readonly events: [{
                readonly eventId: "registrarDevolucao";
                readonly on: "ContratoLocacao.registrarDevolucao";
            }];
            readonly updatedAt: "2026-09-12T21:34:32.288Z";
        }, {
            readonly moduleName: "inscricaoEvento";
            readonly actors: [{
                readonly actorId: "organizador";
                readonly kind: "internal";
            }, {
                readonly actorId: "publico";
                readonly kind: "external";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "inscricaoEvento.Participante";
                readonly namespace: "inscricaoEvento";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Evento";
                readonly kind: "core";
            }, {
                readonly entityId: "Inscricao";
                readonly kind: "core";
            }, {
                readonly entityId: "Participante";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }];
            readonly events: [{
                readonly eventId: "publicarEvento";
                readonly on: "Evento.publicarEvento";
            }, {
                readonly eventId: "cancelarInscricao";
                readonly on: "Inscricao.cancelarInscricao";
            }, {
                readonly eventId: "promoverListaEspera";
                readonly on: "Inscricao.promoverListaEspera";
            }];
            readonly updatedAt: "2026-09-12T21:37:59.069Z";
        }, {
            readonly moduleName: "compras";
            readonly actors: [{
                readonly actorId: "comprador";
                readonly kind: "internal";
            }, {
                readonly actorId: "gerenteCompras";
                readonly kind: "internal";
            }, {
                readonly actorId: "almoxarife";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "Person";
                readonly role: "compras.Comprador";
                readonly namespace: "compras";
            }, {
                readonly mdmSubtype: "Company";
                readonly role: "compras.Fornecedor";
                readonly namespace: "compras";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Comprador";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Fornecedor";
                readonly kind: "mdm";
                readonly mdmSubtype: "Company";
            }, {
                readonly entityId: "Produto";
                readonly kind: "supporting";
            }, {
                readonly entityId: "EstoqueProduto";
                readonly kind: "supporting";
            }, {
                readonly entityId: "FornecimentoProduto";
                readonly kind: "supporting";
            }, {
                readonly entityId: "PedidoCompra";
                readonly kind: "core";
            }, {
                readonly entityId: "ItemPedidoCompra";
                readonly kind: "supporting";
            }, {
                readonly entityId: "RecebimentoCompra";
                readonly kind: "event";
            }, {
                readonly entityId: "ItemRecebimentoCompra";
                readonly kind: "supporting";
            }];
            readonly events: [{
                readonly eventId: "registrarRecebimentoParcial";
                readonly on: "PedidoCompra.registrarRecebimentoParcial";
            }, {
                readonly eventId: "registrarRecebimentoTotal";
                readonly on: "PedidoCompra.registrarRecebimentoTotal";
            }];
            readonly updatedAt: "2026-09-12T21:43:47.888Z";
        }, {
            readonly moduleName: "comandaRestaurante";
            readonly actors: [{
                readonly actorId: "garcom";
                readonly kind: "internal";
            }, {
                readonly actorId: "caixa";
                readonly kind: "internal";
            }];
            readonly roles: [{
                readonly mdmSubtype: "AssetEquipment";
                readonly role: "comandaRestaurante.Mesa";
                readonly namespace: "comandaRestaurante";
            }, {
                readonly mdmSubtype: "Product";
                readonly role: "comandaRestaurante.ItemCardapio";
                readonly namespace: "comandaRestaurante";
            }, {
                readonly mdmSubtype: "Person";
                readonly role: "comandaRestaurante.Garcom";
                readonly namespace: "comandaRestaurante";
            }];
            readonly generalFields: [];
            readonly entities: [{
                readonly entityId: "Mesa";
                readonly kind: "mdm";
                readonly mdmSubtype: "AssetEquipment";
            }, {
                readonly entityId: "ItemCardapio";
                readonly kind: "mdm";
                readonly mdmSubtype: "Product";
            }, {
                readonly entityId: "Garcom";
                readonly kind: "mdm";
                readonly mdmSubtype: "Person";
            }, {
                readonly entityId: "Comanda";
                readonly kind: "core";
            }, {
                readonly entityId: "ItemComanda";
                readonly kind: "supporting";
            }];
            readonly events: [{
                readonly eventId: "comandaFechada";
                readonly on: "Comanda.fecharComanda";
            }];
            readonly updatedAt: "2026-09-12T21:48:01.323Z";
        }];
    };
    export type SolutionRegistryType = typeof solutionRegistry;
    export default solutionRegistry;
}
declare module "_102047_/l4/reembolsoDespesas/access.defs" {
    export const reembolsoDespesasAccess: {
        readonly schemaVersion: "2026-09-12-ns5-access-v3";
        readonly moduleName: "reembolsoDespesas";
        readonly actors: [{
            readonly actorId: "colaborador";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Colaborador";
            readonly description: "Colaborador que registra, envia e acompanha suas próprias despesas para reembolso.";
        }, {
            readonly actorId: "gestorEquipe";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Gestor da equipe";
            readonly description: "Gestor que avalia as despesas dos colaboradores de sua equipe e as aprova ou rejeita.";
        }, {
            readonly actorId: "financeiro";
            readonly kind: "internal";
            readonly origin: "named";
            readonly title: "Financeiro";
            readonly description: "Profissional do financeiro que consulta despesas aprovadas e registra seus pagamentos.";
        }];
        readonly grants: [{
            readonly grantId: "colaboradorGerenciaPerfil";
            readonly actorRef: "colaborador";
            readonly title: "Gerenciar meu cadastro de colaborador";
            readonly description: "Permite ao colaborador criar ou vincular e manter seu próprio papel de colaborador no módulo de reembolsos.";
            readonly entityRefs: ["Colaborador"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente o papel de colaborador associado à pessoa autenticada.";
                readonly anchorEntity: "Colaborador";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso ao registro completo do próprio papel de colaborador.";
            };
        }, {
            readonly grantId: "colaboradorGerenciaPropriasDespesas";
            readonly actorRef: "colaborador";
            readonly title: "Registrar e acompanhar minhas despesas";
            readonly description: "Permite ao colaborador registrar, enviar, corrigir uma vez quando rejeitada e acompanhar exclusivamente suas próprias solicitações de reembolso.";
            readonly entityRefs: ["Despesa"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente despesas vinculadas ao colaborador correspondente à pessoa autenticada.";
                readonly anchorEntity: "Colaborador";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso ao registro completo das próprias despesas, incluindo decisão, motivo de rejeição e data de pagamento.";
            };
        }, {
            readonly grantId: "gestorGerenciaPerfil";
            readonly actorRef: "gestorEquipe";
            readonly title: "Gerenciar meu cadastro de gestor";
            readonly description: "Permite ao gestor criar ou vincular e manter seu próprio papel de gestor de equipe no módulo de reembolsos.";
            readonly entityRefs: ["GestorEquipe"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente o papel de gestor associado à pessoa autenticada.";
                readonly anchorEntity: "GestorEquipe";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso ao registro completo do próprio papel de gestor de equipe.";
            };
        }, {
            readonly grantId: "gestorAvaliaDespesasDaEquipe";
            readonly actorRef: "gestorEquipe";
            readonly title: "Avaliar despesas da equipe";
            readonly description: "Permite ao gestor consultar e registrar a decisão sobre despesas dos colaboradores que se reportam a ele.";
            readonly entityRefs: ["Despesa"];
            readonly dataScope: {
                readonly mode: "related";
                readonly description: "Somente despesas de colaboradores que possuem relacionamento de reporte com o gestor autenticado.";
                readonly anchorEntity: "GestorEquipe";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso aos dados completos necessários para avaliar a despesa, consultar o comprovante e registrar aprovação ou rejeição.";
            };
        }, {
            readonly grantId: "financeiroRegistraPagamentosAprovados";
            readonly actorRef: "financeiro";
            readonly title: "Consultar e pagar despesas aprovadas";
            readonly description: "Permite ao financeiro consultar despesas aprovadas e registrar a data de pagamento do reembolso.";
            readonly entityRefs: ["Despesa"];
            readonly dataScope: {
                readonly mode: "own";
                readonly description: "Somente despesas vinculadas ao colaborador correspondente à pessoa autenticada.";
                readonly anchorEntity: "Colaborador";
            };
            readonly disclosure: {
                readonly mode: "fullRecord";
                readonly description: "Acesso aos dados completos da despesa aprovada, incluindo comprovante e data de pagamento.";
            };
        }];
    };
    export type ReembolsoDespesasAccessType = typeof reembolsoDespesasAccess;
    export default reembolsoDespesasAccess;
}
declare module "_102047_/l4/reembolsoDespesas/integration.defs" {
    export const reembolsoDespesasIntegration: {
        readonly schemaVersion: "2026-09-12-ns5-integration-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly inbound: [];
        readonly outbound: [{
            readonly id: "despesaEnviadaParaAprovacao";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "despesaEnviadaParaAprovacao";
            readonly on: "Despesa.submitForApproval";
            readonly description: "Publica que uma despesa foi enviada para aprovação.";
            readonly entityRefs: ["Despesa"];
        }, {
            readonly id: "despesaReenviadaParaAprovacao";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "despesaReenviadaParaAprovacao";
            readonly on: "Despesa.resubmitForApproval";
            readonly description: "Publica que uma despesa corrigida foi reenviada para aprovação.";
            readonly entityRefs: ["Despesa"];
        }, {
            readonly id: "decisaoDeAprovacaoRegistrada";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "decisaoDeAprovacaoRegistrada";
            readonly on: "Despesa.recordApprovalDecision";
            readonly description: "Publica que a decisão de aprovação ou rejeição da despesa foi registrada.";
            readonly entityRefs: ["Despesa"];
        }, {
            readonly id: "pagamentoDeDespesaRegistrado";
            readonly kind: "event";
            readonly to: "any";
            readonly event: "pagamentoDeDespesaRegistrado";
            readonly on: "Despesa.registerPayment";
            readonly description: "Publica que o pagamento de uma despesa aprovada foi registrado.";
            readonly entityRefs: ["Despesa"];
        }];
        readonly plugins: [];
    };
    export type ReembolsoDespesasIntegrationType = typeof reembolsoDespesasIntegration;
    export default reembolsoDespesasIntegration;
}
declare module "_102047_/l4/reembolsoDespesas/module.defs" {
    export const reembolsoDespesasModule: {
        readonly schemaVersion: "2026-09-10-ns5-module-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly title: "Reembolso de despesas";
        readonly userLanguage: "pt-BR";
        readonly productLanguages: ["pt-BR"];
        readonly defaultLanguage: "pt-BR";
        readonly sourcePrompt: "reembolsoDespesas em português. colaboradores registram despesas (data, categoria, valor, descrição, comprovante) e enviam para aprovação. o gestor da equipe aprova ou rejeita com um motivo; despesa rejeitada pode ser corrigida e reenviada uma vez. o financeiro vê as aprovadas e registra o pagamento com a data. cada colaborador vê apenas as próprias despesas; o gestor vê as da sua equipe; o financeiro vê todas as aprovadas. três perfis.";
    };
    export type ReembolsoDespesasModuleType = typeof reembolsoDespesasModule;
    export default reembolsoDespesasModule;
}
declare module "_102047_/l4/reembolsoDespesas/rules.defs" {
    export const reembolsoDespesasRules: {
        readonly schemaVersion: "2026-09-10-ns5-rules-v1";
        readonly moduleName: "reembolsoDespesas";
        readonly rules: [{
            readonly ruleId: "resubmissionOnlyWhenRejected";
            readonly description: "Uma despesa só pode ser reenviada para aprovação quando tiver sido rejeitada.";
        }, {
            readonly ruleId: "onlyOneResubmission";
            readonly description: "Uma despesa rejeitada pode ser corrigida e reenviada para aprovação apenas uma vez.";
        }, {
            readonly ruleId: "rejectionRequiresReason";
            readonly description: "A rejeição de uma despesa exige o registro de um motivo.";
        }, {
            readonly ruleId: "paymentOnlyForApprovedExpense";
            readonly description: "O pagamento só pode ser registrado para uma despesa aprovada.";
        }];
    };
    export type ReembolsoDespesasRulesType = typeof reembolsoDespesasRules;
    export default reembolsoDespesasRules;
}
declare module "_102047_/l4/reembolsoDespesas/workflows.defs" {
    export const reembolsoDespesasWorkflows: {
        readonly schemaVersion: "2026-09-12-ns5-workflows-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly processes: [{
            readonly processId: "fluxoReembolsoDespesa";
            readonly title: "Fluxo de reembolso de despesa";
            readonly description: "Orquestra o envio, a avaliação, a eventual correção e o pagamento de uma despesa de colaborador.";
            readonly trigger: {
                readonly kind: "manual";
                readonly actorRef: "colaborador";
            };
            readonly tasks: [{
                readonly taskId: "registrarEEnviar";
                readonly kind: "human";
                readonly actorRef: "colaborador";
                readonly journeyRef: "registrarEenviarDespesa";
                readonly next: ["avaliarDespesa"];
                readonly description: "O colaborador registra a despesa e a encaminha ao gestor da equipe para aprovação.";
            }, {
                readonly taskId: "avaliarDespesa";
                readonly kind: "human";
                readonly actorRef: "gestorEquipe";
                readonly journeyRef: "avaliarDespesaDaEquipe";
                readonly next: ["registrarPagamento", "corrigirEReenviar"];
                readonly description: "O gestor avalia a despesa e a encaminha para pagamento quando aprovada ou a devolve ao colaborador quando rejeitada.";
            }, {
                readonly taskId: "registrarPagamento";
                readonly kind: "human";
                readonly actorRef: "financeiro";
                readonly journeyRef: "registrarPagamentoDespesa";
                readonly next: [];
                readonly description: "O financeiro registra a data de pagamento da despesa aprovada.";
            }, {
                readonly taskId: "corrigirEReenviar";
                readonly kind: "human";
                readonly actorRef: "colaborador";
                readonly journeyRef: "corrigirEreenviarDespesa";
                readonly next: ["aguardarNovaAvaliacao"];
                readonly description: "O colaborador corrige a despesa rejeitada e a reenvia uma única vez para nova avaliação.";
            }, {
                readonly taskId: "aguardarNovaAvaliacao";
                readonly kind: "wait";
                readonly next: ["avaliarDespesa"];
                readonly description: "Aguarda o reenvio da despesa corrigida para que o gestor realize a nova avaliação.";
            }];
        }];
        readonly journeyDecisions: [{
            readonly journeyId: "registrarEenviarDespesa";
            readonly inProcess: true;
            readonly processId: "fluxoReembolsoDespesa";
        }, {
            readonly journeyId: "acompanharMinhasDespesas";
            readonly inProcess: false;
        }, {
            readonly journeyId: "corrigirEreenviarDespesa";
            readonly inProcess: true;
            readonly processId: "fluxoReembolsoDespesa";
        }, {
            readonly journeyId: "avaliarDespesaDaEquipe";
            readonly inProcess: true;
            readonly processId: "fluxoReembolsoDespesa";
        }, {
            readonly journeyId: "registrarPagamentoDespesa";
            readonly inProcess: true;
            readonly processId: "fluxoReembolsoDespesa";
        }];
    };
    export type ReembolsoDespesasWorkflowsType = typeof reembolsoDespesasWorkflows;
    export default reembolsoDespesasWorkflows;
}
declare module "_102047_/l4/reembolsoDespesas/journeys/acompanharMinhasDespesas.defs" {
    export const acompanharMinhasDespesasJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "acompanharMinhasDespesas";
        readonly business: {
            readonly actorRef: "colaborador";
            readonly title: "Acompanhar minhas despesas";
            readonly goal: "Consultar as próprias despesas e verificar sua situação de aprovação ou pagamento.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarMinhasDespesas";
                readonly kind: "locate";
                readonly entity: "Despesa";
                readonly title: "Localizar minhas despesas";
                readonly description: "Localiza as despesas vinculadas ao próprio colaborador.";
            }, {
                readonly stepId: "consultarSituacaoDespesa";
                readonly kind: "inspect";
                readonly entity: "Despesa";
                readonly title: "Consultar situação da despesa";
                readonly description: "Verifica os dados da despesa, a decisão do gestor, o motivo de rejeição quando existir e a data de pagamento quando registrada.";
            }];
            readonly outcome: {
                readonly statement: "O colaborador acompanha a situação de suas próprias despesas.";
                readonly evidence: ["Lista de despesas do colaborador é apresentada.", "Situação de aprovação, motivo de rejeição e pagamento podem ser consultados."];
            };
        };
        readonly businessHash: "sha256:02c034c15d4142b6a905fc2ebdc527135d86404df5ea00886401ee53051e1c02";
    };
    export type AcompanharMinhasDespesasJourneyType = typeof acompanharMinhasDespesasJourney;
    export default acompanharMinhasDespesasJourney;
}
declare module "_102047_/l4/reembolsoDespesas/journeys/avaliarDespesaDaEquipe.defs" {
    export const avaliarDespesaDaEquipeJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "avaliarDespesaDaEquipe";
        readonly business: {
            readonly actorRef: "gestorEquipe";
            readonly title: "Avaliar despesa da equipe";
            readonly goal: "Avaliar uma despesa de colaborador da equipe e decidir por sua aprovação para pagamento ou rejeição com motivo.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarDespesaPendente";
                readonly kind: "locate";
                readonly entity: "Despesa";
                readonly title: "Localizar despesa pendente";
                readonly description: "Localiza uma despesa pendente de aprovação de colaborador da equipe.";
            }, {
                readonly stepId: "consultarDespesaPendente";
                readonly kind: "inspect";
                readonly entity: "Despesa";
                readonly title: "Consultar despesa";
                readonly description: "Consulta os dados, a descrição e o comprovante da despesa.";
            }, {
                readonly stepId: "decidirAprovacaoOuRejeicao";
                readonly kind: "decide";
                readonly entity: "Despesa";
                readonly title: "Decidir sobre a despesa";
                readonly description: "Escolhe aprovar a despesa para pagamento ou rejeitá-la, informando o motivo da rejeição quando essa for a decisão.";
            }, {
                readonly stepId: "registrarDecisaoDaDespesa";
                readonly kind: "act";
                readonly entity: "Despesa";
                readonly effect: "transition";
                readonly transitionRef: "recordApprovalDecision";
                readonly title: "Registrar decisão";
                readonly description: "Registra a aprovação para pagamento ou a rejeição com seu motivo e encaminha a despesa ao responsável pela próxima tratativa.";
            }, {
                readonly stepId: "encaminharDespesaAposDecisao";
                readonly kind: "handoff";
                readonly entity: "Despesa";
                readonly title: "Encaminhar após decisão";
                readonly description: "A despesa aprovada segue para o financeiro; a rejeitada retorna ao colaborador.";
                readonly handoffTo: "financeiro";
            }];
            readonly outcome: {
                readonly statement: "A decisão do gestor sobre a despesa da equipe fica registrada, com aprovação para pagamento ou rejeição motivada.";
                readonly evidence: ["Decisão de aprovação ou rejeição fica registrada na despesa.", "Motivo da rejeição pode ser consultado quando a despesa for rejeitada.", "Despesa aprovada fica disponível para pagamento e despesa rejeitada fica disponível ao colaborador."];
            };
        };
        readonly businessHash: "sha256:edd9fbf41940eb8b331606377d32248e65b72ce698a6edf05a5319d23ff57ec3";
    };
    export type AvaliarDespesaDaEquipeJourneyType = typeof avaliarDespesaDaEquipeJourney;
    export default avaliarDespesaDaEquipeJourney;
}
declare module "_102047_/l4/reembolsoDespesas/journeys/corrigirEreenviarDespesa.defs" {
    export const corrigirEreenviarDespesaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "corrigirEreenviarDespesa";
        readonly business: {
            readonly actorRef: "colaborador";
            readonly title: "Corrigir e reenviar despesa rejeitada";
            readonly goal: "Corrigir uma despesa rejeitada e reenviá-la uma única vez para nova aprovação.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarDespesaRejeitada";
                readonly kind: "locate";
                readonly entity: "Despesa";
                readonly title: "Localizar despesa rejeitada";
                readonly description: "Localiza uma despesa própria rejeitada que ainda pode ser reenviada.";
            }, {
                readonly stepId: "consultarMotivoRejeicao";
                readonly kind: "inspect";
                readonly entity: "Despesa";
                readonly title: "Consultar motivo da rejeição";
                readonly description: "Consulta o motivo informado pelo gestor para a rejeição.";
            }, {
                readonly stepId: "corrigirDespesa";
                readonly kind: "act";
                readonly entity: "Despesa";
                readonly effect: "update";
                readonly title: "Corrigir despesa";
                readonly description: "Corrige os dados ou o comprovante da despesa conforme necessário.";
            }, {
                readonly stepId: "reenviarDespesa";
                readonly kind: "act";
                readonly entity: "Despesa";
                readonly effect: "transition";
                readonly transitionRef: "resubmitForApproval";
                readonly title: "Reenviar para aprovação";
                readonly description: "Reenvia a despesa corrigida para nova avaliação do gestor.";
            }, {
                readonly stepId: "encaminharDespesaReenviada";
                readonly kind: "handoff";
                readonly entity: "Despesa";
                readonly title: "Encaminhar despesa reenviada";
                readonly description: "A despesa corrigida segue para nova avaliação do gestor da equipe.";
                readonly handoffTo: "gestorEquipe";
            }];
            readonly outcome: {
                readonly statement: "A despesa rejeitada é corrigida e reenviada para uma única nova avaliação.";
                readonly evidence: ["Alterações da despesa ficam registradas.", "Despesa passa novamente para aprovação.", "Reenvio da despesa é identificado como realizado."];
            };
        };
        readonly businessHash: "sha256:210ae97b6f01738f5e82d4315051823abd445b362499fcd9e2bdd7f89f91467e";
    };
    export type CorrigirEreenviarDespesaJourneyType = typeof corrigirEreenviarDespesaJourney;
    export default corrigirEreenviarDespesaJourney;
}
declare module "_102047_/l4/reembolsoDespesas/journeys/index.defs" {
    export const reembolsoDespesasJourneyIndex: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly moduleName: "reembolsoDespesas";
        readonly journeys: [{
            readonly journeyId: "registrarEenviarDespesa";
            readonly actorRef: "colaborador";
            readonly title: "Registrar e enviar despesa para aprovação";
        }, {
            readonly journeyId: "acompanharMinhasDespesas";
            readonly actorRef: "colaborador";
            readonly title: "Acompanhar minhas despesas";
        }, {
            readonly journeyId: "corrigirEreenviarDespesa";
            readonly actorRef: "colaborador";
            readonly title: "Corrigir e reenviar despesa rejeitada";
        }, {
            readonly journeyId: "avaliarDespesaDaEquipe";
            readonly actorRef: "gestorEquipe";
            readonly title: "Avaliar despesa da equipe";
        }, {
            readonly journeyId: "registrarPagamentoDespesa";
            readonly actorRef: "financeiro";
            readonly title: "Registrar pagamento de despesa aprovada";
        }];
        readonly systemDecisions: [];
    };
    export type ReembolsoDespesasJourneyIndexType = typeof reembolsoDespesasJourneyIndex;
    export default reembolsoDespesasJourneyIndex;
}
declare module "_102047_/l4/reembolsoDespesas/journeys/registrarEenviarDespesa.defs" {
    export const registrarEenviarDespesaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarEenviarDespesa";
        readonly business: {
            readonly actorRef: "colaborador";
            readonly title: "Registrar e enviar despesa para aprovação";
            readonly goal: "Registrar uma despesa própria com seus dados e comprovante e encaminhá-la ao gestor da equipe.";
            readonly entry: {
                readonly mode: "coldStart";
            };
            readonly steps: [{
                readonly stepId: "registrarDespesa";
                readonly kind: "act";
                readonly entity: "Despesa";
                readonly effect: "create";
                readonly title: "Registrar despesa";
                readonly description: "Informa data, categoria, valor, descrição e comprovante da despesa.";
            }, {
                readonly stepId: "enviarParaAprovacao";
                readonly kind: "act";
                readonly entity: "Despesa";
                readonly effect: "transition";
                readonly transitionRef: "submitForApproval";
                readonly title: "Enviar para aprovação";
                readonly description: "Encaminha a despesa registrada para avaliação do gestor da equipe.";
            }, {
                readonly stepId: "encaminharAoGestor";
                readonly kind: "handoff";
                readonly entity: "Despesa";
                readonly title: "Encaminhar ao gestor";
                readonly description: "A despesa enviada passa para a avaliação do gestor da equipe.";
                readonly handoffTo: "gestorEquipe";
            }];
            readonly outcome: {
                readonly statement: "A despesa própria fica registrada e enviada para aprovação do gestor da equipe.";
                readonly evidence: ["Despesa criada com data, categoria, valor, descrição e comprovante.", "Despesa identificada como enviada para aprovação.", "Gestor da equipe recebe a responsabilidade de avaliá-la."];
            };
        };
        readonly businessHash: "sha256:ce14ccc28f1d87c980d7595f2e45d7d6a0674e464c81591c4e11b61a7b90ff5e";
    };
    export type RegistrarEenviarDespesaJourneyType = typeof registrarEenviarDespesaJourney;
    export default registrarEenviarDespesaJourney;
}
declare module "_102047_/l4/reembolsoDespesas/journeys/registrarPagamentoDespesa.defs" {
    export const registrarPagamentoDespesaJourney: {
        readonly schemaVersion: "2026-09-10-ns5-journey-v1";
        readonly journeyId: "registrarPagamentoDespesa";
        readonly business: {
            readonly actorRef: "financeiro";
            readonly title: "Registrar pagamento de despesa aprovada";
            readonly goal: "Consultar despesas aprovadas e registrar a data de pagamento de uma delas.";
            readonly entry: {
                readonly mode: "contextOrLookup";
            };
            readonly steps: [{
                readonly stepId: "localizarDespesasAprovadas";
                readonly kind: "locate";
                readonly entity: "Despesa";
                readonly title: "Localizar despesas aprovadas";
                readonly description: "Localiza as despesas aprovadas disponíveis para pagamento.";
            }, {
                readonly stepId: "consultarDespesaAprovada";
                readonly kind: "inspect";
                readonly entity: "Despesa";
                readonly title: "Consultar despesa aprovada";
                readonly description: "Consulta os dados e o comprovante da despesa aprovada.";
            }, {
                readonly stepId: "registrarPagamento";
                readonly kind: "act";
                readonly entity: "Despesa";
                readonly effect: "transition";
                readonly transitionRef: "registerPayment";
                readonly title: "Registrar pagamento";
                readonly description: "Registra a data em que a despesa aprovada foi paga.";
            }];
            readonly outcome: {
                readonly statement: "O pagamento da despesa aprovada fica registrado com sua data.";
                readonly evidence: ["Despesa consultada consta como aprovada.", "Data de pagamento fica registrada na despesa.", "Despesa é identificada como paga."];
            };
        };
        readonly businessHash: "sha256:96b2a3dc369f55cd902011a621ad1160228c3443d338e2b0f7eb819d5301fc47";
    };
    export type RegistrarPagamentoDespesaJourneyType = typeof registrarPagamentoDespesaJourney;
    export default registrarPagamentoDespesaJourney;
}
declare module "_102047_/l4/reembolsoDespesas/ontology/Colaborador.defs" {
    export const reembolsoDespesasEntityColaborador: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly entityId: "Colaborador";
        readonly title: "Colaborador";
        readonly description: "Pessoa que registra, acompanha e corrige as próprias despesas para reembolso.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "colaboradorId";
            readonly mdmType: "reembolsoDespesas.Colaborador";
        };
        readonly writer: "crud";
    };
    export type ReembolsoDespesasEntityColaboradorType = typeof reembolsoDespesasEntityColaborador;
    export default reembolsoDespesasEntityColaborador;
}
declare module "_102047_/l4/reembolsoDespesas/ontology/Despesa.defs" {
    export const reembolsoDespesasEntityDespesa: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly entityId: "Despesa";
        readonly title: "Despesa";
        readonly description: "Solicitação de reembolso de uma despesa realizada por um colaborador, desde o registro até o pagamento.";
        readonly kind: "core";
        readonly party: "none";
        readonly displayField: "descricao";
        readonly fields: [{
            readonly fieldId: "despesaId";
            readonly title: "Identificador da despesa";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da solicitação de reembolso.";
        }, {
            readonly fieldId: "colaboradorId";
            readonly title: "Colaborador";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao colaborador responsável pela despesa e pelo reembolso.";
        }, {
            readonly fieldId: "gestorEquipeId";
            readonly title: "Gestor da equipe";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao gestor da equipe que avaliou a despesa.";
        }, {
            readonly fieldId: "dataDespesa";
            readonly title: "Data da despesa";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data em que a despesa foi realizada.";
        }, {
            readonly fieldId: "categoria";
            readonly title: "Categoria";
            readonly type: "string";
            readonly required: true;
            readonly description: "Categoria informada para classificar a despesa.";
        }, {
            readonly fieldId: "valor";
            readonly title: "Valor";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor solicitado para reembolso.";
        }, {
            readonly fieldId: "descricao";
            readonly title: "Descrição";
            readonly type: "text";
            readonly required: true;
            readonly description: "Descrição da despesa realizada.";
        }, {
            readonly fieldId: "comprovanteId";
            readonly title: "Comprovante";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador do comprovante anexado à despesa.";
        }, {
            readonly fieldId: "status";
            readonly title: "Situação";
            readonly type: "string";
            readonly required: true;
            readonly enum: [{
                readonly value: "draft";
                readonly title: "Em elaboração";
            }, {
                readonly value: "pendingApproval";
                readonly title: "Pendente de aprovação";
            }, {
                readonly value: "decisionRecorded";
                readonly title: "Decisão registrada";
            }, {
                readonly value: "paid";
                readonly title: "Paga";
            }];
            readonly description: "Etapa atual da solicitação de reembolso.";
        }, {
            readonly fieldId: "decisaoAprovacao";
            readonly title: "Decisão de aprovação";
            readonly type: "string";
            readonly required: false;
            readonly enum: [{
                readonly value: "approved";
                readonly title: "Aprovada";
            }, {
                readonly value: "rejected";
                readonly title: "Rejeitada";
            }];
            readonly description: "Resultado da avaliação realizada pelo gestor da equipe.";
        }, {
            readonly fieldId: "motivoRejeicao";
            readonly title: "Motivo da rejeição";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo informado pelo gestor quando a despesa é rejeitada.";
        }, {
            readonly fieldId: "dataPagamento";
            readonly title: "Data de pagamento";
            readonly type: "date";
            readonly required: false;
            readonly description: "Data em que o financeiro registrou o pagamento do reembolso.";
        }];
        readonly lifecycleStates: [{
            readonly state: "draft";
            readonly reachedBy: "actor";
        }, {
            readonly state: "pendingApproval";
            readonly reachedBy: "actor";
        }, {
            readonly state: "decisionRecorded";
            readonly reachedBy: "actor";
        }, {
            readonly state: "paid";
            readonly reachedBy: "actor";
        }];
        readonly transitions: [{
            readonly transitionId: "submitForApproval";
            readonly from: ["draft"];
            readonly to: "pendingApproval";
            readonly by: ["colaborador"];
            readonly description: "Encaminha a despesa registrada para avaliação do gestor da equipe.";
        }, {
            readonly transitionId: "resubmitForApproval";
            readonly from: ["decisionRecorded"];
            readonly to: "pendingApproval";
            readonly by: ["colaborador"];
            readonly description: "Reencaminha para aprovação uma despesa rejeitada e corrigida.";
            readonly ruleRefs: ["resubmissionOnlyWhenRejected", "onlyOneResubmission"];
        }, {
            readonly transitionId: "recordApprovalDecision";
            readonly from: ["pendingApproval"];
            readonly to: "decisionRecorded";
            readonly by: ["gestorEquipe"];
            readonly description: "Registra a aprovação ou a rejeição da despesa, incluindo o motivo quando rejeitada.";
            readonly ruleRefs: ["rejectionRequiresReason"];
        }, {
            readonly transitionId: "registerPayment";
            readonly from: ["decisionRecorded"];
            readonly to: "paid";
            readonly by: ["financeiro"];
            readonly description: "Registra a data de pagamento de uma despesa aprovada.";
            readonly ruleRefs: ["paymentOnlyForApprovedExpense"];
        }];
        readonly storage: {
            readonly target: "moduleDatabase";
            readonly scope: "module";
            readonly idField: "despesaId";
        };
    };
    export type ReembolsoDespesasEntityDespesaType = typeof reembolsoDespesasEntityDespesa;
    export default reembolsoDespesasEntityDespesa;
}
declare module "_102047_/l4/reembolsoDespesas/ontology/GestorEquipe.defs" {
    export const reembolsoDespesasEntityGestorEquipe: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly entityId: "GestorEquipe";
        readonly title: "Gestor da equipe";
        readonly description: "Pessoa responsável por avaliar as despesas dos colaboradores de sua equipe.";
        readonly kind: "mdm";
        readonly party: "person";
        readonly mdmSubtype: "Person";
        readonly displayField: "name";
        readonly fields: [];
        readonly lifecycleStates: [];
        readonly transitions: [];
        readonly storage: {
            readonly target: "mdm";
            readonly scope: "organization";
            readonly idField: "gestorEquipeId";
            readonly mdmType: "reembolsoDespesas.GestorEquipe";
        };
        readonly writer: "crud";
    };
    export type ReembolsoDespesasEntityGestorEquipeType = typeof reembolsoDespesasEntityGestorEquipe;
    export default reembolsoDespesasEntityGestorEquipe;
}
declare module "_102047_/l4/reembolsoDespesas/ontology/index.defs" {
    export const reembolsoDespesasOntologyIndex: {
        readonly schemaVersion: "2026-09-11-ns5-ontology-v2";
        readonly moduleName: "reembolsoDespesas";
        readonly businessDomain: "Reembolso de despesas de colaboradores, incluindo envio para aprovação, decisão do gestor e registro de pagamento.";
        readonly entities: ["Despesa", "Colaborador", "GestorEquipe"];
        readonly relationships: [{
            readonly relationshipId: "despesaPertenceAoColaborador";
            readonly fromEntity: "Despesa";
            readonly toEntity: "Colaborador";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada despesa é registrada por um colaborador responsável pelo seu reembolso.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Despesa";
                readonly from: {
                    readonly entityId: "Despesa";
                    readonly fieldIds: ["colaboradorId"];
                };
                readonly to: {
                    readonly entityId: "Colaborador";
                    readonly fieldIds: ["colaboradorId"];
                };
            };
        }, {
            readonly relationshipId: "despesaAvaliadaPeloGestor";
            readonly fromEntity: "Despesa";
            readonly toEntity: "GestorEquipe";
            readonly type: "manyToOne";
            readonly required: false;
            readonly description: "Uma despesa pode ser avaliada pelo gestor responsável pela equipe do colaborador.";
            readonly persistence: {
                readonly mode: "crossStoreReference";
            };
            readonly realization: {
                readonly kind: "fieldReference";
                readonly ownerEntity: "Despesa";
                readonly from: {
                    readonly entityId: "Despesa";
                    readonly fieldIds: ["gestorEquipeId"];
                };
                readonly to: {
                    readonly entityId: "GestorEquipe";
                    readonly fieldIds: ["gestorEquipeId"];
                };
            };
        }, {
            readonly relationshipId: "colaboradorReportaAoGestor";
            readonly fromEntity: "Colaborador";
            readonly toEntity: "GestorEquipe";
            readonly type: "manyToOne";
            readonly required: true;
            readonly description: "Cada colaborador reporta-se a um gestor da equipe para fins de aprovação de despesas.";
            readonly persistence: {
                readonly mode: "mdmRelationship";
            };
            readonly realization: {
                readonly kind: "mdmRelationship";
                readonly ownerEntity: "Colaborador";
                readonly from: {
                    readonly entityId: "Colaborador";
                    readonly fieldIds: ["colaboradorId"];
                };
                readonly to: {
                    readonly entityId: "GestorEquipe";
                    readonly fieldIds: ["gestorEquipeId"];
                };
            };
        }];
    };
    export type ReembolsoDespesasOntologyIndexType = typeof reembolsoDespesasOntologyIndex;
    export default reembolsoDespesasOntologyIndex;
}
